/*
 *     DL_MESO_GUI
 *     author: R. S. Qin, M. A. Seaton
 *     copyright: STFC Daresbury Laboratory and CCP5
 *     2005, 2010
 */
class lbesysdim {
    static int lbnx = 0;
    static int lbny = 0;
    static int lbnz = 0;
    static int lbd = 0;
    public void lbedimension() {}
}
