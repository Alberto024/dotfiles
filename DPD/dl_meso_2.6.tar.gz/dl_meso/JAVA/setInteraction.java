import javax.swing.*;
import java.util.*;
import java.lang.*;
import java.io.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.geom.*;
import java.awt.image.*;
/*
 *     DL_MESO_GUI
 *     author: R. S. Qin, M. A. Seaton
 *     copyright: STFC Daresbury Laboratory and CCP5
 *     2005, 2015
 */
class setInteraction extends JFrame {

    setdpdInteractEvt interactdpd=new setdpdInteractEvt(this);
    Font font=new Font("Dialog", Font.BOLD, 13);

    JLabel specilabel = new JLabel("species i:", JLabel.RIGHT);
    JLabel specjlabel = new JLabel("species j:", JLabel.RIGHT);
    JLabel interactlabel = new JLabel("interaction type:", JLabel.RIGHT);
    JLabel wallspeclabel = new JLabel("wall species:", JLabel.RIGHT);

    JLabel alabel = new JLabel("Aij:", JLabel.RIGHT);
    JLabel blabel = new JLabel("Bij:", JLabel.RIGHT);
    JLabel clabel = new JLabel("Cij:", JLabel.RIGHT);
    JLabel dlabel = new JLabel("Dij:", JLabel.RIGHT);
    JLabel elabel = new JLabel("Eij:", JLabel.RIGHT);
    JLabel distlabel = new JLabel("interaction length:", JLabel.RIGHT);
    JLabel gammalabel = new JLabel("dissipative/collision parameter:", JLabel.RIGHT);
    JLabel walldenslabel = new JLabel("wall density:", JLabel.RIGHT);
    JLabel wallthicklabel = new JLabel("wall thickness:", JLabel.RIGHT);

    JComboBox speci = new JComboBox();
    JComboBox specj = new JComboBox();
    JComboBox inter = new JComboBox();
    JComboBox wallspec = new JComboBox();
    JTextField aa = new JTextField("25.0", 6);
    JTextField bb = new JTextField("0.0", 6);
    JTextField cc = new JTextField("0.0", 6);
    JTextField dd = new JTextField("0.0", 6);
    JTextField ee = new JTextField("0.0", 6);
    JTextField dist = new JTextField("1.0", 6);
    JTextField gamma = new JTextField("4.5", 6);
    JTextField walldens = new JTextField("3.0", 6);
    JTextField wallthick = new JTextField("1.0", 6);

    JButton set = new JButton("SET I");
    JButton save = new JButton("SAVE I");
    JButton close = new JButton("CANCEL I");
    
    public setInteraction(int totsp, String[] name) {
	super("DPD interaction properties");
	setBounds(170, 120, 410, 480);
	JPanel pane=new JPanel(new GridBagLayout());

        specilabel.setFont(font);
        specjlabel.setFont(font);
        interactlabel.setFont(font);
        alabel.setFont(font);
        blabel.setFont(font);
        clabel.setFont(font);
        dlabel.setFont(font);
        elabel.setFont(font);
        distlabel.setFont(font);
        gammalabel.setFont(font);
        addItem(pane, specilabel, 0, 0, 1, 1, GridBagConstraints.EAST);
        addItem(pane, specjlabel, 0, 1, 1, 1, GridBagConstraints.EAST);
        addItem(pane, interactlabel, 0, 2, 1, 1, GridBagConstraints.EAST);
        addItem(pane, alabel, 2, 0, 1, 1, GridBagConstraints.EAST);
        addItem(pane, blabel, 2, 1, 1, 1, GridBagConstraints.EAST);
        addItem(pane, clabel, 2, 2, 1, 1, GridBagConstraints.EAST);
        addItem(pane, dlabel, 2, 3, 1, 1, GridBagConstraints.EAST);
        addItem(pane, elabel, 2, 4, 1, 1, GridBagConstraints.EAST);
        addItem(pane, distlabel, 0, 5, 3, 1, GridBagConstraints.EAST);
        addItem(pane, gammalabel, 0, 6, 3, 1, GridBagConstraints.EAST);
        addItem(pane, aa, 3, 0, 1, 1, GridBagConstraints.WEST);
        addItem(pane, bb, 3, 1, 1, 1, GridBagConstraints.WEST);
        addItem(pane, cc, 3, 2, 1, 1, GridBagConstraints.WEST);
        addItem(pane, dd, 3, 3, 1, 1, GridBagConstraints.WEST);
        addItem(pane, ee, 3, 4, 1, 1, GridBagConstraints.WEST);
        addItem(pane, dist, 3, 5, 1, 1, GridBagConstraints.WEST);
        addItem(pane, gamma, 3, 6, 1, 1, GridBagConstraints.WEST);
        JSeparator sep1 = new JSeparator(JSeparator.HORIZONTAL);
        addItemFillSep(pane, sep1, 7, GridBagConstraints.HORIZONTAL);
        addItem(pane, wallspeclabel, 0, 8, 1, 1, GridBagConstraints.EAST);
        addItem(pane, walldenslabel, 0, 9, 3, 1, GridBagConstraints.EAST);
        addItem(pane, walldens, 3, 9, 1, 1, GridBagConstraints.WEST);
        addItem(pane, wallthicklabel, 0, 10, 3, 1, GridBagConstraints.EAST);
        addItem(pane, wallthick, 3, 10, 1, 1, GridBagConstraints.WEST);

        for(int i=0; i<totsp; i++) {
            speci.addItem(name[i]);
            specj.addItem(name[i]);
            wallspec.addItem(name[i]);
        }

        inter.addItem("DPD");
        inter.addItem("many-body DPD");
        inter.addItem("Lennard-Jones");
        inter.addItem("WCA");

        addItem(pane, speci, 1, 0, 1, 1, GridBagConstraints.WEST);
        addItem(pane, specj, 1, 1, 1, 1, GridBagConstraints.WEST);
        addItem(pane, inter, 1, 2, 1, 1, GridBagConstraints.WEST);
        addItem(pane, wallspec, 1, 8, 1, 1, GridBagConstraints.WEST);
        speci.addItemListener(interactdpd);
        specj.addItemListener(interactdpd);
        inter.addItemListener(interactdpd);
        wallspec.addItemListener(interactdpd);

        alabel.setEnabled(true);
        blabel.setEnabled(false);
        clabel.setEnabled(false);
        dlabel.setEnabled(false);
        elabel.setEnabled(false);
        aa.setEnabled(true);
        aa.setEditable(true);
        bb.setEnabled(false);
        bb.setEditable(false);
        cc.setEnabled(false);
        cc.setEditable(false);
        dd.setEnabled(false);
        dd.setEditable(false);
        ee.setEnabled(false);
        ee.setEditable(false);
        if(setdpdSysEvt.srftype!=2) {
          wallspec.setEnabled(false);
          wallspeclabel.setEnabled(false);
          walldenslabel.setEnabled(false);
          wallthicklabel.setEnabled(false);
          walldens.setEnabled(false);
          wallthick.setEnabled(false);
          walldens.setEditable(false);
          wallthick.setEditable(false);
        }

        Box buttonBox = Box.createHorizontalBox();
        set.setFont(font);
        set.addActionListener(interactdpd);
        buttonBox.add(set);
        save.setFont(font);
        save.addActionListener(interactdpd);
        buttonBox.add(save);
        close.setFont(font);
        close.addActionListener(interactdpd);
        buttonBox.add(close);
        addItem(pane, buttonBox, 0, 14, 3, 1, GridBagConstraints.WEST);

        this.add(pane);
        this.pack();
        setVisible(true);
    }

    private void addItem(JPanel p, JComponent c, int x, int y, int width, int height, int align)
    {
        GridBagConstraints gc = new GridBagConstraints();
        gc.gridx = x;
        gc.gridy = y;
        gc.gridwidth = width;
        gc.gridheight = height;
        gc.weightx = 100.0;
        gc.weighty = 100.0;
        gc.insets = new Insets(5, 5, 5, 5);
        gc.anchor = align;
        gc.fill = GridBagConstraints.NONE;
        p.add(c, gc);
    }

    private void addItemFillSep(JPanel p, JComponent c, int y, int fill)
    {
        GridBagConstraints gc = new GridBagConstraints();
        gc.gridx = 0;
        gc.gridy = y;
        gc.gridwidth = 5;
        gc.gridheight = 1;
        gc.weightx = 1;
        gc.weighty = 1;
        gc.insets = new Insets(5, 5, 5, 5);
        gc.anchor = GridBagConstraints.CENTER;
        gc.fill = fill;
        p.add(c, gc);
    }

    private void addItemFill(JPanel p, JComponent c, int x, int y, int width, int height, int align, int fill)
    {
        GridBagConstraints gc = new GridBagConstraints();
        gc.gridx = x;
        gc.gridy = y;
        gc.gridwidth = width;
        gc.gridheight = height;
        gc.weightx = 100.0;
        gc.weighty = 100.0;
        gc.insets = new Insets(5, 5, 5, 5);
        gc.anchor = align;
        gc.fill = fill;
        p.add(c, gc);
    }

}
