import javax.swing.*;
import java.util.*;
import java.lang.*;
import java.io.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.geom.*;
import java.awt.image.*;
/*
 *     DL_MESO_GUI
 *     author: R. S. Qin, M. A. Seaton
 *     copyright: STFC Daresbury Laboratory and CCP5
 *     2005, 2015
 */
class setElectrostatic extends JFrame {

    setdpdSysEvt eleinidpd=new setdpdSysEvt(this);
    Font font=new Font("Dialog", Font.BOLD, 13);

    JLabel electrotype = new JLabel("ELECTROSTATICS TYPE", JLabel.RIGHT);
    JLabel electrodetail = new JLabel("DETAIL", JLabel.RIGHT);

    JLabel aeleclabel = new JLabel("electrostatics parameter a:", JLabel.RIGHT);
    JLabel beleclabel = new JLabel("electrostatics parameter b:", JLabel.RIGHT);
    JLabel celeclabel = new JLabel("electrostatics parameter c:", JLabel.RIGHT);
    JLabel kmax1label = new JLabel("k-vector (x component):", JLabel.RIGHT);
    JLabel kmax2label = new JLabel("k-vector (y component):", JLabel.RIGHT);
    JLabel kmax3label = new JLabel("k-vector (z component):", JLabel.RIGHT);
    JTextField aelec = new JTextField("0.0", 7);
    JTextField belec = new JTextField("0.0", 7);
    JTextField celec = new JTextField("0.0", 7);
    JTextField kmax1 = new JTextField("0", 7);
    JTextField kmax2 = new JTextField("0", 7);
    JTextField kmax3 = new JTextField("0", 7);

    JButton save = new JButton("SAVE E");
    JButton close = new JButton("CANCEL E");
    
    public setElectrostatic(int et, double ae, double be, double ce, int k1, int k2, int k3) {
	super("DPD electrostatic properties");
	setBounds(170, 120, 350, 400);
	JPanel pane=new JPanel(new GridBagLayout());

        if (et==1) { 
           electrotype.setText("EWALD SUM WITH SLATER SMEARING");
           electrodetail.setText("");
           aeleclabel.setText("system coupling constant:");
           beleclabel.setText("Ewald real-space convergence:");
           celeclabel.setText("charge smearing:");
           aeleclabel.setFont(font);
           beleclabel.setFont(font);
           celeclabel.setFont(font);
           addItem(pane, aeleclabel, 0, 2, 1, 1, GridBagConstraints.WEST);
           addItem(pane, beleclabel, 0, 3, 1, 1, GridBagConstraints.WEST);
           addItem(pane, celeclabel, 0, 4, 1, 1, GridBagConstraints.WEST);
           aelec.setText(Double.toString(ae));
           belec.setText(Double.toString(be));
           celec.setText(Double.toString(ce));
           addItem(pane, aelec, 1, 2, 1, 1, GridBagConstraints.WEST);
           addItem(pane, belec, 1, 3, 1, 1, GridBagConstraints.WEST);
           addItem(pane, celec, 1, 4, 1, 1, GridBagConstraints.WEST);
           kmax1label.setFont(font);
           kmax2label.setFont(font);
           kmax3label.setFont(font);
           addItem(pane, kmax1label, 0, 5, 1, 1, GridBagConstraints.WEST);
           addItem(pane, kmax2label, 0, 6, 1, 1, GridBagConstraints.WEST);
           addItem(pane, kmax3label, 0, 7, 1, 1, GridBagConstraints.WEST);
           kmax1.setText(Integer.toString(k1));
           kmax2.setText(Integer.toString(k2));
           kmax3.setText(Integer.toString(k3));
           addItem(pane, kmax1, 1, 5, 1, 1, GridBagConstraints.WEST);
           addItem(pane, kmax2, 1, 6, 1, 1, GridBagConstraints.WEST);
           addItem(pane, kmax3, 1, 7, 1, 1, GridBagConstraints.WEST);
        }
        else if (et==2) { 
           electrotype.setText("EWALD SUM WITH GAUSSIAN SMEARING");
           electrodetail.setText("");
           aeleclabel.setText("system coupling constant:");
           beleclabel.setText("Ewald real-space convergence:");
           celeclabel.setText("charge smearing lengthscale:");
           aeleclabel.setFont(font);
           beleclabel.setFont(font);
           celeclabel.setFont(font);
           addItem(pane, aeleclabel, 0, 2, 1, 1, GridBagConstraints.WEST);
           addItem(pane, beleclabel, 0, 3, 1, 1, GridBagConstraints.WEST);
           addItem(pane, celeclabel, 0, 4, 1, 1, GridBagConstraints.WEST);
           aelec.setText(Double.toString(ae));
           belec.setText(Double.toString(be));
           celec.setText(Double.toString(ce));
           addItem(pane, aelec, 1, 2, 1, 1, GridBagConstraints.WEST);
           addItem(pane, belec, 1, 3, 1, 1, GridBagConstraints.WEST);
           addItem(pane, celec, 1, 4, 1, 1, GridBagConstraints.WEST);
           kmax1label.setFont(font);
           kmax2label.setFont(font);
           kmax3label.setFont(font);
           addItem(pane, kmax1label, 0, 5, 1, 1, GridBagConstraints.WEST);
           addItem(pane, kmax2label, 0, 6, 1, 1, GridBagConstraints.WEST);
           addItem(pane, kmax3label, 0, 7, 1, 1, GridBagConstraints.WEST);
           kmax1.setText(Integer.toString(k1));
           kmax2.setText(Integer.toString(k2));
           kmax3.setText(Integer.toString(k3));
           addItem(pane, kmax1, 1, 5, 1, 1, GridBagConstraints.WEST);
           addItem(pane, kmax2, 1, 6, 1, 1, GridBagConstraints.WEST);
           addItem(pane, kmax3, 1, 7, 1, 1, GridBagConstraints.WEST);
        }
        else if (et==3) { 
           electrotype.setText("EWALD SUM WITH GAUSSIAN SMEARING");
           electrodetail.setText("(NO REAL SPACE TERMS)");
           aeleclabel.setText("system coupling constant:");
           beleclabel.setText("Ewald real-space convergence:");
           aeleclabel.setFont(font);
           beleclabel.setFont(font);
           addItem(pane, aeleclabel, 0, 2, 1, 1, GridBagConstraints.WEST);
           addItem(pane, beleclabel, 0, 3, 1, 1, GridBagConstraints.WEST);
           aelec.setText(Double.toString(ae));
           belec.setText(Double.toString(be));
           addItem(pane, aelec, 1, 2, 1, 1, GridBagConstraints.WEST);
           addItem(pane, belec, 1, 3, 1, 1, GridBagConstraints.WEST);
           kmax1label.setFont(font);
           kmax2label.setFont(font);
           kmax3label.setFont(font);
           addItem(pane, kmax1label, 0, 5, 1, 1, GridBagConstraints.WEST);
           addItem(pane, kmax2label, 0, 6, 1, 1, GridBagConstraints.WEST);
           addItem(pane, kmax3label, 0, 7, 1, 1, GridBagConstraints.WEST);
           kmax1.setText(Integer.toString(k1));
           kmax2.setText(Integer.toString(k2));
           kmax3.setText(Integer.toString(k3));
           addItem(pane, kmax1, 1, 5, 1, 1, GridBagConstraints.WEST);
           addItem(pane, kmax2, 1, 6, 1, 1, GridBagConstraints.WEST);
           addItem(pane, kmax3, 1, 7, 1, 1, GridBagConstraints.WEST);
        }

        electrotype.setFont(font);
        electrodetail.setFont(font);
        addItem(pane, electrotype, 0, 0, 2, 1, GridBagConstraints.WEST);
        addItem(pane, electrodetail, 0, 1, 2, 1, GridBagConstraints.WEST);

        Box buttonBox = Box.createHorizontalBox();
	save.setFont(font);
	save.addActionListener(eleinidpd);
	buttonBox.add(save);
	close.setFont(font);
	close.addActionListener(eleinidpd);
	buttonBox.add(close);
        addItem(pane, buttonBox, 0, 8, 2, 1, GridBagConstraints.WEST);

	this.add(pane);
        this.pack();
	setVisible(true);
    }

    private void addItem(JPanel p, JComponent c, int x, int y, int width, int height, int align)
    {
        GridBagConstraints gc = new GridBagConstraints();
        gc.gridx = x;
        gc.gridy = y;
        gc.gridwidth = width;
        gc.gridheight = height;
        gc.weightx = 100.0;
        gc.weighty = 100.0;
        gc.insets = new Insets(5, 5, 5, 5);
        gc.anchor = align;
        gc.fill = GridBagConstraints.NONE;
        p.add(c, gc);
    }

}
