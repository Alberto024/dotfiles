import javax.swing.*;
import java.util.*;
import java.lang.*;
import java.io.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.geom.*;
import java.awt.image.*;
/*
 *     DL_MESO_GUI
 *     author: R. S. Qin, M. A. Seaton
 *     copyright: STFC Daresbury Laboratory and CCP5
 *     2005, 2015
 */
class setThermal extends JFrame {

    setlbeSysEvt theinilbe=new setlbeSysEvt(this);
    Font font=new Font("Dialog", Font.BOLD, 13);

    JLabel difulabel = new JLabel("heat relaxation time",JLabel.RIGHT);
    JTextField difut = new JTextField(5);

    JLabel positionlabel = new JLabel("wall", JLabel.RIGHT);
    JLabel tlabel = new JLabel("T (K)", JLabel.RIGHT);
    JLabel dtlabel = new JLabel("dT/dt (K/s)", JLabel.RIGHT);

    JLabel uplabel = new JLabel("top", JLabel.RIGHT);
    JTextField upt = new JTextField(5);
    JTextField updt = new JTextField(5);

    JLabel downlabel = new JLabel("bottom", JLabel.RIGHT);
    JTextField downt = new JTextField(5);
    JTextField downdt = new JTextField(5);

    JLabel leftlabel = new JLabel("left", JLabel.RIGHT);
    JTextField leftt = new JTextField(5);
    JTextField leftdt = new JTextField(5);

    JLabel rightlabel = new JLabel("right", JLabel.RIGHT);
    JTextField rightt = new JTextField(5);
    JTextField rightdt = new JTextField(5);

    JLabel frontlabel = new JLabel("front", JLabel.RIGHT);
    JTextField frontt = new JTextField(5);
    JTextField frontdt = new JTextField(5);

    JLabel backlabel = new JLabel("back", JLabel.RIGHT);
    JTextField backt = new JTextField(5);
    JTextField backdt = new JTextField(5);

    JLabel inilabel = new JLabel("initial T(K):", JLabel.RIGHT);
    JTextField init = new JTextField(5);
    JLabel inidtlabel = new JLabel("initial dT/dt (K/s):", JLabel.RIGHT);
    JTextField inidt = new JTextField(5);

    JLabel boushlabel = new JLabel("boussinesq high T(K):", JLabel.RIGHT);
    JTextField boushigh = new JTextField(5);
    JLabel bousllabel = new JLabel("boussinesq low T(K):", JLabel.RIGHT);
    JTextField bouslow = new JTextField(5);
 
    JButton save = new JButton("SAVE T");
    JButton close = new JButton("CANCEL T");

    public setThermal(int dim, double heatrelax, double boustemph, double boustempl, 
                      double[] temps, double[] heatrates) {
	super("LBE thermal properties");
	setBounds(160, 10, 312, 530);
	JPanel pane=new JPanel(new GridBagLayout());

	inilabel.setFont(font);
        addItem(pane, inilabel, 0, 0, 2, 1, GridBagConstraints.WEST);
        init.setText(Double.toString(temps[0]));
        addItem(pane, init, 2, 0, 1, 1, GridBagConstraints.CENTER);

	inidtlabel.setFont(font);
        addItem(pane, inidtlabel, 0, 1, 2, 1, GridBagConstraints.WEST);
        inidt.setText(Double.toString(heatrates[0]));
        addItem(pane, inidt, 2, 1, 1, 1, GridBagConstraints.CENTER);

	boushlabel.setFont(font);
        addItem(pane, boushlabel, 0, 2, 2, 1, GridBagConstraints.WEST);
        boushigh.setText(Double.toString(boustemph));
        addItem(pane, boushigh, 2, 2, 1, 1, GridBagConstraints.CENTER);

	bousllabel.setFont(font);
        addItem(pane, bousllabel, 0, 3, 2, 1, GridBagConstraints.WEST);
        bouslow.setText(Double.toString(boustempl));
        addItem(pane, bouslow, 2, 3, 1, 1, GridBagConstraints.CENTER);

        difulabel.setFont(font);
        addItem(pane, difulabel, 0, 4, 2, 1, GridBagConstraints.WEST);
        difut.setText(Double.toString(heatrelax));
        addItem(pane, difut, 2, 4, 1, 1, GridBagConstraints.CENTER);

	positionlabel.setFont(font);
        addItem(pane, positionlabel, 0, 5, 1, 1, GridBagConstraints.EAST);      
	tlabel.setFont(font);
        addItem(pane, tlabel, 1, 5, 1, 1, GridBagConstraints.CENTER);      
	dtlabel.setFont(font);
        addItem(pane, dtlabel, 2, 5, 1, 1, GridBagConstraints.CENTER);      

	uplabel.setFont(font);
        addItem(pane, uplabel, 0, 6, 1, 1, GridBagConstraints.EAST);
        upt.setText(Double.toString(temps[1]));
        addItem(pane, upt, 1, 6, 1, 1, GridBagConstraints.CENTER);
        updt.setText(Double.toString(heatrates[1]));
        addItem(pane, updt, 2, 6, 1, 1, GridBagConstraints.CENTER);

	downlabel.setFont(font);
        addItem(pane, downlabel, 0, 7, 1, 1, GridBagConstraints.EAST);
        downt.setText(Double.toString(temps[2]));
        addItem(pane, downt, 1, 7, 1, 1, GridBagConstraints.CENTER);
        downdt.setText(Double.toString(heatrates[2]));
        addItem(pane, downdt, 2, 7, 1, 1, GridBagConstraints.CENTER);

	leftlabel.setFont(font);
        addItem(pane, leftlabel, 0, 8, 1, 1, GridBagConstraints.EAST);
        leftt.setText(Double.toString(temps[3]));
        addItem(pane, leftt, 1, 8, 1, 1, GridBagConstraints.CENTER);
        leftdt.setText(Double.toString(heatrates[3]));
        addItem(pane, leftdt, 2, 8, 1, 1, GridBagConstraints.CENTER);

	rightlabel.setFont(font);
        addItem(pane, rightlabel, 0, 9, 1, 1, GridBagConstraints.EAST);
        rightt.setText(Double.toString(temps[4]));
        addItem(pane, rightt, 1, 9, 1, 1, GridBagConstraints.CENTER);
        rightdt.setText(Double.toString(heatrates[4]));
        addItem(pane, rightdt, 2, 9, 1, 1, GridBagConstraints.CENTER);

	frontlabel.setFont(font);
        addItem(pane, frontlabel, 0, 10, 1, 1, GridBagConstraints.EAST);
        frontt.setText(Double.toString(temps[5]));
        addItem(pane, frontt, 1, 10, 1, 1, GridBagConstraints.CENTER);
        frontdt.setText(Double.toString(heatrates[5]));
        addItem(pane, frontdt, 2, 10, 1, 1, GridBagConstraints.CENTER);

	backlabel.setFont(font);
        addItem(pane, backlabel, 0, 11, 1, 1, GridBagConstraints.EAST);
        backt.setText(Double.toString(temps[6]));
        addItem(pane, backt, 1, 11, 1, 1, GridBagConstraints.CENTER);
        backdt.setText(Double.toString(heatrates[6]));
        addItem(pane, backdt, 2, 11, 1, 1, GridBagConstraints.CENTER);

        if (dim==2) {
          frontlabel.setEnabled(false);
          backlabel.setEnabled(false);
          frontt.setEnabled(false);
          frontt.setEditable(false);
          frontdt.setEnabled(false);
          frontdt.setEditable(false);
          backt.setEnabled(false);
          backt.setEditable(false);
          backdt.setEnabled(false);
          backdt.setEditable(false);
        }

	save.setFont(font);
	save.addActionListener(theinilbe);
        addItem(pane, save, 0, 12, 1, 1, GridBagConstraints.CENTER);

	close.setFont(font);
	close.addActionListener(theinilbe);
        addItem(pane, close, 1, 12, 1, 1, GridBagConstraints.CENTER);

	this.add(pane);
        this.pack();
	setVisible(true);
    }

    private void addItem(JPanel p, JComponent c, int x, int y, int width, int height, int align)
    {
        GridBagConstraints gc = new GridBagConstraints();
        gc.gridx = x;
        gc.gridy = y;
        gc.gridwidth = width;
        gc.gridheight = height;
        gc.weightx = 100.0;
        gc.weighty = 100.0;
        gc.insets = new Insets(5, 5, 5, 5);
        gc.anchor = align;
        gc.fill = GridBagConstraints.NONE;
        p.add(c, gc);
    }

}
