import javax.swing.*;
import java.util.*;
import java.lang.*;
import java.io.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.geom.*;
import java.awt.image.*;
/*
 *     DL_MESO_GUI
 *     author: R. S. Qin, M. A. Seaton
 *     copyright: STFC Daresbury Laboratory and CCP5
 *     2005, 2015
 */
class setSpecies extends JFrame {
    
    setdpdInteractEvt speinidpd=new setdpdInteractEvt(this);

    JLabel namlabel = new JLabel("name:", JLabel.RIGHT);
    JTextField[] specname = new JTextField[10];

    JLabel masslabel = new JLabel("mass:", JLabel.RIGHT);
    JTextField[] specmass = new JTextField[10];

    JLabel chargelabel = new JLabel("charge:", JLabel.RIGHT);
    JTextField[] speccharge = new JTextField[10];

    JLabel poplabel = new JLabel("population (unbonded):", JLabel.RIGHT);
    JTextField[] specpop = new JTextField[10];

    JLabel frozlabel = new JLabel("frozen:", JLabel.RIGHT);
    JCheckBox[] specfroz = new JCheckBox[10]; 

    JLabel srfaalabel = new JLabel("wall repulsion parameter:", JLabel.RIGHT);
    JTextField[] srfzaa = new JTextField[10];

    JButton save = new JButton("SAVE SP");
    JButton close = new JButton("CANCEL SP");
    Font font=new Font("Dialog", Font.BOLD, 13);
    
    public setSpecies(int totsp) {

	super("DPD species properties");
	setBounds(160, 10, 217+93*totsp, 285);
	JPanel pane=new JPanel(new GridBagLayout());

        for(int i=0; i<totsp; i++) {
            addItem(pane, new JLabel("species "+(i+1)), i+1, 0, 1, 1, GridBagConstraints.CENTER);
        }

        namlabel.setFont(font);
        addItem(pane, namlabel, 0, 1, 1, 1, GridBagConstraints.WEST);
        for(int i=0; i<totsp; i++) {
            specname[i]=new JTextField("SPEC"+(i+1), 7);
            addItem(pane, specname[i], i+1, 1, 1, 1, GridBagConstraints.CENTER);
        }

        masslabel.setFont(font);
        addItem(pane, masslabel, 0, 2, 1, 1, GridBagConstraints.WEST);
        for(int i=0; i<totsp; i++) {
            specmass[i]=new JTextField("1.0", 7);
            addItem(pane, specmass[i], i+1, 2, 1, 1, GridBagConstraints.CENTER);
        }

        chargelabel.setFont(font);
        addItem(pane, chargelabel, 0, 3, 1, 1, GridBagConstraints.WEST);
        for(int i=0; i<totsp; i++) {
            speccharge[i]=new JTextField("0.0", 7);
            addItem(pane, speccharge[i], i+1, 3, 1, 1, GridBagConstraints.CENTER);
        }

        poplabel.setFont(font);
        addItem(pane, poplabel, 0, 4, 1, 1, GridBagConstraints.WEST);
        for(int i=0; i<totsp; i++) {
            specpop[i]=new JTextField("0", 7);
            addItem(pane, specpop[i], i+1, 4, 1, 1, GridBagConstraints.CENTER);
        }

        frozlabel.setFont(font);
        addItem(pane, frozlabel, 0, 5, 1, 1, GridBagConstraints.WEST);
        for(int i=0; i<totsp; i++) {
            specfroz[i]=new JCheckBox("", false);
            addItem(pane, specfroz[i], i+1, 5, 1, 1, GridBagConstraints.CENTER);
        }

        srfaalabel.setFont(font);
        addItem(pane, srfaalabel, 0, 6, 1, 1, GridBagConstraints.WEST);
        if(setdpdSysEvt.srftype!=1)
          srfaalabel.setEnabled(false);
        for(int i=0; i<totsp; i++) {
            srfzaa[i]=new JTextField("25.0", 7);
            addItem(pane, srfzaa[i], i+1, 6, 1, 1, GridBagConstraints.CENTER);
            if(setdpdSysEvt.srftype!=1) {
              srfzaa[i].setEnabled(false);
              srfzaa[i].setEditable(false);
            }
        }

        Box buttonBox = Box.createHorizontalBox();
        save.setFont(font);
        save.addActionListener(speinidpd);
        buttonBox.add(save);
        close.setFont(font);
        close.addActionListener(speinidpd);
        buttonBox.add(close);
        addItem(pane, buttonBox, 0, 11, 6, 1, GridBagConstraints.WEST);

        this.add(pane);
        this.pack();
        setVisible(true);
    }

    private void addItem(JPanel p, JComponent c, int x, int y, int width, int height, int align)
    {
        GridBagConstraints gc = new GridBagConstraints();
        gc.gridx = x;
        gc.gridy = y;
        gc.gridwidth = width;
        gc.gridheight = height;
        gc.weightx = 100.0;
        gc.weighty = 100.0;
        gc.insets = new Insets(5, 5, 5, 5);
        gc.anchor = align;
        gc.fill = GridBagConstraints.NONE;
        p.add(c, gc);
    }

}
