import javax.swing.*;
import java.util.*;
import java.lang.*;
import java.io.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.geom.*;
import java.awt.image.*;
/*
 *     DL_MESO_GUI
 *     author: R. S. Qin, W. Smith and M. A. Seaton 2006, 2015
 *     copyright: STFC Daresbury Laboratory and CCP5
 */
class plotdpd extends JPanel {
    plotdpdEvt cdpd = new plotdpdEvt(this); 
    
    Font font=new Font("Dialog", Font.BOLD, 12);
    Color paneltop=new Color(170, 170, 230);
    
    JPanel row1a =new JPanel();
    
    JPanel row2a =new JPanel();
    JPanel row2b =new JPanel();
    JPanel row2c =new JPanel();
    JComboBox command= new JComboBox();
    JCheckBox konsole=new JCheckBox("run in terminal", false);

    JTextField plotalt = new JTextField (20);     

    JButton runbutton = new JButton("Plot data");

    public plotdpd() {
        setSize(620, 530);
        GridLayout gl =new GridLayout(4, 1, 5, 5);
        FlowLayout fl = new FlowLayout(FlowLayout.CENTER);
        BorderLayout bl = new BorderLayout();
        setLayout(gl);
        add(row1a);
        command.addItem("Choose a Plotting Package");
        command.addItem("field view");
        command.addItem("gnuplot");
        command.addItem("vmd");
        command.addItem("paraview");
        command.addItem("other ...");
        command.addItemListener(cdpd);
        row2a.setLayout(fl);
        row2a.add(command);
        row2a.add(plotalt);
        row2b.setLayout(fl);
        row2b.add(konsole);
        runbutton.addActionListener(cdpd);
        row2c.add(runbutton);
        add(row2a);
        add(row2b);
        add(row2c);
    }
}
