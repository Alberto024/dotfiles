import javax.swing.*;
import java.util.*;
import java.lang.*;
import java.io.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.geom.*;
import java.awt.image.*;
/*
 *     DL_MESO_GUI
 *     author: R. S. Qin, M. A. Seaton  
 *     copyright: STFC Daresbury Laboratory and CCP5
 *     2005, 2015
 */
public class dlmesogui extends JFrame {
    dlmesoguiEvt mesoev=new dlmesoguiEvt(this);

    Font buttonfont=new Font("Serif", Font.BOLD, 14);
    Color bgcolor=new Color(220, 200, 190);
    Color focolor=new Color(10, 10, 15);
    
    Font labelfont=new Font("Dialog", Font.BOLD, 22);
    Color labelfo=new Color(190, 110, 65);
    Color paneltop = new Color(200, 200, 210);
    
    JPanel row1 =new JPanel();
    JLabel logo = new JLabel("DL_MESO", JLabel.CENTER);

    JPanel row2 =new JPanel();
    JButton lbe = new JButton("LBE");
    JButton dpd =new JButton("DPD");

    JPanel row3 =new JPanel();
    JButton sph =new JButton("SPH");
    JButton manual =new JButton("Manual");  

    JPanel row4 =new JPanel();
    JButton help =new JButton("Help");  
    JButton exit =new JButton("Exit");      

    JPanel rowtop = new JPanel();
    JPanel rowdown = new JPanel();

    public dlmesogui() {
	super("DL_MESO");
	setBounds(5, 5, 795, 795);
        Container pane=getContentPane();	
	BorderLayout blout = new BorderLayout();
	pane.setLayout(blout);

	GridLayout glt =new GridLayout(1, 4, 5, 5);
	GridLayout gl1 =new GridLayout(1, 1, 5, 5);
	GridLayout gl2 =new GridLayout(1, 2, 5, 5);
	rowtop.setBackground(paneltop);
	rowtop.setOpaque(true);
	rowtop.setSize(795, 80);
	rowtop.setLayout(glt);

	FlowLayout fd = new FlowLayout(FlowLayout.CENTER, 5, 70);
	rowdown.setSize(795, 580);
	rowdown.setLayout(fd);

	row1.setLayout(gl1);
	logo.setFont(labelfont);
	logo.setForeground(labelfo);
	row1.setBackground(paneltop);
	row1.setOpaque(true);
	row1.add(logo);
	rowtop.add(logo);

	row2.setLayout(gl2);	
	row2.setBackground(paneltop);
	row2.setOpaque(true);
	lbe.setFont(buttonfont);
	lbe.setBackground(bgcolor);
	lbe.setForeground(focolor);
	lbe.addActionListener(mesoev);
	row2.add(lbe);
	
	dpd.setFont(buttonfont);
	dpd.setBackground(bgcolor);
	dpd.setForeground(focolor);
	dpd.addActionListener(mesoev);
	row2.add(dpd);
	rowtop.add(row2);

	row3.setLayout(gl2);
	row3.setBackground(paneltop);
	row3.setOpaque(true);		
	sph.setFont(buttonfont);
	sph.setBackground(bgcolor);
	sph.setForeground(focolor);
	sph.addActionListener(mesoev);
	row3.add(sph);
	
	manual.setFont(buttonfont);
	manual.setBackground(bgcolor);
	manual.setForeground(focolor);
	manual.addActionListener(mesoev);
	row3.add(manual);
	rowtop.add(row3);

	row4.setLayout(gl2);	
	row4.setBackground(paneltop);
	row4.setOpaque(true);
	help.setFont(buttonfont);
	help.setBackground(bgcolor);
	help.setForeground(focolor);
	help.addActionListener(mesoev);
	row4.add(help);

	exit.setFont(buttonfont);
	exit.setBackground(bgcolor);
	exit.setForeground(focolor);
	exit.addActionListener(mesoev);
	row4.add(exit);
	rowtop.add(row4);
	pane.add(rowtop, BorderLayout.NORTH);

        dlwelcome dw = new dlwelcome();
	rowdown.add(dw);
	pane.add(rowdown, BorderLayout.CENTER);

	setContentPane(pane);
	setVisible(true);	
    }

   public static void main(String[] arguments) {
	dlmesogui haha = new dlmesogui();
    }
}
