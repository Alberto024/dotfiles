import javax.swing.*;
import java.util.*;
import java.lang.*;
import java.io.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.geom.*;
import java.awt.image.*;
/*
 *     DL_MESO_GUI
 *     author: R. S. Qin, M. A. Seaton
 *     copyright: STFC Daresbury Laboratory and CCP5
 *     2005, 2015
 */
class setFluid extends JFrame {
    
    setlbeSysEvt fluinilbe=new setlbeSysEvt(this);

    JLabel fxlabel = new JLabel("body force x-axis:", JLabel.RIGHT);
    JTextField[] xforce = new JTextField[6];

    JLabel fylabel = new JLabel("body force y-axis:", JLabel.RIGHT);
    JTextField[] yforce = new JTextField[6];

    JLabel fzlabel = new JLabel("body force z-axis:", JLabel.RIGHT);
    JTextField[] zforce = new JTextField[6];

    JLabel bousfxlabel = new JLabel("boussinesq force x-axis:", JLabel.RIGHT);
    JTextField[] bousxforce = new JTextField[6];

    JLabel bousfylabel = new JLabel("boussinesq force y-axis:", JLabel.RIGHT);
    JTextField[] bousyforce = new JTextField[6];

    JLabel bousfzlabel = new JLabel("boussinesq force z-axis:", JLabel.RIGHT);
    JTextField[] bouszforce = new JTextField[6];

    JLabel densitylabel = new JLabel("fluid densities:", 
				     JLabel.RIGHT);
    JLabel inilabel = new JLabel("initial:", JLabel.RIGHT);
    JTextField[] inidensity = new JTextField[6];

    JLabel cstlabel = new JLabel("constant:", JLabel.RIGHT);
    JTextField[] cstdensity = new JTextField[6];

    JLabel toplabel = new JLabel("top:", JLabel.RIGHT);
    JTextField[] topdensity = new JTextField[6];
    
    JLabel dowlabel = new JLabel("bottom:", JLabel.RIGHT);
    JTextField[] dowdensity = new JTextField[6];
    
    JLabel leflabel = new JLabel("left:", JLabel.RIGHT);
    JTextField[] lefdensity = new JTextField[6];

    JLabel riglabel = new JLabel("right:", JLabel.RIGHT);
    JTextField[] rigdensity = new JTextField[6];

    JLabel frolabel = new JLabel("front:", JLabel.RIGHT);
    JTextField[] frodensity = new JTextField[6];
    
    JLabel baclabel = new JLabel("back:", JLabel.RIGHT);
    JTextField[] bacdensity = new JTextField[6];
    
    JLabel viscositylabel = new JLabel("relaxation time:", 
				       JLabel.RIGHT);
    JTextField[] viscosities = new JTextField[6];
    
    JLabel bulkviscositylabel = new JLabel("bulk relaxation time:", 
				       JLabel.RIGHT);
    JTextField[] bulkviscosities = new JTextField[6];

/*    
    JLabel interactionlabel = new JLabel("interaction parameters:", 
					 JLabel.RIGHT);
    
    JTextField[] interactions = new JTextField[36];

    JLabel wallinteractlabel = new JLabel("wall interaction parameters:", JLabel.RIGHT);

    JTextField[] wallinteractions = new JTextField[36];

    JLabel segregationlabel = new JLabel("segregation parameter:", 
					 JLabel.RIGHT);
    
    JTextField segregation =new JTextField(5);
*/
   
    JButton save = new JButton("SAVE F");
    JButton close = new JButton("CANCEL F");
    Font font=new Font("Dialog", Font.BOLD, 13);
    
    public setFluid(int totf, int dim, int inter, double[] bdf, double[] bousf, double[] densf, 
                    double[] relaxtime) {

	super("LBE fluid properties");
        
	setBounds(160, 10, 220+81*totf, 692+54*totf);
	JPanel pane=new JPanel(new GridBagLayout());

        for(int i=0; i<totf; i++) {
            addItem(pane, new JLabel("fluid "+i), i+2, 0, 1, 1, GridBagConstraints.CENTER);
        }

	fxlabel.setFont(font);
        addItem(pane, fxlabel, 0, 1, 2, 1, GridBagConstraints.WEST);
	for(int i=0; i<totf; i++) {
	    xforce[i]=new JTextField(5);
            xforce[i].setText(Double.toString(bdf[i*3]));
            addItem(pane, xforce[i], i+2, 1, 1, 1, GridBagConstraints.CENTER);
	}
	
	fylabel.setFont(font);
        addItem(pane, fylabel, 0, 2, 2, 1, GridBagConstraints.WEST);
	for(int i=0; i<totf; i++) {
	    yforce[i]=new JTextField(5);
            yforce[i].setText(Double.toString(bdf[i*3+1]));
            addItem(pane, yforce[i], i+2, 2, 1, 1, GridBagConstraints.CENTER);
	}
	
	fzlabel.setFont(font);
        if (dim==2)
          fzlabel.setEnabled(false);
        addItem(pane, fzlabel, 0, 3, 2, 1, GridBagConstraints.WEST);
	for(int i=0; i<totf; i++) {
	    zforce[i]=new JTextField(5);
            zforce[i].setText(Double.toString(bdf[i*3+2]));
            if (dim==2) {
              zforce[i].setEditable(false);
              zforce[i].setEnabled(false);
            }
            addItem(pane, zforce[i], i+2, 3, 1, 1, GridBagConstraints.CENTER);
	}
	
	bousfxlabel.setFont(font);
        addItem(pane, bousfxlabel, 0, 4, 2, 1, GridBagConstraints.WEST);
	for(int i=0; i<totf; i++) {
	    bousxforce[i]=new JTextField(5);
            bousxforce[i].setText(Double.toString(bousf[i*3]));
            addItem(pane, bousxforce[i], i+2, 4, 1, 1, GridBagConstraints.CENTER);
	}
	
	bousfylabel.setFont(font);
        addItem(pane, bousfylabel, 0, 5, 2, 1, GridBagConstraints.WEST);
	for(int i=0; i<totf; i++) {
	    bousyforce[i]=new JTextField(5);
            bousyforce[i].setText(Double.toString(bousf[i*3+1]));
            addItem(pane, bousyforce[i], i+2, 5, 1, 1, GridBagConstraints.CENTER);
	}
	
	bousfzlabel.setFont(font);
        if (dim==2)
          bousfzlabel.setEnabled(false);
        addItem(pane, bousfzlabel, 0, 6, 2, 1, GridBagConstraints.WEST);
	for(int i=0; i<totf; i++) {
	    bouszforce[i]=new JTextField(5);
            bouszforce[i].setText(Double.toString(bousf[i*3+2]));
            if (dim==2) {
              bouszforce[i].setEditable(false);
              bouszforce[i].setEnabled(false);
            }
            addItem(pane, bouszforce[i], i+2, 6, 1, 1, GridBagConstraints.CENTER);
	}

	densitylabel.setFont(font);
	addItem(pane, densitylabel, 0, 7, 1, 1, GridBagConstraints.WEST);

	inilabel.setFont(font);
	addItem(pane, inilabel, 1, 7, 1, 1, GridBagConstraints.EAST);
	for(int i=0; i<totf; i++) {
  	    inidensity[i]=new JTextField(5);
            inidensity[i].setText(Double.toString(densf[8*i]));
            addItem(pane, inidensity[i], i+2, 7, 1, 1, GridBagConstraints.CENTER);
	}	

	cstlabel.setFont(font);
	addItem(pane, cstlabel, 1, 8, 1, 1, GridBagConstraints.EAST);
	for(int i=0; i<totf; i++) {
	    cstdensity[i]=new JTextField(5);
            cstdensity[i].setText(Double.toString(densf[8*i+1]));
            addItem(pane, cstdensity[i], i+2, 8, 1, 1, GridBagConstraints.CENTER);
	}	

	toplabel.setFont(font);
	addItem(pane, toplabel, 1, 9, 1, 1, GridBagConstraints.EAST);
	for(int i=0; i<totf; i++) {
	    topdensity[i]=new JTextField(5);
            topdensity[i].setText(Double.toString(densf[8*i+2]));
            addItem(pane, topdensity[i], i+2, 9, 1, 1, GridBagConstraints.CENTER);
	}	

	dowlabel.setFont(font);
	addItem(pane, dowlabel, 1, 10, 1, 1, GridBagConstraints.EAST);
	for(int i=0; i<totf; i++) {
	    dowdensity[i]=new JTextField(5);
            dowdensity[i].setText(Double.toString(densf[8*i+3]));
            addItem(pane, dowdensity[i], i+2, 10, 1, 1, GridBagConstraints.CENTER);
	}	

	leflabel.setFont(font);
	addItem(pane, leflabel, 1, 11, 1, 1, GridBagConstraints.EAST);
	for(int i=0; i<totf; i++) {
	    lefdensity[i]=new JTextField(5);
            lefdensity[i].setText(Double.toString(densf[8*i+4]));
            addItem(pane, lefdensity[i], i+2, 11, 1, 1, GridBagConstraints.CENTER);
	}	

	riglabel.setFont(font);
	addItem(pane, riglabel, 1, 12, 1, 1, GridBagConstraints.EAST);
	for(int i=0; i<totf; i++) {
	    rigdensity[i]=new JTextField(5);
            rigdensity[i].setText(Double.toString(densf[8*i+5]));
            addItem(pane, rigdensity[i], i+2, 12, 1, 1, GridBagConstraints.CENTER);
	}	
	
	frolabel.setFont(font);
        if (dim==2)
          frolabel.setEnabled(false);
	addItem(pane, frolabel, 1, 13, 1, 1, GridBagConstraints.EAST);
	for(int i=0; i<totf; i++) {
	    frodensity[i]=new JTextField(5);
            frodensity[i].setText(Double.toString(densf[8*i+6]));
            if (dim==2) {
              frodensity[i].setEditable(false);
              frodensity[i].setEnabled(false);
            }
            addItem(pane, frodensity[i], i+2, 13, 1, 1, GridBagConstraints.CENTER);
	}	

	baclabel.setFont(font);
        if (dim==2)
          baclabel.setEnabled(false);
	addItem(pane, baclabel, 1, 14, 1, 1, GridBagConstraints.EAST);
	for(int i=0; i<totf; i++) {
	    bacdensity[i]=new JTextField(5);
            bacdensity[i].setText(Double.toString(densf[8*i+7]));
            if (dim==2) {
              bacdensity[i].setEditable(false);
              bacdensity[i].setEnabled(false);
            }
            addItem(pane, bacdensity[i], i+2, 14, 1, 1, GridBagConstraints.CENTER);
	}	

	viscositylabel.setFont(font);
	addItem(pane, viscositylabel, 0, 15, 2, 1, GridBagConstraints.WEST);
	for(int i=0; i<totf; i++) {
	    viscosities[i]=new JTextField(5);
            viscosities[i].setText(Double.toString(relaxtime[2*i]));
            addItem(pane, viscosities[i], i+2, 15, 1, 1, GridBagConstraints.CENTER);
	}	

	bulkviscositylabel.setFont(font);
	addItem(pane, bulkviscositylabel, 0, 16, 2, 1, GridBagConstraints.WEST);
	for(int i=0; i<totf; i++) {
	    bulkviscosities[i]=new JTextField(5);
            bulkviscosities[i].setText(Double.toString(relaxtime[2*i+1]));
            addItem(pane, bulkviscosities[i], i+2, 16, 1, 1, GridBagConstraints.CENTER);
	}	

/*
	interactionlabel.setFont(font);
	addItem(pane, interactionlabel, 0, 17, 2, 1, GridBagConstraints.WEST);
        for(int i=0; i<totf; i++) {
          addItem(pane, new JLabel("fluid "+i), i+2, 17, 1, 1, GridBagConstraints.CENTER);
        }

*/

// fluid-fluid interactions

/*
        for(int j=0; j<totf; j++) {
          addItem(pane, new JLabel("fluid "+j), 1, j+18, 1, 1, GridBagConstraints.EAST);
	  for(int i=j; i<totf; i++) {
	    interactions[i + j*totf]=new JTextField(5);
            interactions[i + j*totf].setText(Double.toString(interact[i+j*totf]));
            addItem(pane, interactions[i + j*totf], i+2, j+18, 1, 1, GridBagConstraints.CENTER);
            if(inter==3 && i==j) {
              interactions[i+j*totf].setEnabled(false);
              interactions[i+j*totf].setEditable(false);
            }
          }
	}	

// (Shan-Chen) fluid-wall interactions

        if(inter==1 || inter==2) {
          wallinteractlabel.setFont(font);
          addItem(pane, wallinteractlabel, 0, 18+totf, 2, 1, GridBagConstraints.WEST);
          for(int j=0; j<totf; j++) {
  	    wallinteractions[j]=new JTextField("0", 5);
            wallinteractions[j].setText(Double.toString(wallinteract[j]));
            addItem(pane, wallinteractions[j], j+2, 18+totf, 1, 1, GridBagConstraints.CENTER);
          }
	}	

// Lishchuk segregation parameter

        if((inter==3 || inter==4) && totf>1) {
  	  segregationlabel.setFont(font);
          segregation.setText(Double.toString(segregate));
          addItem(pane, segregationlabel, 0, 18+totf, 2, 1, GridBagConstraints.WEST);
          addItem(pane, segregation, 2, 18+totf, 1, 1, GridBagConstraints.CENTER);
        }

*/

        Box buttonBox = Box.createHorizontalBox();
	save.setFont(font);
	save.addActionListener(fluinilbe);
	buttonBox.add(save);
	close.setFont(font);
	close.addActionListener(fluinilbe);
	buttonBox.add(close);
        addItem(pane, buttonBox, 0, 18, 4, 1, GridBagConstraints.WEST);

        this.add(pane);
        this.pack();
	setVisible(true);
    }

    private void addItem(JPanel p, JComponent c, int x, int y, int width, int height, int align)
    {
        GridBagConstraints gc = new GridBagConstraints();
        gc.gridx = x;
        gc.gridy = y;
        gc.gridwidth = width;
        gc.gridheight = height;
        gc.weightx = 100.0;
        gc.weighty = 100.0;
        gc.insets = new Insets(5, 5, 5, 5);
        gc.anchor = align;
        gc.fill = GridBagConstraints.NONE;
        p.add(c, gc);
    }

}
