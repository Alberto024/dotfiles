import javax.swing.*;
import java.util.*;
import java.lang.*;
import java.io.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.geom.*;
import java.awt.image.*;
/*
 *     DL_MESO_GUI
 *     author: R. S. Qin, M. A. Seaton
 *     copyright: STFC Daresbury Laboratory and CCP5
 *     2005, 2015
 */
class setSurface extends JFrame {
    
    setdpdSysEvt surinidpd=new setdpdSysEvt(this);

    JLabel surfacetype = new JLabel("SURFACE TYPE", JLabel.RIGHT);

    JLabel walllabel = new JLabel("wall directions:", JLabel.RIGHT);
    JCheckBox xwall = new JCheckBox("x");
    JCheckBox ywall = new JCheckBox("y");
    JCheckBox zwall = new JCheckBox("z");

    JButton save = new JButton("SAVE SF");
    JButton close = new JButton("CANCEL SF");
    Font font=new Font("Dialog", Font.BOLD, 13);
    
    public setSurface(int srft, int sx, int sy, int sz) {

	super("DPD surface properties");
	setBounds(160, 10, 400, 220);
	JPanel pane=new JPanel(new GridBagLayout());

        if (srft==1) {
          surfacetype.setText("HARD SURFACES WITH SOFT REPULSION");
        }
        else if (srft==2) {
          surfacetype.setText("WALLS OF FROZEN BEADS");
        }
        else if (srft==3) {
          surfacetype.setText("LEES-EDWARDS SHEARING PERIODIC BOUNDARIES");
        }

        surfacetype.setFont(font);
        addItem(pane, surfacetype, 0, 0, 3, 1, GridBagConstraints.WEST);
        walllabel.setFont(font);
        addItem(pane, walllabel, 0, 1, 1, 1, GridBagConstraints.WEST);

	Box tickBox = Box.createHorizontalBox();
        xwall.addActionListener(surinidpd);
        tickBox.add(xwall);
        ywall.addActionListener(surinidpd);
        tickBox.add(ywall);
        zwall.addActionListener(surinidpd);
        tickBox.add(zwall);
        addItem(pane, tickBox, 1, 1, 2, 1, GridBagConstraints.WEST);

        if(sx>0)
          xwall.setSelected(true);
        else
          xwall.setSelected(false);

        if(sy>0)
          ywall.setSelected(true);
        else
          ywall.setSelected(false);

        if(sz>0)
          zwall.setSelected(true);
        else
          zwall.setSelected(false);

        Box buttonBox = Box.createHorizontalBox();
	save.setFont(font);
	save.addActionListener(surinidpd);
	buttonBox.add(save);
	close.setFont(font);
	close.addActionListener(surinidpd);
	buttonBox.add(close);
        addItem(pane, buttonBox, 0, 4, 3, 1, GridBagConstraints.WEST);

	this.add(pane);
        this.pack();
	setVisible(true);
    }

    private void addItem(JPanel p, JComponent c, int x, int y, int width, int height, int align)
    {
        GridBagConstraints gc = new GridBagConstraints();
        gc.gridx = x;
        gc.gridy = y;
        gc.gridwidth = width;
        gc.gridheight = height;
        gc.weightx = 100.0;
        gc.weighty = 100.0;
        gc.insets = new Insets(5, 5, 5, 5);
        gc.anchor = align;
        gc.fill = GridBagConstraints.NONE;
        p.add(c, gc);
    }

}
