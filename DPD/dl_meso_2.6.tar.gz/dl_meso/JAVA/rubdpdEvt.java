import javax.swing.*;
import java.util.*;
import java.lang.*;
import java.io.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.geom.*;
import java.awt.image.*;
/*
 *     DL_MESO_GUI
 *     author: R. S. Qin, M. A. Seaton
 *     copyright: STFC Daresbury Laboratory and CCP5
 *     2005, 2015
 */
class rubdpdEvt implements ItemListener, ActionListener{
    rubdpd gui;
    static String rcmd="executable-file"; 
    static Boolean runalt=false;
    public rubdpdEvt(rubdpd in){
        gui = in;
    }

    public void actionPerformed(ActionEvent event) {
        String cmd =event.getActionCommand();
        if (cmd == "RUN DPD"){
            try {
                if (runalt)
                    rcmd = gui.commandalt.getText();
                Process p2 = Runtime.getRuntime().exec(rcmd);
                BufferedReader ou2 = new BufferedReader (new InputStreamReader(p2.getInputStream()));
                String line2;
                while ((line2 = ou2.readLine()) != null)
                    System.out.println(line2);
            } catch (IOException e1) {
                System.out.println(e1);
            }
        }
    }
    public void itemStateChanged(ItemEvent event) {
        Object item=event.getItem();
        String answer=item.toString();
        if(answer == "./dpd.exe") {
            rcmd="./dpd.exe";
            runalt=false;
        }
        else if(answer == "dpd.exe") {
            rcmd="dpd.exe";
            runalt=false;
        }
        else if(answer == "llsubmit hpc-script") {
            rcmd="llsubmit hpc-script";
            runalt=false;
        }
        else if(answer == "bsub ibm-script") {
            rcmd="bsub ibm-script";
            runalt=false;
        }
        else if(answer == "qsub cray-script") {
            rcmd="qsub hpc-script";
            runalt=false;
        }
        else if(answer == "other ...")
            runalt=true;
    }

}
