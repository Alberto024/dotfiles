import javax.swing.*;
import java.util.*;
import java.lang.*;
import java.io.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.geom.*;
import java.awt.image.*;
/*
 *     DL_MESO_GUI
 *     author: W. Smith, M. A. Seaton - from code by R. S. Qin
 *     copyright: STFC Daresbury Laboratory and CCP5
 *     2006, 2012
 */
class dldpd extends JPanel {

    dlmesoguiEvt dpdv=new dlmesoguiEvt(this);

    JButton defsys = new JButton("Define DPD System");
    JButton setinteract = new JButton("Set DPD Interactions");
    JButton changecode =new JButton("Change DPD Code");
    JButton compile =new JButton("Compile DPD Code");
    JButton runcode =new JButton("Run DPD Program");    
    JButton gatherdata =new JButton("Process DPD Data");
    JButton plotdpd =new JButton("Plot DPD Results");
    JButton closedpd = new JButton("Close DPD Panel");
    JLabel lb1 =new JLabel("Dissipative Particle Dynamics", JLabel.CENTER);
    Font buttonfont=new Font("Serif", Font.BOLD, 16);
    Color bgcolor=new Color(170, 200, 190);
    Color focolor=new Color(10, 10, 15);

    public dldpd() {
	setSize(160, 530);
	GridLayout dpdlayout =new GridLayout(9, 1, 10, 10);
	setLayout(dpdlayout);

	add(lb1);

	defsys.setFont(buttonfont);
	defsys.setBackground(bgcolor);
	defsys.setForeground(focolor);
	defsys.addActionListener(dpdv);
	add(defsys);

	setinteract.setFont(buttonfont);
	setinteract.setBackground(bgcolor);
	setinteract.setForeground(focolor);
	setinteract.addActionListener(dpdv);
	add(setinteract);

	changecode.setFont(buttonfont);
	changecode.setBackground(bgcolor);
	changecode.setForeground(focolor);
	changecode.addActionListener(dpdv);
	add(changecode);

	compile.setFont(buttonfont);
	compile.setBackground(bgcolor);
	compile.setForeground(focolor);
	compile.addActionListener(dpdv);
	add(compile);

	runcode.setFont(buttonfont);
	runcode.setBackground(bgcolor);
	runcode.setForeground(focolor);
	runcode.addActionListener(dpdv);
	add(runcode);

	gatherdata.setFont(buttonfont);
	gatherdata.setBackground(bgcolor);
	gatherdata.setForeground(focolor);
	gatherdata.addActionListener(dpdv);
	add(gatherdata);
	
	plotdpd.setFont(buttonfont);
	plotdpd.setBackground(bgcolor);
	plotdpd.setForeground(focolor);
	plotdpd.addActionListener(dpdv);
	add(plotdpd);

	closedpd.setFont(buttonfont);
	closedpd.setBackground(bgcolor);
	closedpd.setForeground(focolor);
	closedpd.addActionListener(dpdv);
	add(closedpd);	
    }
}
