import javax.swing.*;
import java.util.*;
import java.lang.*;
import java.io.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.geom.*;
import java.awt.image.*;
/*
 *     DL_MESO_GUI
 *     author: R. S. Qin, M. A. Seaton
 *     copyright: STFC Daresbury Laboratory and CCP5
 *     2005, 2015
 */
class rublbe extends JPanel {
    rublbeEvt clbe = new rublbeEvt(this); 
    
    Font font=new Font("Dialog", Font.BOLD, 12);
    Color paneltop=new Color(170, 170, 230);
    
    JPanel row1a =new JPanel();
    JPanel row1b =new JPanel();
    
    JPanel row2a =new JPanel();
    JComboBox command= new JComboBox();
    JTextField commandalt = new JTextField (10);
    JPanel row2b =new JPanel();
    
    JPanel row3 =new JPanel();    
    JLabel info1 = new JLabel("You may need to write the job script file"
			      + " for your machine");
    JPanel row31 =new JPanel();
    JButton runbutton = new JButton("RUN LBE");

    public rublbe() {
        setSize(620, 530);
        GridLayout gl =new GridLayout(6, 1, 5, 5);
        FlowLayout fl = new FlowLayout(FlowLayout.CENTER);
        BorderLayout bl = new BorderLayout();
        setLayout(gl);
        add(row1a);
        add(row1b);
        command.addItem("Choose a Command");
        command.addItem("./lbe.exe");
        command.addItem("lbe.exe");
        command.addItem("llsubmit hpc-script");
        command.addItem("bsub ibm-script");
        command.addItem("qsub cray-script");
        command.addItem("other ...");
        command.addItemListener(clbe);
        row2a.setLayout(fl);
        row2a.add(command);
        row2a.add(commandalt);
        add(row2a);
        runbutton.addActionListener(clbe);
        row2b.add(runbutton);
        add(row2b);
        row31.setLayout(fl);
        row31.add(info1);
        add(row31);
    }
}
