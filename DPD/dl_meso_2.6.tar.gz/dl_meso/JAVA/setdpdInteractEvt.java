import javax.swing.*;
import java.util.*;
import java.lang.*;
import java.io.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.geom.*;
import java.awt.image.*;
/*
 *     DL_MESO_GUI
 *     author: R. S. Qin, M. A. Seaton
 *     copyright: STFC Daresbury Laboratory and CCP5
 *     2005, 2012
 */
class setdpdInteractEvt implements ItemListener, ActionListener {

    static setdpdInteract sg;
    setSpecies spg; 
    setInteraction ig;
    setExternal eg;
    FileWriter ot;
    String rcmd;
    String str;
    String filename = "FIELD";
    String editor = "dlmesoEditor";
    int xint,ii,jj,kk;
    double xdouble;
    static int istate, nspe, npot, ktyp, externtype, frzspe;
    static double bdfx, bdfy, bdfz, frzdens, frzthick;
    static String[] spenam = new String[10];
    static double spemass[] = new double[10];
    static double spechge[] = new double[10];
    static int spenum[] = new int[10];
    static int spefrz[] = new int[10];
    static double srfaa[] = new double[10];
    static double aa[] = new double[10*(10+1)/2];
    static double bb[] = new double[10*(10+1)/2];
    static double cc[] = new double[10*(10+1)/2];
    static double dd[] = new double[10*(10+1)/2];
    static double ee[] = new double[10*(10+1)/2];
    static double gamma[] = new double[10*(10+1)/2];
    static double distance[] = new double[10*(10+1)/2];
    static int ktype[] = new int[10*(10+1)/2];
    private static String OS = System.getProperty("os.name").toLowerCase();

    public setdpdInteractEvt(setdpdInteract setinteractions) {
	sg=setinteractions;
        nspe = 1;
        npot = 1;
        for (int i=0; i<10; i++) {
          spenam[i] = "SPEC"+(i+1);
          srfaa[i] = 25.0;
        }
        java.util.Arrays.fill(spenum, 0);
        java.util.Arrays.fill(spemass, 1.0);
        java.util.Arrays.fill(spechge, 1.0);
        java.util.Arrays.fill(aa, 25.0);
        java.util.Arrays.fill(bb, 0.0);
        java.util.Arrays.fill(cc, 0.0);
        java.util.Arrays.fill(dd, 0.0);
        java.util.Arrays.fill(ee, 0.0);
        java.util.Arrays.fill(gamma, 4.5);
        java.util.Arrays.fill(distance, 1.0);
        java.util.Arrays.fill(srfaa, 25.0); 
        java.util.Arrays.fill(ktype, 2); 
        kk=0;
        ktyp=2;
    }

    public setdpdInteractEvt(setSpecies speini) {
	spg=speini;
    }

    public setdpdInteractEvt(setInteraction interactdpd) {
	ig=interactdpd;
    }

    public setdpdInteractEvt(setExternal externdpd) {
	eg=externdpd;
    }


    public void actionPerformed(ActionEvent event) {
        String cmd =event.getActionCommand();
        if (cmd == "set species") {
            nspe = (Integer)sg.species.getValue();
            npot = nspe * (nspe+1) / 2;
            setspecies(nspe);
        }
        else if (cmd == "set interactions") {
            setinteract(nspe, spenam);
        }

        else if (cmd == "SAVE SP") {
            savespecies();
        }
        else if (cmd == "CANCEL SP") {
            spg.dispose();
        }

        else if (cmd == "SET I") {
             ii = ig.speci.getSelectedIndex();
             jj = ig.specj.getSelectedIndex();
             if (ii>jj) {
                 kk = ii;
                 ii = jj;
                 jj = kk;
             }
             kk = jj * (jj + 1) / 2 + ii;
             xdouble=Double.parseDouble(ig.aa.getText());
             aa[kk]=xdouble;
             xdouble=Double.parseDouble(ig.bb.getText());
             bb[kk]=xdouble;
             xdouble=Double.parseDouble(ig.cc.getText());
             cc[kk]=xdouble;
             xdouble=Double.parseDouble(ig.dd.getText());
             dd[kk]=xdouble;
             xdouble=Double.parseDouble(ig.ee.getText());
             ee[kk]=xdouble;
             xdouble=Double.parseDouble(ig.dist.getText());
             distance[kk]=xdouble;
             xdouble=Double.parseDouble(ig.gamma.getText());
             gamma[kk]=xdouble;
             ktype[kk]=ktyp;
        }
        else if (cmd == "SAVE I") {
            saveinteract();
        }
        else if (cmd == "CANCEL I") {
            ig.dispose();
        }

        else if (cmd == "SAVE E") {
            saveexternal();
        }
        else if (cmd == "CANCEL E") {
            eg.dispose();
        }

        else if (cmd == "create molecules"){
            try {
                if(isMac()) {
                    String executionPath = System.getProperty("user.dir");
                    rcmd = "tell application \"Terminal\" to do script \"cd "+executionPath+";./molecule.exe;exit\"";
                    String[] rcmdargs = { "osascript", "-e", rcmd };
                    Process p2 = Runtime.getRuntime().exec(rcmdargs);
                    BufferedReader ou2 = new BufferedReader
                    (new InputStreamReader(p2.getInputStream()));
                    String line2;
                    while ((line2 = ou2.readLine()) != null)
                        System.out.println(line2);
                }
                else if(isWindows()) {
                    rcmd = "molecule.exe";
                    String[] rcmdargs = { "cmd.exe", "/c", rcmd };
                    Process p2 = Runtime.getRuntime().exec(rcmdargs);
                    BufferedReader ou2 = new BufferedReader
                    (new InputStreamReader(p2.getInputStream()));
                    String line2;
                    while ((line2 = ou2.readLine()) != null)
                        System.out.println(line2);
                }
                else {
                    rcmd = "./molecule.exe";
                    String[] rcmdargs = { "xterm", "-e", rcmd };
                    Process p2 = Runtime.getRuntime().exec(rcmdargs);
                    BufferedReader ou2 = new BufferedReader
                    (new InputStreamReader(p2.getInputStream()));
                    String line2;
                    while ((line2 = ou2.readLine()) != null)
                        System.out.println(line2);
                }
            } catch (IOException e1) {
                System.out.println(e1);
            }
        }
        else if(cmd == "set parameters") {
             externtype = sg.external.getSelectedIndex();
             setexternal(externtype);
        }
        else if(cmd == "edit FIELD file") {
             if(editor=="dlmesoEditor") {
                 dledit(filename);
             }
             else if(editor=="other") {
                 str = sg.otheredit.getText() + " " + filename;
                 try {
                     Process p2 = Runtime.getRuntime().exec(str);
                     BufferedReader ou2 = new BufferedReader
                     (new InputStreamReader(p2.getErrorStream()));
                     String line2;
                     while ((line2 = ou2.readLine()) != null)
                         System.err.println(line2);
                } catch (IOException e1) {
                    ierr(" "+sg.otheredit.getText()+": not found");
                }
            }
            else {
                str = editor + " " + filename;
                try {
                    Process p2 = Runtime.getRuntime().exec(str);
                    BufferedReader ou2 = new BufferedReader
                    (new InputStreamReader(p2.getErrorStream()));
                    String line2;
                    while ((line2 = ou2.readLine()) != null)
                        System.err.println(line2);
                } catch (IOException e1) {
                    ierr(" "+editor+": not found");
                }
            }
        }
        else if(cmd == "SAVE") {
             File fieldfile = new File(filename);
             try {
                 ot = new FileWriter(filename, true);
                 ot.write("close\n");
             } catch (IOException e) {
                 ierr(" cannot write to FIELD file ");
             }
             try {
                 ot.close();
             } catch (IOException e) {
                 ierr(" error when closing FIELD file ");
             }
             sg.setinteract.setEnabled(false);
             sg.createmolecule.setEnabled(false);
             sg.savefield.setEnabled(false);
             sg.external.setEnabled(false);
             sg.compiled.setEnabled(false);
             sg.exterforce.setEnabled(false);
        }

    }

    public void itemStateChanged(ItemEvent event) {
	Object item=event.getItem();
	String answer=item.toString();

        if(answer == "DPD") {
            ktyp = 2;
            ig.blabel.setEnabled(false);
            ig.clabel.setEnabled(false);
            ig.dlabel.setEnabled(false);
            ig.elabel.setEnabled(false);
            ig.bb.setEnabled(false);
            ig.bb.setEditable(false);
            ig.cc.setEnabled(false);
            ig.cc.setEditable(false);
            ig.dd.setEnabled(false);
            ig.dd.setEditable(false);
            ig.ee.setEnabled(false);
            ig.ee.setEditable(false);
        }
        else if(answer == "many-body DPD") {
            ktyp = 3;
            ig.blabel.setEnabled(true);
            ig.clabel.setEnabled(true);
            ig.dlabel.setEnabled(true);
            ig.elabel.setEnabled(true);
            ig.bb.setEnabled(true);
            ig.bb.setEditable(true);
            ig.cc.setEnabled(true);
            ig.cc.setEditable(true);
            ig.dd.setEnabled(true);
            ig.dd.setEditable(true);
            ig.ee.setEnabled(true);
            ig.ee.setEditable(true);
        }
        else if(answer == "Lennard-Jones") {
            ktyp = 0;
            ig.blabel.setEnabled(false);
            ig.clabel.setEnabled(false);
            ig.dlabel.setEnabled(false);
            ig.elabel.setEnabled(false);
            ig.bb.setEnabled(false);
            ig.bb.setEditable(false);
            ig.cc.setEnabled(false);
            ig.cc.setEditable(false);
            ig.dd.setEnabled(false);
            ig.dd.setEditable(false);
            ig.ee.setEnabled(false);
            ig.ee.setEditable(false);
        }
        else if(answer == "WCA") {
            ktyp = 1;
            ig.blabel.setEnabled(false);
            ig.clabel.setEnabled(false);
            ig.dlabel.setEnabled(false);
            ig.elabel.setEnabled(false);
            ig.bb.setEnabled(false);
            ig.bb.setEditable(false);
            ig.cc.setEnabled(false);
            ig.cc.setEditable(false);
            ig.dd.setEnabled(false);
            ig.dd.setEditable(false);
            ig.ee.setEnabled(false);
            ig.ee.setEditable(false);
        }

        else if(answer == "none") {
            sg.exterparam.setEnabled(false);
        }

        else if(answer == "gravity") {
            sg.exterparam.setEnabled(true);
        }

        else if(answer == "linear shear") {
            sg.exterparam.setEnabled(true);
        }

        else if(answer == "electric field") {
            sg.exterparam.setEnabled(true);
        }
        
        else if(answer == "emacs") {
            editor = "emacs";
        }

        else if(answer == "notepad") {
            editor = "notepad";
        }

        else if(answer == "vi") {
            editor = "vi";
        }

        else if(answer == "dlmesoEditor") {
            editor = "dlmesoEditor";
        }

        else if(answer == "other ...") {
            editor = "other";
        }

        else if(event.getSource()==ig.speci || event.getSource()==ig.specj) {
             ii = ig.speci.getSelectedIndex();
             jj = ig.specj.getSelectedIndex();
             if (ii>jj) {
                 kk = ii;
                 ii = jj;
                 jj = kk;
             }
             kk = jj * (jj + 1) / 2 + ii;
             str = Double.toString(aa[kk]);
             ig.aa.setText(str);
             str = Double.toString(bb[kk]);
             ig.bb.setText(str);
             str = Double.toString(cc[kk]);
             ig.cc.setText(str);
             str = Double.toString(dd[kk]);
             ig.dd.setText(str);
             str = Double.toString(ee[kk]);
             ig.ee.setText(str);
             str = Double.toString(distance[kk]);
             ig.dist.setText(str);
             str = Double.toString(gamma[kk]);
             ig.gamma.setText(str);
             switch (ktype[kk]) {
                 case 0: ig.inter.setSelectedIndex(2); break;
                 case 1: ig.inter.setSelectedIndex(3); break;
                 case 2: ig.inter.setSelectedIndex(0); break;
                 case 3: ig.inter.setSelectedIndex(1); break;
             }
        }

        else if(event.getSource()==ig.wallspec) {
             frzspe = ig.wallspec.getSelectedIndex();
        }

    }

    void setspecies(int totspe) {
      setSpecies spg= new setSpecies(totspe);
    }

    void  savespecies() {
        int i, j, k;
        String str;
        try {
           for(i=0; i<nspe; i++) {
             str = spg.specname[i].getText();
             if (str.isEmpty())
                 throw new NumberFormatException ("Enter species name");
             str = str.toUpperCase() + "        ";
             spenam[i] = str.substring(0, 8);
             xint = Integer.parseInt(spg.specpop[i].getText());
             spenum[i] = xint;
             xdouble=Double.parseDouble(spg.specmass[i].getText());
             spemass[i] = xdouble;
             xdouble=Double.parseDouble(spg.speccharge[i].getText());
             spechge[i] = xdouble;
             if(spg.specfroz[i].isSelected())
                 spefrz[i] = 1;
             else
                 spefrz[i] = 0;
             xdouble=Double.parseDouble(spg.srfzaa[i].getText());
             srfaa[i] = xdouble;
             
            }
            spg.dispose();
            try {
                ot = new FileWriter("FIELD", false);
                ot.write(setdpdSysEvt.name+"\n\n");
                ot.write("SPECIES "+nspe+"\n");
                for(i=0; i<nspe; i++) {
                    ot.write(spenam[i]+" "+spemass[i]+" "+spechge[i]+" "+spenum[i]+" "+spefrz[i]+"\n");
                }
                ot.write("\n");
                if(setdpdSysEvt.srftype==1) {
                    ot.write("SURFACES\n");
                    for(i=0; i<nspe; i++) {
                        ot.write(spenam[i]+" "+srfaa[i]+"\n");
                    }
                    ot.write("\n");
                }
            } catch (IOException e) {
                ierr(" cannot write to FIELD file ");
            }
            try {
                ot.close();
            } catch (IOException e) {
                ierr(" error when closing FIELD file ");
            }
            sg.setspecies.setEnabled(false);
            sg.numspecies.setEnabled(false);
            sg.species.setEnabled(false);
            sg.setinteract.setEnabled(true);
            sg.createmolecule.setEnabled(true);
            sg.editfile.setEnabled(true);
            sg.savefield.setEnabled(true);
            sg.external.setEnabled(true);
            sg.editor.setEnabled(true);
            sg.otheredit.setEnabled(true);
            } catch (NumberFormatException enfl) {
                ierr(" species parameter: format error or no value ");
            }
        }

    void setinteract(int totspe, String[] names) {
        setInteraction ig= new setInteraction(totspe, names);
    }

    void  saveinteract() {
        int i, j, k;
        try {
            try {
                ot = new FileWriter("FIELD", true);
                ot.write("INTERACTIONS "+npot+"\n");
                for(i=0; i<nspe; i++) {
                    for(j=i; j<nspe; j++) {
                        kk = j * (j + 1) / 2 + i;
                        switch (ktype[kk]) {
                            case 0: ot.write(spenam[i]+" "+spenam[j]+" lj   "+aa[kk]+" "+distance[kk]+" "+gamma[kk]+"\n"); break;
                            case 1: ot.write(spenam[i]+" "+spenam[j]+" wca  "+aa[kk]+" "+distance[kk]+" "+gamma[kk]+"\n"); break;
                            case 2: ot.write(spenam[i]+" "+spenam[j]+" dpd  "+aa[kk]+" "+distance[kk]+" "+gamma[kk]+"\n"); break;
                            case 3: ot.write(spenam[i]+" "+spenam[j]+" mdpd "+aa[kk]+" "+bb[kk]+" "+cc[kk]+" "+dd[kk]+" "+ee[kk]
                                     +" "+distance[kk]+" "+gamma[kk]+"\n"); break;
                        }
                    }
                }
                ot.write("\n");
                if(setdpdSysEvt.srftype==2) {
                    xdouble=Double.parseDouble(ig.walldens.getText());
                    frzdens = xdouble;
                    xdouble=Double.parseDouble(ig.wallthick.getText());
                    frzthick = xdouble;
                    ot.write("SURFACES\n");
                    ot.write(spenam[frzspe]+" "+frzdens+" "+frzthick+"\n\n");
                }
            } catch (IOException e) {
                ierr(" cannot write to FIELD file ");
            }
            try {
                ot.close();
            } catch (IOException e) {
                ierr(" error when closing FIELD file ");
            }
            ig.dispose();
            sg.setinteract.setEnabled(false);
        } catch (NumberFormatException enfl) {
            ierr(" species parameter: format error or no value ");
        }
    }

    void setexternal(int exttype) {
      setExternal eg= new setExternal(exttype);
    }

    void  saveexternal() {
	try {
          try {
              ot = new FileWriter("FIELD", true);
              switch (externtype) {
                case 0: break;
                case 1: ot.write("EXTERNAL\n");
                        ot.write("grav ");
                        xdouble=Double.parseDouble(eg.aex.getText());
                        ot.write(xdouble+" ");
                        xdouble=Double.parseDouble(eg.bex.getText());
                        ot.write(xdouble+" ");
                        xdouble=Double.parseDouble(eg.cex.getText());
                        ot.write(xdouble+"\n\n");
                        break;
                case 2: ot.write("EXTERNAL\n");
                        ot.write("shear ");
                        xdouble=Double.parseDouble(eg.aex.getText());
                        ot.write(xdouble+" ");
                        xdouble=Double.parseDouble(eg.bex.getText());
                        ot.write(xdouble+" ");
                        xdouble=Double.parseDouble(eg.cex.getText());
                        ot.write(xdouble+"\n\n");
                        break;
                case 3: ot.write("EXTERNAL\n");
                        ot.write("elec ");
                        xdouble=Double.parseDouble(eg.aex.getText());
                        ot.write(xdouble+" ");
                        xdouble=Double.parseDouble(eg.bex.getText());
                        ot.write(xdouble+" ");
                        xdouble=Double.parseDouble(eg.cex.getText());
                        ot.write(xdouble+"\n\n");
                        break;
              }

           } catch (IOException e) {
             ierr(" cannot write to FIELD file ");
           }
           try {
             ot.close();
           } catch (IOException e) {
             ierr(" error when closing FIELD file ");
           }
 	   eg.dispose();
           sg.exterparam.setEnabled(false);
	} catch (NumberFormatException enfl) {
	    ierr(" species parameter: format error or no value ");
        }
    }

    void dledit(String str) {
	dlmesoeditor dlm = new dlmesoeditor(str);
    }

    void ierr(String errinfo) {
      msgPanel fcer=new msgPanel(errinfo);	
    }

    public static boolean isWindows() {
        return (OS.indexOf("win") >= 0);
    }
    
    public static boolean isMac() {
        return (OS.indexOf("mac") >= 0);
    }
    
    public static boolean isUnix() {
        return (OS.indexOf("nix") >= 0 || OS.indexOf("nux") >= 0 || OS.indexOf("aix") >= 0 || OS.indexOf("sunos") >= 0 );
    }

}
