import javax.swing.*;
import java.util.*;
import java.lang.*;
import java.io.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.geom.*;
import java.awt.image.*;
/*
 *     DL_MESO_GUI
 *     author: R. S. Qin, M. A. Seaton
 *     copyright: STFC Daresbury Laboratory and CCP5
 *     2005, 2015
 */
class compilelbeEvt implements ItemListener, ActionListener {
    compilelbe gui;
    static String str0, str1="C++ compiler", str2, str3="source-file", str4, str5;
    static Boolean altcomp=false;
    private static String OS = System.getProperty("os.name").toLowerCase();
    public compilelbeEvt(compilelbe in){
        gui = in;
    }
    public void actionPerformed(ActionEvent event) {
        String cmd =event.getActionCommand();
        if (cmd == "COMPILE"){
            if (isWindows ())
                str0 = "..\\LBE\\";
            else if (isMac () || isUnix ())
                str0 = "../LBE/";
            if (altcomp)
                str1 = gui.compilealt.getText();
            str4 = gui.compileflag.getText();
            if(str4.length()>0)
                str4 = " "+str4;
            str3 = str1+str4+str5+" -o lbe.exe "+str0+str2;
            try {
                Process p2 = Runtime.getRuntime().exec(str3);
                BufferedReader ou2 = new BufferedReader(new InputStreamReader(p2.getErrorStream()));
                String line2;
                while ((line2 = ou2.readLine()) != null)
                    System.err.println(line2);
                gui.lb1.setEnabled(false);
                gui.lb2.setEnabled(false);
                gui.lb3.setEnabled(false);
                gui.comflag.setEnabled(false);
                gui.ompcomflag.setEnabled(false);
                gui.comp.setEnabled(false);
                gui.code.setEnabled(false);
                gui.compilealt.setEnabled(false);
                gui.compilealt.setEditable(false);
                gui.compileflag.setEnabled(false);
                gui.compileflag.setEditable(false);
                gui.ompcompileflag.setEnabled(false);
                gui.ompcompileflag.setEditable(false);
                gui.compile.setEnabled(false);
            ierr(" lbe.exe created successfully ");
            } catch (IOException e1) {
                ierr(" "+str1+": not found");
            }
        }
    }

    public void itemStateChanged(ItemEvent event) {
        Object item=event.getItem();
        String answer=item.toString();
        if(answer == "g++") {
            str1="g++";
            altcomp = false;
            gui.ompcompileflag.setText("-fopenmp");
        }
        else if(answer == "gcc") {
            str1="gcc";	
            altcomp = false;
            gui.ompcompileflag.setText("-fopenmp");
        }
        else if(answer == "c++") {
            str1="c++";	
            altcomp = false;
            gui.ompcompileflag.setText("-openmp");
        }
        else if(answer == "cpp") {
            str1="cpp";
            altcomp = false;
            gui.ompcompileflag.setText("-openmp");
        }
        else if(answer == "icpc") {
            str1="icpc";
            altcomp = false;
            gui.ompcompileflag.setText("-openmp");
        }
        else if(answer == "mpCC") {
            str1="mpCC";
            altcomp = false;
            gui.ompcompileflag.setText("-openmp");
        }
        else if(answer == "mpiCC") {
            str1="mpiCC";
            altcomp = false;
            gui.ompcompileflag.setText("-openmp");
        }
        else if(answer == "mpicxx") {
            str1="mpicxx";
            altcomp = false;
            gui.ompcompileflag.setText("-fopenmp");
        }
        else if(answer == "cc") {
            str1="cc";
            altcomp = false;
            gui.ompcompileflag.setText("-openmp");
        }
        else if(answer == "other ...")
            altcomp = true;
        else if(answer == "parallel code") {
            str2 = "plbe.cpp";
            str5 = "";
        }
        else if(answer == "serial code") {
            str2 = "slbe.cpp";
            str5 = "";
        }
        else if(answer == "parallel code with OpenMP") {
            str2 = "plbe.cpp";
            str5 = " "+gui.ompcompileflag.getText();
        }
        else if(answer == "serial code with OpenMP") {
            str2 = "slbe.cpp";
            str5 = " "+gui.ompcompileflag.getText();
        }
    }

    void ierr(String errinfo) {
      msgPanel fcer=new msgPanel(errinfo);	
    }

    public static boolean isWindows() {
        return (OS.indexOf("win") >= 0);
    }
    
    public static boolean isMac() {
        return (OS.indexOf("mac") >= 0);
    }
    
    public static boolean isUnix() {
        return (OS.indexOf("nix") >= 0 || OS.indexOf("nux") >= 0 || OS.indexOf("aix") >= 0 || OS.indexOf("sunos") >= 0 );
    }
    
}
