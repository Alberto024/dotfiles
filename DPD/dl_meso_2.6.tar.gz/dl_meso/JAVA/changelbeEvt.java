import javax.swing.*;
import java.util.*;
import java.lang.*;
import java.io.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.geom.*;
import java.awt.image.*;
/*
 *     DL_MESO_GUI
 *     author: R. S. Qin, M. A. Seaton
 *     copyright: STFC Daresbury Laboratory and CCP5
 *     2005, 2015
 */
class changelbeEvt implements ItemListener, ActionListener {
    changelbecode gui;
    static String str0, str1, str2, str3="source-file"; 
    static Boolean altfile = false, altedit = false;
    private static String OS = System.getProperty("os.name").toLowerCase();
    public changelbeEvt(changelbecode in){
        gui = in;
    }
    public void actionPerformed(ActionEvent event) {
        String cmd =event.getActionCommand();
        if (cmd == "EDIT"){
            if (isWindows())
                str0 = "..\\LBE\\";
            else if (isMac() || isUnix())
                str0 = "../LBE/";
            if(altfile) {
               str2 = gui.openalt.getText();
            }
            if(str1 == "dlmesoEditor")
                dledit(str0+str2);
            else {
                if(altedit)
                    str1 = gui.editalt.getText();
                str3 = str1+" "+str0+str2;
                try {
                    Process p2 = Runtime.getRuntime().exec(str3);
                    BufferedReader ou2 = new BufferedReader
                    (new InputStreamReader(p2.getErrorStream()));
                    String line2;
                    while ((line2 = ou2.readLine()) != null)
                        System.err.println(line2);
                } catch (IOException e1) {
                    ierr(" "+str1+": not found");
                }
            }
        }
    }

    public void itemStateChanged(ItemEvent event) {
        Object item=event.getItem();
        String answer=item.toString();
        if(answer == "emacs") {
            str1="emacs";
            altedit = false;
        }
        else if(answer == "notepad") {
            str1="notepad";
            altedit = false;
        }
        else if(answer == "vi") {
            str1="vi";
            altedit = false;
        }
        else if(answer == "dlmesoEditor") {
            str1="dlmesoEditor";
            altedit = false;
        }
        else if(event.getSource() == gui.edit && answer == "other ...")
            altedit = true;
        else if(answer == "parallel main file") {
            str2 = "plbe.cpp";
            altfile = false;
        }
        else if(answer == "serial main file") {
            str2 = "slbe.cpp";
            altfile = false;
        }
        else if(answer == "parallel custom main file") {
            str2 = "plbecustom.cpp";
            altfile = false;
        }
        else if(answer == "serial custom main file") {
            str2 = "slbecustom.cpp";
            altfile = false;
        }
        else if(answer == "parallel run loops") {
            str2 = "lbpRUNPAR.cpp";
            altfile = false;
        }
        else if(answer == "serial run loops") {
            str2 = "lbpRUNSER.cpp";
            altfile = false;
        }
        else if(answer == "main header file") {
            str2 = "slbe.hpp";
            altfile = false;
        }
        else if(answer == "user-defined header file") {
            str2 = "lbpUSER.hpp";
            altfile = false;
        }
        else if(answer == "lattice model file") {
            str2 = "lbpMODEL.cpp";
            altfile = false;
        }
        else if(answer == "boundary condition file") {
            str2 = "lbpBOUND.cpp";
            altfile = false;
        }
        else if(answer == "core subroutines") {
            str2 = "lbpSUB.cpp";
            altfile = false;
        }
        else if(answer == "BGK collision subroutines") {
            str2 = "lbpBGK.cpp";
            altfile = false;
        }
        else if(answer == "TRT collision subroutines") {
            str2 = "lbpTRT.cpp";
            altfile = false;
        }
        else if(answer == "MRT collision subroutines") {
            str2 = "lbpMRT.cpp";
            altfile = false;
        }
        else if(answer == "force subroutines") {
            str2 = "lbpFORCE.cpp";
            altfile = false;
        }
        else if(answer == "user defined subroutines") {
            str2 = "lbpUSER.cpp";
            altfile = false;
        }
        else if(event.getSource() == gui.open && answer == "other ...")
            altfile = true;
        else if(answer == "windows")
            str0 = "..\\LBE\\";
        else if(answer == "unix")
            str0 = "../LBE/";
        else if(answer == "linux")
            str0 = "../LBE/";
    }
    void dledit(String str) {
        dlmesoeditor dlm = new dlmesoeditor(str);
    }
    void ierr(String errinfo) {
        msgPanel fcer=new msgPanel(errinfo);	
    }
    public static boolean isWindows() {
        return (OS.indexOf("win") >= 0);
    }
    
    public static boolean isMac() {
        return (OS.indexOf("mac") >= 0);
    }
    
    public static boolean isUnix() {
        return (OS.indexOf("nix") >= 0 || OS.indexOf("nux") >= 0 || OS.indexOf("aix") >= 0 || OS.indexOf("sunos") >= 0 );
    }
    
}
