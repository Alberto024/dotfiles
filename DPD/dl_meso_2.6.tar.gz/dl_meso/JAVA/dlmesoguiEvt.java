import javax.swing.*;
import java.util.*;
import java.lang.*;
import java.io.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.geom.*;
import java.awt.image.*;
/*
 *     DL_MESO_GUI
 *     author: R. S. Qin, M. A. Seaton
 *     copyright: STFC Daresbury Laboratory and CCP5
 *     2005, 2012
 */
class dlmesoguiEvt implements ActionListener {
    static dlmesogui gui;
    static dllbe lbegui;
    static dldpd dpdgui;
    public dlmesoguiEvt(dlmesogui in) {
	gui = in;
    }

    public dlmesoguiEvt(dllbe lbein) {
	lbegui = lbein;
    }

    public dlmesoguiEvt(dldpd dpdin) {
	dpdgui = dpdin;
    }

    public void actionPerformed(ActionEvent event) {
	String command =event.getActionCommand();

	// top row
	if(command =="LBE")
	    lbe();
        else if(command =="DPD")
	    dpd();
	else if(command =="SPH")
	    sph();
	else if(command =="Manual")
	    manual();
	else if(command =="Help")
	    help();
	else if(command =="Exit")
	    System.exit(0);

	// lbe
	else if(command =="Define LBE System")
	    defsy();
	else if(command =="Set LBE Space") {
            lbesysdim dim = new lbesysdim();
            int lbd=dim.lbd;
	    setspa(lbd);
        }
	else if(command =="Change LBE Code")
	    changecode();
	else if(command =="Compile LBE Code")
	    compilel();
	else if(command =="Run LBE Program")
	    runprogram();
	else if(command =="Gather LBE Data")
	    gatherdata();
	else if(command =="Plot LBE Results")
	    plotresult();
	else if(command  =="Close LBE Panel")
	    closelbe();

	// dpd
	else if(command =="Define DPD System")
	    dpddefsys();
        else if(command =="Set DPD Interactions")
            dpdsetinteract();
	else if(command =="Change DPD Code")
	    dpdchangecode();
	else if(command =="Compile DPD Code")
	    dpdcompile();
	else if(command =="Run DPD Program")
	    dpdrunprogram();
	else if(command =="Process DPD Data")
	    dpdgatherdata();
	else if(command =="Plot DPD Results")
	    dpdplotresult();
	else if(command  =="Close DPD Panel")
	    closedpd();

    }

    void changecode() {
	changelbecode cl = new changelbecode();
	lbeUpdatePan(cl);
    }
    
    void compilel(){
	compilelbe cpl = new compilelbe();
	lbeUpdatePan(cpl);
    }
        
    void runprogram(){
	rublbe rlb = new rublbe();
	lbeUpdatePan(rlb);
    }
    
    void gatherdata() {
	gatherlbe glb = new gatherlbe();
	lbeUpdatePan(glb);
    }
    
    void  plotresult(){
	plotlbe plb = new plotlbe();
	lbeUpdatePan(plb); 	
    }

    void setspa(int dim){
	setlbeSpa dsp =new setlbeSpa(dim);
	lbeUpdatePan(dsp);
    }

    void defsy() {
	setlbeSys ds = new setlbeSys();      
	lbeUpdatePan(ds);
    }

    void dpdchangecode() {
	changedpdcode cd = new changedpdcode();
	dpdUpdatePan(cd);
    }
    
    void dpdcompile(){
	compiledpd cpd = new compiledpd();
	dpdUpdatePan(cpd);
    }
        
    void dpdrunprogram(){
	rubdpd rdp = new rubdpd();
	dpdUpdatePan(rdp);
    }
    
    void dpdgatherdata() {
	gatherdpd gdp = new gatherdpd();
	dpdUpdatePan(gdp);
    }
    
    void  dpdplotresult(){
	plotdpd pdp = new plotdpd();
	dpdUpdatePan(pdp); 	
    }

    void dpdsetinteract() {
	setdpdInteract dpdi = new setdpdInteract();      
	dpdUpdatePan(dpdi);
    }

    void dpddefsys() {
	setdpdSys dpds = new setdpdSys();      
	dpdUpdatePan(dpds);
    }


   void closelbe(){
  	try{
	    gui.getContentPane().invalidate();
	    gui.getContentPane().removeAll();
	    gui.getContentPane().add(gui.rowtop, BorderLayout.NORTH);
	    gui.getContentPane().add(gui.rowdown, BorderLayout.CENTER);
	    gui.getContentPane().validate();
	    gui.getContentPane().repaint();
  	} catch (Exception e) {
	    ierr(" error in lbe main frame");
        }	
    } 

   void closedpd(){
  	try{
	    gui.getContentPane().invalidate();
	    gui.getContentPane().removeAll();
	    gui.getContentPane().add(gui.rowtop, BorderLayout.NORTH);
	    gui.getContentPane().add(gui.rowdown, BorderLayout.CENTER);
	    gui.getContentPane().validate();
	    gui.getContentPane().repaint();
  	} catch (Exception e) {
	    ierr(" error in dpd main frame");
        }	
    } 

    void lbe() {
	lbeUpdatePan0();
    }

    void dpd() {
	dpdUpdatePan0();
    }
    
    void sph() {
  	try{
	    gui.getContentPane().invalidate();
	    gui.getContentPane().removeAll();
	    gui.getContentPane().add(gui.rowtop, BorderLayout.NORTH);
	    gui.getContentPane().add(gui.rowdown, BorderLayout.CENTER);
	    gui.getContentPane().validate();
	    gui.getContentPane().repaint();
  	} catch (Exception e) {
	    ierr(" error in sph main frame");
        }
	ierr(" sph component not ready ");
    }

    void help() {
      	ierr(" visit the DL_MESO website at www.ccp5.ac.uk/DL_MESO/ ");
    }

    void manual() {
	try {
	    Process p = Runtime.getRuntime().
		exec("acroread usermanual.pdf");	    
        } catch (IOException e) {
	    ierr(" cannot find acroread: "+
                 "open usermanual.pdf manually ");
	}
    }    

    void lbeUpdatePan0(){
	lbegui = new dllbe();
  	try{
	    gui.getContentPane().invalidate();
	    gui.getContentPane().removeAll();
	    gui.getContentPane().add(gui.rowtop, BorderLayout.NORTH);
	    gui.getContentPane().add(lbegui, BorderLayout.WEST);
	    gui.getContentPane().validate();
	    gui.getContentPane().repaint();
  	} catch (Exception e) {
	    ierr(" error in lbe main frame");
        }	
    } 

    void lbeUpdatePan(Component cc){
  	try{
	    gui.getContentPane().invalidate();
	    gui.getContentPane().removeAll();
	    gui.getContentPane().add(gui.rowtop, BorderLayout.NORTH);
	    gui.getContentPane().add(lbegui, BorderLayout.WEST);
	    gui.getContentPane().add(cc, BorderLayout.CENTER);
	    gui.getContentPane().validate();
	    gui.getContentPane().repaint();
  	} catch (Exception e) {
	    System.out.println("error in lbe main frame");
        }	
    } 

    void dpdUpdatePan0(){
	dpdgui = new dldpd();
  	try{
	    gui.getContentPane().invalidate();
	    gui.getContentPane().removeAll();
	    gui.getContentPane().add(gui.rowtop, BorderLayout.NORTH);
	    gui.getContentPane().add(dpdgui, BorderLayout.WEST);
	    gui.getContentPane().validate();
	    gui.getContentPane().repaint();
  	} catch (Exception e) {
	    ierr(" error in dpd main frame");
        }	
    } 

    void dpdUpdatePan(Component cc){
  	try{
	    gui.getContentPane().invalidate();
	    gui.getContentPane().removeAll();
	    gui.getContentPane().add(gui.rowtop, BorderLayout.NORTH);
	    gui.getContentPane().add(dpdgui, BorderLayout.WEST);
	    gui.getContentPane().add(cc, BorderLayout.CENTER);
	    gui.getContentPane().validate();
	    gui.getContentPane().repaint();
  	} catch (Exception e) {
	    System.out.println("error in dpd main frame");
        }	
    } 

    void ierr(String errinfo) {
      msgPanel fcer=new msgPanel(errinfo);	
    }
    
}
