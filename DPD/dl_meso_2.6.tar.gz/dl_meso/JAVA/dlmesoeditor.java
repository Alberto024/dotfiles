import javax.swing.*;
import java.util.*;
import java.lang.*;
import java.io.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.geom.*;
import java.awt.image.*;
/*
 *     DL_MESO_GUI
 *     author: R. S. Qin, M. A. Seaton
 *     copyright: STFC Daresbury Laboratory and CCP5
 *     2005, 2012
 */
class dlmesoeditor extends JFrame {

    dlmesoeditEvt dlgui = new dlmesoeditEvt(this);

    Font font=new Font("Monospaced", Font.PLAIN, 12);
    Color paneltop=new Color(170, 170, 230);
//    JPanel row1 = new JPanel();
    JPanel row2 = new JPanel();
    JTextArea text = new JTextArea(30, 80);
    JButton save = new JButton("save");
    JButton clos = new JButton("exit");
    static String filecont, filename;
    public dlmesoeditor(String str1) {
	super("DL_MESO Editor  "+str1);
	setBounds(180, 50, 620, 530);
	Container pane=getContentPane();
	BorderLayout bl = new BorderLayout();
	FlowLayout fl = new FlowLayout();
	pane.setLayout(bl);
//	row1.setBackground(paneltop);
//	row1.setOpaque(true);
	text.setFont(font);
	text.setLineWrap(true);
	text.setWrapStyleWord(true);
	JScrollPane scroll = new JScrollPane(text, 
	JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED,
	JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
	filename = str1;
	try {
	    File openFile=new File(str1);    
	    FileInputStream file=new FileInputStream(openFile);
	    int size=(int)openFile.length();
	    byte[] allpara=new byte[size];
	    file.read(allpara);
	    filecont=new String(allpara);
	    text.setText(filecont);
	} catch (Exception e) {
	    System.out.println("opening "+ str1+" failed \n"); 
	}
//	pane.add(row1, BorderLayout.NORTH);
	pane.add(scroll, BorderLayout.CENTER);
	row2.setLayout(fl);
	save.addActionListener(dlgui);
	clos.addActionListener(dlgui);
	row2.add(save);
	row2.add(clos);
	pane.add(row2, BorderLayout.SOUTH);
	setContentPane(pane);
	setVisible(true);	
    }

}
