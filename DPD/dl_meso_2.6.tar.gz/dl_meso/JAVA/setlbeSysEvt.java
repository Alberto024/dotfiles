import javax.swing.*;
import java.util.*;
import java.lang.*;
import java.io.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.geom.*;
import java.awt.image.*;
/*
 *     DL_MESO_GUI
 *     author: R. S. Qin, M. A. Seaton
 *     copyright: STFC Daresbury Laboratory and CCP5
 *     2005, 2015
 */
class setlbeSysEvt implements ItemListener, ActionListener {
    
    static setlbeSys inigui;
    setFluid fg; 
	setFluidInteract ig;
    setSolute sg;
    setThermal tg;
    FileWriter ot;
    Scanner in,in2;
    String filename="lbin.sys";
    int xint;
    double xdouble;
    lbesysdim dim = new lbesysdim();
    static int lbd=2, lbq=9, lbf=1, lbc=0, lbt=0, lbp=0, lbincomp=0;
    static int istate=0, collide=0, interact=0, outtype=0, outansi=0, eoscrit=0;
    static double bdf[] = new double[6*3];
    static double bousf[] = new double[6*3];
    static double densf[] = new double[6*8];
    static double relaxtime[] = new double[6*2];
    static double fluidinteract[] = new double[6*6];
    static double wallinteract[] = new double[6];
    static int eos[] = new int[6];
    static double eosa[] = new double[6];
    static double eosb[] = new double[6];
    static double acentric[] = new double[6];
    static double psi0[] = new double[6];
    static int wettyp[] = new int[6];

    static double quadw[] = new double[6];
    static double segregate;
    static double concs[] = new double[6*7];
    static double solrelax[] = new double[6];
    static double temps[] = new double[7];
    static double heatrates[] = new double[7];
    static double heatrelax,boustemph,boustempl;
    static double mobrelax,mobility,fekappa;
    static double tempsys,gascon;
   
    public setlbeSysEvt(setlbeSys ini) {
        istate=0;
        java.util.Arrays.fill(bdf, 0.0);
        java.util.Arrays.fill(bousf, 0.0);
        java.util.Arrays.fill(densf, 0.0);
        for (int i=0; i<6; i++) {
          densf[i*8] = 1.0;
          densf[i*8+1] = 1.0;
        }
        java.util.Arrays.fill(relaxtime, 1.0);
        java.util.Arrays.fill(fluidinteract, 0.0);
        java.util.Arrays.fill(wallinteract, 0.0);
        java.util.Arrays.fill(eosa, 0.0);
        java.util.Arrays.fill(eosb, 0.0);
        java.util.Arrays.fill(acentric, 0.0);
        java.util.Arrays.fill(psi0, 0.0);
        segregate = 0.0;
        tempsys=1.0;
        gascon=1.0;
        mobrelax=1.0;
        mobility=1.0;
        java.util.Arrays.fill(concs, 0.0);
        java.util.Arrays.fill(solrelax, 1.0);
        java.util.Arrays.fill(temps, 0.0);
        java.util.Arrays.fill(heatrates, 0.0);
        heatrelax = 1.0;
        boustemph = 1.0;
        boustempl = 0.0;
	inigui=ini;	
    }

    public setlbeSysEvt(setFluid fluini) {
	fg=fluini;
    }

    public setlbeSysEvt(setFluidInteract fluinterini) {
	ig=fluinterini;
    }

    public setlbeSysEvt(setSolute solini) {
	sg=solini;
    }

    public setlbeSysEvt(setThermal theini) {
	tg=theini;
    }

    public void actionPerformed(ActionEvent event) {
	String cmd =event.getActionCommand();

	if (cmd == "set fluid parameters") {
	    try {
			lbf = Integer.parseInt(inigui.fluidn.getText());
			try{
				lbc = Integer.parseInt(inigui.solutn.getText());
			} catch (NumberFormatException ecc) {
				lbc = 0;
			}
			if((lbc > 0) && (lbf > 1))
				ierr(" you cannot have "+lbc+" solutes and "+lbf+" fluids ");	
  	        else if((lbf<0) || (lbf>6)) 
				ierr("  number of fluids should be between 1 to 6  ");
            else if((interact==3 || interact==4) && lbf<2)
                ierr(" at least 2 fluids needed for Lishchuk interactions ");
            else if(interact==5 && lbf>2)
                ierr(" no more than 2 fluids possible for Swift interactions ");
	        else {
				if(inigui.yesincomp.isSelected())
					lbincomp = 1;
                else
					lbincomp = 0;
				if((lbf > 1) && (lbf < 7))
					setfluitparameter(lbf,lbd,interact,bdf,bousf,densf,relaxtime);
				else if(lbf == 1)
					setfluitparameter(lbf,lbd,interact,bdf,bousf,densf,relaxtime);
	        }	
	    } catch (NumberFormatException e) {
			ierr(" expecting an integer number ");
	    }
	}
	
	else if (cmd == "set fluid interactions") {
	    try {
			lbf = Integer.parseInt(inigui.fluidn.getText());
			try{
				lbc = Integer.parseInt(inigui.solutn.getText());
			} catch (NumberFormatException ecc) {
				lbc = 0;
			}
			if((lbc > 0) && (lbf > 1))
				ierr(" you cannot have "+lbc+" solutes and "+lbf+" fluids ");	
  	        else if((lbf<0) || (lbf>6)) 
				ierr("  number of fluids should be between 1 to 6  ");
            else if((interact==3 || interact==4) && lbf<2)
                ierr(" at least 2 fluids needed for Lishchuk interactions ");
            else if(interact==5 && lbf>2)
                ierr(" no more than 2 fluids possible for Swift interactions ");
	        else {
				if(inigui.yesincomp.isSelected())
					lbincomp = 1;
                else
					lbincomp = 0;
				if((lbf > 1) && (lbf < 7))
					setfluitintparameter(lbf,interact,fluidinteract,eos,eoscrit,eosa,eosb,acentric,psi0,quadw,wettyp,wallinteract,segregate,gascon,tempsys,fekappa,mobrelax,mobility);
				else if(lbf == 1)
					setfluitintparameter(lbf,interact,fluidinteract,eos,eoscrit,eosa,eosb,acentric,psi0,quadw,wettyp,wallinteract,segregate,gascon,tempsys,fekappa,mobrelax,mobility);
			}
	    } catch (NumberFormatException e) {
			ierr(" expecting an integer number ");
	    }
	}

	else if (cmd == "set solute parameters") {
	    try {
                lbf = Integer.parseInt(inigui.fluidn.getText());
		lbc = Integer.parseInt(inigui.solutn.getText());
                if(lbf >1)
                    ierr(" error: number of fluid phases = "+lbf);
 	        else if((lbc<0) || (lbc>6))
		    ierr("number of solutes should be between 0 and 6");
		else if(lbc == 0)
                     ierr("no solute parameters needed");
	        else{
		    setsoluteparameter(lbc,lbd,solrelax,concs);
	        }
	    } catch (NumberFormatException e) {
		ierr(" expecting an integer number ");
	    }
	}

	else if (cmd == "set thermal parameters") {
	    try {
                if (inigui.yest.isSelected())
                  lbt = 1;
                else {
                  lbt = 0;
                }
                if(lbt == 0)
                     ierr("no thermal parameters needed");
	        else{
		    setthermalparameter(lbd,heatrelax,boustemph,boustempl,temps,heatrates);
	        }
	    } catch (NumberFormatException e) {
		ierr(" expecting an integer number ");
	    }
	}

	else if (cmd == "OPEN") {
	    openlbe();	    
	}

	else if (cmd == "SAVE") {
	    savelbe();	    
	}

	else if (cmd == "SAVE F") {
        saveflu();
    }

	else if (cmd == "SAVE FI") {
        savefluint();
    }

	else if (cmd == "SAVE C") {
	    savesol();
	}

	else if (cmd == "SAVE T") {
        savethe();
	}

	else if (cmd == "CANCEL F") {
	    fg.dispose();
	}

	else if (cmd == "CANCEL FI") {
	    ig.dispose();
	}

	else if (cmd == "CANCEL C") {
	    sg.dispose();
	}

	else if (cmd == "CANCEL T") {
	    tg.dispose();
	}

    }

    void  saveflu() {
        int i, j, k;
	    try {
			for(i=0; i<lbf; i++) {
				j = i * 3;
				bdf[j]=Double.parseDouble(fg.xforce[i].getText());
				j = i * 3 + 1;
				bdf[j]=Double.parseDouble(fg.yforce[i].getText());
				j = i * 3 + 2;
				bdf[j]=Double.parseDouble(fg.zforce[i].getText());
			}
			for(i=0; i<lbf; i++) {
				j = i * 3;
				bousf[j]=Double.parseDouble(fg.bousxforce[i].getText());
				j = i * 3 + 1;
				bousf[j]=Double.parseDouble(fg.bousyforce[i].getText());
				j = i * 3 + 2;
				bousf[j]=Double.parseDouble(fg.bouszforce[i].getText());
			}
			for(i=0; i<lbf; i++) {
				densf[8*i]=Double.parseDouble(fg.inidensity[i].getText());
				densf[8*i+1]=Double.parseDouble(fg.cstdensity[i].getText());
				densf[8*i+2] =Double.parseDouble(fg.topdensity[i].getText());
				densf[8*i+3] =Double.parseDouble(fg.dowdensity[i].getText());
				densf[8*i+4] =Double.parseDouble(fg.lefdensity[i].getText());
				densf[8*i+5] =Double.parseDouble(fg.rigdensity[i].getText());
				densf[8*i+6] =Double.parseDouble(fg.frodensity[i].getText());
				densf[8*i+7] =Double.parseDouble(fg.bacdensity[i].getText());
			}
			for(i=0; i<lbf; i++) {
				relaxtime[2*i] =Double.parseDouble(fg.viscosities[i].getText());
				relaxtime[2*i+1] =Double.parseDouble(fg.bulkviscosities[i].getText());
			}
			fg.dispose();
        } catch (NumberFormatException enfl) {
			ierr(" fluid parameter: format error or no value ");
	    }
    }

    void  savefluint() {
        int i, j, k, ii;
	    try {
            if(interact==1 || interact==2) {
                for(i=0; i<lbf; i++) {
                    for(j=0; j<lbf; j++) {
                        if(j >= i) {
                            xdouble = Double.parseDouble(ig.interactions[i*lbf+j].getText());
                        }
                        else {
                            xdouble = Double.parseDouble(ig.interactions[j*lbf+i].getText());
                        }
                        k = i*lbf + j;
                        fluidinteract[k] = xdouble;
                    }
                }
            }
            else if(interact==3 || interact==4) {
                for(i=0; i<lbf; i++) {
                    for(j=0; j<lbf; j++) {
                        if(j > i) {
                            xdouble = Double.parseDouble(ig.interactions[i*lbf+j].getText());
                            k = i*lbf + j;
                            fluidinteract[k] = xdouble;
                        }
                        else if (j < i) {
                            xdouble = Double.parseDouble(ig.interactions[j*lbf+i].getText());
                            k = i*lbf + j;
                            fluidinteract[k] = xdouble;
                        }
                    }
                }
            }
			if(interact==2){
				for(i=0; i<lbf; i++) {
					quadw[i] = Double.parseDouble(ig.quadweight[i].getText());
				}
			}
			if(interact==1 || interact==2) {
				for(i=0; i<lbf; i++) {
                    eos[i] = ig.fluid[i].getSelectedIndex();
                    eosa[i] = Double.parseDouble(ig.eosabox[i].getText());
                    eosb[i] = Double.parseDouble(ig.eosbbox[i].getText());
                    acentric[i] = Double.parseDouble(ig.acentricbox[i].getText());
                    psi0[i] = Double.parseDouble(ig.psi0box[i].getText());
                    wettyp[i] = ig.wet[i].getSelectedIndex();
				}
                wallinteract[0] = Double.parseDouble(ig.wallinteractions0.getText());
                wallinteract[1] = Double.parseDouble(ig.wallinteractions1.getText());
                wallinteract[2] = Double.parseDouble(ig.wallinteractions2.getText());
                wallinteract[3] = Double.parseDouble(ig.wallinteractions3.getText());
                wallinteract[4] = Double.parseDouble(ig.wallinteractions4.getText());
                wallinteract[5] = Double.parseDouble(ig.wallinteractions5.getText());
                gascon = Double.parseDouble(ig.gasconst.getText());
                tempsys = Double.parseDouble(ig.systemp.getText());
			}
			if(interact==3 || interact==4)
				segregate = Double.parseDouble(ig.segregation.getText());
            if(interact==5) {
                eos[0] = ig.fluid[0].getSelectedIndex();
                eosa[0] = Double.parseDouble(ig.eosabox[0].getText());
                eosb[0] = Double.parseDouble(ig.eosbbox[0].getText());
                acentric[0] = Double.parseDouble(ig.acentricbox[0].getText());
                fekappa = Double.parseDouble(ig.eosabox[2].getText());
                wettyp[0] = ig.wet[0].getSelectedIndex();
                wallinteract[0] = Double.parseDouble(ig.wallinteractions0.getText());
                wallinteract[1] = Double.parseDouble(ig.wallinteractions1.getText());
                if(lbf>1) {
                    eos[1] = ig.fluid[1].getSelectedIndex();
                    eosa[1] = Double.parseDouble(ig.eosabox[1].getText());
                    eosb[1] = Double.parseDouble(ig.eosbbox[1].getText());
                    wallinteract[2] = Double.parseDouble(ig.wallinteractions2.getText());
                    wallinteract[3] = Double.parseDouble(ig.wallinteractions3.getText());
                    mobrelax = Double.parseDouble(ig.eosabox[4].getText());
                    mobility = Double.parseDouble(ig.eosbbox[4].getText());
                }
                gascon = Double.parseDouble(ig.gasconst.getText());
                tempsys = Double.parseDouble(ig.systemp.getText());
            }

			ig.dispose();
		} catch (NumberFormatException enfl) {
			ierr(" fluid interaction parameter: format error or no value ");
		}
	}

    void  savesol() {
        int i, j;
	    try {
           for(i=0; i<lbc; i++) {
	         concs[7*i] =Double.parseDouble(sg.iniconcen[i].getText());
	         concs[7*i+1] =Double.parseDouble(sg.topconcen[i].getText());
	         concs[7*i+2] =Double.parseDouble(sg.dowconcen[i].getText());
	         concs[7*i+3] =Double.parseDouble(sg.lefconcen[i].getText());
	         concs[7*i+4] =Double.parseDouble(sg.rigconcen[i].getText());
	         concs[7*i+5] =Double.parseDouble(sg.froconcen[i].getText());
	         concs[7*i+6] =Double.parseDouble(sg.bacconcen[i].getText());
           }
           for(i=0; i<lbc; i++) {
	         solrelax[i] =Double.parseDouble(sg.diffusivities[i].getText());
           }
	       sg.dispose();
	    } catch (NumberFormatException enfc) {
	      ierr(" solute parameter: format error or no value ");
	    }
    }

    void  savethe() {
        int i, j;
  	    try {
	        heatrelax = Double.parseDouble(tg.difut.getText());
            boustemph = Double.parseDouble(tg.boushigh.getText());
            boustempl = Double.parseDouble(tg.bouslow.getText());
	        temps[0] = Double.parseDouble(tg.init.getText());
	        heatrates[0] = Double.parseDouble(tg.inidt.getText());
	        temps[1] = Double.parseDouble(tg.upt.getText());
	        heatrates[1] = Double.parseDouble(tg.updt.getText());
	        temps[2] = Double.parseDouble(tg.downt.getText());
	        heatrates[2] = Double.parseDouble(tg.downdt.getText());
	        temps[3] = Double.parseDouble(tg.leftt.getText());
	        heatrates[3] = Double.parseDouble(tg.leftdt.getText());
	        temps[4] = Double.parseDouble(tg.rightt.getText());
	        heatrates[4] = Double.parseDouble(tg.rightdt.getText());
	        temps[5] = Double.parseDouble(tg.frontt.getText());
	        heatrates[5] = Double.parseDouble(tg.frontdt.getText());
	        temps[6] = Double.parseDouble(tg.backt.getText());
	        heatrates[6] = Double.parseDouble(tg.backdt.getText());
            tg.dispose();
	    } catch (NumberFormatException enfc) {
	        ierr(" thermal parameter: format error or no value ");
	    }
    }

    void  savelbe() {
        int i, j, k;
        Boolean gs;
	    try {
            if(istate == 0){
              ot = new FileWriter(filename, false);
              istate =1;
            }
            else
	          ot = new FileWriter(filename, true);
            lbf = Integer.parseInt(inigui.fluidn.getText());
           
	    } catch (IOException e) {
            ierr(" cannot create "+filename+" file ");
     	    try{
	          lbc = Integer.parseInt(inigui.solutn.getText());
	        } catch (NumberFormatException ecc) {
	          lbc = 0;
	        }
            if((lbc > 0) && (lbf > 1))
	          ierr(" you cannot have "+lbc+" solutes and "+lbf+" fluids ");
  	        else if((lbf<0) || (lbf>6))
	          ierr("  number of fluids should be between 1 to 6  ");
            else if((interact==3 || interact==4) && lbf<2)
              ierr(" ");
	        else {
              if(inigui.yesincomp.isSelected())
                lbincomp = 1;
              else
                lbincomp = 0;
	        }
        }
	    try {
            // simulation properties
            ot.write("space_dimension              "+lbd+"\n");
	        dim.lbd = lbd;
            ot.write("discrete_speed               "+lbq+"\n");
            ot.write("number_of_fluid              "+lbf+"\n");
            ot.write("number_of_solute             "+lbc+"\n");
            ot.write("temperature_scalar           "+lbt+"\n");
            ot.write("phase_field                  "+lbp+"\n");
            ot.write("incompressible_fluids        "+lbincomp+"\n");
            switch (collide)
            {
              case 0:
                ot.write("collision_type               BGK\n");
                break;
              case 1:
                ot.write("collision_type               BGKEDM\n");
                break;
              case 2:
                ot.write("collision_type               BGKGuo\n");
                break;
              case 3:
                ot.write("collision_type               TRT\n");
  	            xdouble = Double.parseDouble(inigui.trtmagic.getText());
                ot.write("trt_magic_number             "+xdouble+"\n");
                break;
              case 4:
                ot.write("collision_type               TRTEDM\n");
  	            xdouble = Double.parseDouble(inigui.trtmagic.getText());
                ot.write("trt_magic_number             "+xdouble+"\n");
                break;
              case 5:
                ot.write("collision_type               TRTGuo\n");
  	            xdouble = Double.parseDouble(inigui.trtmagic.getText());
                ot.write("trt_magic_number             "+xdouble+"\n");
                break;
              case 6:
                ot.write("collision_type               MRT\n");
                break;
              case 7:
                ot.write("collision_type               MRTEDM\n");
                break;
              case 8:
                ot.write("collision_type               MRTGuo\n");
                break;
            }
            switch (interact)
            {
              case 1:
                ot.write("interaction_type             ShanChen\n");
                break;
              case 2:
                ot.write("interaction_type             ShanChenQuadratic\n");
                break;
              case 3:
                ot.write("interaction_type             Lishchuk\n");
                break;
              case 4:
                ot.write("interaction_type             LishchukLocal\n");
                break;
              case 5:
                ot.write("interaction_type             Swift\n");
                break;
            }
            switch (outtype)
            {
              case 0:
                ot.write("output_format                VTK\n");
                break;
              case 1:
                ot.write("output_format                LegacyVTK\n");
                break;
              case 2:
                ot.write("output_format                Plot3D\n");
                break;
            }
            switch (outansi)
            {
              case 0:
                ot.write("output_type                  Binary\n");
                break;
              case 1:
                ot.write("output_type                  ANSI\n");
                break;
            }
            // system properties (read directly from window)
            xint = Integer.parseInt(inigui.totx.getText());
            ot.write("grid_number_x                "+xint+"\n");
	        dim.lbnx = xint;
            xint = Integer.parseInt(inigui.toty.getText());
            ot.write("grid_number_y                "+xint+"\n");
	        dim.lbny = xint;
	        xint = Integer.parseInt(inigui.totz.getText());
            ot.write("grid_number_z                "+xint+"\n");
	        dim.lbnz = xint;
            xint = Integer.parseInt(inigui.bwid.getText());
            ot.write("domain_boundary_width        "+xint+"\n");
	        xint = Integer.parseInt(inigui.tott.getText());
            ot.write("total_step                   "+xint+"\n");
	        xint = Integer.parseInt(inigui.equt.getText());
            ot.write("equilibration_step           "+xint+"\n");
	        xint = Integer.parseInt(inigui.savet.getText());
            ot.write("save_span                    "+xint+"\n");
	        xdouble =Double.parseDouble(inigui.noiei.getText());
            ot.write("noise_intensity              "+xdouble+"\n");
	        xdouble = Double.parseDouble(inigui.soundv.getText());
            ot.write("sound_speed                  "+xdouble+"\n");
	        xdouble = Double.parseDouble(inigui.kineticv.getText());
            ot.write("kinetic_viscosity            "+xdouble+"\n");
	        xdouble =Double.parseDouble(inigui.topvx.getText());
            ot.write("speed_top_0                  "+xdouble+"\n");
	        xdouble =Double.parseDouble(inigui.topvy.getText());
            ot.write("speed_top_1                  "+xdouble+"\n");
	        xdouble =Double.parseDouble(inigui.topvz.getText());
            if(lbd==2)
              xdouble = 0.0;
            ot.write("speed_top_2                  "+xdouble+"\n");
	        xdouble =Double.parseDouble(inigui.dowvx.getText());
            ot.write("speed_bot_0                  "+xdouble+"\n");
	        xdouble =Double.parseDouble(inigui.dowvy.getText());
            ot.write("speed_bot_1                  "+xdouble+"\n");
	        xdouble =Double.parseDouble(inigui.dowvz.getText());
            if(lbd==2)
              xdouble = 0.0;
            ot.write("speed_bot_2                  "+xdouble+"\n");
	        xdouble =Double.parseDouble(inigui.lefvx.getText());
            ot.write("speed_lef_0                  "+xdouble+"\n");
	        xdouble =Double.parseDouble(inigui.lefvy.getText());
            ot.write("speed_lef_1                  "+xdouble+"\n");
	        xdouble =Double.parseDouble(inigui.lefvz.getText());
            if(lbd==2)
              xdouble = 0.0;
            ot.write("speed_lef_2                  "+xdouble+"\n");
	        xdouble =Double.parseDouble(inigui.rigvx.getText());
            ot.write("speed_rig_0                  "+xdouble+"\n");
	        xdouble =Double.parseDouble(inigui.rigvy.getText());
            ot.write("speed_rig_1                  "+xdouble+"\n");
	        xdouble =Double.parseDouble(inigui.rigvz.getText());
            ot.write("speed_rig_2                  "+xdouble+"\n");
            if(lbd==2)
              xdouble = 0.0;
            xdouble =Double.parseDouble(inigui.frovx.getText());
            if(lbd==2)
              xdouble = 0.0;
            ot.write("speed_fro_0                  "+xdouble+"\n");
	        xdouble =Double.parseDouble(inigui.frovy.getText());
            if(lbd==2)
              xdouble = 0.0;
            ot.write("speed_fro_1                  "+xdouble+"\n");
	        xdouble =Double.parseDouble(inigui.frovz.getText());
            if(lbd==2)
              xdouble = 0.0;
            ot.write("speed_fro_2                  "+xdouble+"\n");
	        xdouble =Double.parseDouble(inigui.bacvx.getText());
            if(lbd==2)
              xdouble = 0.0;
            ot.write("speed_bac_0                  "+xdouble+"\n");
	        xdouble =Double.parseDouble(inigui.bacvy.getText());
            if(lbd==2)
              xdouble = 0.0;
            ot.write("speed_bac_1                  "+xdouble+"\n");
	        xdouble =Double.parseDouble(inigui.bacvz.getText());
            if(lbd==2)
              xdouble = 0.0;
            ot.write("speed_bac_2                  "+xdouble+"\n");
            // fluid properties
            for(i=0; i<lbf; i++) {
              j = i * 3;
              ot.write("body_force_"+j+"                 "+bdf[j]+"\n");
              j = i * 3 + 1;
              ot.write("body_force_"+j+"                 "+bdf[j]+"\n");
              j = i * 3 + 2;
              ot.write("body_force_"+j+"                 "+bdf[j]+"\n");
            }
            for(i=0; i<lbf; i++) {
              j = i * 3;
              ot.write("boussinesq_force_"+j+"           "+bousf[j]+"\n");
              j = i * 3 + 1;
              ot.write("boussinesq_force_"+j+"           "+bousf[j]+"\n");
              j = i * 3 + 2;
              ot.write("boussinesq_force_"+j+"           "+bousf[j]+"\n");
            }
            for(i=0; i<lbf; i++) {
              ot.write("density_ini_"+i+"                "+densf[8*i]+"\n");
            }
            if (lbincomp>0 || interact>0) {
              for(i=0; i<lbf; i++) {
                ot.write("density_inc_"+i+"                "+densf[8*i+1]+"\n");
              }
            }
            for(i=0; i<lbf; i++) { 
              ot.write("density_top_"+i+"                "+densf[8*i+2]+"\n");
              ot.write("density_bot_"+i+"                "+densf[8*i+3]+"\n");
              ot.write("density_lef_"+i+"                "+densf[8*i+4]+"\n");
              ot.write("density_rig_"+i+"                "+densf[8*i+5]+"\n");
              ot.write("density_fro_"+i+"                "+densf[8*i+6]+"\n");
              ot.write("density_bac_"+i+"                "+densf[8*i+7]+"\n");
	        }
            for(i=0; i<lbf; i++) { 
              ot.write("relaxation_fluid_"+i+"           "+relaxtime[2*i]+"\n");
              ot.write("bulk_relaxation_fluid_"+i+"      "+relaxtime[2*i+1]+"\n");
	        }
            if(interact==1 || interact==2 || interact==3 || interact==4) {
                for(i=0; i<lbf; i++) {
                    for(j=0; j<lbf; j++) {
                        k = i*lbf + j;
                        ot.write("interaction_"+k+"                "+fluidinteract[k]+"\n");
                    }
                }
            }
            if(interact==1 || interact==2) {
              gs = false;
              for(i=0; i<lbf; i++) {
                xint = eos[i];
                switch (xint) {
                    case 0:
                        ot.write("potential_type_"+i+"             IdealLattice\n");
                        break;
                    case 1:
                        ot.write("potential_type_"+i+"             ShanChen1993\n");
                        break;
                    case 2:
                        ot.write("potential_type_"+i+"             ShanChen1994\n");
                        ot.write("shanchen_psi0_"+i+"              "+psi0[i]+"\n");
                        break;
                    case 3:
                        ot.write("potential_type_"+i+"             Rho\n");
                        break;
                    case 4:
                        ot.write("potential_type_"+i+"             Ideal\n");
                        gs = true;
                        break;
                    case 5:
                        ot.write("potential_type_"+i+"             vanderWaals\n");
                        if(eoscrit==0) {
                            ot.write("eos_parameter_a_"+i+"            "+eosa[i]+"\n");
                            ot.write("eos_parameter_b_"+i+"            "+eosb[i]+"\n");
                        }
                        else {
                            ot.write("critical_temperature_"+i+"       "+eosa[i]+"\n");
                            ot.write("critical_pressure_"+i+"          "+eosb[i]+"\n");
                        }
                        gs = true;
                        break;
                    case 6:
                        ot.write("potential_type_"+i+"             RedlichKwong\n");
                        if(eoscrit==0) {
                            ot.write("eos_parameter_a_"+i+"            "+eosa[i]+"\n");
                            ot.write("eos_parameter_b_"+i+"            "+eosb[i]+"\n");
                        }
                        else {
                            ot.write("critical_temperature_"+i+"       "+eosa[i]+"\n");
                            ot.write("critical_pressure_"+i+"          "+eosb[i]+"\n");
                        }
                        gs = true;
                        break;
                    case 7:
                        ot.write("potential_type_"+i+"             SoaveRedlichKwong\n");
                        if(eoscrit==0) {
                            ot.write("eos_parameter_a_"+i+"            "+eosa[i]+"\n");
                            ot.write("eos_parameter_b_"+i+"            "+eosb[i]+"\n");
                        }
                        else {
                            ot.write("critical_temperature_"+i+"       "+eosa[i]+"\n");
                            ot.write("critical_pressure_"+i+"          "+eosb[i]+"\n");
                        }
                        ot.write("acentric_factor_"+i+"            "+acentric[i]+"\n");
                        gs = true;
                        break;
                    case 8:
                        ot.write("potential_type_"+i+"             PengRobinson\n");
                        if(eoscrit==0) {
                            ot.write("eos_parameter_a_"+i+"            "+eosa[i]+"\n");
                            ot.write("eos_parameter_b_"+i+"            "+eosb[i]+"\n");
                        }
                        else {
                            ot.write("critical_temperature_"+i+"       "+eosa[i]+"\n");
                            ot.write("critical_pressure_"+i+"          "+eosb[i]+"\n");
                        }
                        ot.write("acentric_factor_"+i+"            "+acentric[i]+"\n");
                        gs = true;
                        break;
                    case 9:
                        ot.write("potential_type_"+i+"             CarnahanStarlingvanderWaals\n");
                        if(eoscrit==0) {
                            ot.write("eos_parameter_a_"+i+"            "+eosa[i]+"\n");
                            ot.write("eos_parameter_b_"+i+"            "+eosb[i]+"\n");
                        }
                        else {
                            ot.write("critical_temperature_"+i+"       "+eosa[i]+"\n");
                            ot.write("critical_pressure_"+i+"          "+eosb[i]+"\n");
                        }
                        gs = true;
                        break;
                    case 10:
                        ot.write("potential_type_"+i+"             CarnahanStarlingRedlichKwong\n");
                        if(eoscrit==0) {
                            ot.write("eos_parameter_a_"+i+"            "+eosa[i]+"\n");
                            ot.write("eos_parameter_b_"+i+"            "+eosb[i]+"\n");
                        }
                        else {
                            ot.write("critical_temperature_"+i+"       "+eosa[i]+"\n");
                            ot.write("critical_pressure_"+i+"          "+eosb[i]+"\n");
                        }
                        gs = true;
                        break;
                }
                if(interact==2) ot.write("quadratic_weight_"+(i*lbf+i)+"          "+quadw[i]+"\n");
                xint = wettyp[i];
                switch (xint) {
                    case 0:
                        ot.write("wetting_type_"+i+"               Density\n");
                        break;
                    case 1:
                        ot.write("wetting_type_"+i+"               Potential\n");
                        break;
                    case 2:
                        ot.write("wetting_type_"+i+"               ScreenedPotential\n");
                        break;
                }
                ot.write("wall_interaction_"+i+"           "+wallinteract[i]+"\n");
              }
              if(gs) ot.write("gas_constant                 "+gascon+"\n");
              if(gs && lbt==0) ot.write("temperature_system           "+tempsys+"\n");
            }
            if(interact==3 || interact==4) {
              ot.write("segregation                  "+segregate+"\n");
            }
            if(interact==5) {
                xint = eos[0];
                switch (xint) {
                    case 0:
                        ot.write("equation_of_state            IdealLattice\n");
                        break;
                    case 1:
                        ot.write("equation_of_state            ShanChen1993\n");
                        ot.write("eos_parameter_a              "+eosa[0]+"\n");
                        break;
                    case 2:
                        ot.write("equation_of_state            ShanChen1994\n");
                        ot.write("eos_parameter_a              "+eosa[0]+"\n");
                        ot.write("shanchen_psi0_0              "+eosb[0]+"\n");
                        break;
                    case 3:
                        ot.write("equation_of_state            Rho\n");
                        ot.write("eos_parameter_a              "+eosa[0]+"\n");
                        break;
                    case 4:
                        ot.write("equation_of_state            Ideal\n");
                        break;
                    case 5:
                        ot.write("equation_of_state            vanderWaals\n");
                        if(eoscrit==0) {
                            ot.write("eos_parameter_a              "+eosa[0]+"\n");
                            ot.write("eos_parameter_b              "+eosb[0]+"\n");
                        }
                        else {
                            ot.write("critical_temperature_0       "+eosa[0]+"\n");
                            ot.write("critical_pressure_0          "+eosb[0]+"\n");
                        }
                        break;
                    case 6:
                        ot.write("equation_of_state            RedlichKwong\n");
                        if(eoscrit==0) {
                            ot.write("eos_parameter_a              "+eosa[0]+"\n");
                            ot.write("eos_parameter_b              "+eosb[0]+"\n");
                        }
                        else {
                            ot.write("critical_temperature_0       "+eosa[0]+"\n");
                            ot.write("critical_pressure_0          "+eosb[0]+"\n");
                        }
                        break;
                    case 7:
                        ot.write("equation_of_state            SoaveRedlichKwong\n");
                        if(eoscrit==0) {
                            ot.write("eos_parameter_a              "+eosa[0]+"\n");
                            ot.write("eos_parameter_b              "+eosb[0]+"\n");
                        }
                        else {
                            ot.write("critical_temperature_0       "+eosa[0]+"\n");
                            ot.write("critical_pressure_0          "+eosb[0]+"\n");
                        }
                        ot.write("acentric_factor_0            "+acentric[0]+"\n");
                        break;
                    case 8:
                        ot.write("equation_of_state            PengRobinson\n");
                        if(eoscrit==0) {
                            ot.write("eos_parameter_a              "+eosa[0]+"\n");
                            ot.write("eos_parameter_b              "+eosb[0]+"\n");
                        }
                        else {
                            ot.write("critical_temperature_0       "+eosa[0]+"\n");
                            ot.write("critical_pressure_0          "+eosb[0]+"\n");
                        }
                        ot.write("acentric_factor_0            "+acentric[0]+"\n");
                        break;
                    case 9:
                        ot.write("equation_of_state            CarnahanStarlingvanderWaals\n");
                        if(eoscrit==0) {
                            ot.write("eos_parameter_a              "+eosa[0]+"\n");
                            ot.write("eos_parameter_b              "+eosb[0]+"\n");
                        }
                        else {
                            ot.write("critical_temperature_0       "+eosa[0]+"\n");
                            ot.write("critical_pressure_0          "+eosb[0]+"\n");
                        }
                        break;
                    case 10:
                        ot.write("equation_of_state            CarnahanStarlingRedlichKwong\n");
                        if(eoscrit==0) {
                            ot.write("eos_parameter_a              "+eosa[0]+"\n");
                            ot.write("eos_parameter_b              "+eosb[0]+"\n");
                        }
                        else {
                            ot.write("critical_temperature_0       "+eosa[0]+"\n");
                            ot.write("critical_pressure_0          "+eosb[0]+"\n");
                        }
                        break;
                }
                if(xint>3) ot.write("gas_constant                 "+gascon+"\n");
                if(xint>3 && lbt==0) ot.write("temperature_system           "+tempsys+"\n");
                ot.write("surface_tension_parameter    "+fekappa+"\n");
                if(lbf>1) {
                    ot.write("relax_mobility               "+mobrelax+"\n");
                    ot.write("mobility_parameter           "+mobility+"\n");
                    xint = eos[1];
                    switch (xint) {
                        case 0:
                            ot.write("potential_type               None\n");
                            break;
                        case 1:
                            ot.write("potential_type               Quartic\n");
                            ot.write("potential_parameter_a        "+eosa[1]+"\n");
                            break;
                    }
                }
                xint = wettyp[0];
                switch (xint) {
                    case 0:
                        ot.write("wetting_type                 None\n");
                        break;
                    case 1:
                        ot.write("wetting_type                 Quadratic\n");
                        ot.write("wetting_parameter_rho_0      "+wallinteract[0]+"\n");
                        ot.write("wetting_parameter_rho_1      "+wallinteract[1]+"\n");
                        if(lbf>1) {
                            ot.write("wetting_parameter_phi_0      "+wallinteract[2]+"\n");
                            ot.write("wetting_parameter_phi_1      "+wallinteract[3]+"\n");
                        }
                        break;
                }
            }
            // solute properties
            for(i=0; i<lbc; i++) {
	          ot.write("solute_ini_"+i+"                 "+concs[7*i]+"\n");
	          ot.write("solute_top_"+i+"                 "+concs[7*i+1]+"\n");
	          ot.write("solute_bot_"+i+"                 "+concs[7*i+2]+"\n");
	          ot.write("solute_lef_"+i+"                 "+concs[7*i+3]+"\n");
	          ot.write("solute_rig_"+i+"                 "+concs[7*i+4]+"\n");
	          ot.write("solute_fro_"+i+"                 "+concs[7*i+5]+"\n");
	          ot.write("solute_bac_"+i+"                 "+concs[7*i+6]+"\n");
            }
            for(i=0; i<lbc; i++) {
	          ot.write("relax_solute_"+i+"            "+solrelax[i]+"\n");
            }
            // thermal properties
            if(lbt>0) {
              ot.write("temperature_boussinesq_high  "+boustemph+"\n");
              ot.write("temperature_boussinesq_low   "+boustempl+"\n");
	          ot.write("temperature_ini              "+temps[0]+"\n");
	          ot.write("temperature_top              "+temps[1]+"\n");
	          ot.write("temperature_bottom           "+temps[2]+"\n");
  	          ot.write("temperature_left             "+temps[3]+"\n");
              ot.write("temperature_right            "+temps[4]+"\n");
	          ot.write("temperature_front            "+temps[5]+"\n");
	          ot.write("temperature_back             "+temps[6]+"\n");
     	      ot.write("heating_rate_sys             "+heatrates[0]+"\n");
     	      ot.write("heating_rate_top             "+heatrates[1]+"\n"); 
 	          ot.write("heating_rate_bottom          "+heatrates[2]+"\n");
 	          ot.write("heating_rate_left            "+heatrates[3]+"\n");
  	          ot.write("heating_rate_right           "+heatrates[4]+"\n");
 	          ot.write("heating_rate_front           "+heatrates[5]+"\n");
 	          ot.write("heating_rate_back            "+heatrates[6]+"\n");
  	          ot.write("relax_thermal                "+heatrelax+"\n");
            }

 	    } catch (NumberFormatException enf) {
	        ierr(" system parameter: format error or no value ");
	    } catch (IOException e) {
            ierr(" error when saving "+filename+" ");
	        System.out.println("Exception: "+e.getMessage());
	    }
	    try {
	        ot.close();
	    } catch (IOException e) {
            ierr(" error when closing "+filename+" ");
	        System.out.println("Exception: "+e.getMessage());
	    }
    }


    void  openlbe() {
        int i, j, k;
        String word, value, compare1, compare2;
        File it = new File(filename);
        if(!it.exists()) {
          ierr(" cannot find "+filename+" file ");
        }
	try {
            // set defaults
            inigui.yesincomp.setSelected(false);
            // first pass to find simulation properties
            Scanner in = new Scanner(new File(filename));
            while (in.hasNext("\\S+")) {
              word = in.next("\\S+");
              if(word.compareTo("space_dimension") == 0) {
                value = in.next("\\S+");
                lbd = Integer.parseInt(value);
              }
              else if(word.compareTo("discrete_speed") == 0) {
                value = in.next("\\S+");
                lbq = Integer.parseInt(value);
              }
              else if(word.compareTo("number_of_fluid") == 0) {
                value = in.next("\\S+");
                lbf = Integer.parseInt(value);
                if(lbf<1)
                  lbf = 1;
                else if(lbf>6)
                  lbf = 6;
                inigui.fluidn.setText(Integer.toString(lbf));
              }
              else if(word.compareTo("number_of_solute") == 0) {
                value = in.next("\\S+");
                lbc = Integer.parseInt(value);
                if(lbc<0)
                  lbc = 0;
                else if(lbc>6)
                  lbc = 6;
                inigui.solutn.setText(Integer.toString(lbc));
              }
              else if(word.compareTo("temperature_scalar") == 0) {
                value = in.next("\\S+");
                lbt = Integer.parseInt(value);
                if(lbt==0)
                  inigui.yest.setSelected(false);
                else
                  inigui.yest.setSelected(true);
              }
              else if(word.compareTo("phase_field") == 0) {
                value = in.next("\\S+");
                lbp = Integer.parseInt(value);
                if(lbp==0) {
                  inigui.phaseyes.setSelected(false);
                  inigui.phaseno.setSelected(true);
                }
                else {
                  inigui.phaseyes.setSelected(true);
                  inigui.phaseno.setSelected(false);
                }
              }
              else if(word.compareTo("grid_number_x") == 0) {
                value = in.next("\\S+");
                inigui.totx.setText(value);
              }
              else if(word.compareTo("grid_number_y") == 0) {
                value = in.next("\\S+");
                inigui.toty.setText(value);
              }
              else if(word.compareTo("grid_number_z") == 0) {
                value = in.next("\\S+");
                inigui.totz.setText(value);
              }
              else if(word.compareTo("domain_boundary_width") == 0) {
                value = in.next("\\S+");
                inigui.bwid.setText(value);
              }
              else if(word.compareTo("incompressible_fluids") == 0) {
                value = in.next("\\S+");
                lbincomp = Integer.parseInt(value);
                if(lbincomp==0)
                  inigui.yesincomp.setSelected(false);
                else
                  inigui.yesincomp.setSelected(true);
              }
              else if(word.compareTo("interaction_type") == 0) {
                  value = in.next("\\S+");
                  if(value.compareTo("ShanChen") == 0) {
                      inigui.interact.setSelectedItem("Shan/Chen");
                      interact = 1;
                      inigui.sete.setEnabled(true);
                  }
                  else if(value.compareTo("ShanChenQuadratic") == 0) {
                      inigui.interact.setSelectedItem("Shan/Chen Quadratic");
                      interact = 2;
                      inigui.sete.setEnabled(true);
                  }
                  else if(value.compareTo("Lishchuk") == 0) {
                      inigui.interact.setSelectedItem("Lishchuk");
                      interact = 3;
                      inigui.sete.setEnabled(true);
                  }
                  else if(value.compareTo("LishchukLocal") == 0) {
                      inigui.interact.setSelectedItem("Lishchuk Local");
                      interact = 4;
                      inigui.sete.setEnabled(true);
                  }
                  else if(value.compareTo("Swift") == 0) {
                      inigui.interact.setSelectedItem("Swift");
                      interact = 5;
                      inigui.sete.setEnabled(true);
                  }
                  else {
                      inigui.interact.setSelectedItem("none");
                      interact = 0;
                      inigui.sete.setEnabled(false);
                  }
              }
            }
            in.close();
            if(lbd==2 && lbq==9) {
                inigui.model.setSelectedItem("D2Q9");
                inigui.totzlabel.setEnabled(false);
                inigui.totz.setEnabled(false);
        	    inigui.totz.setEditable(false);
                inigui.topvzlabel.setEnabled(false);
            	inigui.topvz.setEditable(false);
                inigui.topvz.setEnabled(false);
                inigui.dowvzlabel.setEnabled(false);
                inigui.dowvz.setEditable(false);
                inigui.dowvz.setEnabled(false);
                inigui.lefvzlabel.setEnabled(false);
                inigui.lefvz.setEditable(false);
                inigui.lefvz.setEnabled(false);
                inigui.rigvzlabel.setEnabled(false);
                inigui.rigvz.setEditable(false);
                inigui.rigvz.setEnabled(false);
                inigui.frovlabel.setEnabled(false);
                inigui.frovxlabel.setEnabled(false);
                inigui.frovx.setEditable(false);
                inigui.frovx.setEnabled(false);
                inigui.frovylabel.setEnabled(false);
                inigui.frovy.setEditable(false);
                inigui.frovy.setEnabled(false);
                inigui.frovzlabel.setEnabled(false);
                inigui.frovz.setEditable(false);
                inigui.frovz.setEnabled(false);
                inigui.bacvlabel.setEnabled(false);
                inigui.bacvxlabel.setEnabled(false);
                inigui.bacvx.setEditable(false);
                inigui.bacvx.setEnabled(false);
                inigui.bacvylabel.setEnabled(false);
                inigui.bacvy.setEditable(false);
                inigui.bacvy.setEnabled(false);
                inigui.bacvzlabel.setEnabled(false);
                inigui.bacvz.setEditable(false);
                inigui.bacvz.setEnabled(false);
            }
            else if(lbd==3 && lbq==15) {
                inigui.model.setSelectedItem("D3Q15");
                inigui.totzlabel.setEnabled(true);
                inigui.totz.setEnabled(true);
        	    inigui.totz.setEditable(true);
                inigui.topvzlabel.setEnabled(true);
            	inigui.topvz.setEditable(true);
                inigui.topvz.setEnabled(true);
                inigui.dowvzlabel.setEnabled(true);
                inigui.dowvz.setEditable(true);
                inigui.dowvz.setEnabled(true);
                inigui.lefvzlabel.setEnabled(true);
                inigui.lefvz.setEditable(true);
                inigui.lefvz.setEnabled(true);
                inigui.rigvzlabel.setEnabled(true);
                inigui.rigvz.setEditable(true);
                inigui.rigvz.setEnabled(true);
                inigui.frovlabel.setEnabled(true);
                inigui.frovxlabel.setEnabled(true);
                inigui.frovx.setEditable(true);
                inigui.frovx.setEnabled(true);
                inigui.frovylabel.setEnabled(true);
                inigui.frovy.setEditable(true);
                inigui.frovy.setEnabled(true);
                inigui.frovzlabel.setEnabled(true);
                inigui.frovz.setEditable(true);
                inigui.frovz.setEnabled(true);
                inigui.bacvlabel.setEnabled(true);
                inigui.bacvxlabel.setEnabled(true);
                inigui.bacvx.setEditable(true);
                inigui.bacvx.setEnabled(true);
                inigui.bacvylabel.setEnabled(true);
                inigui.bacvy.setEditable(true);
                inigui.bacvy.setEnabled(true);
                inigui.bacvzlabel.setEnabled(true);
                inigui.bacvz.setEditable(true);
                inigui.bacvz.setEnabled(true);
            }
            else if(lbd==3 && lbq==19) {
                inigui.model.setSelectedItem("D3Q19");
                inigui.totzlabel.setEnabled(true);
                inigui.totz.setEnabled(true);
        	    inigui.totz.setEditable(true);
                inigui.topvzlabel.setEnabled(true);
            	inigui.topvz.setEditable(true);
                inigui.topvz.setEnabled(true);
                inigui.dowvzlabel.setEnabled(true);
                inigui.dowvz.setEditable(true);
                inigui.dowvz.setEnabled(true);
                inigui.lefvzlabel.setEnabled(true);
                inigui.lefvz.setEditable(true);
                inigui.lefvz.setEnabled(true);
                inigui.rigvzlabel.setEnabled(true);
                inigui.rigvz.setEditable(true);
                inigui.rigvz.setEnabled(true);
                inigui.frovlabel.setEnabled(true);
                inigui.frovxlabel.setEnabled(true);
                inigui.frovx.setEditable(true);
                inigui.frovx.setEnabled(true);
                inigui.frovylabel.setEnabled(true);
                inigui.frovy.setEditable(true);
                inigui.frovy.setEnabled(true);
                inigui.frovzlabel.setEnabled(true);
                inigui.frovz.setEditable(true);
                inigui.frovz.setEnabled(true);
                inigui.bacvlabel.setEnabled(true);
                inigui.bacvxlabel.setEnabled(true);
                inigui.bacvx.setEditable(true);
                inigui.bacvx.setEnabled(true);
                inigui.bacvylabel.setEnabled(true);
                inigui.bacvy.setEditable(true);
                inigui.bacvy.setEnabled(true);
                inigui.bacvzlabel.setEnabled(true);
                inigui.bacvz.setEditable(true);
                inigui.bacvz.setEnabled(true);
            }
            else if(lbd==3 && lbq==27) {
                inigui.model.setSelectedItem("D3Q27");
                inigui.totzlabel.setEnabled(true);
                inigui.totz.setEnabled(true);
        	    inigui.totz.setEditable(true);
                inigui.topvzlabel.setEnabled(true);
            	inigui.topvz.setEditable(true);
                inigui.topvz.setEnabled(true);
                inigui.dowvzlabel.setEnabled(true);
                inigui.dowvz.setEditable(true);
                inigui.dowvz.setEnabled(true);
                inigui.lefvzlabel.setEnabled(true);
                inigui.lefvz.setEditable(true);
                inigui.lefvz.setEnabled(true);
                inigui.rigvzlabel.setEnabled(true);
                inigui.rigvz.setEditable(true);
                inigui.rigvz.setEnabled(true);
                inigui.frovlabel.setEnabled(true);
                inigui.frovxlabel.setEnabled(true);
                inigui.frovx.setEditable(true);
                inigui.frovx.setEnabled(true);
                inigui.frovylabel.setEnabled(true);
                inigui.frovy.setEditable(true);
                inigui.frovy.setEnabled(true);
                inigui.frovzlabel.setEnabled(true);
                inigui.frovz.setEditable(true);
                inigui.frovz.setEnabled(true);
                inigui.bacvlabel.setEnabled(true);
                inigui.bacvxlabel.setEnabled(true);
                inigui.bacvx.setEditable(true);
                inigui.bacvx.setEnabled(true);
                inigui.bacvylabel.setEnabled(true);
                inigui.bacvy.setEditable(true);
                inigui.bacvy.setEnabled(true);
                inigui.bacvzlabel.setEnabled(true);
                inigui.bacvz.setEditable(true);
                inigui.bacvz.setEnabled(true);
            }
	} catch (NumberFormatException enf) {
	    ierr(" system parameter: format error or no value ");
	} catch (IOException e) {
            ierr(" error when opening "+filename+" ");
	    System.out.println("Exception: "+e.getMessage());
	}
	try {
            // second pass to find system properties
            Scanner in2 = new Scanner(new File(filename));
            while (in2.hasNext("\\S+")) {
              word = in2.next("\\S+");
              if(word.compareTo("collision_type") == 0) {
                value = in2.next("\\S+");
                if(value.compareTo("BGKEDM") == 0) {
                  inigui.collide.setSelectedItem("BGK/EDM");
                  inigui.trtmagiclabel.setEnabled(false);
                  inigui.trtmagic.setEditable(false);
                  inigui.trtmagic.setEnabled(false);
                  collide = 1;
                }
                else if(value.compareTo("BGKGuo") == 0) {
                  inigui.collide.setSelectedItem("BGK/Guo");
                  inigui.trtmagiclabel.setEnabled(false);
                  inigui.trtmagic.setEditable(false);
                  inigui.trtmagic.setEnabled(false);
                  collide = 2;
                }
                else if(value.compareTo("TRT") == 0) {
                  inigui.collide.setSelectedItem("TRT");
                  inigui.trtmagiclabel.setEnabled(true);
                  inigui.trtmagic.setEditable(true);
                  inigui.trtmagic.setEnabled(true);
                  collide = 3;
                }
                else if(value.compareTo("TRTEDM") == 0) {
                  inigui.collide.setSelectedItem("TRT/EDM");
                  inigui.trtmagiclabel.setEnabled(true);
                  inigui.trtmagic.setEditable(true);
                  inigui.trtmagic.setEnabled(true);
                  collide = 4;
                }
                else if(value.compareTo("TRTGuo") == 0) {
                  inigui.collide.setSelectedItem("TRT/Guo");
                  inigui.trtmagiclabel.setEnabled(true);
                  inigui.trtmagic.setEditable(true);
                  inigui.trtmagic.setEnabled(true);
                  collide = 5;
                }
                else if(value.compareTo("MRT") == 0) {
                  inigui.collide.setSelectedItem("MRT");
                  inigui.trtmagiclabel.setEnabled(false);
                  inigui.trtmagic.setEditable(false);
                  inigui.trtmagic.setEnabled(false);
                  collide = 6;
                }
                else if(value.compareTo("MRTEDM") == 0) {
                  inigui.collide.setSelectedItem("MRT/EDM");
                  inigui.trtmagiclabel.setEnabled(false);
                  inigui.trtmagic.setEditable(false);
                  inigui.trtmagic.setEnabled(false);
                  collide = 7;
                }
                else if(value.compareTo("MRTGuo") == 0) {
                  inigui.collide.setSelectedItem("MRT/Guo");
                  inigui.trtmagiclabel.setEnabled(false);
                  inigui.trtmagic.setEditable(false);
                  inigui.trtmagic.setEnabled(false);
                  collide = 8;
                }
                else {
                  inigui.collide.setSelectedItem("BGK");
                  inigui.trtmagiclabel.setEnabled(false);
                  inigui.trtmagic.setEditable(false);
                  inigui.trtmagic.setEnabled(false);
                  collide = 0;
                }
              }
              else if(word.compareTo("trt_magic_number") == 0) {
                  value = in2.next("\\S+");
                  inigui.trtmagic.setText(value);
              }
              else if(word.compareTo("output_format") == 0) {
                value = in2.next("\\S+");
                if(value.compareTo("LegacyVTK") == 0) {
                  inigui.outformat.setSelectedItem("LegacyVTK");
                  outtype = 1;
                }
                else if(value.compareTo("Plot3D") == 0) {
                  inigui.outformat.setSelectedItem("Plot3D");
                  outtype = 2;
                }
                else {
                  inigui.outformat.setSelectedItem("VTK");
                  outtype = 0;
                }
              }
              else if(word.compareTo("output_type") == 0) {
                value = in2.next("\\S+");
                if(value.compareTo("Binary") == 0) {
                  inigui.outansi.setSelected(false);
                  outansi = 0;
                }
                else if(value.compareTo("Text") == 0 || value.compareTo("ANSI") == 0) {
                  inigui.outansi.setSelected(true);
                  outansi = 1;
                }
              }
              else if(word.compareTo("total_step") == 0) {
                value = in2.next("\\S+");
                inigui.tott.setText(value);
              }
              else if(word.compareTo("equilibration_step") == 0) {
                value = in2.next("\\S+");
                inigui.equt.setText(value);
              }
              else if(word.compareTo("save_span") == 0) {
                value = in2.next("\\S+");
                inigui.savet.setText(value);
              }
              else if(word.compareTo("noise_intensity") == 0) {
                value = in2.next("\\S+");
                inigui.noiei.setText(value);
              }
              else if(word.compareTo("sound_speed") == 0) {
                value = in2.next("\\S+");
                inigui.soundv.setText(value);
              }
              else if(word.compareTo("kinetic_viscosity") == 0) {
                value = in2.next("\\S+");
                inigui.kineticv.setText(value);
              }
              else if(word.compareTo("speed_top_0") == 0) {
                value = in2.next("\\S+");
                inigui.topvx.setText(value);
              }
              else if(word.compareTo("speed_top_1") == 0) {
                value = in2.next("\\S+");
                inigui.topvy.setText(value);
              }
              else if(word.compareTo("speed_top_2") == 0) {
                value = in2.next("\\S+");
                inigui.topvz.setText(value);
              }
              else if(word.compareTo("speed_bot_0") == 0) {
                value = in2.next("\\S+");
                inigui.dowvx.setText(value);
              }
              else if(word.compareTo("speed_bot_1") == 0) {
                value = in2.next("\\S+");
                inigui.dowvy.setText(value);
              }
              else if(word.compareTo("speed_bot_2") == 0) {
                value = in2.next("\\S+");
                inigui.dowvz.setText(value);
              }
              else if(word.compareTo("speed_lef_0") == 0) {
                value = in2.next("\\S+");
                inigui.lefvx.setText(value);
              }
              else if(word.compareTo("speed_lef_1") == 0) {
                value = in2.next("\\S+");
                inigui.lefvy.setText(value);
              }
              else if(word.compareTo("speed_lef_2") == 0) {
                value = in2.next("\\S+");
                inigui.lefvz.setText(value);
              }
              else if(word.compareTo("speed_rig_0") == 0) {
                value = in2.next("\\S+");
                inigui.rigvx.setText(value);
              }
              else if(word.compareTo("speed_rig_1") == 0) {
                value = in2.next("\\S+");
                inigui.rigvy.setText(value);
              }
              else if(word.compareTo("speed_rig_2") == 0) {
                value = in2.next("\\S+");
                inigui.rigvz.setText(value);
              }
              else if(word.compareTo("speed_fro_0") == 0) {
                value = in2.next("\\S+");
                inigui.frovx.setText(value);
              }
              else if(word.compareTo("speed_fro_1") == 0) {
                value = in2.next("\\S+");
                inigui.frovy.setText(value);
              }
              else if(word.compareTo("speed_fro_2") == 0) {
                value = in2.next("\\S+");
                inigui.frovz.setText(value);
              }
              else if(word.compareTo("speed_bac_0") == 0) {
                value = in2.next("\\S+");
                inigui.bacvx.setText(value);
              }
              else if(word.compareTo("speed_bac_1") == 0) {
                value = in2.next("\\S+");
                inigui.bacvy.setText(value);
              }
              else if(word.compareTo("speed_bac_2") == 0) {
                value = in2.next("\\S+");
                inigui.bacvz.setText(value);
              }
              else if(word.compareTo("segregation") == 0) {
                value = in2.next("\\S+");
                segregate = Double.parseDouble(value);
              }
              else if(word.compareTo("surface_tension_parameter") == 0) {
                  value = in2.next("\\S+");
                  fekappa = Double.parseDouble(value);
              }
              else if(word.compareTo("relax_mobility") == 0) {
                  value = in2.next("\\S+");
                  mobrelax = Double.parseDouble(value);
              }
              else if(word.compareTo("relax_freq_mobility") == 0) {
                  value = in2.next("\\S+");
                  mobrelax = 1.0/Double.parseDouble(value);
              }
              else if(word.compareTo("mobility_parameter") == 0) {
                  value = in2.next("\\S+");
                  mobility = Double.parseDouble(value);
              }
              else if(word.compareTo("eos_parameter_a") == 0) {
                  value = in2.next("\\S+");
                  eosa[0] = Double.parseDouble(value);
              }
              else if(word.compareTo("eos_parameter_b") == 0) {
                  value = in2.next("\\S+");
                  eosb[0] = Double.parseDouble(value);
              }
              else if(word.compareTo("potential_parameter_a") == 0) {
                  value = in2.next("\\S+");
                  eosa[1] = Double.parseDouble(value);
              }
              else if(word.compareTo("potential_parameter_b") == 0) {
                  value = in2.next("\\S+");
                  eosb[1] = Double.parseDouble(value);
              }
              else if(word.compareTo("temperature_system") == 0) {
                  value = in2.next("\\S+");
                  tempsys = Double.parseDouble(value);
              }
              else if(word.compareTo("gas_constant") == 0) {
                  value = in2.next("\\S+");
                  gascon = Double.parseDouble(value);
              }
              else if(word.compareTo("quadratic_weight") == 0) {
                  value = in2.next("\\S+");
                  for(i=0; i<lbf; i++) {
                      quadw[i] = Double.parseDouble(value);
                  }
              }
              else if(word.compareTo("equation_of_state") == 0) {
                  value = in2.next("\\S+");
                  if(value.compareTo("IdealLattice")==0) {
                      eos[0] = 0;
                  }
                  else if(value.compareTo("ShanChen1993")==0) {
                      eos[0] = 1;
                  }
                  else if(value.compareTo("ShanChen1994")==0) {
                      eos[0] = 2;
                  }
                  else if(value.compareTo("Rho")==0) {
                      eos[0] = 3;
                  }
                  else if(value.compareTo("Ideal")==0) {
                      eos[0] = 4;
                  }
                  else if(value.compareTo("vanderWaals")==0 || value.compareTo("vdW")==0) {
                      eos[0] = 5;
                  }
                  else if(value.compareTo("RedlichKwong")==0 || value.compareTo("RK")==0) {
                      eos[0] = 6;
                  }
                  else if(value.compareTo("SoaveRedlichKwong")==0 || value.compareTo("SRK")==0) {
                      eos[0] = 7;
                  }
                  else if(value.compareTo("PengRobinson")==0 || value.compareTo("PR")==0) {
                      eos[0] = 8;
                  }
                  else if(value.compareTo("CarnahanStarlingvanderWaals")==0 || value.compareTo("CSvdW")==0) {
                      eos[0] = 9;
                  }
                  else if(value.compareTo("CarnahanStarlingRedlichKwong")==0 || value.compareTo("CSRK")==0) {
                      eos[0] = 10;
                  }
              }
              else if(word.compareTo("potential_type") == 0) {
                  value = in2.next("\\S+");
                  if(value.compareTo("IdealLattice")==0) {
                      for(i=0; i<lbf; i++) {
                          eos[i] = 0;
                      }
                  }
                  else if(value.compareTo("ShanChen1993")==0) {
                      for(i=0; i<lbf; i++) {
                          eos[i] = 1;
                      }
                  }
                  else if(value.compareTo("ShanChen1994")==0) {
                      for(i=0; i<lbf; i++) {
                          eos[i] = 2;
                      }
                  }
                  else if(value.compareTo("Rho")==0) {
                      for(i=0; i<lbf; i++) {
                          eos[i] = 3;
                      }
                  }
                  else if(value.compareTo("Ideal")==0) {
                      for(i=0; i<lbf; i++) {
                          eos[i] = 4;
                      }
                  }
                  else if(value.compareTo("vanderWaals")==0 || value.compareTo("vdW")==0) {
                      for(i=0; i<lbf; i++) {
                          eos[i] = 5;
                      }
                  }
                  else if(value.compareTo("RedlichKwong")==0 || value.compareTo("RK")==0) {
                      for(i=0; i<lbf; i++) {
                          eos[i] = 6;
                      }
                  }
                  else if(value.compareTo("SoaveRedlichKwong")==0 || value.compareTo("SRK")==0) {
                      for(i=0; i<lbf; i++) {
                          eos[i] = 7;
                      }
                  }
                  else if(value.compareTo("PengRobinson")==0 || value.compareTo("PR")==0) {
                      for(i=0; i<lbf; i++) {
                          eos[i] = 8;
                      }
                  }
                  else if(value.compareTo("CarnahanStarlingvanderWaals")==0 || value.compareTo("CSvdW")==0) {
                      for(i=0; i<lbf; i++) {
                          eos[i] = 9;
                      }
                  }
                  else if(value.compareTo("CarnahanStarlingRedlichKwong")==0 || value.compareTo("CSRK")==0) {
                      for(i=0; i<lbf; i++) {
                          eos[i] = 10;
                      }
                  }
                  else if(value.compareTo("None")==0) {
                      eos[1] = 0;
                  }
                  else if(value.compareTo("Quartic")==0) {
                      eos[1] = 1;
                  }
              }
              else if(word.compareTo("wetting_type") == 0) {
                  value = in2.next("\\S+");
                  if(value.compareTo("Density")==0) {
                      for(i=0; i<lbf; i++) {
                          wettyp[i] = 0;
                      }
                  }
                  else if(value.compareTo("Potential")==0) {
                      for(i=0; i<lbf; i++) {
                          wettyp[i] = 1;
                      }
                  }
                  else if(value.compareTo("ScreenedPotential")==0) {
                      for(i=0; i<lbf; i++) {
                          wettyp[i] = 2;
                      }
                  }
                  else if(value.compareTo("None")==0) {
                      wettyp[0] = 0;
                  }
                  else if(value.compareTo("Quadratic")==0) {
                      wettyp[0] = 1;
                  }
              }
              else if(word.compareTo("wetting_parameter_rho_0")==0) {
                  value = in2.next("\\S+");
                  wallinteract[0] = Double.parseDouble(value);
              }
              else if(word.compareTo("wetting_parameter_rho_1")==0) {
                  value = in2.next("\\S+");
                  wallinteract[1] = Double.parseDouble(value);
              }
              else if(word.compareTo("wetting_parameter_phi_0")==0) {
                  value = in2.next("\\S+");
                  wallinteract[2] = Double.parseDouble(value);
              }
              else if(word.compareTo("wetting_parameter_phi_1")==0) {
                  value = in2.next("\\S+");
                  wallinteract[3] = Double.parseDouble(value);
              }
              

            // find fluid properties
              for(i=0; i<lbf; i++) {
                compare1 = "body_force_"+(3*i);
                compare2 = "body_force_x_"+i;
                if(word.compareTo(compare1) == 0 || word.compareTo(compare2) == 0) {
                  value = in2.next("\\S+");
                  bdf[3*i] = Double.parseDouble(value);
                }
                compare1 = "body_force_"+(3*i+1);
                compare2 = "body_force_y_"+i;
                if(word.compareTo(compare1) == 0 || word.compareTo(compare2) == 0) {
                  value = in2.next("\\S+");
                  bdf[3*i+1] = Double.parseDouble(value);
                }
                compare1 = "body_force_"+(3*i+2);
                compare2 = "body_force_z_"+i;
                if(word.compareTo(compare1) == 0 || word.compareTo(compare2) == 0) {
                  value = in2.next("\\S+");
                  bdf[3*i+2] = Double.parseDouble(value);
                }
                compare1 = "boussinesq_force_"+(3*i);
                compare2 = "boussinesq_force_x_"+i;
                if(word.compareTo(compare1) == 0 || word.compareTo(compare2) == 0) {
                  value = in2.next("\\S+");
                  bousf[3*i] = Double.parseDouble(value);
                }
                compare1 = "boussinesq_force_"+(3*i+1);
                compare2 = "boussinesq_force_y_"+i;
                if(word.compareTo(compare1) == 0 || word.compareTo(compare2) == 0) {
                  value = in2.next("\\S+");
                  bousf[3*i+1] = Double.parseDouble(value);
                }
                compare1 = "boussinesq_force_"+(3*i+2);
                compare2 = "boussinesq_force_z_"+i;
                if(word.compareTo(compare1) == 0 || word.compareTo(compare2) == 0) {
                  value = in2.next("\\S+");
                  bousf[3*i+2] = Double.parseDouble(value);
                }
                compare1 = "density_ini_"+i;
                if(word.compareTo(compare1) == 0) {
                  value = in2.next("\\S+");
                  densf[8*i] = Double.parseDouble(value);
                }
                compare1 = "density_inc_"+i;
                if(word.compareTo(compare1) == 0) {
                  value = in2.next("\\S+");
                  densf[8*i+1] = Double.parseDouble(value);
                }
                compare1 = "density_top_"+i;
                if(word.compareTo(compare1) == 0) {
                  value = in2.next("\\S+");
                  densf[8*i+2] = Double.parseDouble(value);
                }
                compare1 = "density_bot_"+i;
                if(word.compareTo(compare1) == 0) {
                  value = in2.next("\\S+");
                  densf[8*i+3] = Double.parseDouble(value);
                }
                compare1 = "density_lef_"+i;
                if(word.compareTo(compare1) == 0) {
                  value = in2.next("\\S+");
                  densf[8*i+4] = Double.parseDouble(value);
                }
                compare1 = "density_rig_"+i;
                if(word.compareTo(compare1) == 0) {
                  value = in2.next("\\S+");
                  densf[8*i+5] = Double.parseDouble(value);
                }
                compare1 = "density_fro_"+i;
                if(word.compareTo(compare1) == 0) {
                  value = in2.next("\\S+");
                  densf[8*i+6] = Double.parseDouble(value);
                }
                compare1 = "density_bac_"+i;
                if(word.compareTo(compare1) == 0) {
                  value = in2.next("\\S+");
                  densf[8*i+7] = Double.parseDouble(value);
                }
                compare1 = "relaxation_fluid_"+i;
                if(word.compareTo(compare1) == 0) {
                  value = in2.next("\\S+");
                  relaxtime[2*i] = Double.parseDouble(value);
                }
                compare1 = "relax_freq_fluid_"+i;
                if(word.compareTo(compare1) == 0) {
                  value = in2.next("\\S+");
                  relaxtime[2*i] = 1.0/Double.parseDouble(value);
                }
                compare1 = "bulk_relaxation_fluid_"+i;
                if(word.compareTo(compare1) == 0) {
                  value = in2.next("\\S+");
                  relaxtime[2*i+1] = Double.parseDouble(value);
                }
                compare1 = "bulk_relax_freq_fluid_"+i;
                if(word.compareTo(compare1) == 0) {
                  value = in2.next("\\S+");
                  relaxtime[2*i+1] = 1.0/Double.parseDouble(value);
                }
                compare1 = "wall_interaction_"+i;
                if(word.compareTo(compare1) == 0) {
                  value = in2.next("\\S+");
                  wallinteract[i] = Double.parseDouble(value);
                }
                compare1 = "shanchen_psi0_"+i;
                if(word.compareTo(compare1) == 0) {
                  value = in2.next("\\S+");
                  psi0[i] = Double.parseDouble(value);
                }
                compare1 = "critical_temperature_"+i;
                if(word.compareTo(compare1) == 0) {
                  value = in2.next("\\S+");
                  eosa[i] = Double.parseDouble(value);
                  eoscrit = 1;
                }
                compare1 = "critical_pressure_"+i;
                if(word.compareTo(compare1) == 0) {
                  value = in2.next("\\S+");
                  eosb[i] = Double.parseDouble(value);
                  eoscrit = 1;
                }
                compare1 = "eos_parameter_a_"+i;
                if(word.compareTo(compare1) == 0) {
                  value = in2.next("\\S+");
                  eosa[i] = Double.parseDouble(value);
                  eoscrit = 0;
                }
                compare1 = "eos_parameter_b_"+i;
                if(word.compareTo(compare1) == 0) {
                  value = in2.next("\\S+");
                  eosb[i] = Double.parseDouble(value);
                  eoscrit = 0;
                }
                compare1 = "acentric_factor_"+i;
                if(word.compareTo(compare1) == 0) {
                  value = in2.next("\\S+");
                  acentric[i] = Double.parseDouble(value);
                }
                compare1 = "potential_type_"+i;
                if(word.compareTo(compare1) == 0) {
                  value = in2.next("\\S+");
                    if(value.compareTo("IdealLattice")==0) {
                        eos[i] = 0;
                    }
                    else if(value.compareTo("ShanChen1993")==0) {
                        eos[i] = 1;
                    }
                    else if(value.compareTo("ShanChen1994")==0) {
                        eos[i] = 2;
                    }
                    else if(value.compareTo("Rho")==0) {
                        eos[i] = 3;
                    }
                    else if(value.compareTo("Ideal")==0) {
                        eos[i] = 4;
                    }
                    else if(value.compareTo("vanderWaals")==0 || value.compareTo("vdW")==0) {
                        eos[i] = 5;
                    }
                    else if(value.compareTo("RedlichKwong")==0 || value.compareTo("RK")==0) {
                        eos[i] = 6;
                    }
                    else if(value.compareTo("SoaveRedlichKwong")==0 || value.compareTo("SRK")==0) {
                        eos[i] = 7;
                    }
                    else if(value.compareTo("PengRobinson")==0 || value.compareTo("PR")==0) {
                        eos[i] = 8;
                    }
                    else if(value.compareTo("CarnahanStarlingvanderWaals")==0 || value.compareTo("CSvdW")==0) {
                        eos[i] = 9;
                    }
                    else if(value.compareTo("CarnahanStarlingRedlichKwong")==0 || value.compareTo("CSRK")==0) {
                        eos[i] = 10;
                    }
                }
                compare1 = "wetting_type_"+i;
                if(word.compareTo(compare1) == 0) {
                  value = in2.next("\\S+");
                    if(value.compareTo("Density")==0) {
                        wettyp[i] = 0;
                    }
                    else if(value.compareTo("Potential")==0) {
                        wettyp[i] = 1;
                    }
                    else if(value.compareTo("ScreenedPotential")==0) {
                        wettyp[i] = 2;
                    }
                }
                compare1 = "quadratic_weight_"+(i*lbf+i);
                compare2 = "quadratic_weight_"+i+"_"+i;
                if(word.compareTo(compare1)==0 || word.compareTo(compare2)==0) {
                    value = in2.next("\\S+");
                    quadw[i] = Double.parseDouble(value);
                }

                  
                for (j=0; j<lbf; j++) {
                  compare1 = "interaction_"+(i*lbf+j);
                  compare2 = "interaction_"+i+"_"+j;
                  if(word.compareTo(compare1) == 0) {
                    value = in2.next("\\S+");
                    fluidinteract[i*lbf+j] = Double.parseDouble(value);                  
                  }
                  else if(word.compareTo(compare2) == 0) {
                    value = in2.next("\\S+");
                    fluidinteract[i*lbf+j] = Double.parseDouble(value);                  
                    fluidinteract[j*lbf+i] = Double.parseDouble(value);                  
                  }
                  compare1 = "segregation_"+(i*lbf+j);
                  compare2 = "segregation_"+i+"_"+j;
                  if(word.compareTo(compare1) == 0) {
                    value = in2.next("\\S+");
                    segregate = Double.parseDouble(value);                  
                  }
                  else if(word.compareTo(compare2) == 0) {
                    value = in2.next("\\S+");
                    segregate = Double.parseDouble(value);                  
                  }
                }
              }
            // find solute properties
              if(lbc>0) {
                for(i=0; i<lbc; i++) {
                  compare1 = "solute_ini_"+i;
                  if(word.compareTo(compare1) == 0) {
                    value = in2.next("\\S+");
                    concs[7*i] = Double.parseDouble(value);
                  }
                  compare1 = "solute_top_"+i;
                  if(word.compareTo(compare1) == 0) {
                    value = in2.next("\\S+");
                    concs[7*i+1] = Double.parseDouble(value);
                  }
                  compare1 = "solute_bot_"+i;
                  if(word.compareTo(compare1) == 0) {
                    value = in2.next("\\S+");
                    concs[7*i+2] = Double.parseDouble(value);
                  }
                  compare1 = "solute_lef_"+i;
                  if(word.compareTo(compare1) == 0) {
                    value = in2.next("\\S+");
                    concs[7*i+3] = Double.parseDouble(value);
                  }
                  compare1 = "solute_rig_"+i;
                  if(word.compareTo(compare1) == 0) {
                    value = in2.next("\\S+");
                    concs[7*i+4] = Double.parseDouble(value);
                  }
                  compare1 = "solute_fro_"+i;
                  if(word.compareTo(compare1) == 0) {
                    value = in2.next("\\S+");
                    concs[7*i+5] = Double.parseDouble(value);
                  }
                  compare1 = "solute_bac_"+i;
                  if(word.compareTo(compare1) == 0) {
                    value = in2.next("\\S+");
                    concs[7*i+6] = Double.parseDouble(value);
                  }
                  compare1 = "relax_solute_"+i;
                  if(word.compareTo(compare1) == 0) {
                    value = in2.next("\\S+");
                    solrelax[i] = Double.parseDouble(value);
                  }
                  compare1 = "relax_freq_solute_"+i;
                  if(word.compareTo(compare1) == 0) {
                    value = in2.next("\\S+");
                    solrelax[i] = 1.0/Double.parseDouble(value);
                  }
                }
              }
            // find thermal properties
              if(lbt>0) {
                if(word.compareTo("temperature_boussinesq_high") == 0) {
                  value = in2.next("\\S+");
                  boustemph = Double.parseDouble(value);
                }
                else if(word.compareTo("temperature_boussinesq_low") == 0) {
                  value = in2.next("\\S+");
                  boustempl = Double.parseDouble(value);
                }
                else if(word.compareTo("temperature_ini") == 0) {
                  value = in2.next("\\S+");
                  temps[0] = Double.parseDouble(value);
                }
                else if(word.compareTo("temperature_top") == 0) {
                  value = in2.next("\\S+");
                  temps[1] = Double.parseDouble(value);
                }
                else if(word.compareTo("temperature_bottom") == 0) {
                  value = in2.next("\\S+");
                  temps[2] = Double.parseDouble(value);
                }
                else if(word.compareTo("temperature_left") == 0) {
                  value = in2.next("\\S+");
                  temps[3] = Double.parseDouble(value);
                }
                else if(word.compareTo("temperature_right") == 0) {
                  value = in2.next("\\S+");
                  temps[4] = Double.parseDouble(value);
                }
                else if(word.compareTo("temperature_front") == 0) {
                  value = in2.next("\\S+");
                  temps[5] = Double.parseDouble(value);
                }
                else if(word.compareTo("temperature_back") == 0) {
                  value = in2.next("\\S+");
                  temps[6] = Double.parseDouble(value);
                }
                else if(word.compareTo("heating_rate_sys") == 0) {
                  value = in2.next("\\S+");
                  heatrates[0] = Double.parseDouble(value);
                }
                else if(word.compareTo("heating_rate_top") == 0) {
                  value = in2.next("\\S+");
                  heatrates[1] = Double.parseDouble(value);
                }
                else if(word.compareTo("heating_rate_bottom") == 0) {
                  value = in2.next("\\S+");
                  heatrates[2] = Double.parseDouble(value);
                }
                else if(word.compareTo("heating_rate_left") == 0) {
                  value = in2.next("\\S+");
                  heatrates[3] = Double.parseDouble(value);
                }
                else if(word.compareTo("heating_rate_right") == 0) {
                  value = in2.next("\\S+");
                  heatrates[4] = Double.parseDouble(value);
                }
                else if(word.compareTo("heating_rate_front") == 0) {
                  value = in2.next("\\S+");
                  heatrates[5] = Double.parseDouble(value);
                }
                else if(word.compareTo("heating_rate_back") == 0) {
                  value = in2.next("\\S+");
                  heatrates[6] = Double.parseDouble(value);
                }
                else if(word.compareTo("relax_thermal") == 0) {
                  value = in2.next("\\S+");
                  heatrelax = Double.parseDouble(value);
                }
                else if(word.compareTo("relax_freq_thermal") == 0) {
                  value = in2.next("\\S+");
                  heatrelax = 1.0/Double.parseDouble(value);
                }
              } 
            } 
            in2.close();
	} catch (NumberFormatException enf) {
	    ierr(" system parameter: format error or no value ");
	} catch (IOException e) {
            ierr(" error when opening "+filename+" ");
	    System.out.println("Exception: "+e.getMessage());
	}
    }

    public void itemStateChanged(ItemEvent event) {
        Object item=event.getItem();
        String answer=item.toString();
        String compare;
        int i;
        Boolean j, j1, j2, j3, j4, k;
        Boolean select1=inigui.yest.isSelected();
        Boolean select2=inigui.outansi.isSelected();
        
        if (select1)
           lbt = 1;
        else {
           lbt = 0;
        }
        if (select2)
            outansi = 1;
        else {
            outansi = 0;
        }

	    if(answer == "D2Q9") {
	      lbd = 2;
	      lbq = 9;
          inigui.totzlabel.setEnabled(false);
          inigui.totz.setEnabled(false);
          inigui.totz.setEditable(false);
          inigui.topvzlabel.setEnabled(false);
	      inigui.topvz.setEditable(false);
          inigui.topvz.setEnabled(false);
          inigui.dowvzlabel.setEnabled(false);
          inigui.dowvz.setEditable(false);
          inigui.dowvz.setEnabled(false);
          inigui.lefvzlabel.setEnabled(false);
          inigui.lefvz.setEditable(false);
          inigui.lefvz.setEnabled(false);
          inigui.rigvzlabel.setEnabled(false);
          inigui.rigvz.setEditable(false);
          inigui.rigvz.setEnabled(false);
          inigui.frovlabel.setEnabled(false);
          inigui.frovxlabel.setEnabled(false);
          inigui.frovx.setEditable(false);
          inigui.frovx.setEnabled(false);
          inigui.frovylabel.setEnabled(false);
          inigui.frovy.setEditable(false);
          inigui.frovy.setEnabled(false);
          inigui.frovzlabel.setEnabled(false);
          inigui.frovz.setEditable(false);
          inigui.frovz.setEnabled(false);
          inigui.bacvlabel.setEnabled(false);
          inigui.bacvxlabel.setEnabled(false);
          inigui.bacvx.setEditable(false);
          inigui.bacvx.setEnabled(false);
          inigui.bacvylabel.setEnabled(false);
          inigui.bacvy.setEditable(false);
          inigui.bacvy.setEnabled(false);
          inigui.bacvzlabel.setEnabled(false);
          inigui.bacvz.setEditable(false);
          inigui.bacvz.setEnabled(false);
	    }

	    else if((answer == "D3Q15") || (answer == "D3Q19") ||(answer == "D3Q27")) {
	      lbd=3;
          inigui.totzlabel.setEnabled(true);
          inigui.totz.setEnabled(true);
   	      inigui.totz.setEditable(true);
          inigui.topvzlabel.setEnabled(true);
	      inigui.topvz.setEditable(true);
          inigui.topvz.setEnabled(true);
          inigui.dowvzlabel.setEnabled(true);
          inigui.dowvz.setEditable(true);
          inigui.dowvz.setEnabled(true);
          inigui.lefvzlabel.setEnabled(true);
          inigui.lefvz.setEditable(true);
          inigui.lefvz.setEnabled(true);
          inigui.rigvzlabel.setEnabled(true);
          inigui.rigvz.setEditable(true);
          inigui.rigvz.setEnabled(true);
          inigui.frovlabel.setEnabled(true);
          inigui.frovxlabel.setEnabled(true);
          inigui.frovx.setEditable(true);
          inigui.frovx.setEnabled(true);
          inigui.frovylabel.setEnabled(true);
          inigui.frovy.setEditable(true);
          inigui.frovy.setEnabled(true);
          inigui.frovzlabel.setEnabled(true);
          inigui.frovz.setEditable(true);
          inigui.frovz.setEnabled(true);
          inigui.bacvlabel.setEnabled(true);
          inigui.bacvxlabel.setEnabled(true);
          inigui.bacvx.setEditable(true);
          inigui.bacvx.setEnabled(true);
          inigui.bacvylabel.setEnabled(true);
          inigui.bacvy.setEditable(true);
          inigui.bacvy.setEnabled(true);
          inigui.bacvzlabel.setEnabled(true);
          inigui.bacvz.setEditable(true);
          inigui.bacvz.setEnabled(true);
	  if(answer == "D3Q15")
	    lbq = 15;
	  else if(answer == "D3Q19")
	    lbq = 19;
	  else
	    lbq = 27;
	}
        else if(answer == "BGK") {
          inigui.trtmagiclabel.setEnabled(false);
          inigui.trtmagic.setEditable(false);
          inigui.trtmagic.setEnabled(false);
          collide=0;
        }
        else if(answer == "BGK/EDM") {
          inigui.trtmagiclabel.setEnabled(false);
          inigui.trtmagic.setEditable(false);
          inigui.trtmagic.setEnabled(false);
          collide=1;
        }
        else if(answer == "BGK/Guo") {
          inigui.trtmagiclabel.setEnabled(false);
          inigui.trtmagic.setEditable(false);
          inigui.trtmagic.setEnabled(false);
          collide=2;
        }
        else if(answer == "TRT") {
          inigui.trtmagiclabel.setEnabled(true);
          inigui.trtmagic.setEditable(true);
          inigui.trtmagic.setEnabled(true);
          collide=3;
        }
        else if(answer == "TRT/EDM") {
          inigui.trtmagiclabel.setEnabled(true);
          inigui.trtmagic.setEditable(true);
          inigui.trtmagic.setEnabled(true);
          collide=4;
        }
        else if(answer == "TRT/Guo") {
          inigui.trtmagiclabel.setEnabled(true);
          inigui.trtmagic.setEditable(true);
          inigui.trtmagic.setEnabled(true);
          collide=5;
        }
        else if(answer == "MRT") {
          inigui.trtmagiclabel.setEnabled(false);
          inigui.trtmagic.setEditable(false);
          inigui.trtmagic.setEnabled(false);
          collide=6;
        }
        else if(answer == "MRT/EDM") {
          inigui.trtmagiclabel.setEnabled(false);
          inigui.trtmagic.setEditable(false);
          inigui.trtmagic.setEnabled(false);
          collide=7;
        }
        else if(answer == "MRT/Guo") {
          inigui.trtmagiclabel.setEnabled(false);
          inigui.trtmagic.setEditable(false);
          inigui.trtmagic.setEnabled(false);
          collide=8;
        }

        else if(answer == "no interactions") {
            interact=0;
			inigui.sete.setEnabled(false);
		}
        else if(answer == "Shan/Chen") {
            interact=1;
			inigui.sete.setEnabled(true);
		}
		else if(answer == "Shan/Chen Quadratic") {
		    interact=2;
			inigui.sete.setEnabled(true);
		}
        else if(answer == "Lishchuk") {
            interact=3;
			inigui.sete.setEnabled(true);
		}
		else if(answer == "Lishchuk Local") {
            interact=4;
			inigui.sete.setEnabled(true);
		}
        else if(answer == "Swift") {
            interact=5;
			inigui.sete.setEnabled(true);
		}

        else if(answer == "VTK")
            outtype=0;
        else if(answer == "LegacyVTK")
            outtype=1;
        else if(answer == "Plot3D")
            outtype=1;

		else if(item == inigui.phaseyes)
			lbp=1;   

		else if(item == inigui.phaseno)
			lbp=0;
        
        else if(answer == "eos parameters") {
            ig.eosalabel.setText("a:");
            ig.eosblabel.setText("b:");
            eoscrit = 0;
        }

        else if(answer == "critical properties") {
            ig.eosalabel.setText("Tc:");
            ig.eosblabel.setText("Pc:");
            eoscrit = 1;
        }

        try {
            if(event.getSource() instanceof JComboBox) {
                JComboBox combo = (JComboBox) event.getSource();
                k = false;
                for(i=0; i<lbf; i++) {
                    compare = "eos"+i;
                    if(compare.equals(combo.getName())) {
                        if(answer=="lattice gas" || answer=="ideal gas") {
                            ig.eosabox[i].setEnabled(false);
                            ig.eosabox[i].setEditable(false);
                            ig.eosbbox[i].setEnabled(false);
                            ig.eosbbox[i].setEditable(false);
                            ig.acentricbox[i].setEnabled(false);
                            ig.acentricbox[i].setEditable(false);
                            if(interact==1 || interact==2) {
                                ig.psi0box[i].setEnabled(false);
                                ig.psi0box[i].setEditable(false);
                            }
                            else if (interact==5) {
                                ig.eosalabel.setText("a:");
                                ig.eosblabel.setText("b:");
                                ig.eoscrit.setSelectedItem("eos parameters");
                                ig.eoscrit.setEnabled(false);
                            }
                            k = true;
                        }
                        else if(answer=="SC 1993" || answer=="density" || answer=="quadratic") {
                            ig.eosbbox[i].setEnabled(false);
                            ig.eosbbox[i].setEditable(false);
                            ig.acentricbox[i].setEnabled(false);
                            ig.acentricbox[i].setEditable(false);
                            if(interact==1 || interact==2) {
                                ig.eosabox[i].setEnabled(false);
                                ig.eosabox[i].setEditable(false);
                                ig.psi0box[i].setEnabled(false);
                                ig.psi0box[i].setEditable(false);
                            }
                            else if(interact==5) {
                                ig.eosabox[i].setEnabled(true);
                                ig.eosabox[i].setEditable(true);
                                ig.eosalabel.setText("g:");
                                ig.eosblabel.setText("");
                                ig.eoscrit.setSelectedItem("eos parameters");
                                ig.eoscrit.setEnabled(false);
                            }
                            k = true;
                        }
                        else if(answer=="SC 1994") {
                            ig.acentricbox[i].setEnabled(false);
                            ig.acentricbox[i].setEditable(false);
                            if(interact==1 || interact==2) {
                                ig.eosabox[i].setEnabled(false);
                                ig.eosabox[i].setEditable(false);
                                ig.eosbbox[i].setEnabled(false);
                                ig.eosbbox[i].setEditable(false);
                                ig.psi0box[i].setEnabled(true);
                                ig.psi0box[i].setEditable(true);
                            }
                            else if(interact==5) {
                                ig.eosabox[i].setEnabled(true);
                                ig.eosabox[i].setEditable(true);
                                ig.eosbbox[i].setEnabled(true);
                                ig.eosbbox[i].setEditable(true);
                                ig.eosalabel.setText("g:");
                                ig.eosblabel.setText("psi0:");
                                ig.eoscrit.setSelectedItem("eos parameters");
                                ig.eoscrit.setEnabled(false);
                            }
                            k = true;
                        }
                        else if(answer=="vdW" || answer=="RK" || answer=="CS-vdW" || answer=="CS-RK") {
                            ig.eosabox[i].setEnabled(true);
                            ig.eosabox[i].setEditable(true);
                            ig.eosbbox[i].setEnabled(true);
                            ig.eosbbox[i].setEditable(true);
                            ig.acentricbox[i].setEnabled(false);
                            ig.acentricbox[i].setEditable(false);
                            if(interact==1 || interact==2) {
                                ig.psi0box[i].setEnabled(false);
                                ig.psi0box[i].setEditable(false);
                            }
                            else if (interact==5) {
                                ig.eosalabel.setText("a:");
                                ig.eosblabel.setText("b:");
                                ig.eoscrit.setSelectedItem("eos parameters");
                                ig.eoscrit.setEnabled(true);
                            }
                            k = true;
                        }
                        else if(answer=="SRK" || answer=="PR") {
                            ig.eosabox[i].setEnabled(true);
                            ig.eosabox[i].setEditable(true);
                            ig.eosbbox[i].setEnabled(true);
                            ig.eosbbox[i].setEditable(true);
                            ig.acentricbox[i].setEnabled(true);
                            ig.acentricbox[i].setEditable(true);
                            if(interact==1 || interact==2) {
                                ig.psi0box[i].setEnabled(false);
                                ig.psi0box[i].setEditable(false);
                            }
                            else if (interact==5) {
                                ig.eosalabel.setText("a:");
                                ig.eosblabel.setText("b:");
                                ig.eoscrit.setSelectedItem("eos parameters");
                                ig.eoscrit.setEnabled(true);
                            }
                            k = true;
                        }
                        else if(answer=="none") {
                            ig.eosabox[i].setEnabled(false);
                            ig.eosabox[i].setEditable(false);
                            ig.eosbbox[i].setEnabled(false);
                            ig.eosbbox[i].setEditable(false);
                        }
                        else if(answer=="quartic") {
                            ig.eosabox[i].setEnabled(true);
                            ig.eosabox[i].setEditable(true);
                            ig.eosbbox[i].setEnabled(false);
                            ig.eosbbox[i].setEditable(false);
                        }
                    }
                }
                if(k) {
                    j=false;
                    j1=false;
                    j2=false;
                    j3=false;
                    j4=false;
                    for(i=0; i<lbf; i++) {
                        j = (j || (ig.fluid[i].getSelectedIndex()>3));
                        j1 = (j1 || (ig.fluid[i].getSelectedIndex()>4));
                        j2 = (j2 || (ig.fluid[i].getSelectedIndex()>6 && ig.fluid[i].getSelectedIndex()<9));
                        j3 = (j3 || (ig.fluid[i].getSelectedIndex()==2));
                        j4 = (j4 || !(ig.fluid[i].getSelectedIndex()==0 || ig.fluid[i].getSelectedIndex()==4));
                    }
                    
                    if(j) {
                        ig.gasconstlabel.setEnabled(true);
                        ig.systemplabel.setEnabled(true);
                        ig.gasconst.setEnabled(true);
                        ig.gasconst.setEditable(true);
                        ig.systemp.setEnabled(true);
                        ig.systemp.setEditable(true);
                    }
                    else {
                        ig.gasconstlabel.setEnabled(false);
                        ig.systemplabel.setEnabled(false);
                        ig.gasconst.setEnabled(false);
                        ig.gasconst.setEditable(false);
                        ig.systemp.setEnabled(false);
                        ig.systemp.setEditable(false);
                    }
                    if(j1) {
                        ig.eoscrit.setEnabled(true);
                    }
                    else {
                        ig.eoscrit.setEnabled(false);
                    }
                    if(j2) {
                        ig.acentriclabel.setEnabled(true);
                    }
                    else {
                        ig.acentriclabel.setEnabled(false);
                    }
                    if(interact==1 || interact==2) {
                        if(j3)
                            ig.psi0label.setEnabled(true);
                        else
                            ig.psi0label.setEnabled(false);
                    }
                    if((j1 && (interact==1 || interact==2)) || (j4 && interact==5)) {
                        ig.eosalabel.setEnabled(true);
                        ig.eosblabel.setEnabled(true);
                    }
                    else {
                        ig.eosalabel.setEnabled(false);
                        ig.eosblabel.setEnabled(false);
                    }
                }
                if("wet".equals(combo.getName())) {
                    if(answer=="none") {
                        ig.wetadenslabel.setEnabled(false);
                        ig.wetbdenslabel.setEnabled(false);
                        ig.wallinteractions0.setEnabled(false);
                        ig.wallinteractions0.setEditable(false);
                        ig.wallinteractions1.setEnabled(false);
                        ig.wallinteractions1.setEditable(false);
                        ig.wetaconclabel.setEnabled(false);
                        ig.wetbconclabel.setEnabled(false);
                        ig.wallinteractions2.setEnabled(false);
                        ig.wallinteractions2.setEditable(false);
                        ig.wallinteractions3.setEnabled(false);
                        ig.wallinteractions3.setEditable(false);
                    }
                    else if(answer=="quadratic") {
                        ig.wetadenslabel.setEnabled(true);
                        ig.wetbdenslabel.setEnabled(true);
                        ig.wallinteractions0.setEnabled(true);
                        ig.wallinteractions0.setEditable(true);
                        ig.wallinteractions1.setEnabled(true);
                        ig.wallinteractions1.setEditable(true);
                        ig.wetaconclabel.setEnabled(true);
                        ig.wetbconclabel.setEnabled(true);
                        ig.wallinteractions2.setEnabled(true);
                        ig.wallinteractions2.setEditable(true);
                        ig.wallinteractions3.setEnabled(true);
                        ig.wallinteractions3.setEditable(true);
                    }
                }
                
            }            
        } catch (NullPointerException e) {
            // do nothing
        }
    }

    void setfluitparameter(int totf,int dim,int inter,double[] bdf,double[] bousf,double[] densf,double[] relaxtime) {
      setFluid sf= new setFluid(totf, dim, inter, bdf, bousf, densf, relaxtime);
    }

    void setfluitintparameter(int totf,int inter,double[] fluidinteract,int[] eos,int eoscrit, double[] eosa,double[] eosb,double[] acentric,double[] psi0,double[] quadw,int[] wettype, double[] wallinteract,double segregate,double gascon,double tempsys,double kappa,double taumob,double mobparam) {
      setFluidInteract sg= new setFluidInteract(totf, inter, fluidinteract, eos, eoscrit, eosa, eosb, acentric, psi0, quadw, wettype, wallinteract, segregate, gascon, tempsys, kappa, taumob, mobparam);
    }

    void setsoluteparameter(int totc,int dim,double[] solrelax,double[] concs) {
      setSolute ss = new setSolute(totc, dim, solrelax, concs);
    }

    void setthermalparameter(int dim,double heatrelax,double boustemph,double boustempl,double[] temps,double[] heatrates) {
      setThermal st = new setThermal(dim, heatrelax, boustemph, boustempl, temps, heatrates);
    }

    void ierr(String errinfo) {
      msgPanel fcer=new msgPanel(errinfo);	
    }

}
