import javax.swing.*;
import java.util.*;
import java.lang.*;
import java.io.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.geom.*;
import java.awt.image.*;
/*
 *     DL_MESO_GUI
 *     author: R. S. Qin, M. A. Seaton
 *     copyright: STFC Daresbury Laboratory and CCP5
 *     2005, 2015
 */
class setlbeSpa extends JPanel {
    /*
      DL_MESO_GUI 
      Set lattice Boltzmann space
      Author    :   R.S. Qin, M. A. Seaton
      Copyright :   STFC Daresbury Laboratory              
      Control Panel  
    */
    
    setlbeSpaEvt lbespace=new  setlbeSpaEvt(this);

    Font font=new Font("Dialog", Font.BOLD, 13);
    Color bgcolor=new Color(170, 200, 190);
    Color focolor=new Color(10, 10, 15);
    Color paneltop=new Color(170, 170, 230);

    JComboBox upwall=new JComboBox();
    
    JComboBox downwall=new JComboBox();
    
    JComboBox leftwall=new JComboBox();
    
    JComboBox rightwall=new JComboBox();
    
    JComboBox frontwall=new JComboBox();

    JComboBox backwall=new JComboBox();
    
    JLabel addobstacle=new JLabel("ADD OBSTACLES", JLabel.RIGHT);

    JLabel obsttypelabel=new JLabel("obstacle type:", JLabel.RIGHT);
    JComboBox obsttype=new JComboBox();
    JLabel obstbbtypelabel=new JLabel("bounce back type:", JLabel.RIGHT);
    JComboBox obstbbtype=new JComboBox();
    
    JTextField[] obstpos = new JTextField[7];
    JLabel x0=new JLabel("x0:", JLabel.RIGHT);
    JLabel y0=new JLabel("y0:", JLabel.RIGHT); 
    JLabel z0=new JLabel("z0:", JLabel.RIGHT); 
    JButton addobst = new JButton("add obstacle");

    JLabel dx=new JLabel("dx:", JLabel.RIGHT);
    JLabel dy=new JLabel("dy:", JLabel.RIGHT);
    JLabel dz=new JLabel("dz:", JLabel.RIGHT);
    JLabel radius=new JLabel("r:", JLabel.RIGHT);

    JLabel setporous=new JLabel("SET AS POROUS MEDIA", JLabel.RIGHT);

    JLabel porebbtypelabel=new JLabel("bounce back type:", JLabel.RIGHT);
    JComboBox porebbtype=new JComboBox();
    JLabel porous=new JLabel("pore fraction (%)", JLabel.RIGHT); 
    JTextField pore = new JTextField("0", 6);
    JButton setpore = new JButton("set pore");
    
    JLabel gradordlabel=new JLabel("gradient order:", JLabel.RIGHT);
    JComboBox gradord=new JComboBox();

    JButton creatspace = new JButton("Create");
    
    public setlbeSpa(int dim) {
        setSize(620, 530);
        JPanel panel1 = new JPanel();
        panel1.setLayout(new GridBagLayout());
	
        upwall.addItem("top periodic boundary condition");
        upwall.addItem("top on-grid bounce back");
        upwall.addItem("top mid-grid bounce back");
        upwall.addItem("top fixed V, C and T");
        upwall.addItem("top fixed V and C, Neumann T");
        upwall.addItem("top fixed V and T, Neumann C");
        upwall.addItem("top fixed V, Neumann C and T");
        upwall.addItem("top fixed P, C and T");
        upwall.addItem("top fixed P and C, Neumann T");
        upwall.addItem("top fixed P and T, Neumann C");
        upwall.addItem("top fixed P, Neumann C and T");
        upwall.setFont(font);
        upwall.addItemListener(lbespace);
        addItemFill(panel1, upwall, 0, 0, 8, 1, GridBagConstraints.CENTER, GridBagConstraints.HORIZONTAL);

        downwall.addItem("bottom periodic boundary condition");
        downwall.addItem("bottom on-grid bounce back");
        downwall.addItem("bottom mid-grid bounce back");
        downwall.addItem("bottom fixed V, C and T");
        downwall.addItem("bottom fixed V and C, Neumann T");
        downwall.addItem("bottom fixed V and T, Neumann C");
        downwall.addItem("bottom fixed V, Neumann C and T");
        downwall.addItem("bottom fixed P, C and T");
        downwall.addItem("bottom fixed P and C, Neumann T");
        downwall.addItem("bottom fixed P and T, Neumann C");
        downwall.addItem("bottom fixed P, Neumann C and T");
        downwall.setFont(font);
        downwall.addItemListener(lbespace);
        addItemFill(panel1, downwall, 0, 1, 8, 1, GridBagConstraints.CENTER, GridBagConstraints.HORIZONTAL);

        leftwall.addItem("left periodic boundary condition");
        leftwall.addItem("left on-grid bounce back");
        leftwall.addItem("left mid-grid bounce back");
        leftwall.addItem("left fixed V, C and T");
        leftwall.addItem("left fixed V and C, Neumann T");
        leftwall.addItem("left fixed V and T, Neumann C");
        leftwall.addItem("left fixed V, Neumann C and T");
        leftwall.addItem("left fixed P, C and T");
        leftwall.addItem("left fixed P and C, Neumann T");
        leftwall.addItem("left fixed P and T, Neumann C");
        leftwall.addItem("left fixed P, Neumann C and T");
        leftwall.setFont(font);
        leftwall.addItemListener(lbespace);
        addItemFill(panel1, leftwall, 0, 2, 8, 1, GridBagConstraints.CENTER, GridBagConstraints.HORIZONTAL);

        rightwall.addItem("right periodic boundary condition");
        rightwall.addItem("right on-grid bounce back");
        rightwall.addItem("right mid-grid bounce back");
        rightwall.addItem("right fixed V, C and T");
        rightwall.addItem("right fixed V and C, Neumann T");
        rightwall.addItem("right fixed V and T, Neumann C");
        rightwall.addItem("right fixed V, Neumann C and T");
        rightwall.addItem("right fixed P, C and T");
        rightwall.addItem("right fixed P and C, Neumann T");
        rightwall.addItem("right fixed P and T, Neumann C");
        rightwall.addItem("right fixed P, Neumann C and T");
        rightwall.setFont(font);
        rightwall.addItemListener(lbespace);
        addItemFill(panel1, rightwall, 0, 3, 8, 1, GridBagConstraints.CENTER, GridBagConstraints.HORIZONTAL);

        frontwall.addItem("front periodic boundary condition");
        frontwall.addItem("front on-grid bounce back");
        frontwall.addItem("front mid-grid bounce back");
        frontwall.addItem("front fixed V, C and T");
        frontwall.addItem("front fixed V and C, Neumann T");
        frontwall.addItem("front fixed V and T, Neumann C");
        frontwall.addItem("front fixed V, Neumann C and T");
        frontwall.addItem("front fixed P, C and T");
        frontwall.addItem("front fixed P and C, Neumann T");
        frontwall.addItem("front fixed P and T, Neumann C");
        frontwall.addItem("front fixed P, Neumann C and T");
        frontwall.setFont(font);
        frontwall.addItemListener(lbespace);
        addItemFill(panel1, frontwall, 0, 4, 8, 1, GridBagConstraints.CENTER, GridBagConstraints.HORIZONTAL);
        if (dim==2)
            frontwall.setEnabled(false);

        backwall.addItem("back periodic boundary condition");
        backwall.addItem("back on-grid bounce back");
        backwall.addItem("back mid-grid bounce back");
        backwall.addItem("back fixed V, C and T");
        backwall.addItem("back fixed V and C, Neumann T");
        backwall.addItem("back fixed V and T, Neumann C");
        backwall.addItem("back fixed V, Neumann C and T");
        backwall.addItem("back fixed P, C and T");
        backwall.addItem("back fixed P and C, Neumann T");
        backwall.addItem("back fixed P and T, Neumann C");
        backwall.addItem("back fixed P, Neumann C and T");
        backwall.setFont(font);
        backwall.addItemListener(lbespace);
        addItemFill(panel1, backwall, 0, 5, 8, 1, GridBagConstraints.CENTER, GridBagConstraints.HORIZONTAL);
        if (dim==2)
            backwall.setEnabled(false);

        gradordlabel.setFont(font);
        addItem(panel1, gradordlabel, 0, 6, 2, 1, GridBagConstraints.EAST);
        
        gradord.addItem("1");
        gradord.addItem("2");
        gradord.setFont(font);
        gradord.addItemListener(lbespace);
        addItem(panel1, gradord, 2, 6, 2, 1, GridBagConstraints.CENTER);
        
        addobstacle.setFont(font);
        addItemPadding(panel1, addobstacle, 0, 7, 8, 1, GridBagConstraints.CENTER, 10);

        obstbbtypelabel.setFont(font);
        addItem(panel1, obstbbtypelabel, 0, 8, 1, 1, GridBagConstraints.EAST);

        obstbbtype.addItem("on-grid");
        obstbbtype.addItem("mid-grid");
        obstbbtype.setFont(font);
        obstbbtype.addItemListener(lbespace);
        addItemFill(panel1, obstbbtype, 1, 8, 1, 1, GridBagConstraints.CENTER, GridBagConstraints.HORIZONTAL);

        obsttypelabel.setFont(font);
        addItem(panel1, obsttypelabel, 0, 9, 1, 1, GridBagConstraints.EAST);

        obsttype.addItem("point");
        obsttype.addItem("sphere");
        obsttype.addItem("cylinder");
        obsttype.addItem("block");
        obsttype.setFont(font);
        obsttype.addItemListener(lbespace);
        addItemFill(panel1, obsttype, 1, 9, 1, 1, GridBagConstraints.CENTER, GridBagConstraints.HORIZONTAL);

        addItem(panel1, x0, 2, 8, 1, 1, GridBagConstraints.EAST);
        addItem(panel1, y0, 2, 9, 1, 1, GridBagConstraints.EAST);
        addItem(panel1, z0, 2, 10, 1, 1, GridBagConstraints.EAST);
        addItem(panel1, dx, 4, 8, 1, 1, GridBagConstraints.EAST);
        addItem(panel1, dy, 4, 9, 1, 1, GridBagConstraints.EAST);
        addItem(panel1, dz, 4, 10, 1, 1, GridBagConstraints.EAST);
        for(int i=0; i<3; i++) {
            obstpos[i] = new JTextField(4);
            addItem(panel1, obstpos[i], 3, i+8, 1, 1, GridBagConstraints.CENTER);
        }
        for(int i=0; i<3; i++) {
            obstpos[i+3] = new JTextField(4);
            addItem(panel1, obstpos[i+3], 5, i+8, 1, 1, GridBagConstraints.CENTER);
        }
        addItem(panel1, radius, 6, 8, 1, 1, GridBagConstraints.EAST);
        obstpos[6] = new JTextField(4);
        addItem(panel1, obstpos[6], 7, 8, 1, 1, GridBagConstraints.CENTER);

        addobst.setFont(font);
        addobst.addActionListener(lbespace);
        addItem(panel1, addobst, 0, 11, 8, 1, GridBagConstraints.CENTER);
       
        setporous.setFont(font);
        addItemPadding(panel1, setporous, 0, 12, 8, 1, GridBagConstraints.CENTER, 10);

        porebbtypelabel.setFont(font);
        addItem(panel1, porebbtypelabel, 0, 13, 1, 1, GridBagConstraints.EAST);

        porebbtype.addItem("on-grid");
        porebbtype.addItem("mid-grid");
        porebbtype.setFont(font);
        porebbtype.addItemListener(lbespace);
        addItem(panel1, porebbtype, 1, 13, 1, 1, GridBagConstraints.CENTER);

        porous.setFont(font);
        addItem(panel1, porous, 3, 13, 3, 1, GridBagConstraints.EAST);
        addItem(panel1, pore, 6, 13, 2, 1, GridBagConstraints.CENTER);

        setpore.setFont(font);
        setpore.addActionListener(lbespace);
        addItem(panel1, setpore, 0, 14, 8, 1, GridBagConstraints.CENTER);

        Box creatspacebox = Box.createHorizontalBox();
        creatspace.setFont(font);
        creatspace.setBackground(bgcolor);
        creatspace.addActionListener(lbespace);
        creatspacebox.add(creatspace);
        addItemPadding(panel1, creatspacebox, 0, 15, 8, 1, GridBagConstraints.CENTER, 20);

        if(dim==2) {
            z0.setEnabled(false);
            obstpos[2].setEnabled(false);
        }
        dx.setEnabled(false);
        dy.setEnabled(false);
        dz.setEnabled(false);
        radius.setEnabled(false);
        obstpos[3].setEnabled(false);
        obstpos[4].setEnabled(false);
        obstpos[5].setEnabled(false);
        obstpos[6].setEnabled(false);

        this.add(panel1);
    }

    private void addItem(JPanel p, JComponent c, int x, int y, int width, int height, int align) {
        GridBagConstraints gc = new GridBagConstraints();
        gc.gridx = x;
        gc.gridy = y;
        gc.gridwidth = width;
        gc.gridheight = height;
        gc.weightx = 100.0;
        gc.weighty = 100.0;
        gc.insets = new Insets(5, 5, 5, 5);
        gc.anchor = align;
        gc.fill = GridBagConstraints.NONE;
        p.add(c, gc);
    }
    
    private void addItemFill(JPanel p, JComponent c, int x, int y, int width, int height, int align, int fill) {
        GridBagConstraints gc = new GridBagConstraints();
        gc.gridx = x;
        gc.gridy = y;
        gc.gridwidth = width;
        gc.gridheight = height;
        gc.weightx = 100.0;
        gc.weighty = 100.0;
        gc.insets = new Insets(5, 5, 5, 5);
        gc.anchor = align;
        gc.fill = fill;
        p.add(c, gc);
    }

    private void addItemPadding(JPanel p, JComponent c, int x, int y, int width, int height, int align, int padding) {
        GridBagConstraints gc = new GridBagConstraints();
        gc.gridx = x;
        gc.gridy = y;
        gc.gridwidth = width;
        gc.gridheight = height;
        gc.weightx = 100.0;
        gc.weighty = 100.0;
        gc.insets = new Insets(padding, padding, padding, padding);
        gc.anchor = align;
        gc.fill = GridBagConstraints.NONE;
        p.add(c, gc);
    }

}
