import javax.swing.*;
import java.util.*;
import java.lang.*;
import java.io.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.geom.*;
import java.awt.image.*;
/*
 *     DL_MESO_GUI
 *     author: R. S. Qin, M. A. Seaton
 *     copyright: STFC Daresbury Laboratory and CCP5
 *     2005, 2015
 */
class setFluidInteract extends JFrame {
    
    setlbeSysEvt fluinterinilbe=new setlbeSysEvt(this);

	JLabel pseudolabel = new JLabel("pseudopotential:", JLabel.RIGHT);

    JLabel eoslabel = new JLabel("equation of state:", JLabel.RIGHT);
    JLabel potentiallabel = new JLabel("potential:", JLabel.RIGHT);

    JLabel interactionlabel = new JLabel("interaction parameters:", 
					 JLabel.RIGHT);
    
    JTextField[] interactions = new JTextField[36];

    JLabel quadweightlabel = new JLabel("quadratic weights:", JLabel.RIGHT);

    JTextField[] quadweight = new JTextField[6];

	JLabel wettypelabel = new JLabel("wetting type:", JLabel.RIGHT);

    JTextField wallinteractions0=new JTextField("0", 8);
    JTextField wallinteractions1=new JTextField("0", 8);
    JTextField wallinteractions2=new JTextField("0", 8);
    JTextField wallinteractions3=new JTextField("0", 8);
    JTextField wallinteractions4=new JTextField("0", 8);
    JTextField wallinteractions5=new JTextField("0", 8);

    JLabel segregationlabel = new JLabel("segregation parameter:", JLabel.RIGHT);
    
    JTextField segregation =new JTextField(8);

	JComboBox[] fluid = new JComboBox[6];
    
    JComboBox eoscrit = new JComboBox();
    JLabel eosalabel = new JLabel("a:", JLabel.RIGHT);
    JLabel eosblabel = new JLabel("b:", JLabel.RIGHT);
    JLabel acentriclabel = new JLabel("acentric factor:", JLabel.RIGHT);
    JLabel psi0label = new JLabel("psi0:", JLabel.RIGHT);
    JLabel potalabel = new JLabel("a:", JLabel.RIGHT);
    JLabel potblabel = new JLabel("b:", JLabel.RIGHT);
    
    JTextField[] eosabox = new JTextField[6];
    JTextField[] eosbbox = new JTextField[6];
    JTextField[] acentricbox = new JTextField[6];
    JTextField[] psi0box = new JTextField[6];
    
    JLabel gasconstlabel = new JLabel("gas constant R:", JLabel.RIGHT);
    JTextField gasconst = new JTextField(8);
    JLabel systemplabel = new JLabel("isothermal system temperature:", JLabel.RIGHT);
    JTextField systemp = new JTextField(8);
    
    JLabel wallinteractlabel = new JLabel("wall interaction parameters:", JLabel.RIGHT);
    JLabel wetadenslabel = new JLabel("density a_0:", JLabel.RIGHT);
    JLabel wetbdenslabel = new JLabel("density a_1:", JLabel.RIGHT);
    JLabel wetaconclabel = new JLabel("concentration b_0:", JLabel.RIGHT);
    JLabel wetbconclabel = new JLabel("concentration b_1:", JLabel.RIGHT);
	JComboBox[] wet = new JComboBox[6];

    JLabel kappalabel = new JLabel("surface tension parameter:", JLabel.RIGHT);
    JLabel taumoblabel = new JLabel("mobility relaxation time:", JLabel.RIGHT);
    JLabel mobilitylabel = new JLabel("mobility parameter:", JLabel.RIGHT);
    
    JButton save = new JButton("SAVE FI");
    JButton close = new JButton("CANCEL FI");
    Font font=new Font("Dialog", Font.BOLD, 13);
    
    public setFluidInteract(int totf, int inter, double[] interact, int[] eos, int eoscrt, double[] eosa, double[] eosb, double[] acentric, double[] psi0, double[] quadw, int[] wettyp, double[] wallinteract, double segregate, double gascon, double tempsys, double kappa, double taumob, double mobparam) {

        super("LBE fluid interaction properties");
        Boolean k, k1, k2, k3;
        
//		setBounds(160, 10, 220+81*totf, 692+54*totf);
		JPanel pane=new JPanel(new GridBagLayout());

//		interactionlabel.setFont(font);
//		addItem(pane, interactionlabel, 0, 0, 2, 1, GridBagConstraints.WEST);

		Box buttonBox = Box.createHorizontalBox();
		switch (inter) {
			case 1:
			// Shan-Chen interactions (standard form)
                k = false;
                k1 = false;
                k2 = false;
                k3 = false;
				pseudolabel.setFont(font);
				addItem(pane, pseudolabel, 0, 1, 1, 1, GridBagConstraints.WEST);
				for(int i=0; i<totf; i++) {
					addItem(pane, new JLabel("fluid "+i), i+2, 0, 1, 1, GridBagConstraints.CENTER);
					fluid[i] = new JComboBox();
					fluid[i].addItem("lattice gas");
					fluid[i].addItem("SC 1993");
					fluid[i].addItem("SC 1994");
					fluid[i].addItem("density");
					fluid[i].addItem("ideal gas");
					fluid[i].addItem("vdW");
					fluid[i].addItem("RK");
					fluid[i].addItem("SRK");
					fluid[i].addItem("PR");
					fluid[i].addItem("CS-vdW");
					fluid[i].addItem("CS-RK");
                    fluid[i].setName("eos"+i);
					fluid[i].addItemListener(fluinterinilbe);
                    fluid[i].setSelectedIndex(eos[i]);
                    k = (k || eos[i]>3);
                    k1 = (k1 || eos[i]>4);
                    k2 = (k2 || (eos[i]>6 && eos[i]<9));
                    k3 = (k3 || eos[i]==2);
					addItem(pane, fluid[i], i+2, 1, 1, 1, GridBagConstraints.CENTER);
				}
                eoscrit.addItem("eos parameters");
                eoscrit.addItem("critical properties");
                eoscrit.setSelectedIndex(eoscrt);
                if(k1) {
                    eoscrit.setEnabled(true);
                    eosalabel.setEnabled(true);
                    eosblabel.setEnabled(true);
                }
                else {
                    eoscrit.setEnabled(false);
                    eosalabel.setEnabled(false);
                    eosblabel.setEnabled(false);
                }
                if(k2)
                    acentriclabel.setEnabled(true);
                else
                    acentriclabel.setEnabled(false);
                if(k3)
                    psi0label.setEnabled(true);
                else
                    psi0label.setEnabled(false);
                
                eoscrit.addItemListener(fluinterinilbe);
                addItem(pane, eoscrit, 0, 2, 1, 1, GridBagConstraints.WEST);
                eosalabel.setFont(font);
                eosblabel.setFont(font);
                acentriclabel.setFont(font);
                psi0label.setFont(font);
                addItem(pane, eosalabel, 1, 2, 1, 1, GridBagConstraints.EAST);
                addItem(pane, eosblabel, 1, 3, 1, 1, GridBagConstraints.EAST);
                addItem(pane, acentriclabel, 1, 4, 1, 1, GridBagConstraints.EAST);
                addItem(pane, psi0label, 1, 5, 1, 1, GridBagConstraints.EAST);
                for(int j=0; j<totf; j++) {
                    eosabox[j]=new JTextField(8);
                    eosabox[j].setText(Double.toString(eosa[j]));
                    if(eos[j]<5) {
                        eosabox[j].setEnabled(false);
                        eosabox[j].setEditable(false);
                    }
                    else {
                        eosabox[j].setEnabled(true);
                        eosabox[j].setEditable(true);
                    }
                    addItem(pane, eosabox[j], 2+j, 2, 1, 1, GridBagConstraints.CENTER);
                    eosbbox[j]=new JTextField(8);
                    eosbbox[j].setText(Double.toString(eosb[j]));
                    if(eos[j]<5) {
                        eosbbox[j].setEnabled(false);
                        eosbbox[j].setEditable(false);
                    }
                    else {
                        eosbbox[j].setEnabled(true);
                        eosbbox[j].setEditable(true);
                    }
                    addItem(pane, eosbbox[j], 2+j, 3, 1, 1, GridBagConstraints.CENTER);
                    acentricbox[j]=new JTextField(8);
                    acentricbox[j].setText(Double.toString(acentric[j]));
                    if(eos[j]==7 || eos[j]==8) {
                        acentricbox[j].setEnabled(true);
                        acentricbox[j].setEditable(true);
                    }
                    else {
                        acentricbox[j].setEnabled(false);
                        acentricbox[j].setEditable(false);
                    }
                    addItem(pane, acentricbox[j], 2+j, 4, 1, 1, GridBagConstraints.CENTER);
                    psi0box[j]=new JTextField(8);
                    psi0box[j].setText(Double.toString(psi0[j]));
                    if(eos[j]==2) {
                        psi0box[j].setEnabled(true);
                        psi0box[j].setEditable(true);
                    }
                    else {
                        psi0box[j].setEnabled(false);
                        psi0box[j].setEditable(false);
                    }
                    addItem(pane, psi0box[j], 2+j, 5, 1, 1, GridBagConstraints.CENTER);
                }
                gasconstlabel.setFont(font);
                systemplabel.setFont(font);
                if(k) {
                    gasconstlabel.setEnabled(true);
                    systemplabel.setEnabled(true);
                    gasconst.setEnabled(true);
                    gasconst.setEditable(true);
                    systemp.setEnabled(true);
                    systemp.setEditable(true);
                }
                else {
                    gasconstlabel.setEnabled(false);
                    systemplabel.setEnabled(false);
                    gasconst.setEnabled(false);
                    gasconst.setEditable(false);
                    systemp.setEnabled(false);
                    systemp.setEditable(false);
                }
                addItem(pane, gasconstlabel, 0, 6, 2, 1, GridBagConstraints.EAST);
                addItem(pane, systemplabel, 0, 7, 2, 1, GridBagConstraints.EAST);
                gasconst.setText(Double.toString(gascon));
                addItem(pane, gasconst, 2, 6, 1, 1, GridBagConstraints.CENTER);
                systemp.setText(Double.toString(tempsys));
                addItem(pane, systemp, 2, 7, 1, 1, GridBagConstraints.CENTER);
                
				interactionlabel.setFont(font);
				addItem(pane, interactionlabel, 0, 9, 1, 1, GridBagConstraints.WEST);
				for(int j=0; j<totf; j++) {
					addItem(pane, new JLabel("fluid "+j), j+2, 8, 1, 1, GridBagConstraints.CENTER);
					addItem(pane, new JLabel("fluid "+j), 1, j+9, 1, 1, GridBagConstraints.EAST);
					for(int i=j; i<totf; i++) {
						interactions[i + j*totf]=new JTextField(8);
						interactions[i + j*totf].setText(Double.toString(interact[i+j*totf]));
						addItem(pane, interactions[i + j*totf], i+2, j+9, 1, 1, GridBagConstraints.CENTER);
					}
				}	
				wettypelabel.setFont(font);
				addItem(pane, wettypelabel, 0, 9+totf, 2, 1, GridBagConstraints.WEST);
				wallinteractlabel.setFont(font);
				addItem(pane, wallinteractlabel, 0, 10+totf, 2, 1, GridBagConstraints.WEST);
				for(int j=0; j<totf; j++) {
					wet[j] = new JComboBox();
					wet[j].addItem("density");
					wet[j].addItem("potential");
					wet[j].addItem("screened");
                    wet[j].setSelectedIndex(wettyp[j]);
					wet[j].addItemListener(fluinterinilbe);
					addItem(pane, wet[j], j+2, 9+totf, 1, 1, GridBagConstraints.CENTER);
                    switch (j) {
                        case 0:
                            wallinteractions0.setText(Double.toString(wallinteract[0]));
                            addItem(pane, wallinteractions0, 2, 10+totf, 1, 1, GridBagConstraints.CENTER);
                            break;
                        case 1:
                            wallinteractions1.setText(Double.toString(wallinteract[1]));
                            addItem(pane, wallinteractions1, 3, 10+totf, 1, 1, GridBagConstraints.CENTER);
                            break;
                        case 2:
                            wallinteractions2.setText(Double.toString(wallinteract[2]));
                            addItem(pane, wallinteractions2, 4, 10+totf, 1, 1, GridBagConstraints.CENTER);
                            break;
                        case 3:
                            wallinteractions3.setText(Double.toString(wallinteract[2]));
                            addItem(pane, wallinteractions3, 5, 10+totf, 1, 1, GridBagConstraints.CENTER);
                            break;
                        case 4:
                            wallinteractions4.setText(Double.toString(wallinteract[2]));
                            addItem(pane, wallinteractions4, 6, 10+totf, 1, 1, GridBagConstraints.CENTER);
                            break;
                        case 5:
                            wallinteractions5.setText(Double.toString(wallinteract[2]));
                            addItem(pane, wallinteractions5, 7, 10+totf, 1, 1, GridBagConstraints.CENTER);
                            break;
                    }
				}
				save.setFont(font);
				save.addActionListener(fluinterinilbe);
				buttonBox.add(save);
				close.setFont(font);
				close.addActionListener(fluinterinilbe);
				buttonBox.add(close);
				addItem(pane, buttonBox, 0, 11+totf, 4, 1, GridBagConstraints.WEST);
				break;
			case 2:
			// Shan-Chen interactions with quadratic terms
                k = false;
                k1 = false;
                k2 = false;
                k3 = false;
				pseudolabel.setFont(font);
				addItem(pane, pseudolabel, 0, 1, 1, 1, GridBagConstraints.WEST);
				for(int i=0; i<totf; i++) {
					addItem(pane, new JLabel("fluid "+i), i+2, 0, 1, 1, GridBagConstraints.CENTER);
					fluid[i] = new JComboBox();
					fluid[i].addItem("lattice gas");
					fluid[i].addItem("SC 1993");
					fluid[i].addItem("SC 1994");
					fluid[i].addItem("density");
					fluid[i].addItem("ideal gas");
					fluid[i].addItem("vdW");
					fluid[i].addItem("RK");
					fluid[i].addItem("SRK");
					fluid[i].addItem("PR");
					fluid[i].addItem("CS-vdW");
					fluid[i].addItem("CS-RK");
					fluid[i].addItemListener(fluinterinilbe);
                    fluid[i].setSelectedIndex(eos[i]);
                    k = (k || eos[i]>3);
                    k1 = (k1 || eos[i]>4);
                    k2 = (k2 || (eos[i]>6 && eos[i]<9));
                    k3 = (k3 || eos[i]==2);
					addItem(pane, fluid[i], i+2, 1, 1, 1, GridBagConstraints.CENTER);
				}
                eoscrit.addItem("eos parameters");
                eoscrit.addItem("critical properties");
                eoscrit.setSelectedIndex(eoscrt);
                if(k1) {
                    eoscrit.setEnabled(true);
                    eosalabel.setEnabled(true);
                    eosblabel.setEnabled(true);
                }
                else {
                    eoscrit.setEnabled(false);
                    eosalabel.setEnabled(false);
                    eosblabel.setEnabled(false);
                }
                if(k2)
                    acentriclabel.setEnabled(true);
                else
                    acentriclabel.setEnabled(false);
                if(k3)
                    psi0label.setEnabled(true);
                else
                    psi0label.setEnabled(false);
                
                eoscrit.addItemListener(fluinterinilbe);
                addItem(pane, eoscrit, 0, 2, 1, 1, GridBagConstraints.WEST);
                eosalabel.setFont(font);
                eosblabel.setFont(font);
                acentriclabel.setFont(font);
                psi0label.setFont(font);
                addItem(pane, eosalabel, 1, 2, 1, 1, GridBagConstraints.EAST);
                addItem(pane, eosblabel, 1, 3, 1, 1, GridBagConstraints.EAST);
                addItem(pane, acentriclabel, 1, 4, 1, 1, GridBagConstraints.EAST);
                addItem(pane, psi0label, 1, 5, 1, 1, GridBagConstraints.EAST);
                for(int j=0; j<totf; j++) {
                    eosabox[j]=new JTextField(8);
                    eosabox[j].setText(Double.toString(eosa[j]));
                    if(eos[j]<5) {
                        eosabox[j].setEnabled(false);
                        eosabox[j].setEditable(false);
                    }
                    else {
                        eosabox[j].setEnabled(true);
                        eosabox[j].setEditable(true);
                    }
                    addItem(pane, eosabox[j], 2+j, 2, 1, 1, GridBagConstraints.CENTER);
                    eosbbox[j]=new JTextField(8);
                    eosbbox[j].setText(Double.toString(eosb[j]));
                    if(eos[j]<5) {
                        eosbbox[j].setEnabled(false);
                        eosbbox[j].setEditable(false);
                    }
                    else {
                        eosbbox[j].setEnabled(true);
                        eosbbox[j].setEditable(true);
                    }
                    addItem(pane, eosbbox[j], 2+j, 3, 1, 1, GridBagConstraints.CENTER);
                    acentricbox[j]=new JTextField(8);
                    acentricbox[j].setText(Double.toString(acentric[j]));
                    if(eos[j]==7 || eos[j]==8) {
                        acentricbox[j].setEnabled(true);
                        acentricbox[j].setEditable(true);
                    }
                    else {
                        acentricbox[j].setEnabled(false);
                        acentricbox[j].setEditable(false);
                    }
                    addItem(pane, acentricbox[j], 2+j, 4, 1, 1, GridBagConstraints.CENTER);
                    psi0box[j]=new JTextField(8);
                    psi0box[j].setText(Double.toString(psi0[j]));
                    if(eos[j]==2) {
                        psi0box[j].setEnabled(true);
                        psi0box[j].setEditable(true);
                    }
                    else {
                        psi0box[j].setEnabled(false);
                        psi0box[j].setEditable(false);
                    }
                    addItem(pane, psi0box[j], 2+j, 5, 1, 1, GridBagConstraints.CENTER);
                }
                if(k) {
                    gasconstlabel.setEnabled(true);
                    systemplabel.setEnabled(true);
                    gasconst.setEnabled(true);
                    gasconst.setEditable(true);
                    systemp.setEnabled(true);
                    systemp.setEditable(true);
                }
                else {
                    gasconstlabel.setEnabled(false);
                    systemplabel.setEnabled(false);
                    gasconst.setEnabled(false);
                    gasconst.setEditable(false);
                    systemp.setEnabled(false);
                    systemp.setEditable(false);
                }
                gasconstlabel.setFont(font);
                systemplabel.setFont(font);
                addItem(pane, gasconstlabel, 0, 6, 2, 1, GridBagConstraints.EAST);
                addItem(pane, systemplabel, 0, 7, 2, 1, GridBagConstraints.EAST);
                gasconst.setText(Double.toString(gascon));
                addItem(pane, gasconst, 2, 6, 1, 1, GridBagConstraints.CENTER);
                systemp.setText(Double.toString(tempsys));
                addItem(pane, systemp, 2, 7, 1, 1, GridBagConstraints.CENTER);
                
				interactionlabel.setFont(font);
				addItem(pane, interactionlabel, 0, 9, 1, 1, GridBagConstraints.WEST);
				for(int j=0; j<totf; j++) {
                    addItem(pane, new JLabel("fluid "+j), j+2, 8, 1, 1, GridBagConstraints.CENTER);
					addItem(pane, new JLabel("fluid "+j), 1, j+9, 1, 1, GridBagConstraints.EAST);
					for(int i=j; i<totf; i++) {
						interactions[i + j*totf]=new JTextField(8);
						interactions[i + j*totf].setText(Double.toString(interact[i+j*totf]));
						addItem(pane, interactions[i + j*totf], i+2, j+9, 1, 1, GridBagConstraints.CENTER);
					}
				}	
				quadweightlabel.setFont(font);
				addItem(pane, quadweightlabel, 0, 9+totf, 1, 1, GridBagConstraints.WEST);
				for(int j=0; j<totf; j++) {
					quadweight[j]=new JTextField("0", 8);
					quadweight[j].setText(Double.toString(quadw[j]));
					addItem(pane, quadweight[j], j+2, 9+totf, 1, 1, GridBagConstraints.CENTER);
				}			
				wettypelabel.setFont(font);
				addItem(pane, wettypelabel, 0, 10+totf, 2, 1, GridBagConstraints.WEST);
				wallinteractlabel.setFont(font);
				addItem(pane, wallinteractlabel, 0, 11+totf, 1, 1, GridBagConstraints.WEST);
				for(int j=0; j<totf; j++) {
					wet[j] = new JComboBox();
					wet[j].addItem("density");
					wet[j].addItem("potential");
					wet[j].addItem("screened");
                    wet[j].setSelectedIndex(wettyp[j]);
					wet[j].addItemListener(fluinterinilbe);
					addItem(pane, wet[j], j+2, 10+totf, 1, 1, GridBagConstraints.CENTER);
                    switch (j) {
                        case 0:
                            wallinteractions0.setText(Double.toString(wallinteract[0]));
                            addItem(pane, wallinteractions0, 2, 10+totf, 1, 1, GridBagConstraints.CENTER);
                            break;
                        case 1:
                            wallinteractions1.setText(Double.toString(wallinteract[1]));
                            addItem(pane, wallinteractions1, 3, 10+totf, 1, 1, GridBagConstraints.CENTER);
                            break;
                        case 2:
                            wallinteractions2.setText(Double.toString(wallinteract[2]));
                            addItem(pane, wallinteractions2, 4, 10+totf, 1, 1, GridBagConstraints.CENTER);
                            break;
                        case 3:
                            wallinteractions3.setText(Double.toString(wallinteract[2]));
                            addItem(pane, wallinteractions3, 5, 10+totf, 1, 1, GridBagConstraints.CENTER);
                            break;
                        case 4:
                            wallinteractions4.setText(Double.toString(wallinteract[2]));
                            addItem(pane, wallinteractions4, 6, 10+totf, 1, 1, GridBagConstraints.CENTER);
                            break;
                        case 5:
                            wallinteractions5.setText(Double.toString(wallinteract[2]));
                            addItem(pane, wallinteractions5, 7, 10+totf, 1, 1, GridBagConstraints.CENTER);
                            break;
                    }
				}
				save.setFont(font);
				save.addActionListener(fluinterinilbe);
				buttonBox.add(save);
				close.setFont(font);
				close.addActionListener(fluinterinilbe);
				buttonBox.add(close);
				addItem(pane, buttonBox, 0, 12+totf, 4, 1, GridBagConstraints.WEST);
				break;
			case 3:
			// Lishchuk interactions (calculated non-locally)
                interactionlabel.setFont(font);
                addItem(pane, interactionlabel, 0, 1, 1, 1, GridBagConstraints.WEST);
                for(int j=0; j<totf; j++) {
                    if(j>0) addItem(pane, new JLabel("fluid "+j), j+1, 0, 1, 1, GridBagConstraints.CENTER);
                    if(j<totf-1) addItem(pane, new JLabel("fluid "+j), 1, j+1, 1, 1, GridBagConstraints.EAST);
                    for(int i=j; i<totf; i++) {
                        if(i!=j) {
                            interactions[i + j*totf]=new JTextField(8);
                            interactions[i + j*totf].setText(Double.toString(interact[i+j*totf]));
                            addItem(pane, interactions[i + j*totf], i+1, j+1, 1, 1, GridBagConstraints.CENTER);
                        }
                    }
                }	
                segregationlabel.setFont(font);
                segregation.setText(Double.toString(segregate));
                addItem(pane, segregationlabel, 0, 1+totf, 2, 1, GridBagConstraints.WEST);
                addItem(pane, segregation, 2, 1+totf, 1, 1, GridBagConstraints.CENTER);
                save.setFont(font);
                save.addActionListener(fluinterinilbe);
                buttonBox.add(save);
                close.setFont(font);
                close.addActionListener(fluinterinilbe);
                buttonBox.add(close);
                addItem(pane, buttonBox, 0, 2+totf, 4, 1, GridBagConstraints.WEST);
				break;
            case 4:
                // Lishchuk interactions (calculated locally)
                interactionlabel.setFont(font);
                addItem(pane, interactionlabel, 0, 1, 1, 1, GridBagConstraints.WEST);
                for(int j=0; j<totf; j++) {
                    if(j>0) addItem(pane, new JLabel("fluid "+j), j+1, 0, 1, 1, GridBagConstraints.CENTER);
                    if(j<totf-1) addItem(pane, new JLabel("fluid "+j), 1, j+1, 1, 1, GridBagConstraints.EAST);
                    for(int i=j; i<totf; i++) {
                        if(i!=j) {
                            interactions[i + j*totf]=new JTextField(8);
                            interactions[i + j*totf].setText(Double.toString(interact[i+j*totf]));
                            addItem(pane, interactions[i + j*totf], i+1, j+1, 1, 1, GridBagConstraints.CENTER);
                        }
                    }
                }
                segregationlabel.setFont(font);
                segregation.setText(Double.toString(segregate));
                addItem(pane, segregationlabel, 0, 1+totf, 2, 1, GridBagConstraints.WEST);
                addItem(pane, segregation, 2, 1+totf, 1, 1, GridBagConstraints.CENTER);
                save.setFont(font);
                save.addActionListener(fluinterinilbe);
                buttonBox.add(save);
                close.setFont(font);
                close.addActionListener(fluinterinilbe);
                buttonBox.add(close);
                addItem(pane, buttonBox, 0, 2+totf, 4, 1, GridBagConstraints.WEST);
                break;
            case 5:
                // Swift interactions
                eoslabel.setFont(font);
                addItem(pane, eoslabel, 0, 0, 1, 1, GridBagConstraints.WEST);
                fluid[0] = new JComboBox();
                fluid[0].addItem("lattice gas");
                fluid[0].addItem("SC 1993");
                fluid[0].addItem("SC 1994");
                fluid[0].addItem("quadratic");
                fluid[0].addItem("ideal gas");
                fluid[0].addItem("vdW");
                fluid[0].addItem("RK");
                fluid[0].addItem("SRK");
                fluid[0].addItem("PR");
                fluid[0].addItem("CS-vdW");
                fluid[0].addItem("CS-RK");
                fluid[0].setName("eos0");
                fluid[0].addItemListener(fluinterinilbe);
                fluid[0].setSelectedIndex(eos[0]);
                addItem(pane, fluid[0], 2, 0, 1, 1, GridBagConstraints.CENTER);
                eoscrit.addItem("eos parameters");
                eoscrit.addItem("critical properties");
                eoscrit.setSelectedIndex(eoscrt);
                if(eos[0]<5) {
                    eoscrit.setEnabled(false);
                }
                else {
                    eoscrit.setEnabled(true);
                }
                eoscrit.addItemListener(fluinterinilbe);
                addItem(pane, eoscrit, 0, 1, 1, 1, GridBagConstraints.WEST);
                if(eos[0]==1 || eos[0]==2 || eos[0]==3)
                    eosalabel.setText("g:");
                if(eos[0]==1 || eos[0]==3)
                    eosblabel.setText("");
                if(eos[0]==2)
                    eosblabel.setText("psi0:");
                eosalabel.setFont(font);
                eosblabel.setFont(font);
                acentriclabel.setFont(font);
                addItem(pane, eosalabel, 1, 1, 1, 1, GridBagConstraints.EAST);
                addItem(pane, eosblabel, 1, 2, 1, 1, GridBagConstraints.EAST);
                addItem(pane, acentriclabel, 1, 3, 1, 1, GridBagConstraints.EAST);
                eosabox[0]=new JTextField(8);
                eosbbox[0]=new JTextField(8);
                acentricbox[0]=new JTextField(8);
                if(eos[0]==0 || eos[0]==4) {
                    eosabox[0].setEnabled(false);
                    eosabox[0].setEditable(false);
                    eosbbox[0].setEnabled(false);
                    eosbbox[0].setEditable(false);
                    acentricbox[0].setEnabled(false);
                    acentricbox[0].setEditable(false);
                    eosalabel.setEnabled(false);
                    eosblabel.setEnabled(false);
                    acentriclabel.setEnabled(false);
                }
                if(eos[0]==1 || eos[0]==3) {
                    eosabox[0].setEnabled(true);
                    eosabox[0].setEditable(true);
                    eosbbox[0].setEnabled(false);
                    eosbbox[0].setEditable(false);
                    acentricbox[0].setEnabled(false);
                    acentricbox[0].setEditable(false);
                    eosalabel.setEnabled(true);
                    eosblabel.setEnabled(true);
                    acentriclabel.setEnabled(false);
                }
                if(eos[0]==2 || eos[0]==5 || eos[0]==6 || eos[0]==9 || eos[0]==10) {
                    eosabox[0].setEnabled(true);
                    eosabox[0].setEditable(true);
                    eosbbox[0].setEnabled(true);
                    eosbbox[0].setEditable(true);
                    acentricbox[0].setEnabled(false);
                    acentricbox[0].setEditable(false);
                    eosalabel.setEnabled(true);
                    eosblabel.setEnabled(true);
                    acentriclabel.setEnabled(false);
                }
                if(eos[0]==7 || eos[0]==8) {
                    eosabox[0].setEnabled(true);
                    eosabox[0].setEditable(true);
                    eosbbox[0].setEnabled(true);
                    eosbbox[0].setEditable(true);
                    acentricbox[0].setEnabled(true);
                    acentricbox[0].setEditable(true);
                    eosalabel.setEnabled(true);
                    eosblabel.setEnabled(true);
                    acentriclabel.setEnabled(true);
                }
                eosabox[0].setText(Double.toString(eosa[0]));
                addItem(pane, eosabox[0], 2, 1, 1, 1, GridBagConstraints.CENTER);
                eosbbox[0].setText(Double.toString(eosb[0]));
                addItem(pane, eosbbox[0], 2, 2, 1, 1, GridBagConstraints.CENTER);
                acentricbox[0].setText(Double.toString(acentric[0]));
                addItem(pane, acentricbox[0], 2, 3, 1, 1, GridBagConstraints.CENTER);
                gasconstlabel.setFont(font);
                systemplabel.setFont(font);
                if(eos[0]<4) {
                    gasconstlabel.setEnabled(false);
                    systemplabel.setEnabled(false);
                    gasconst.setEnabled(false);
                    gasconst.setEditable(false);
                    systemp.setEnabled(false);
                    systemp.setEditable(false);
                }
                else {
                    gasconstlabel.setEnabled(true);
                    systemplabel.setEnabled(true);
                    gasconst.setEnabled(true);
                    gasconst.setEditable(true);
                    systemp.setEnabled(true);
                    systemp.setEditable(true);
                }
                addItem(pane, gasconstlabel, 0, 4, 2, 1, GridBagConstraints.EAST);
                addItem(pane, systemplabel, 0, 5, 2, 1, GridBagConstraints.EAST);
                gasconst.setText(Double.toString(gascon));
                addItem(pane, gasconst, 2, 4, 1, 1, GridBagConstraints.CENTER);
                systemp.setText(Double.toString(tempsys));
                addItem(pane, systemp, 2, 5, 1, 1, GridBagConstraints.CENTER);
                fluid[1] = new JComboBox();
                fluid[1].addItem("none");
                fluid[1].addItem("quartic");
                fluid[1].setName("eos1");
                fluid[1].addItemListener(fluinterinilbe);
                fluid[1].setSelectedIndex(eos[1]);
                eosabox[1]=new JTextField(8);
                eosbbox[1]=new JTextField(8);
                eosabox[1].setText(Double.toString(eosa[1]));
                eosbbox[1].setText(Double.toString(eosb[1]));
                if(eos[1]==0) {
                    eosabox[1].setEnabled(false);
                    eosabox[1].setEditable(false);
                }
                else {
                    eosabox[1].setEnabled(true);
                    eosabox[1].setEditable(true);
                }
                eosbbox[1].setEnabled(false);
                eosbbox[1].setEditable(false);
                if(totf>1) {
                    potentiallabel.setFont(font);
                    addItem(pane, potentiallabel, 0, 6, 1, 1, GridBagConstraints.WEST);
                    addItem(pane, fluid[1], 2, 6, 1, 1, GridBagConstraints.CENTER);
                    potalabel.setFont(font);
                    potblabel.setFont(font);
                    addItem(pane, potalabel, 1, 7, 1, 1, GridBagConstraints.EAST);
                    addItem(pane, potblabel, 1, 8, 1, 1, GridBagConstraints.EAST);
                    addItem(pane, eosabox[1], 2, 7, 1, 1, GridBagConstraints.CENTER);
                    addItem(pane, eosbbox[1], 2, 8, 1, 1, GridBagConstraints.CENTER);
                }
                kappalabel.setFont(font);
                addItem(pane, kappalabel, 0, 3+3*totf, 2, 1, GridBagConstraints.WEST);
                eosabox[2]=new JTextField(8);
                eosabox[2].setText(Double.toString(kappa));
                addItem(pane, eosabox[2], 2, 3+3*totf, 1, 1, GridBagConstraints.CENTER);
                
                wettypelabel.setFont(font);
                addItem(pane, wettypelabel, 0, 4+3*totf, 2, 1, GridBagConstraints.WEST);
                wet[0] = new JComboBox();
                wet[0].addItem("none");
                wet[0].addItem("quadratic");
                wet[0].setName("wet");
                wet[0].addItemListener(fluinterinilbe);
                wet[0].setSelectedIndex(wettyp[0]);
                addItem(pane, wet[0], 2, 4+3*totf, 1, 1, GridBagConstraints.CENTER);
                wetadenslabel.setFont(font);
                wetadenslabel.setEnabled(false);
                wetbdenslabel.setFont(font);
                wetbdenslabel.setEnabled(false);
                wetaconclabel.setFont(font);
                wetaconclabel.setEnabled(false);
                wetbconclabel.setFont(font);
                wetbconclabel.setEnabled(false);
                addItem(pane, wetadenslabel, 0, 5+3*totf, 2, 1, GridBagConstraints.EAST);
                addItem(pane, wetbdenslabel, 0, 6+3*totf, 2, 1, GridBagConstraints.EAST);
                wallinteractions0.setText(Double.toString(wallinteract[0]));
                addItem(pane, wallinteractions0, 2, 5+3*totf, 1, 1, GridBagConstraints.CENTER);
                wallinteractions1.setText(Double.toString(wallinteract[1]));
                addItem(pane, wallinteractions1, 2, 6+3*totf, 1, 1, GridBagConstraints.CENTER);
                wallinteractions2.setText(Double.toString(wallinteract[2]));
                wallinteractions3.setText(Double.toString(wallinteract[3]));
                if(wettyp[0]==0) {
                    wetadenslabel.setEnabled(false);
                    wetbdenslabel.setEnabled(false);
                    wetaconclabel.setEnabled(false);
                    wetbconclabel.setEnabled(false);
                    wallinteractions0.setEnabled(false);
                    wallinteractions0.setEditable(false);
                    wallinteractions1.setEnabled(false);
                    wallinteractions1.setEditable(false);
                    wallinteractions2.setEnabled(false);
                    wallinteractions2.setEditable(false);
                    wallinteractions3.setEnabled(false);
                    wallinteractions3.setEditable(false);
                }
                else {
                    wetadenslabel.setEnabled(true);
                    wetbdenslabel.setEnabled(true);
                    wetaconclabel.setEnabled(true);
                    wetbconclabel.setEnabled(true);
                    wallinteractions0.setEnabled(true);
                    wallinteractions0.setEditable(true);
                    wallinteractions1.setEnabled(true);
                    wallinteractions1.setEditable(true);
                    wallinteractions2.setEnabled(true);
                    wallinteractions2.setEditable(true);
                    wallinteractions3.setEnabled(true);
                    wallinteractions3.setEditable(true);
                }
                taumoblabel.setFont(font);
                mobilitylabel.setFont(font);
                eosabox[4]=new JTextField(8);
                eosabox[4].setText(Double.toString(taumob));
                eosbbox[4]=new JTextField(8);
                eosbbox[4].setText(Double.toString(mobparam));
                if(totf>1) {
                    addItem(pane, wetaconclabel, 0, 13, 2, 1, GridBagConstraints.EAST);
                    addItem(pane, wetbconclabel, 0, 14, 2, 1, GridBagConstraints.EAST);
                    addItem(pane, wallinteractions2, 2, 13, 1, 1, GridBagConstraints.CENTER);
                    addItem(pane, wallinteractions3, 2, 14, 1, 1, GridBagConstraints.CENTER);
                    addItem(pane, taumoblabel, 0, 15, 2, 1, GridBagConstraints.WEST);
                    addItem(pane, mobilitylabel, 0, 16, 2, 1, GridBagConstraints.WEST);
                    addItem(pane, eosabox[4], 2, 15, 1, 1, GridBagConstraints.CENTER);
                    addItem(pane, eosbbox[4], 2, 16, 1, 1, GridBagConstraints.CENTER);
                }
                save.setFont(font);
                save.addActionListener(fluinterinilbe);
                buttonBox.add(save);
                close.setFont(font);
                close.addActionListener(fluinterinilbe);
                buttonBox.add(close);
                addItem(pane, buttonBox, 0, 3+7*totf, 4, 1, GridBagConstraints.WEST);
                break;
		}
		

        this.add(pane);
        this.pack();
		setVisible(true);
    }

    private void addItem(JPanel p, JComponent c, int x, int y, int width, int height, int align)
    {
        GridBagConstraints gc = new GridBagConstraints();
        gc.gridx = x;
        gc.gridy = y;
        gc.gridwidth = width;
        gc.gridheight = height;
        gc.weightx = 100.0;
        gc.weighty = 100.0;
        gc.insets = new Insets(5, 5, 5, 5);
        gc.anchor = align;
        gc.fill = GridBagConstraints.NONE;
        p.add(c, gc);
    }

}
