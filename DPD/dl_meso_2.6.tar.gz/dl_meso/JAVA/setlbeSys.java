import javax.swing.*;
import java.util.*;
import java.lang.*;
import java.io.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.geom.*;
import java.awt.image.*;
/*
 *     DL_MESO_GUI
 *     author: R. S. Qin, M. A. Seaton
 *     copyright: STFC Daresbury Laboratory and CCP5
 *     2005, 2015
 */
class setlbeSys extends JPanel {

    setlbeSysEvt inilbe=new setlbeSysEvt(this);
    
    Font font=new Font("Dialog", Font.BOLD, 13);
    Color bgcolor=new Color(170, 200, 190);
    Color focolor=new Color(10, 10, 15);
    Color paneltop=new Color(170, 170, 230);

    JLabel setmod=new JLabel("LBE model:", JLabel.RIGHT);
    JComboBox model=new JComboBox();
    JCheckBox yesincomp=new JCheckBox("incompressible", false);

    JLabel colllabel=new JLabel("collision/forcing type:", JLabel.RIGHT);
    JComboBox collide=new JComboBox();

    JLabel interalabel=new JLabel("interactions:", JLabel.RIGHT);
    JComboBox interact=new JComboBox();
    JLabel trtmagiclabel=new JLabel("trt magic number:", JLabel.RIGHT);
    JTextField trtmagic =new JTextField("0.375", 6);
    
    JLabel setgrid = new JLabel("number of grid points", JLabel.RIGHT);
    JLabel totxlabel =new JLabel("x:", JLabel.RIGHT);
    JTextField totx =new JTextField("40", 4);
    JLabel totylabel =new JLabel("y:", JLabel.RIGHT);
    JTextField toty =new JTextField("30", 4);
    JLabel totzlabel =new JLabel("z:", JLabel.RIGHT);
    JTextField totz =new JTextField("1", 4);

    JLabel tottlabel =new JLabel("total steps:", JLabel.RIGHT);
    JTextField tott =new JTextField("10", 6);
    JLabel equillabel =new JLabel("equilibration steps:", JLabel.RIGHT);
    JTextField equt =new JTextField("0", 6);

    JLabel savetlabel =new JLabel("save span:", JLabel.RIGHT);
    JTextField savet =new JTextField("5", 4);
    JLabel bdwidlabel =new JLabel("boundary width:", JLabel.RIGHT);
    JTextField bwid =new JTextField("1", 2);

    JLabel outfmtlabel=new JLabel("output format:", JLabel.RIGHT);
    JComboBox outformat=new JComboBox();
    JCheckBox outansi = new JCheckBox("text", false);
    
    JLabel soundvlabel =new JLabel("sound speed:", JLabel.RIGHT);
    JTextField soundv =new JTextField("540", 6);
    JLabel viscolabel =new JLabel("kinetic viscosity:",JLabel.RIGHT);
    JTextField kineticv =new JTextField("0.001", 6);

    JLabel topvlabel = new JLabel("top boundary speed", JLabel.RIGHT);
    JLabel topvxlabel =new JLabel("Vx:", JLabel.RIGHT);
    JTextField topvx =new JTextField("0", 6);
    JLabel topvylabel =new JLabel("Vy:", JLabel.RIGHT);
    JTextField topvy =new JTextField("0", 6);
    JLabel topvzlabel =new JLabel("Vz:", JLabel.RIGHT);
    JTextField topvz =new JTextField("0", 6);
  
    JLabel dowvlabel = new JLabel("bottom boundary speed", JLabel.RIGHT);
    JLabel dowvxlabel =new JLabel("Vx:", JLabel.RIGHT);
    JTextField dowvx =new JTextField("0", 6);
    JLabel dowvylabel =new JLabel("Vy:", JLabel.RIGHT);
    JTextField dowvy =new JTextField("0", 6);
    JLabel dowvzlabel =new JLabel("Vz:", JLabel.RIGHT);
    JTextField dowvz =new JTextField("0", 6);

    JLabel lefvlabel = new JLabel("left boundary speed", JLabel.RIGHT);
    JLabel lefvxlabel =new JLabel("Vx:", JLabel.RIGHT);
    JTextField lefvx =new JTextField("0", 6);
    JLabel lefvylabel =new JLabel("Vy:", JLabel.RIGHT);
    JTextField lefvy =new JTextField("0", 6);
    JLabel lefvzlabel =new JLabel("Vz:", JLabel.RIGHT);
    JTextField lefvz =new JTextField("0", 6);

    JLabel rigvlabel = new JLabel("right boundary speed", JLabel.RIGHT);
    JLabel rigvxlabel =new JLabel("Vx:", JLabel.RIGHT);
    JTextField rigvx =new JTextField("0", 6);
    JLabel rigvylabel =new JLabel("Vy:", JLabel.RIGHT);
    JTextField rigvy =new JTextField("0", 6);
    JLabel rigvzlabel =new JLabel("Vz:", JLabel.RIGHT);
    JTextField rigvz =new JTextField("0", 6);

    JLabel frovlabel = new JLabel("front boundary speed", JLabel.RIGHT);
    JLabel frovxlabel =new JLabel("Vx:", JLabel.RIGHT);
    JTextField frovx =new JTextField("0", 6);
    JLabel frovylabel =new JLabel("Vy:", JLabel.RIGHT);
    JTextField frovy =new JTextField("0", 6);
    JLabel frovzlabel =new JLabel("Vz:", JLabel.RIGHT);
    JTextField frovz =new JTextField("0", 6);

    JLabel bacvlabel = new JLabel("back boundary speed", JLabel.RIGHT);
    JLabel bacvxlabel =new JLabel("Vx:", JLabel.RIGHT);
    JTextField bacvx =new JTextField("0", 6);
    JLabel bacvylabel =new JLabel("Vy:", JLabel.RIGHT);
    JTextField bacvy =new JTextField("0", 6);
    JLabel bacvzlabel =new JLabel("Vz:", JLabel.RIGHT);
    JTextField bacvz =new JTextField("0", 6);

    JLabel noiselabel =new JLabel("noise (0~1):", JLabel.RIGHT);
    JTextField noiei =new JTextField("0", 4);
    ButtonGroup phasefield =new ButtonGroup();
    JCheckBox phaseyes = new JCheckBox("phase field", false);
    JCheckBox phaseno = new JCheckBox("no phase field", true);

    JLabel fluidlabel =new JLabel("number of fluids (phases)", JLabel.RIGHT);
    JTextField fluidn = new JTextField("1", 3);
    JLabel direclabel =new JLabel(">>", JLabel.RIGHT);
    JButton setf=new JButton("set fluid parameters");

    JButton sete=new JButton("set fluid interactions");

    JLabel solutelabel =new JLabel("number of solutes", JLabel.RIGHT);
    JTextField solutn = new JTextField("0", 3);
    JLabel direclabel2 =new JLabel(">>", JLabel.RIGHT);
    JButton setn=new JButton("set solute parameters");

    JLabel tempslabel =new JLabel("using temperature scalar?", JLabel.RIGHT);
    JCheckBox yest = new JCheckBox("yes", false);
    JLabel direclabel3 =new JLabel(">>", JLabel.RIGHT);
    JButton sett=new JButton("set thermal parameters");
    
    JButton opens=new JButton("OPEN");
    JButton saves=new JButton("SAVE");

    public setlbeSys() {
//        setSize(620, 580);
        JPanel panel1 = new JPanel();
        panel1.setLayout(new GridBagLayout());
      
        // row1	
		setmod.setFont(font);
        addItem(panel1, setmod, 0, 0, 1, 1, GridBagConstraints.WEST);

        model.addItem("D2Q9");
        model.addItem("D3Q15");
        model.addItem("D3Q19");
        model.addItem("D3Q27");
		model.setFont(font);
		model.addItemListener(inilbe);
        addItem(panel1, model, 2, 0, 1, 1, GridBagConstraints.WEST);
		yesincomp.addActionListener(inilbe);
        addItem(panel1, yesincomp, 4, 0, 3, 1, GridBagConstraints.WEST);

        // row2
        colllabel.setFont(font);
        addItem(panel1, colllabel, 0, 1, 1, 1, GridBagConstraints.WEST);

        collide.addItem("BGK");
        collide.addItem("BGK/EDM");
        collide.addItem("BGK/Guo");
        collide.addItem("TRT");
        collide.addItem("TRT/EDM");
        collide.addItem("TRT/Guo");
        collide.addItem("MRT");
        collide.addItem("MRT/EDM");
        collide.addItem("MRT/Guo");
        collide.setFont(font);
		collide.addItemListener(inilbe);
        addItem(panel1, collide, 2, 1, 1, 1, GridBagConstraints.WEST);
        
        trtmagiclabel.setFont(font);
        trtmagiclabel.setEnabled(false);
        addItem(panel1, trtmagiclabel, 3, 1, 2, 1, GridBagConstraints.WEST);
        trtmagic.setEditable(false);
        trtmagic.setEnabled(false);
        addItem(panel1, trtmagic, 6, 1, 1, 1, GridBagConstraints.WEST);
        
        // row3
        interalabel.setFont(font);
        addItem(panel1, interalabel, 0, 2, 1, 1, GridBagConstraints.WEST);

        interact.addItem("no interactions");
        interact.addItem("Shan/Chen");
        interact.addItem("Shan/Chen Quadratic");
        interact.addItem("Lishchuk");
        interact.addItem("Lishchuk Local");
        interact.addItem("Swift");
        interact.setFont(font);
		interact.addItemListener(inilbe);
        addItem(panel1, interact, 2, 2, 3, 1, GridBagConstraints.WEST);

	// row4
		setgrid.setFont(font);
        addItem(panel1, setgrid, 0, 3, 1, 1, GridBagConstraints.WEST);

		totxlabel.setFont(font);
        addItem(panel1, totxlabel, 1, 3, 1, 1, GridBagConstraints.EAST);
		totx.setEditable(true);
        addItem(panel1, totx, 2, 3, 1, 1, GridBagConstraints.WEST);

		totylabel.setFont(font);
        addItem(panel1, totylabel, 3, 3, 1, 1, GridBagConstraints.EAST);
		toty.setEditable(true);
        addItem(panel1, toty, 4, 3, 1, 1, GridBagConstraints.WEST);

		totzlabel.setFont(font);
		totzlabel.setEnabled(false);
        addItem(panel1, totzlabel, 5, 3, 1, 1, GridBagConstraints.EAST);
		totz.setEditable(false);
		totz.setEnabled(false);
        addItem(panel1, totz, 6, 3, 1, 1, GridBagConstraints.WEST);

        // row5
		tottlabel.setFont(font);
        addItem(panel1, tottlabel, 0, 4, 1, 1, GridBagConstraints.WEST);
		tott.setEditable(true);
		equillabel.setFont(font);
        addItem(panel1, equillabel, 3, 4, 3, 1, GridBagConstraints.WEST);
		tott.setEditable(true);

        addItem(panel1, tott, 2, 4, 1, 1, GridBagConstraints.WEST);
        addItem(panel1, equt, 6, 4, 1, 1, GridBagConstraints.WEST);

        // row6
		savetlabel.setFont(font);
        addItem(panel1, savetlabel, 0, 5, 1, 1, GridBagConstraints.WEST);
		savet.setEditable(true);
        addItem(panel1, savet, 2, 5, 1, 1, GridBagConstraints.WEST);

		bdwidlabel.setFont(font);
        addItem(panel1, bdwidlabel, 3, 5, 2, 1, GridBagConstraints.WEST);
		bwid.setEditable(true);
        addItem(panel1, bwid, 6, 5, 1, 1, GridBagConstraints.WEST);

        // row7
        outfmtlabel.setFont(font);
        addItem(panel1, outfmtlabel, 0, 6, 1, 1, GridBagConstraints.WEST);

        outformat.addItem("VTK");
        outformat.addItem("LegacyVTK");
        outformat.addItem("Plot3D");
        outformat.setFont(font);
		outformat.addItemListener(inilbe);
        addItem(panel1, outformat, 2, 6, 2, 1, GridBagConstraints.WEST);
        
        outansi.addActionListener(inilbe);
        addItem(panel1, outansi, 4, 6, 1, 1, GridBagConstraints.WEST);

		// row8
		soundvlabel.setFont(font);
        addItem(panel1, soundvlabel, 0, 7, 1, 1, GridBagConstraints.WEST);
		soundv.setEditable(true);
        addItem(panel1, soundv, 2, 7, 1, 1, GridBagConstraints.WEST);

		viscolabel.setFont(font);
        addItem(panel1, viscolabel, 3, 7, 2, 1, GridBagConstraints.WEST);
		kineticv.setEditable(true);
        addItem(panel1, kineticv, 6, 7, 1, 1, GridBagConstraints.WEST);

		// row9
		topvlabel.setFont(font);
        addItem(panel1, topvlabel, 0, 8, 1, 1, GridBagConstraints.WEST);

		topvxlabel.setFont(font);
        addItem(panel1, topvxlabel, 1, 8, 1, 1, GridBagConstraints.EAST);
		topvx.setEditable(true);
        addItem(panel1, topvx, 2, 8, 1, 1, GridBagConstraints.WEST);

		topvylabel.setFont(font);
        addItem(panel1, topvylabel, 3, 8, 1, 1, GridBagConstraints.EAST);
		topvy.setEditable(true);
        addItem(panel1, topvy, 4, 8, 1, 1, GridBagConstraints.WEST);

		topvzlabel.setFont(font);
		topvzlabel.setEnabled(false);
        addItem(panel1, topvzlabel, 5, 8, 1, 1, GridBagConstraints.EAST);
		topvz.setEnabled(false);
		topvz.setEditable(false);
        addItem(panel1, topvz, 6, 8, 1, 1, GridBagConstraints.WEST);

		// row10
		dowvlabel.setFont(font);
        addItem(panel1, dowvlabel, 0, 9, 1, 1, GridBagConstraints.WEST);

		dowvxlabel.setFont(font);
        addItem(panel1, dowvxlabel, 1, 9, 1, 1, GridBagConstraints.EAST);
		dowvx.setEditable(true);
        addItem(panel1, dowvx, 2, 9, 1, 1, GridBagConstraints.WEST);

		dowvylabel.setFont(font);
        addItem(panel1, dowvylabel, 3, 9, 1, 1, GridBagConstraints.EAST);
		dowvy.setEditable(true);
        addItem(panel1, dowvy, 4, 9, 1, 1, GridBagConstraints.WEST);

		dowvzlabel.setFont(font);
		dowvzlabel.setEnabled(false);
        addItem(panel1, dowvzlabel, 5, 9, 1, 1, GridBagConstraints.EAST);
		dowvz.setEnabled(false);
		dowvz.setEditable(false);
        addItem(panel1, dowvz, 6, 9, 1, 1, GridBagConstraints.WEST);

		// row11
		lefvlabel.setFont(font);
        addItem(panel1, lefvlabel, 0, 10, 1, 1, GridBagConstraints.WEST);

		lefvxlabel.setFont(font);
        addItem(panel1, lefvxlabel, 1, 10, 1, 1, GridBagConstraints.EAST);
		lefvx.setEditable(true);
        addItem(panel1, lefvx, 2, 10, 1, 1, GridBagConstraints.WEST);

		lefvylabel.setFont(font);
        addItem(panel1, lefvylabel, 3, 10, 1, 1, GridBagConstraints.EAST);
		lefvy.setEditable(true);
        addItem(panel1, lefvy, 4, 10, 1, 1, GridBagConstraints.WEST);

		lefvzlabel.setFont(font);
		lefvzlabel.setEnabled(false);
        addItem(panel1, lefvzlabel, 5, 10, 1, 1, GridBagConstraints.EAST);
		lefvz.setEnabled(false);
		lefvz.setEditable(false);
        addItem(panel1, lefvz, 6, 10, 1, 1, GridBagConstraints.WEST);

		// row12
		rigvlabel.setFont(font);
        addItem(panel1, rigvlabel, 0, 11, 1, 1, GridBagConstraints.WEST);

		rigvxlabel.setFont(font);
        addItem(panel1, rigvxlabel, 1, 11, 1, 1, GridBagConstraints.EAST);
		rigvx.setEditable(true);
        addItem(panel1, rigvx, 2, 11, 1, 1, GridBagConstraints.WEST);

		rigvylabel.setFont(font);
        addItem(panel1, rigvylabel, 3, 11, 1, 1, GridBagConstraints.EAST);
		rigvy.setEditable(true);
        addItem(panel1, rigvy, 4, 11, 1, 1, GridBagConstraints.WEST);

		rigvzlabel.setFont(font);
		rigvzlabel.setEnabled(false);
        addItem(panel1, rigvzlabel, 5, 11, 1, 1, GridBagConstraints.EAST);
		rigvz.setEditable(false);
		rigvz.setEnabled(false);
        addItem(panel1, rigvz, 6, 11, 1, 1, GridBagConstraints.WEST);

		// row13
		frovlabel.setFont(font);
		frovlabel.setEnabled(false);
        addItem(panel1, frovlabel, 0, 12, 1, 1, GridBagConstraints.WEST);

		frovxlabel.setFont(font);
		frovxlabel.setEnabled(false);
        addItem(panel1, frovxlabel, 1, 12, 1, 1, GridBagConstraints.EAST);
		frovx.setEnabled(false);
		frovx.setEditable(false);
        addItem(panel1, frovx, 2, 12, 1, 1, GridBagConstraints.WEST);

		frovylabel.setFont(font);
        frovylabel.setEnabled(false);
        addItem(panel1, frovylabel, 3, 12, 1, 1, GridBagConstraints.EAST);
		frovy.setEditable(false);
        frovy.setEnabled(false);
        addItem(panel1, frovy, 4, 12, 1, 1, GridBagConstraints.WEST);

		frovzlabel.setFont(font);
        frovzlabel.setEnabled(false);
        addItem(panel1, frovzlabel, 5, 12, 1, 1, GridBagConstraints.EAST);
		frovz.setEditable(false);
        frovz.setEnabled(false);
        addItem(panel1, frovz, 6, 12, 1, 1, GridBagConstraints.WEST);

		// row14
		bacvlabel.setFont(font);
        bacvlabel.setEnabled(false);
        addItem(panel1, bacvlabel, 0, 13, 1, 1, GridBagConstraints.WEST);

		bacvxlabel.setFont(font);
        bacvxlabel.setEnabled(false);
        addItem(panel1, bacvxlabel, 1, 13, 1, 1, GridBagConstraints.EAST);
		bacvx.setEditable(false);
		bacvx.setEnabled(false);
        addItem(panel1, bacvx, 2, 13, 1, 1, GridBagConstraints.WEST);

		bacvylabel.setFont(font);
        bacvylabel.setEnabled(false);
        addItem(panel1, bacvylabel, 3, 13, 1, 1, GridBagConstraints.EAST);
		bacvy.setEditable(false);
		bacvy.setEnabled(false);
        addItem(panel1, bacvy, 4, 13, 1, 1, GridBagConstraints.WEST);

		bacvzlabel.setFont(font);
		bacvzlabel.setEnabled(false);
        addItem(panel1, bacvzlabel, 5, 13, 1, 1, GridBagConstraints.EAST);
		bacvz.setEditable(false);
		bacvz.setEnabled(false);
        addItem(panel1, bacvz, 6, 13, 1, 1, GridBagConstraints.WEST);

		// row15
		noiselabel.setFont(font);
        addItem(panel1, noiselabel, 0, 14, 1, 1, GridBagConstraints.WEST);
		noiei.setEditable(true);
        addItem(panel1, noiei, 2, 14, 1, 1, GridBagConstraints.WEST);

		phasefield.add(phaseyes);
		phasefield.add(phaseno);

        Box phasebox = Box.createHorizontalBox();
		phaseyes.setFont(font);
		phaseyes.setEnabled(false);
		phaseyes.addItemListener(inilbe);
		phaseno.setFont(font);
		phaseno.setEnabled(false);
		phaseno.addItemListener(inilbe);
        phasebox.add(phaseyes);
        phasebox.add(phaseno);
        addItem(panel1, phasebox, 3, 14, 4, 1, GridBagConstraints.WEST);

		// row16
		fluidlabel.setFont(font);
        addItem(panel1, fluidlabel, 0, 15, 1, 1, GridBagConstraints.WEST);
        addItem(panel1, fluidn, 2, 15, 1, 1, GridBagConstraints.WEST);
        addItem(panel1, direclabel, 3, 15, 1, 1, GridBagConstraints.CENTER);
		setf.addActionListener(inilbe);
        addItemFill(panel1, setf, 4, 15, 3, 1, GridBagConstraints.WEST, GridBagConstraints.HORIZONTAL);

		// row17
		sete.addActionListener(inilbe);
		addItemFill(panel1, sete, 4, 16, 3, 1, GridBagConstraints.WEST, GridBagConstraints.HORIZONTAL);
        sete.setEnabled(false);

		// row18
		solutelabel.setFont(font);
        addItem(panel1, solutelabel, 0, 17, 1, 1, GridBagConstraints.WEST);
        addItem(panel1, solutn, 2, 17, 1, 1, GridBagConstraints.WEST);
        addItem(panel1, direclabel2, 3, 17, 1, 1, GridBagConstraints.CENTER);
		setn.addActionListener(inilbe);
        addItemFill(panel1, setn, 4, 17, 3, 1, GridBagConstraints.WEST, GridBagConstraints.HORIZONTAL);

		// row19
		tempslabel.setFont(font);
        addItem(panel1, tempslabel, 0, 18, 1, 1, GridBagConstraints.WEST);
		yest.addActionListener(inilbe);
        addItem(panel1, yest, 2, 18, 1, 1, GridBagConstraints.WEST);
        addItem(panel1, direclabel3, 3, 18, 1, 1, GridBagConstraints.CENTER);
		sett.addActionListener(inilbe);
        addItemFill(panel1, sett, 4, 18, 3, 1, GridBagConstraints.WEST, GridBagConstraints.HORIZONTAL);

        // row20
        Box buttonbox = Box.createHorizontalBox();
		opens.setBackground(bgcolor);
		opens.addActionListener(inilbe);
		saves.setBackground(bgcolor);
		saves.addActionListener(inilbe);
        buttonbox.add(opens);
        buttonbox.add(saves);
        addItemPadding(panel1, buttonbox, 0, 19, 7, 1, GridBagConstraints.CENTER, 20);

        panel1.setSize(panel1.getPreferredSize());
        panel1.doLayout();
        this.add(panel1);
    }

    private void addItem(JPanel p, JComponent c, int x, int y, int width, int height, int align)
    {
        GridBagConstraints gc = new GridBagConstraints();
        gc.gridx = x;
        gc.gridy = y;
        gc.gridwidth = width;
        gc.gridheight = height;
        gc.weightx = 100.0;
        gc.weighty = 100.0;
        gc.insets = new Insets(3, 3, 3, 3);
        gc.anchor = align;
        gc.fill = GridBagConstraints.NONE;
        p.add(c, gc);
    }

    private void addItemFill(JPanel p, JComponent c, int x, int y, int width, int height, int align, int fill)
    {
        GridBagConstraints gc = new GridBagConstraints();
        gc.gridx = x;
        gc.gridy = y;
        gc.gridwidth = width;
        gc.gridheight = height;
        gc.weightx = 100.0;
        gc.weighty = 100.0;
        gc.insets = new Insets(5, 5, 5, 5);
        gc.anchor = align;
        gc.fill = fill;
        p.add(c, gc);
    }

    private void addItemPadding(JPanel p, JComponent c, int x, int y, int width, int height, int align, int padding)
    {
        GridBagConstraints gc = new GridBagConstraints();
        gc.gridx = x;
        gc.gridy = y;
        gc.gridwidth = width;
        gc.gridheight = height;
        gc.weightx = 100.0;
        gc.weighty = 100.0;
        gc.insets = new Insets(padding, padding, padding, padding);
        gc.anchor = align;
        gc.fill = GridBagConstraints.NONE;
        p.add(c, gc);
    }

}
