import javax.swing.*;
import java.util.*;
import java.lang.*;
import java.io.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.geom.*;
import java.awt.image.*;
/*
 *     DL_MESO_GUI
 *     author: W. Smith, R. S. Qin & M. A. Seaton 2006, 2015
 *     copyright: STFC Daresbury Laboratory and CCP5
 */
class setdpdSysEvt implements ItemListener, ActionListener {
    
    static setdpdSys inidpd;
    setThermostat tg;
    setBarostat bg;
    setElectrostatic eg;
    setSurface sfg;
    FileWriter fw;
    BufferedReader in;
    String filename="CONTROL", str;
    int xint;
    double xdouble;
    static int istate, kres, itype, btype, etype;
    public static int srftype; 
    public static String name;
    static int srfx, srfy, srfz, kmax1, kmax2, kmax3;
    static int ii, jj, kk;
    static boolean cube=true, lisotrop=true, lgbnd, lnfold, lconf, lind;
    static double atherm, abaro, bbaro, cbaro, aelec, belec, celec;

    public setdpdSysEvt(setdpdSys ini) {
        istate=0;
        atherm = 0.3;
        abaro = 2.0;
        bbaro = 5.0;
        cbaro = 0.0;
        aelec = 13.87;
        belec = 0.9695;
        celec = 0.929;
        kmax1 = 5;
        kmax2 = 5;
        kmax3 = 5;
        srfx = 0;
        srfy = 0;
        srfz = 0;
        istate=0;
        kres=0;
        itype=0;
        btype=0;
        etype=0;
        srftype=0;
        inidpd=ini;
        lnfold=false;
        lconf=false;
    }

    public setdpdSysEvt(setThermostat theini) {
        tg=theini;
    }

    public setdpdSysEvt(setBarostat barini) {
        bg=barini;
    }

    public setdpdSysEvt(setElectrostatic eleini) {
        eg=eleini;
    }

    public setdpdSysEvt(setSurface surini) {
        sfg=surini;
    }

    public void actionPerformed(ActionEvent event) {
        String cmd =event.getActionCommand();

        if (cmd == "set thermostat") {
            try {
                setthermostatparameter(itype,atherm);
            } catch  (NumberFormatException e) {
                ierr(" expecting an integer number ");
            }
        }
        else if (cmd == "set barostat") {
            try {
                setbarostatparameter(btype,abaro,bbaro,cbaro,lisotrop);
            } catch  (NumberFormatException e) {
                ierr(" expecting an integer number ");
            }
        }
        else if (cmd == "set electrostatics") {
            try {
                setelectroparameter(etype,aelec,belec,celec,kmax1,kmax2,kmax3);
            } catch  (NumberFormatException e) {
                ierr(" expecting an integer number ");
            }
        }
        else if (cmd == "set surfaces") {
            try {
                setsurfaceparameter(srftype,srfx,srfy,srfz);
            } catch  (NumberFormatException e) {
                ierr(" expecting an integer number ");
            }
        }
        else if (cmd == "OPEN") {
            opendpd();
        }
        else if (cmd == "SAVE") {
            savedpd();
        }
        else if (cmd == "SAVE T") {
            savethermo();
        }
        else if (cmd == "CANCEL T") {
            tg.dispose();
        }
        else if (cmd == "SAVE B") {
            savebaro();
        }
        else if (cmd == "CANCEL B") {
            bg.dispose();
        }
        else if (cmd == "SAVE E") {
            saveelectro();
        }
        else if (cmd == "CANCEL E") {
            eg.dispose();
        }
        else if (cmd == "SAVE SF") {
            savesurface();
        }
	    else if (cmd == "CANCEL SF") {
            sfg.dispose();
	    }

    }

    public void itemStateChanged(ItemEvent event) {
        Object item=event.getItem();
	    String answer=item.toString();
        if (answer == "cubic") {
          cube = true;
          lnfold = false;
          inidpd.label22x.setEnabled(false);
          inidpd.label22y.setEnabled(false);
          inidpd.label22z.setEnabled(false);
          inidpd.volume_y.setEditable(false);
          inidpd.volume_y.setEnabled(false);
          inidpd.volume_z.setEditable(false);
          inidpd.volume_z.setEnabled(false);
          inidpd.config.setEnabled(true);
        } 
        else if (answer == "orthorhombic") {
          cube = false;
          lnfold = false;
          inidpd.label22x.setEnabled(true);
          inidpd.label22y.setEnabled(true);
          inidpd.label22z.setEnabled(true);
          inidpd.volume_y.setEditable(true);
          inidpd.volume_y.setEnabled(true);
          inidpd.volume_z.setEditable(true);
          inidpd.volume_z.setEnabled(true);         
          inidpd.config.setEnabled(true);
        }
        else if (answer == "nfold") {
          cube = false;
          lnfold = true;
          inidpd.label22x.setEnabled(true);
          inidpd.label22y.setEnabled(true);
          inidpd.label22z.setEnabled(true);
          inidpd.volume_y.setEditable(true);
          inidpd.volume_y.setEnabled(true);
          inidpd.volume_z.setEditable(true);
          inidpd.volume_z.setEnabled(true);         
          inidpd.config.setEnabled(false);
        }
        else if (event.getSource() == inidpd.restart_key && answer == "none")
          kres = 0;
        else if (answer == "full restart")
          kres = 1;
        else if (answer == "new run")
          kres = 2;
        else if (answer == "rescaled")
          kres = 3;
        else if (answer == "DPD/MD-VV") {
          itype = 0;
          inidpd.setthermo.setEnabled(false);           
        }
        else if (answer == "DPD/DPD-VV") {
          itype = 1;
          inidpd.setthermo.setEnabled(false);           
        }
        else if (answer == "Lowe-Andersen") {
          itype = 2;
          inidpd.setthermo.setEnabled(false);           
        }
        else if (answer == "Peters") {
          itype = 3;
          inidpd.setthermo.setEnabled(false);           
        }
        else if (answer == "Stoyanov-Groot") {
          itype = 4;
          inidpd.setthermo.setEnabled(true);           
        }
        else if (event.getSource() == inidpd.barostat_key && answer == "none") {
          btype = 0;
          inidpd.label32.setEnabled(false);
          inidpd.sys_pressure.setEditable(false);
          inidpd.sys_pressure.setEnabled(false);
          inidpd.setbaro.setEnabled(false);
        }
        else if (answer == "Langevin NPT") {
          btype = 1;
          inidpd.label32.setEnabled(true);
          inidpd.sys_pressure.setEditable(true);
          inidpd.sys_pressure.setEnabled(true);
          inidpd.setbaro.setEnabled(true);
        }
        else if (answer == "Langevin NPAT") {
            btype = 2;
            inidpd.label32.setEnabled(true);
            inidpd.sys_pressure.setEditable(true);
            inidpd.sys_pressure.setEnabled(true);
            inidpd.setbaro.setEnabled(true);
        }
        else if (answer == "Langevin NsT") {
            btype = 3;
            inidpd.label32.setEnabled(true);
            inidpd.sys_pressure.setEditable(true);
            inidpd.sys_pressure.setEnabled(true);
            inidpd.setbaro.setEnabled(true);
        }
        else if (answer == "Berendsen NPT") {
          btype = 4;
          inidpd.label32.setEnabled(true);
          inidpd.sys_pressure.setEditable(true);
          inidpd.sys_pressure.setEnabled(true);
          inidpd.setbaro.setEnabled(true);
        }
        else if (answer == "Berendsen NPAT") {
            btype = 5;
            inidpd.label32.setEnabled(true);
            inidpd.sys_pressure.setEditable(true);
            inidpd.sys_pressure.setEnabled(true);
            inidpd.setbaro.setEnabled(true);
        }
        else if (answer == "Berendsen NsT") {
            btype = 6;
            inidpd.label32.setEnabled(true);
            inidpd.sys_pressure.setEditable(true);
            inidpd.sys_pressure.setEnabled(true);
            inidpd.setbaro.setEnabled(true);
        }
        else if (event.getSource() == inidpd.electrostatic_key && answer == "none") {
          etype = 0;
          inidpd.label51.setEnabled(false);
          inidpd.electrostatic_cutoff.setEditable(false);
          inidpd.electrostatic_cutoff.setEnabled(false);
          inidpd.setelectro.setEnabled(false);
        }
        else if (answer == "Ewald sum/Slater smearing") {
          etype = 1;
          inidpd.label51.setEnabled(true);
          inidpd.electrostatic_cutoff.setEditable(true);
          inidpd.electrostatic_cutoff.setEnabled(true);
          inidpd.setelectro.setEnabled(true);
        }
        else if (answer == "Ewald sum/Gauss smearing") {
          etype = 2;
          inidpd.label51.setEnabled(true);
          inidpd.electrostatic_cutoff.setEditable(true);
          inidpd.electrostatic_cutoff.setEnabled(true);
          inidpd.setelectro.setEnabled(true);
        }
        else if (answer == "Ewald sum/no real space") {
          etype = 3;
          inidpd.label51.setEnabled(true);
          inidpd.electrostatic_cutoff.setEditable(true);
          inidpd.electrostatic_cutoff.setEnabled(true);
          inidpd.setelectro.setEnabled(true);
        }
        else if (event.getSource() == inidpd.surface_key && answer == "none") {
          srftype = 0;
          inidpd.label52.setEnabled(false);
          inidpd.surface_cutoff.setEditable(false);
          inidpd.surface_cutoff.setEnabled(false);
          inidpd.setsurface.setEnabled(false);
        }
        else if (answer == "hard surfaces") {
          srftype = 1;
          inidpd.label52.setEnabled(true);
          inidpd.surface_cutoff.setEditable(true);
          inidpd.surface_cutoff.setEnabled(true);
          inidpd.setsurface.setEnabled(true);
        }
        else if (answer == "frozen beads") {
          srftype = 2;
          inidpd.label52.setEnabled(false);
          inidpd.surface_cutoff.setEditable(false);
          inidpd.surface_cutoff.setEnabled(false);
          inidpd.setsurface.setEnabled(true);
        }
        else if (answer == "Lees-Edwards shear") {
          srftype = 3;
          inidpd.label52.setEnabled(false);
          inidpd.surface_cutoff.setEditable(false);
          inidpd.surface_cutoff.setEnabled(false);
          inidpd.setsurface.setEnabled(true);
        }
        else if (event.getSource() == inidpd.config) {
          lconf = inidpd.config.isSelected();
          if(lconf) {
            inidpd.index.setEnabled(false);
          }
          else {
            inidpd.index.setEnabled(true);
          }
        }
    }

    void setthermostatparameter(int ityp,double at) {
      setThermostat st= new setThermostat(ityp,at);
    }

    void setbarostatparameter(int btyp,double ab,double bb,double cb,boolean iso) {
      setBarostat sb= new setBarostat(btyp,ab,bb,cb,iso);
    }

    void setelectroparameter(int etyp,double ae,double be,double ce,int k1,int k2,int k3) {
      setElectrostatic se= new setElectrostatic(etyp,ae,be,ce,k1,k2,k3);
    }

    void setsurfaceparameter(int sftyp,int sx,int sy,int sz) {
      setSurface ssf= new setSurface(sftyp,sx,sy,sz);
    }

    void savethermo() {
        int i, j, k;
        String str;
	try {
           xdouble=Double.parseDouble(tg.atherm.getText());
           atherm = xdouble;
           tg.dispose();
	} catch (NumberFormatException enfl) {
	    ierr(" thermostat parameter: format error or no value ");
        }
    }

    void savebaro() {
        int i, j, k;
        String str;
        try {
            lisotrop = bg.isotrop.isSelected();
            xdouble=Double.parseDouble(bg.abaro.getText());
            abaro = xdouble;
            xdouble=Double.parseDouble(bg.bbaro.getText());
            bbaro = xdouble;
            bg.dispose();
        } catch (NumberFormatException enfl) {
	    ierr(" barostat parameter: format error or no value ");
        }
    }

    void saveelectro() {
        int i, j, k;
        String str;
        try {
            xdouble=Double.parseDouble(eg.aelec.getText());
            aelec = xdouble;
            xdouble=Double.parseDouble(eg.belec.getText());
            belec = xdouble;
            xdouble=Double.parseDouble(eg.celec.getText());
            celec = xdouble;
            xint=Integer.parseInt(eg.kmax1.getText());
            kmax1 = xint;
            xint=Integer.parseInt(eg.kmax2.getText());
            kmax2 = xint;
            xint=Integer.parseInt(eg.kmax3.getText());
            kmax3 = xint;
            eg.dispose();
        } catch (NumberFormatException enfl) {
	    ierr(" electrostatic parameter: format error or no value ");
        }
    }

    void  savesurface() {
        int i, j, k;
        Boolean surface;
        String str;
        try {
            surface = sfg.xwall.isSelected();
            if (surface)
              srfx = 1;
            else
              srfx = 0;
            surface = sfg.ywall.isSelected();
            if (surface)
              srfy = 1;
            else
              srfy = 0;
            surface = sfg.zwall.isSelected();
            if (surface)
              srfz = 1;
            else
              srfz = 0;
            sfg.dispose();
        } catch (NumberFormatException enfl) {
	    ierr(" surface parameter: format error or no value ");
        }
    }


    void  savedpd() {
        try {
            if(istate == 0){
                fw = new FileWriter(filename, false);
                istate =1;
            }
            else
                fw = new FileWriter(filename, true);
            } catch (IOException e) {
                ierr(" cannot create "+filename+" file ");
            }
	
        try {
            name = inidpd.job_header.getText();
            int nfoldx=0, nfoldy=0, nfoldz=0;
            double volx=0, voly=0, volz=0;
            if(lnfold) {
              nfoldx = Integer.parseInt(inidpd.volume_x.getText());            
              nfoldy = Integer.parseInt(inidpd.volume_y.getText());            
              nfoldz = Integer.parseInt(inidpd.volume_z.getText());            
            }
            else {
              volx = Double.parseDouble(inidpd.volume_x.getText());
              voly = Double.parseDouble(inidpd.volume_y.getText());
              volz = Double.parseDouble(inidpd.volume_z.getText());
            }
            double temp = Double.parseDouble(inidpd.sys_temperature.getText());
            double pres = Double.parseDouble(inidpd.sys_pressure.getText());
            double delt = Double.parseDouble(inidpd.time_step.getText());
            double cut = Double.parseDouble(inidpd.cutoff_radius.getText());
            double halo = Double.parseDouble(inidpd.boundary_halo.getText());
            double mbcut = Double.parseDouble(inidpd.manybody_cutoff.getText());
            double eleccut = Double.parseDouble(inidpd.electrostatic_cutoff.getText());
            double surfcut = Double.parseDouble(inidpd.surface_cutoff.getText());
            double densvar = Double.parseDouble(inidpd.dens_var.getText());
            int dump = Integer.parseInt(inidpd.dump_interval.getText());
            int nstp = Integer.parseInt(inidpd.total_steps.getText());
            int neql = Integer.parseInt(inidpd.equilib_steps.getText());
            int pint = Integer.parseInt(inidpd.print_interval.getText());
            int tscal = Integer.parseInt(inidpd.temp_scaling.getText());
            int spanstart = Integer.parseInt(inidpd.save_start.getText());
            int span = Integer.parseInt(inidpd.save_interval.getText());
            int savelevel = inidpd.save_level.getSelectedIndex();
            int stak = Integer.parseInt(inidpd.stack_interval.getText());
            int plot = Integer.parseInt(inidpd.plot_interval.getText());
            int seed = Integer.parseInt(inidpd.random_seed.getText());
            double tjob = Double.parseDouble(inidpd.job_time.getText());
            double ctim = Double.parseDouble(inidpd.close_time.getText());
            fw.write(name+"\n\n");
            if (cube) {
              fw.write("volume "+volx+"\n");
            }
            else if (lnfold) {
              fw.write("nfold "+nfoldx+" "+nfoldy+" "+nfoldz+"\n");
            }
            else {
              fw.write("volume "+volx+" "+voly+" "+volz+"\n");
            }
            if (densvar>0)
              fw.write("densvar "+densvar+"\n");
            fw.write("temperature "+temp+"\n");
            if (btype>0) {
              fw.write("pressure "+pres+"\n");
            }
            fw.write("cutoff "+cut+"\n");
            if (mbcut<cut) {
              fw.write("manybody cutoff "+mbcut+"\n");
            }
            if (etype>0) {
              fw.write("electrostatic cutoff "+eleccut+"\n");
            }
            if (srftype>0) {
              fw.write("surface cutoff "+surfcut+"\n");
            }
            if (halo>cut) {
              fw.write("boundary halo "+halo+"\n");
            }
            if(kres==1) {
              fw.write("restart\n");
            }
            else if(kres==2) {
              fw.write("restart noscale\n");
            }
            else if(kres==3) {
              fw.write("restart scale\n");
            }
            lgbnd = inidpd.global.isSelected();
            if(lgbnd)
              fw.write("global bonds\n");
            lconf = inidpd.config.isSelected();
            if(lconf && !lnfold)
              fw.write("no config\n");
            lind = inidpd.index.isSelected();
            if(lind && !lconf)
              fw.write("no index\n");
            fw.write("timestep "+delt+"\n");
            fw.write("steps "+nstp+"\n");
            fw.write("equilibration steps "+neql+"\n");
     	    if(tscal > 0)
              fw.write("scale temperature every "+tscal+"\n");
            if(span > 0)
              fw.write("trajectory "+spanstart+" "+span+" "+savelevel+"\n");
            if(plot > 0)
	          fw.write("stats every "+plot+"\n");
            fw.write("stack size "+stak+"\n");
            fw.write("print every "+pint+"\n");
            if(dump!=1000)
              fw.write("ndump "+dump+"\n");
            if(seed!=0)
              fw.write("seed "+seed+"\n");
            fw.write("job time "+tjob+"\n");
            fw.write("close time "+ctim+"\n");
            if (btype==0) {
              fw.write("ensemble nvt ");
              switch (itype) {
                case 0: fw.write("mdvv\n");                break;
                case 1: fw.write("dpdvv\n");               break;
                case 2: fw.write("lowe\n");                break;
                case 3: fw.write("peters\n");              break;
                case 4: fw.write("stoyanov "+atherm+"\n"); break;
              }
            }
            else if(btype==1) {
              fw.write("ensemble npt ");
              switch (itype) {
                case 0: fw.write("mdvv");             break;
                case 1: fw.write("dpdvv");            break;
                case 2: fw.write("lowe");             break;
                case 3: fw.write("peters");           break;
                case 4: fw.write("stoyanov "+atherm); break;
              }
              fw.write(" langevin "+abaro+" "+bbaro+"\n");
            }
            else if(btype==2) {
                fw.write("ensemble nst ");
                switch (itype) {
                    case 0: fw.write("mdvv");             break;
                    case 1: fw.write("dpdvv");            break;
                    case 2: fw.write("lowe");             break;
                    case 3: fw.write("peters");           break;
                    case 4: fw.write("stoyanov "+atherm); break;
                }
                fw.write(" langevin "+abaro+" "+bbaro+" area\n");
            }
            else if(btype==3) {
                fw.write("ensemble nst ");
                switch (itype) {
                    case 0: fw.write("mdvv");             break;
                    case 1: fw.write("dpdvv");            break;
                    case 2: fw.write("lowe");             break;
                    case 3: fw.write("peters");           break;
                    case 4: fw.write("stoyanov "+atherm); break;
                }
                if(!lisotrop)
                    fw.write(" langevin "+abaro+" "+bbaro+" tension "+cbaro+"\n");
                else
                    fw.write(" langevin "+abaro+" "+bbaro+" tension "+cbaro+" semi\n");
            }
            else if(btype==4) {
              fw.write("ensemble npt ");
              switch (itype) {
                case 0: fw.write("mdvv");             break;
                case 1: fw.write("dpdvv");            break;
                case 2: fw.write("lowe");             break;
                case 3: fw.write("peters");           break;
                case 4: fw.write("stoyanov "+atherm); break;
              }
              fw.write(" berendsen "+abaro+"\n");
            }
            else if(btype==5) {
                fw.write("ensemble nst ");
                switch (itype) {
                    case 0: fw.write("mdvv");             break;
                    case 1: fw.write("dpdvv");            break;
                    case 2: fw.write("lowe");             break;
                    case 3: fw.write("peters");           break;
                    case 4: fw.write("stoyanov "+atherm); break;
                }
                fw.write(" berendsen "+abaro+" area\n");
            }
            else if(btype==6) {
                fw.write("ensemble nst ");
                switch (itype) {
                    case 0: fw.write("mdvv");             break;
                    case 1: fw.write("dpdvv");            break;
                    case 2: fw.write("lowe");             break;
                    case 3: fw.write("peters");           break;
                    case 4: fw.write("stoyanov "+atherm); break;
                }
                if(!lisotrop)
                    fw.write(" berendsen "+abaro+" tension "+cbaro+"\n");
                else
                    fw.write(" berendsen "+abaro+" tension "+cbaro+" semi\n");
            }
            if (etype==1) {
              fw.write("ewald sum "+belec+" "+kmax1+" "+kmax2+" "+kmax3+"\n");
              fw.write("permittivity constant "+aelec+"\n");
              fw.write("smear slater "+celec+"\n");
            }
            else if(etype==2) {
              fw.write("ewald sum "+belec+" "+kmax1+" "+kmax2+" "+kmax3+"\n");
              fw.write("permittivity constant "+aelec+"\n");
              fw.write("smear gauss "+celec+"\n");
            }
            else if(etype==3) {
              fw.write("ewald sum "+belec+" "+kmax1+" "+kmax2+" "+kmax3+"\n");
              fw.write("permittivity constant "+aelec+"\n");
              fw.write("smear gauss equal\n");
            }
            if (srftype==1) {
              fw.write("surface hard");
              if(srfx>0)
                fw.write(" x");
              if(srfy>0)
                fw.write(" y");
              if(srfz>0)
                fw.write(" z");
              fw.write("\n");
            }
            else if (srftype==2) {
              fw.write("surface frozen");
              if(srfx>0)
                fw.write(" x");
              if(srfy>0)
                fw.write(" y");
              if(srfz>0)
                fw.write(" z");
              fw.write("\n");
            }
            else if (srftype==3) {
              fw.write("surface shear");
              if(srfx>0)
                fw.write(" x");
              if(srfy>0)
                fw.write(" y");
              if(srfz>0)
                fw.write(" z");
              fw.write("\n");
            }
            fw.write("\nfinish\n");
            } catch (NumberFormatException enf) {
            ierr(" system parameter: format error or no value ");
                } catch (IOException e) {
            ierr(" error when saving "+filename+" ");
            System.out.println("Exception: "+e.getMessage());
            }
            try {
                fw.close();
            } catch (IOException e) {
            ierr(" error when closing "+filename+" ");
            System.out.println("Exception: "+e.getMessage());
        }
    }

    void  opendpd() {
        int i,j,k;
        int re=0,rs=0,rm=0,st=0,ab=0,bb=0,cb=0;
        String input,barostat="none";
        String[] words;
        File it = new File(filename);
        if(!it.exists()) {
          ierr(" cannot find "+filename+" file ");
        }
        try {
            // set defaults
            inidpd.restart_key.setSelectedItem("none");
            kres=0;
            inidpd.thermostat_key.setSelectedItem("DPD/MD-VV");
            itype=0;
            inidpd.setthermo.setEnabled(false);
            inidpd.barostat_key.setSelectedItem("none");
            btype=0;
            lisotrop=true;
            inidpd.setbaro.setEnabled(false);
            inidpd.label52.setEnabled(false);
            inidpd.surface_cutoff.setEditable(false);
            inidpd.surface_cutoff.setEnabled(false);
            inidpd.electrostatic_key.setSelectedItem("none");
            etype=0;
            inidpd.setelectro.setEnabled(false);
            inidpd.label51.setEnabled(false);
            inidpd.electrostatic_cutoff.setEditable(false);
            inidpd.electrostatic_cutoff.setEnabled(false);
            inidpd.surface_key.setSelectedItem("none");
            srftype=0;
            inidpd.setsurface.setEnabled(false);
            inidpd.label52.setEnabled(false);
            inidpd.surface_cutoff.setEditable(false);
            inidpd.surface_cutoff.setEnabled(false);
            srfx=0;
            srfy=0;
            srfz=0;
            inidpd.global.setSelected(false);
            inidpd.config.setSelected(false);
            inidpd.index.setSelected(false);
            inidpd.dump_interval.setText("1000");
            inidpd.equilib_steps.setText("0");
            inidpd.plot_interval.setText("0");
            inidpd.save_start.setText("0");
            inidpd.save_interval.setText("0");
            inidpd.dens_var.setText("0.0");
            inidpd.boundary_halo.setText("0.0");
            // read name of simulation from CONTROL file
            BufferedReader in = new BufferedReader(new FileReader(filename));
            name = in.readLine();
            inidpd.job_header.setText(name);
            // read in CONTROL file line by line
            while((input = in.readLine()) != null) {
              words = input.split(" ");
              k = words.length;
              if(words[0].toLowerCase().startsWith("finish"))
                break;
              else if(words[0].toLowerCase().startsWith("vol")) {
                inidpd.volume_x.setText(words[1]);
                if(k>2) {
                  inidpd.volume_y.setText(words[2]);
                  inidpd.volume_z.setText(words[3]);
                  cube = false;
                  lnfold = false;
                  inidpd.cubic.setSelectedItem("orthorhombic");
                  inidpd.label22x.setEnabled(true);
                  inidpd.label22y.setEnabled(true);
                  inidpd.label22z.setEnabled(true);
                  inidpd.volume_y.setEditable(true);
                  inidpd.volume_y.setEnabled(true);
                  inidpd.volume_z.setEditable(true);
                  inidpd.volume_z.setEnabled(true);
                }
                else {
                  inidpd.volume_y.setText("0.0");
                  inidpd.volume_z.setText("0.0");
                  cube = true;
                  lnfold = false;
                  inidpd.cubic.setSelectedItem("cubic");
                  inidpd.label22x.setEnabled(false);
                  inidpd.label22y.setEnabled(false);
                  inidpd.label22z.setEnabled(false);
                  inidpd.volume_y.setEditable(false);
                  inidpd.volume_y.setEnabled(false);
                  inidpd.volume_z.setEditable(false);
                  inidpd.volume_z.setEnabled(false);
                }
              }
              else if(words[0].toLowerCase().startsWith("nfold")) {
                inidpd.volume_x.setText(words[1]);
                inidpd.volume_y.setText(words[2]);
                inidpd.volume_z.setText(words[3]);
                cube = false;
                lnfold = true;
                inidpd.cubic.setSelectedItem("nfold");
                inidpd.label22x.setEnabled(true);
                inidpd.label22y.setEnabled(true);
                inidpd.label22z.setEnabled(true);
                inidpd.volume_y.setEditable(true);
                inidpd.volume_y.setEnabled(true);
                inidpd.volume_z.setEditable(true);
                inidpd.volume_z.setEnabled(true);
              }
              else if(words[0].toLowerCase().startsWith("temp"))
                inidpd.sys_temperature.setText(words[1]);
              else if(words[0].toLowerCase().startsWith("pres"))
                inidpd.sys_pressure.setText(words[1]);
              else if(words[0].toLowerCase().startsWith("timestep"))
                inidpd.time_step.setText(words[1]);
              else if(words[0].toLowerCase().startsWith("cut") || words[0].toLowerCase().startsWith("rcut"))
                inidpd.cutoff_radius.setText(words[1]);
              else if(words[0].toLowerCase().startsWith("many")) {
                inidpd.manybody_cutoff.setText(words[2]);
                rm=1;
              }
              else if(words[0].toLowerCase().startsWith("elec")) {
                inidpd.electrostatic_cutoff.setText(words[2]);
                re=1;
              }
              else if(words[0].toLowerCase().startsWith("surf")) {
                if(words[1].toLowerCase().startsWith("cut")) {
                  inidpd.surface_cutoff.setText(words[2]);
                  rs=1;
                }
                else if(words[1].toLowerCase().startsWith("hard")) {
                  srftype=1;
                  inidpd.surface_key.setSelectedItem("hard surfaces");
                  inidpd.label52.setEnabled(true);
                  inidpd.surface_cutoff.setEditable(true);
                  inidpd.surface_cutoff.setEnabled(true);
                  inidpd.setsurface.setEnabled(true);
                  if(k>2) {
                    if(words[2].toLowerCase().startsWith("x"))
                      srfx = 1;
                    else if(words[2].toLowerCase().startsWith("y"))
                      srfy = 1;
                    else if(words[2].toLowerCase().startsWith("z"))
                      srfz = 1;
                  }
                  if(k>3) {
                    if(words[3].toLowerCase().startsWith("x"))
                      srfx = 1;
                    else if(words[3].toLowerCase().startsWith("y"))
                      srfy = 1;
                    else if(words[3].toLowerCase().startsWith("z"))
                      srfz = 1;
                  }
                  if(k>4) {
                    if(words[4].toLowerCase().startsWith("x"))
                      srfx = 1;
                    else if(words[4].toLowerCase().startsWith("y"))
                      srfy = 1;
                    else if(words[4].toLowerCase().startsWith("z"))
                      srfz = 1;
                  }
                }
                else if(words[1].toLowerCase().startsWith("froz")) {
                  srftype=2;
                  inidpd.surface_key.setSelectedItem("frozen beads");
                  inidpd.label52.setEnabled(false);
                  inidpd.surface_cutoff.setEditable(false);
                  inidpd.surface_cutoff.setEnabled(false);
                  inidpd.setsurface.setEnabled(true);
                  if(k>2) {
                    if(words[2].toLowerCase().startsWith("x"))
                      srfx = 1;
                    else if(words[2].toLowerCase().startsWith("y"))
                      srfy = 1;
                    else if(words[2].toLowerCase().startsWith("z"))
                      srfz = 1;
                  }
                  if(k>3) {
                    if(words[3].toLowerCase().startsWith("x"))
                      srfx = 1;
                    else if(words[3].toLowerCase().startsWith("y"))
                      srfy = 1;
                    else if(words[3].toLowerCase().startsWith("z"))
                      srfz = 1;
                  }
                  if(k>4) {
                    if(words[4].toLowerCase().startsWith("x"))
                      srfx = 1;
                    else if(words[4].toLowerCase().startsWith("y"))
                      srfy = 1;
                    else if(words[4].toLowerCase().startsWith("z"))
                      srfz = 1;
                  }
                }
                else if(words[1].toLowerCase().startsWith("shea")) {
                  srftype=3;
                  inidpd.surface_key.setSelectedItem("Lees-Edwards shear");
                  inidpd.label52.setEnabled(false);
                  inidpd.surface_cutoff.setEditable(false);
                  inidpd.surface_cutoff.setEnabled(false);
                  inidpd.setsurface.setEnabled(true);
                  if(k>2) {
                    if(words[2].toLowerCase().startsWith("x"))
                      srfx = 1;
                    else if(words[2].toLowerCase().startsWith("y"))
                      srfy = 1;
                    else if(words[2].toLowerCase().startsWith("z"))
                      srfz = 1;
                  }
                }
              }
              else if(words[0].toLowerCase().startsWith("densvar"))
                inidpd.dens_var.setText(words[1]);
              else if(words[0].toLowerCase().startsWith("ndump"))
                inidpd.dump_interval.setText(words[1]);
              else if(words[0].toLowerCase().startsWith("steps"))
                inidpd.total_steps.setText(words[1]);
              else if(words[0].toLowerCase().startsWith("equil")) {
                if(k>2)
                  inidpd.equilib_steps.setText(words[2]);
                else
                  inidpd.equilib_steps.setText(words[1]);
              }  
              else if(words[0].toLowerCase().startsWith("print")) {
                if(k>2)
                  inidpd.print_interval.setText(words[2]);
                else
                  inidpd.print_interval.setText(words[1]);
              }  
              else if(words[0].toLowerCase().startsWith("scale")) {
                if(k>3)
                  inidpd.temp_scaling.setText(words[3]);
                else if(k>2)
                  inidpd.temp_scaling.setText(words[2]);
                else
                  inidpd.temp_scaling.setText(words[1]);
              }
              else if(words[0].toLowerCase().startsWith("seed"))
                  inidpd.random_seed.setText(words[1]);
              else if(words[0].toLowerCase().startsWith("traj")) {
                if(k>2) {
                  inidpd.save_start.setText(words[1]);
                  inidpd.save_interval.setText(words[2]);
                  st=1;
                  if(k>3) {
                    if(words[3].startsWith("1"))
                      inidpd.save_level.setSelectedItem("1: x,v");
                    else if(words[3].startsWith("2"))
                      inidpd.save_level.setSelectedItem("2: x,v,f");
                    else
                      inidpd.save_level.setSelectedItem("0: x");
                  }
                }
                else {
                  inidpd.save_interval.setText(words[1]);
                  inidpd.save_level.setSelectedItem("0: x");
                }
              }
              else if(words[0].toLowerCase().startsWith("stack")) {
                if(k>2)
                  inidpd.stack_interval.setText(words[2]);
                else
                  inidpd.stack_interval.setText(words[1]);
              }  
              else if(words[0].toLowerCase().startsWith("stats")) {
                if(k>2)
                  inidpd.plot_interval.setText(words[2]);
                else
                  inidpd.plot_interval.setText(words[1]);
              }  
              else if(words[0].toLowerCase().startsWith("job"))
                inidpd.job_time.setText(words[2]);
              else if(words[0].toLowerCase().startsWith("close"))
                inidpd.close_time.setText(words[2]);
              else if(words[0].toLowerCase().startsWith("bound"))
                inidpd.boundary_halo.setText(words[2]);
              else if(words[0].toLowerCase().startsWith("ewald")) {
                inidpd.label51.setEnabled(true);
                inidpd.electrostatic_cutoff.setEditable(true);
                inidpd.electrostatic_cutoff.setEnabled(true);
                if(k>5) {
                  belec = Double.parseDouble(words[2]);
                  kmax1 = Integer.parseInt(words[3]);
                  kmax2 = Integer.parseInt(words[4]);
                  kmax3 = Integer.parseInt(words[5]);
                }
                else {
                  belec = Double.parseDouble(words[1]);
                  kmax1 = Integer.parseInt(words[2]);
                  kmax2 = Integer.parseInt(words[3]);
                  kmax3 = Integer.parseInt(words[4]);
                }
              }
              else if(words[0].toLowerCase().startsWith("smear")) {
                if(words[1].toLowerCase().startsWith("slater")) {
                  etype = 1;
                  inidpd.electrostatic_key.setSelectedItem("Ewald sum/Slater smearing");
                  celec = Double.parseDouble(words[2]);
                  inidpd.setelectro.setEnabled(true);
                }
              }
              else if(words[0].toLowerCase().startsWith("perm")) {
                if(k>2)
                  aelec = Double.parseDouble(words[2]);
                else
                  aelec = Double.parseDouble(words[1]);
              }
              else if(words[0].toLowerCase().startsWith("global"))
                inidpd.global.setSelected(true);
              else if(words[0].toLowerCase().startsWith("no")) {
                if(words[1].toLowerCase().startsWith("conf"))
                  inidpd.config.setSelected(true);
                else if(words[1].toLowerCase().startsWith("ind"))
                  inidpd.index.setSelected(true);
                else if(words[1].toLowerCase().startsWith("elec")) {
                  inidpd.electrostatic_key.setSelectedItem("none");
                  etype=0;
                  inidpd.setelectro.setEnabled(false);
                  inidpd.label51.setEnabled(false);
                  inidpd.electrostatic_cutoff.setEditable(false);
                  inidpd.electrostatic_cutoff.setEnabled(false);
                }
              }
              else if(words[0].toLowerCase().startsWith("restart")) {
                kres = 1;
                if(k>1) {
                  if(words[1].toLowerCase().startsWith("noscale")) {
                    kres = 2;
                    inidpd.restart_key.setSelectedItem("new run");
                  }
                  else if(words[1].toLowerCase().startsWith("scale")) {
                    kres = 3;
                    inidpd.restart_key.setSelectedItem("rescaled");
                  }
                }
                if(kres==1)
                  inidpd.restart_key.setSelectedItem("full restart");
              }
              else if(words[0].toLowerCase().startsWith("ensemble")) {
                if(words[1].toLowerCase().startsWith("nvt")) {
                  btype = 0;
                  inidpd.barostat_key.setSelectedItem("none");
                  if(words[2].toLowerCase().startsWith("mdvv")) {
                    itype = 0;
                    inidpd.thermostat_key.setSelectedItem("DPD/MD-VV");
                  }
                  else if(words[2].toLowerCase().startsWith("dpdv")) {
                    itype = 1;
                    inidpd.thermostat_key.setSelectedItem("DPD/DPD-VV");
                  }
                  else if(words[2].toLowerCase().startsWith("lowe")) {
                    itype = 2;
                    inidpd.thermostat_key.setSelectedItem("Lowe-Andersen");
                  }
                  else if(words[2].toLowerCase().startsWith("pete")) {
                    itype = 3;
                    inidpd.thermostat_key.setSelectedItem("Peters");
                  }
                  else if(words[2].toLowerCase().startsWith("stoy")) {
                    itype = 4;
                    inidpd.thermostat_key.setSelectedItem("Stoyanov-Groot");
                    atherm = Double.parseDouble(words[3]);
                    inidpd.setthermo.setEnabled(true);
                  }
                }
                else if(words[1].toLowerCase().startsWith("npt")) {
                  if(words[2].toLowerCase().startsWith("mdvv")) {
                    itype = 0;
                    inidpd.thermostat_key.setSelectedItem("DPD/MD-VV");
                    barostat = words[3];
                    ab = 4; bb = 5;
                  }
                  else if(words[2].toLowerCase().startsWith("dpdv")) {
                    itype = 1;
                    inidpd.thermostat_key.setSelectedItem("DPD/DPD-VV");
                    barostat = words[3];
                    ab = 4; bb = 5;
                  }
                  else if(words[2].toLowerCase().startsWith("lowe")) {
                    itype = 2;
                    inidpd.thermostat_key.setSelectedItem("Lowe-Andersen");
                    barostat = words[3];
                    ab = 4; bb = 5;
                  }
                  else if(words[2].toLowerCase().startsWith("pete")) {
                    itype = 3;
                    inidpd.thermostat_key.setSelectedItem("Peters");
                    barostat = words[3];
                    ab = 4; bb = 5;
                  }
                  else if(words[2].toLowerCase().startsWith("stoy")) {
                    itype = 4;
                    inidpd.thermostat_key.setSelectedItem("Stoyanov-Groot");
                    atherm = Double.parseDouble(words[3]);
                    inidpd.setthermo.setEnabled(true);
                    barostat = words[4];
                    ab = 5; bb = 6;
                  }
                  if(barostat.toLowerCase().startsWith("lang")) {
                    btype = 1;
                    inidpd.barostat_key.setSelectedItem("Langevin NPT");
                    abaro = Double.parseDouble(words[ab]);
                    bbaro = Double.parseDouble(words[bb]);
                    inidpd.setbaro.setEnabled(true);
                  }
                  else if(barostat.toLowerCase().startsWith("bere")) {
                    btype = 4;
                    inidpd.barostat_key.setSelectedItem("Berendsen NPT");
                    abaro = Double.parseDouble(words[ab]);
                    inidpd.setbaro.setEnabled(true);
                  }
                }
                else if(words[1].toLowerCase().startsWith("nst")) {
                    if(words[2].toLowerCase().startsWith("mdvv")) {
                        itype = 0;
                        inidpd.thermostat_key.setSelectedItem("DPD/MD-VV");
                        barostat = words[3];
                        ab = 4; bb = 5; cb = 7;
                    }
                    else if(words[2].toLowerCase().startsWith("dpdv")) {
                        itype = 1;
                        inidpd.thermostat_key.setSelectedItem("DPD/DPD-VV");
                        barostat = words[3];
                        ab = 4; bb = 5; cb = 7;
                    }
                    else if(words[2].toLowerCase().startsWith("lowe")) {
                        itype = 2;
                        inidpd.thermostat_key.setSelectedItem("Lowe-Andersen");
                        barostat = words[3];
                        ab = 4; bb = 5; cb = 7;
                    }
                    else if(words[2].toLowerCase().startsWith("pete")) {
                        itype = 3;
                        inidpd.thermostat_key.setSelectedItem("Peters");
                        barostat = words[3];
                        ab = 4; bb = 5; cb = 7;
                    }
                    else if(words[2].toLowerCase().startsWith("stoy")) {
                        itype = 4;
                        inidpd.thermostat_key.setSelectedItem("Stoyanov-Groot");
                        atherm = Double.parseDouble(words[3]);
                        inidpd.setthermo.setEnabled(true);
                        barostat = words[4];
                        ab = 5; bb = 6; cb = 8;
                    }
                    if(barostat.toLowerCase().startsWith("lang")) {
                        btype = 3;
                        lisotrop = false;
                        if(words[cb-1].toLowerCase().startsWith("area")) {
                            btype = 2;
                            inidpd.barostat_key.setSelectedItem("Langevin NPAT");
                            abaro = Double.parseDouble(words[ab]);
                            bbaro = Double.parseDouble(words[bb]);
                        }
                        else {
                            btype = 3;
                            inidpd.barostat_key.setSelectedItem("Langevin NsT");
                            if(words[bb+1].toLowerCase().startsWith("orth")) {
                                abaro = Double.parseDouble(words[ab]);
                                bbaro = Double.parseDouble(words[bb]);
                                cbaro = 0.0;
                                if(words[cb].toLowerCase().startsWith("semi"))
                                    lisotrop = true;
                            }
                            else {
                                abaro = Double.parseDouble(words[ab]);
                                bbaro = Double.parseDouble(words[bb]);
                                cbaro = Double.parseDouble(words[cb]);
                                if(k>cb+1) {
                                    if(words[cb+1].toLowerCase().startsWith("semi"))
                                        lisotrop = true;
                                }
                            }
                        }
                        inidpd.setbaro.setEnabled(true);
                    }
                    else if(barostat.toLowerCase().startsWith("bere")) {
                        lisotrop = false;
                        if(words[bb].toLowerCase().startsWith("area")) {
                           btype = 5;
                           abaro = Double.parseDouble(words[ab]);
                           inidpd.barostat_key.setSelectedItem("Berendsen NPAT");
                        }
                        else {
                            btype = 6;
                            inidpd.barostat_key.setSelectedItem("Berendsen NsT");
                            if(words[bb].toLowerCase().startsWith("orth")) {
                                abaro = Double.parseDouble(words[ab]);
                                bbaro = 0.0;
                                if(words[cb-1].toLowerCase().startsWith("semi"))
                                   lisotrop = true;
                            }
                            else {
                                abaro = Double.parseDouble(words[ab]);
                                bbaro = Double.parseDouble(words[cb-1]);
                                if(k>cb) {
                                    if(words[cb].toLowerCase().startsWith("semi"))
                                        lisotrop = true;
                                }
                            }
                        }
                        inidpd.setbaro.setEnabled(true);
                    }
                }
                  
              }
            }
        if(st==0)
            inidpd.save_start.setText(inidpd.equilib_steps.getText());

	    in.close();
        } catch (NumberFormatException enf) {
            ierr(" system parameter: format error or no value ");
        } catch (IOException e) {
            ierr(" error when reading "+filename+" ");
            System.out.println("Exception: "+e.getMessage());
        }
    }

    void ierr(String errinfo) {
      msgPanel fcer=new msgPanel(errinfo);	
    }
}
