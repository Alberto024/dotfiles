import javax.swing.*;
import java.util.*;
import java.lang.*;
import java.io.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.geom.*;
import java.awt.image.*;
/*
 *     DL_MESO_GUI
 *     author: R. S. Qin, M. A. Seaton
 *     copyright: STFC Daresbury Laboratory and CCP5
 *     2005, 2015
 */
class compilelbe extends JPanel {
    compilelbeEvt clbe = new compilelbeEvt(this); 

    Font font=new Font("Dialog", Font.BOLD, 12);
    Color paneltop=new Color(170, 170, 230);

    Color bgcolorc=new Color(200, 200, 190);
    Color focolorc=new Color(30, 20, 30);

    JLabel lb1 = new JLabel("Step 1: ");
    JLabel lb2 = new JLabel("Step 2: ");
    JLabel lb3 = new JLabel("Step 3: ");
    JLabel comflag = new JLabel("Flags:");
    JLabel ompcomflag = new JLabel("OpenMP flags:");
    JComboBox comp= new JComboBox();
    JTextField compilealt = new JTextField(10);  
    JTextField compileflag = new JTextField("-O3", 22);
    JTextField ompcompileflag = new JTextField("-openmp", 22);
    JComboBox code= new JComboBox();
    JButton compile = new JButton("COMPILE");

    JLabel info1 = new JLabel("The code can also be compiled at a command-line");

    public compilelbe() {
        setSize(620, 530);
        JPanel panel1 = new JPanel();
        panel1.setLayout(new GridBagLayout());

        comp.addItem("Choose Compiler");
        comp.addItem("g++");
        comp.addItem("gcc");
        comp.addItem("c++");
        comp.addItem("cpp");
        comp.addItem("icpc");
        comp.addItem("mpCC");
        comp.addItem("mpiCC");
        comp.addItem("mpicxx");
        comp.addItem("cc");
        comp.addItem("other ...");
        comp.setFont(font);
        comp.addItemListener(clbe);
        code.addItem("Code");
        code.addItem("parallel code");
        code.addItem("parallel code with OpenMP");
        code.addItem("serial code");
        code.addItem("serial code with OpenMP");
        code.setFont(font);
        code.addItemListener(clbe);
        compile.setFont(font);
        compile.addActionListener(clbe);

        addItem(panel1, new JLabel(" "), 0, 0, 4, 1, GridBagConstraints.CENTER);

        addItemSpacing(panel1, lb1, 0, 1, 1, 1, GridBagConstraints.EAST, 30, 5);
        addItemSpacing(panel1, comp, 1, 1, 2, 1, GridBagConstraints.WEST, 30, 5);
        addItemSpacing(panel1, compilealt, 3, 1, 1, 1, GridBagConstraints.WEST, 30, 5);
        addItemSpacing(panel1, comflag, 2, 2, 1, 1, GridBagConstraints.EAST, 5, 5);
        addItemSpacing(panel1, compileflag, 3, 2, 1, 1, GridBagConstraints.CENTER, 5, 5);
        addItemSpacing(panel1, ompcomflag, 2, 3, 1, 1, GridBagConstraints.EAST, 5, 30);
        addItemSpacing(panel1, ompcompileflag, 3, 3, 1, 1, GridBagConstraints.CENTER, 5, 30);

        addItemSpacing(panel1, lb2, 0, 4, 1, 1, GridBagConstraints.EAST, 2, 30);
        addItemSpacing(panel1, code, 1, 4, 3, 1, GridBagConstraints.WEST, 2, 30);

        addItem(panel1, lb3, 0, 5, 1, 1, GridBagConstraints.EAST);
        addItem(panel1, compile, 1, 5, 3, 1, GridBagConstraints.WEST);

        addItem(panel1, info1, 0, 6, 4, 1, GridBagConstraints.CENTER);

        this.add(panel1);
    }

    private void addItem(JPanel p, JComponent c, int x, int y, int width, int height, int align)
    {
        GridBagConstraints gc = new GridBagConstraints();
        gc.gridx = x;
        gc.gridy = y;
        gc.gridwidth = width;
        gc.gridheight = height;
        gc.weightx = 100.0;
        gc.weighty = 100.0;
        gc.insets = new Insets(30, 5, 30, 5);
        gc.anchor = align;
        gc.fill = GridBagConstraints.NONE;
        p.add(c, gc);
    }

    private void addItemSpacing(JPanel p, JComponent c, int x, int y, int width, int height, int align, int inset1, int inset2)
    {
        GridBagConstraints gc = new GridBagConstraints();
        gc.gridx = x;
        gc.gridy = y;
        gc.gridwidth = width;
        gc.gridheight = height;
        gc.weightx = 100.0;
        gc.weighty = 100.0;
        gc.insets = new Insets(inset1, 5, inset2, 5);
        gc.anchor = align;
        gc.fill = GridBagConstraints.VERTICAL;
        p.add(c, gc);
    }

}
