import javax.swing.*;
import java.util.*;
import java.lang.*;
import java.io.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.geom.*;
import java.awt.image.*;
/*
 *     DL_MESO_GUI
 *     author: R. S. Qin, M. A. Seaton
 *     copyright: STFC Daresbury Laboratory and CCP5
 *     2005, 2012
 */
class msgPanel extends JFrame {
    msgPanelEvt evt = new msgPanelEvt(this);
    JPanel row1 = new JPanel();
    JLabel msglabel;
    JButton closebutton = new JButton("close window");
    public msgPanel(String phrase) {
	super("messager");	
	setBounds(350, 430, 80, 70);
	BorderLayout layout =new BorderLayout();
	Container pane=getContentPane();
	Font font=new Font("Dialog", Font.BOLD, 14);
	Color bgcolor=new Color(255, 200, 200);
	row1.setBackground(bgcolor);
	row1.setOpaque(true);
	row1.setLayout(layout);
	msglabel = new JLabel(phrase, JLabel.CENTER);
	msglabel.setFont(font);
	row1.add(msglabel, BorderLayout.NORTH);
	closebutton.addActionListener(evt);
	row1.add(closebutton, BorderLayout.CENTER);
	pane.add(row1);
	super.pack();
	setContentPane(pane);
	setVisible(true);
    }
}
