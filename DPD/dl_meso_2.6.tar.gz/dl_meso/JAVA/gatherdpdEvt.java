import javax.swing.*;
import java.util.*;
import java.lang.*;
import java.io.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.geom.*;
import java.awt.image.*;
/*
 *     DL_MESO_GUI
 *     author: R. S. Qin, M. A. Seaton
 *     copyright: STFC Daresbury Laboratory and CCP5
 *     2005, 2015
 */
class gatherdpdEvt implements ItemListener, ActionListener{
    gatherdpd gui;
    static String ostype,utilcmd,species,rcmd="gather-file";
    static int levcfg=0,lcx,lcy,lcz,numnode,septraj,fftbins,fft;
    static double dx,sigma,cutoff;
    private static String OS = System.getProperty("os.name").toLowerCase();
    public gatherdpdEvt(gatherdpd in){
        gui = in;
    }

    public void actionPerformed(ActionEvent event) {
        String cmd =event.getActionCommand();
        if (cmd == "Process data"){
            try {
                numnode = Integer.parseInt(gui.numnode.getText());
                lcx = Integer.parseInt(gui.localx.getText());
                lcy = Integer.parseInt(gui.localy.getText());
                lcz = Integer.parseInt(gui.localz.getText());
                species = (String)gui.species.getSelectedItem();
                dx = Double.parseDouble(gui.griddx.getText());
                sigma = Double.parseDouble(gui.sigma.getText());
                fftbins = Integer.parseInt(gui.fftbins.getText());
                if (gui.separatetraj.isSelected())
                    septraj=1;
                else
                    septraj=0;
                if (gui.fftrdf.isSelected())
                    fft=1;
                else
                    fft=0;
                if (isWindows ()) {
                    ostype="";
                } else if (isMac ()) {
                    ostype="./";
                } else if (isUnix ()) {
                    ostype="./";
                }
                if(numnode<1)
                    throw new IOException ("need at least one node");
                if (utilcmd=="export_image.exe")
                    rcmd = ostype+utilcmd+" "+numnode;
                else if (utilcmd=="traject.exe")
                    rcmd = ostype+utilcmd+" "+numnode+" "+septraj;
                else if (utilcmd=="export_config.exe")
                    rcmd = ostype+utilcmd+" "+numnode+" "+levcfg;
                else if (utilcmd=="local.exe")
                    rcmd = ostype+utilcmd+" "+numnode+" "+lcx+" "+lcy+" "+lcz;
                else if (utilcmd=="isosurfaces.exe") {
                    rcmd = ostype+utilcmd+" "+numnode+" "+species+" "+dx+" "+sigma;
                }
                else if (utilcmd=="radius.exe") {
                    rcmd = ostype+utilcmd+" "+numnode+" "+dx+" "+sigma;
                }
                else if (utilcmd=="rdf.exe") {
                    if(fft==1)
                        rcmd = ostype+utilcmd+" "+numnode+" "+dx+" "+sigma+" 1 "+fftbins;
                    else
                        rcmd = ostype+utilcmd+" "+numnode+" "+dx+" "+sigma;
                }
		Process p2 = Runtime.getRuntime().exec(rcmd);
		BufferedReader ou2 = new BufferedReader
		    (new InputStreamReader(p2.getInputStream()));
		String line2;
		while ((line2 = ou2.readLine()) != null)
		    System.out.println(line2);
	    } catch (IOException e1) {
		System.out.println(e1);
	    }
	}
    }
    public void itemStateChanged(ItemEvent event) {
        Object item=event.getItem();
        String answer=item.toString();
        if(answer == "Choose processing output") {
            utilcmd="";
            gui.config.setEnabled(false);
            gui.numnodelabel.setEnabled(false);
            gui.numnode.setEnabled(false);
            gui.numnode.setEditable(false);
            gui.locallabel.setEnabled(false);
            gui.specieslabel.setEnabled(false);
            gui.gridlabel.setEnabled(false);
            gui.sigmalabel.setEnabled(false);
            gui.fftbinslabel.setEnabled(false);
            gui.localx.setEnabled(false);
            gui.localx.setEditable(false);
            gui.localy.setEnabled(false);
            gui.localy.setEditable(false);
            gui.localz.setEnabled(false);
            gui.localz.setEditable(false);
            gui.species.setEnabled(false);
            gui.griddx.setEnabled(false);
            gui.griddx.setEditable(false);
            gui.sigma.setEnabled(false);
            gui.sigma.setEditable(false);
            gui.fftbins.setEnabled(false);
            gui.fftbins.setEditable(false);
            gui.separatetraj.setEnabled(false);
            gui.fftrdf.setEnabled(false);
            gui.runbutton.setEnabled(false);
        }
        else if(answer == "trajectories") {
            utilcmd="traject.exe";
            gui.config.setEnabled(false);
            gui.numnodelabel.setEnabled(true);
            gui.numnode.setEnabled(true);
            gui.numnode.setEditable(true);
            gui.locallabel.setEnabled(false);
            gui.specieslabel.setEnabled(false);
            gui.gridlabel.setEnabled(false);
            gui.sigmalabel.setEnabled(false);
            gui.fftbinslabel.setEnabled(false);
            gui.localx.setEnabled(false);
            gui.localx.setEditable(false);
            gui.localy.setEnabled(false);
            gui.localy.setEditable(false);
            gui.localz.setEnabled(false);
            gui.localz.setEditable(false);
            gui.species.setEnabled(false);
            gui.griddx.setEnabled(false);
            gui.griddx.setEditable(false);
            gui.sigma.setEnabled(false);
            gui.sigma.setEditable(false);
            gui.fftbins.setEnabled(false);
            gui.fftbins.setEditable(false);
            gui.separatetraj.setEnabled(true);
            gui.fftrdf.setEnabled(false);
            gui.runbutton.setEnabled(true);
        }
        else if(answer == "final image") {
            utilcmd="export_image.exe";
            gui.config.setEnabled(false);
            gui.numnodelabel.setEnabled(true);
            gui.numnode.setEnabled(true);
            gui.numnode.setEditable(true);
            gui.locallabel.setEnabled(false);
            gui.specieslabel.setEnabled(false);
            gui.gridlabel.setEnabled(false);
            gui.sigmalabel.setEnabled(false);
            gui.fftbinslabel.setEnabled(false);
            gui.localx.setEnabled(false);
            gui.localx.setEditable(false);
            gui.localy.setEnabled(false);
            gui.localy.setEditable(false);
            gui.localz.setEnabled(false);
            gui.localz.setEditable(false);
            gui.species.setEnabled(false);
            gui.griddx.setEnabled(false);
            gui.griddx.setEditable(false);
            gui.sigma.setEnabled(false);
            gui.sigma.setEditable(false);
            gui.fftbins.setEnabled(false);
            gui.fftbins.setEditable(false);
            gui.separatetraj.setEnabled(false);
            gui.fftrdf.setEnabled(false);
            gui.runbutton.setEnabled(true);
        }
        else if(answer == "radii of gyration") {
            utilcmd="radius.exe";
            gui.config.setEnabled(false);
            gui.numnodelabel.setEnabled(true);
            gui.numnode.setEnabled(true);
            gui.numnode.setEditable(true);
            gui.locallabel.setEnabled(false);
            gui.specieslabel.setEnabled(false);
            gui.gridlabel.setEnabled(true);
            gui.sigmalabel.setText("maximum distance:");
            gui.sigmalabel.setEnabled(true);
            gui.fftbinslabel.setEnabled(false);
            gui.localx.setEnabled(false);
            gui.localx.setEditable(false);
            gui.localy.setEnabled(false);
            gui.localy.setEditable(false);
            gui.localz.setEnabled(false);
            gui.localz.setEditable(false);
            gui.species.setEnabled(false);
            gui.griddx.setText("0.05");
            gui.griddx.setEnabled(true);
            gui.griddx.setEditable(true);
            gui.sigma.setText("2.0");
            gui.sigma.setEnabled(true);
            gui.sigma.setEditable(true);
            gui.fftbins.setEnabled(false);
            gui.fftbins.setEditable(false);
            gui.separatetraj.setEnabled(false);
            gui.fftrdf.setEnabled(false);
            gui.runbutton.setEnabled(true);
        }
        else if(answer == "CONFIG file") {
            utilcmd="export_config.exe";
            gui.config.setEnabled(true);
            gui.numnodelabel.setEnabled(true);
            gui.numnode.setEnabled(true);
            gui.numnode.setEditable(true);
            gui.locallabel.setEnabled(false);
            gui.specieslabel.setEnabled(false);
            gui.gridlabel.setEnabled(false);
            gui.fftbinslabel.setEnabled(false);
            gui.localx.setEnabled(false);
            gui.localx.setEditable(false);
            gui.localy.setEnabled(false);
            gui.localy.setEditable(false);
            gui.localz.setEnabled(false);
            gui.localz.setEditable(false);
            gui.species.setEnabled(false);
            gui.griddx.setEnabled(false);
            gui.griddx.setEditable(false);
            gui.sigma.setEnabled(false);
            gui.sigma.setEditable(false);
            gui.fftbins.setEnabled(false);
            gui.fftbins.setEditable(false);
            gui.separatetraj.setEnabled(false);
            gui.fftrdf.setEnabled(false);
            gui.runbutton.setEnabled(true);
        }
        else if(answer == "local properties") {
            utilcmd="local.exe";
            gui.config.setEnabled(false);
            gui.numnodelabel.setEnabled(true);
            gui.numnode.setEnabled(true);
            gui.numnode.setEditable(true);
            gui.locallabel.setEnabled(true);
            gui.specieslabel.setEnabled(false);
            gui.gridlabel.setEnabled(false);
            gui.sigmalabel.setEnabled(false);
            gui.fftbinslabel.setEnabled(false);
            gui.localx.setEnabled(true);
            gui.localx.setEditable(true);
            gui.localy.setEnabled(true);
            gui.localy.setEditable(true);
            gui.localz.setEnabled(true);
            gui.localz.setEditable(true);
            gui.species.setEnabled(false);
            gui.griddx.setEnabled(false);
            gui.griddx.setEditable(false);
            gui.sigma.setEnabled(false);
            gui.sigma.setEditable(false);
            gui.fftbins.setEnabled(false);
            gui.fftbins.setEditable(false);
            gui.separatetraj.setEnabled(false);
            gui.fftrdf.setEnabled(false);
            gui.runbutton.setEnabled(true);
        }
        else if(answer == "isosurfaces") {
            utilcmd="isosurfaces.exe";
            gui.config.setEnabled(false);
            gui.numnodelabel.setEnabled(true);
            gui.numnode.setEnabled(true);
            gui.numnode.setEditable(true);
            gui.locallabel.setEnabled(false);
            gui.specieslabel.setEnabled(true);
            gui.gridlabel.setEnabled(true);
            gui.sigmalabel.setText("Gaussian sigma:");
            gui.sigmalabel.setEnabled(true);
            gui.fftbinslabel.setEnabled(false);
            gui.localx.setEnabled(false);
            gui.localx.setEditable(false);
            gui.localy.setEnabled(false);
            gui.localy.setEditable(false);
            gui.localz.setEnabled(false);
            gui.localz.setEditable(false);
            gui.species.setEnabled(true);
            gui.griddx.setText("0.25");
            gui.griddx.setEnabled(true);
            gui.griddx.setEditable(true);
            gui.sigma.setText("0.4");
            gui.sigma.setEnabled(true);
            gui.sigma.setEditable(true);
            gui.fftbins.setEnabled(false);
            gui.fftbins.setEditable(false);
            gui.separatetraj.setEnabled(false);
            gui.fftrdf.setEnabled(false);
            gui.runbutton.setEnabled(true);
        }
        else if(answer == "radial distribution functions") {
            utilcmd="rdf.exe";
            gui.config.setEnabled(false);
            gui.numnodelabel.setEnabled(true);
            gui.numnode.setEnabled(true);
            gui.numnode.setEditable(true);
            gui.locallabel.setEnabled(false);
            gui.specieslabel.setEnabled(false);
            gui.gridlabel.setEnabled(true);
            gui.sigmalabel.setText("maximum distance:");
            gui.sigmalabel.setEnabled(true);
            gui.fftbinslabel.setEnabled(true);
            gui.localx.setEnabled(false);
            gui.localx.setEditable(false);
            gui.localy.setEnabled(false);
            gui.localy.setEditable(false);
            gui.localz.setEnabled(false);
            gui.localz.setEditable(false);
            gui.species.setEnabled(false);
            gui.griddx.setText("0.05");
            gui.griddx.setEnabled(true);
            gui.griddx.setEditable(true);
            gui.sigma.setText("2.0");
            gui.sigma.setEnabled(true);
            gui.sigma.setEditable(true);
            gui.fftbins.setEnabled(true);
            gui.fftbins.setEditable(true);
            gui.separatetraj.setEnabled(false);
            gui.fftrdf.setEnabled(true);
            gui.runbutton.setEnabled(true);
        }
        else if(answer == "0 - positions")
            levcfg = 0;
        else if(answer == "1 - positions, velocities")
            levcfg = 1;
        else if(answer == "2 - positions, velocities, forces")
            levcfg = 2;
        
    }

    void ierr(String errinfo) {
      msgPanel fcer=new msgPanel(errinfo);	
    }

    public static boolean isWindows() {
        return (OS.indexOf("win") >= 0);
    }
    
    public static boolean isMac() {
        return (OS.indexOf("mac") >= 0);
    }
    
    public static boolean isUnix() {
        return (OS.indexOf("nix") >= 0 || OS.indexOf("nux") >= 0 || OS.indexOf("aix") >= 0 || OS.indexOf("sunos") >= 0 );
    }

}
