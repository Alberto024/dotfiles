import javax.swing.*;
import java.util.*;
import java.lang.*;
import java.io.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.geom.*;
import java.awt.image.*;
/*
 *     DL_MESO_GUI
 *     author: R. S. Qin, M. A. Seaton
 *     copyright: STFC Daresbury Laboratory and CCP5
 *     2005, 2015
 */
class setlbeSpaEvt implements ItemListener, ActionListener {

    static setlbeSpa sg;
    lbesysdim dim = new lbesysdim();
    int nx=dim.lbnx, ny=dim.lbny, nz=dim.lbnz, lbd=dim.lbd;
    FileWriter ot, ot2;
    String filename="lbin.spa";
    String filename2="lbin.sys";
    String obst="point";
    String obstbb="ONBOUNCEBACK";
    String porebb="ONBOUNCEBACK";

    int[] ins = new int[6];
    double[] dbs = new double[6];
    static int istate=0;
    static int tp=0,bt=0,lf=0,rt=0,ft=0,bk=0;
    public setlbeSpaEvt(setlbeSpa setspace) {
        istate=0;
        sg=setspace;
        if((lbd == 2) && (nz > 1)) {
            nz = 1;
            ierr(" the number of grid points in z-axis is reset to 1");
        }
        if(nx<1 || ny <1 || nz< 1)
            ierr("the number of grid points in at least one axis was set as "+
                 "negative or zero: please re-define system");
    }
    
    public void actionPerformed(ActionEvent event) {
        String cmd =event.getActionCommand();

        if(cmd == "add obstacle") {
            if(obst == "point")
                addpoint(obstbb);
            else if(obst == "sphere")
                addsphere(obstbb);
            else if(obst == "cylinder")
                addcylinder(obstbb);
            else if(obst == "block") {
                try {
                    if(lbd==2) {
                        ins[0] =Integer.parseInt(sg.obstpos[0].getText());
                        ins[1] =Integer.parseInt(sg.obstpos[1].getText());
                        ins[3] =Integer.parseInt(sg.obstpos[3].getText());
                        ins[4] =Integer.parseInt(sg.obstpos[4].getText());
                        addBlock(obstbb, ins[0], ins[1], ins[3], ins[4]);
                    }
                    else {
                        for(int i=0; i<6; i++)
                            ins[i] =Integer.parseInt(sg.obstpos[i].getText());
                        addblock(obstbb, ins[0], ins[1], ins[2], ins[3], ins[4], ins[5]);
                    }
                } catch (NumberFormatException enfc) {
                    ierr(" number format incorrect ");
                }
            }
        }
        else if(cmd == "set pore") {
            try {
                dbs[0] = Double.parseDouble(sg.pore.getText());
                if((dbs[0] <0) || (dbs[0] >100))
                    ierr("pore fraction should be 0-100% ");
                else
                    addpore(porebb, dbs[0], nx, ny, nz);
            } catch (NumberFormatException e) {
                ierr(" either no number or number in incorrect format ");
            }
        }
        else if (cmd == "Create") {
            checkexist();
            sg.upwall.setEnabled(false);
            sg.downwall.setEnabled(false);
            sg.leftwall.setEnabled(false);
            sg.rightwall.setEnabled(false);
            sg.frontwall.setEnabled(false);
            sg.backwall.setEnabled(false);
            sg.creatspace.setEnabled(false);
            sg.pore.setEnabled(false);
            sg.setpore.setEnabled(false);
            sg.obsttype.setEnabled(false);
            sg.obstbbtype.setEnabled(false);
            sg.porebbtype.setEnabled(false);
            sg.addobst.setEnabled(false);
        }
    }

    public void itemStateChanged(ItemEvent event) {
        Object item=event.getItem();
        String answer=item.toString();
    
        if(answer == "top periodic boundary condition")
            tp=0;
        else if(answer == "top on-grid bounce back")
            tp=1;
        else if(answer == "top mid-grid bounce back")
            tp=2;
        else if(answer == "top fixed V, C and T")
            tp=3;
        else if(answer == "top fixed V and C, Neumann T")
            tp=4;
        else if(answer == "top fixed V and T, Neumann C")
            tp=5;
        else if(answer == "top fixed V, Neumann C and T")
            tp=6;
        else if(answer == "top fixed P, C and T")
            tp=7;
        else if(answer == "top fixed P and C, Neumann T")
            tp=8;
        else if(answer == "top fixed P and T, Neumann C")
            tp=9;
        else if(answer == "top fixed P, Neumann C and T")
            tp=10;

        else if(answer == "bottom periodic boundary condition")
            bt=0;
        else if(answer == "bottom on-grid bounce back")
            bt=1;
        else if(answer == "bottom mid-grid bounce back")
            bt=2;
        else if(answer == "bottom fixed V, C and T")
            bt=3;
        else if(answer == "bottom fixed V and C, Neumann T")
            bt=4;
        else if(answer == "bottom fixed V and T, Neumann C")
            bt=5;
        else if(answer == "bottom fixed V, Neumann C and T")
            bt=6;
        else if(answer == "bottom fixed P, C and T")
            bt=7;
        else if(answer == "bottom fixed P and C, Neumann T")
            bt=8;
        else if(answer == "bottom fixed P and T, Neumann C")
            bt=9;
        else if(answer == "bottom fixed P, Neumann C and T")
            bt=10;

        else if(answer == "left periodic boundary condition")
            lf=0;
        else if(answer == "left on-grid bounce back")
            lf=1;
        else if(answer == "left mid-grid bounce back")
            lf=2;
        else if(answer == "left fixed V, C and T")
            lf=3;
        else if(answer == "left fixed V and C, Neumann T")
            lf=4;
        else if(answer == "left fixed V and T, Neumann C")
            lf=5;
        else if(answer == "left fixed V, Neumann C and T")
            lf=6;
        else if(answer == "left fixed P, C and T")
            lf=7;
        else if(answer == "left fixed P and C, Neumann T")
            lf=8;
        else if(answer == "left fixed P and T, Neumann C")
            lf=9;
        else if(answer == "left fixed P, Neumann C and T")
            lf=10;

        else if(answer == "right periodic boundary condition")
            rt=0;
        else if(answer == "right on-grid bounce back")
            rt=1;
        else if(answer == "right mid-grid bounce back")
            rt=2;
        else if(answer == "right fixed V, C and T")
            rt=3;
        else if(answer == "right fixed V and C, Neumann T")
            rt=4;
        else if(answer == "right fixed V and T, Neumann C")
            rt=5;
        else if(answer == "right fixed V, Neumann C and T")
            rt=6;
        else if(answer == "right fixed P, C and T")
            rt=7;
        else if(answer == "right fixed P and C, Neumann T")
            rt=8;
        else if(answer == "right fixed P and T, Neumann C")
            rt=9;
        else if(answer == "right fixed P, Neumann C and T")
            rt=10;

        else if(answer == "front periodic boundary condition")
            ft=0;
        else if(answer == "front on-grid bounce back")
            ft=1;
        else if(answer == "front mid-grid bounce back")
            ft=2;
        else if(answer == "front fixed V, C and T")
            ft=3;
        else if(answer == "front fixed V and C, Neumann T")
            ft=4;
        else if(answer == "front fixed V and T, Neumann C")
            ft=5;
        else if(answer == "front fixed V, Neumann C and T")
            ft=6;
        else if(answer == "front fixed P, C and T")
            ft=7;
        else if(answer == "front fixed P and C, Neumann T")
            ft=8;
        else if(answer == "front fixed P and T, Neumann C")
            ft=9;
        else if(answer == "front fixed P, Neumann C and T")
            ft=10;
    
        else if(answer == "back periodic boundary condition")
            bk=0;
        else if(answer == "back on-grid bounce back")
            bk=1;
        else if(answer == "back mid-grid bounce back")
            bk=2;
        else if(answer == "back fixed V, C and T")
            bk=3;
        else if(answer == "back fixed V and C, Neumann T")
            bk=4;
        else if(answer == "back fixed V and T, Neumann C")
            bk=5;
        else if(answer == "back fixed V, Neumann C and T")
            bk=6;
        else if(answer == "back fixed P, C and T")
            bk=7;
        else if(answer == "back fixed P and C, Neumann T")
            bk=8;
        else if(answer == "back fixed P and T, Neumann C")
            bk=9;
        else if(answer == "back fixed P, Neumann C and T")
            bk=10;

        else if(answer == "point") {
            obst="point";
            sg.z0.setEnabled(true);
            sg.dx.setEnabled(false);
            sg.dy.setEnabled(false);
            sg.dz.setEnabled(false);
            sg.radius.setEnabled(false);
            if(lbd==2)
                sg.obstpos[2].setEnabled(false);
            else
                sg.obstpos[2].setEnabled(true);
            sg.obstpos[3].setEnabled(false);
            sg.obstpos[4].setEnabled(false);
            sg.obstpos[5].setEnabled(false);
            sg.obstpos[6].setEnabled(false);
        }

        else if(answer == "sphere") {
            obst="sphere";
            sg.z0.setEnabled(true);
            sg.dx.setEnabled(false);
            sg.dy.setEnabled(false);
            sg.dz.setEnabled(false);
            sg.radius.setEnabled(true);
            sg.obstpos[2].setEnabled(true);
            sg.obstpos[3].setEnabled(false);
            sg.obstpos[4].setEnabled(false);
            sg.obstpos[5].setEnabled(false);
            sg.obstpos[6].setEnabled(true);
        }

        else if(answer == "cylinder") {
            obst="cylinder";
            sg.z0.setEnabled(false);
            sg.dx.setEnabled(false);
            sg.dy.setEnabled(false);
            sg.dz.setEnabled(false);
            sg.radius.setEnabled(true);
            sg.obstpos[2].setEnabled(false);
            sg.obstpos[3].setEnabled(false);
            sg.obstpos[4].setEnabled(false);
            sg.obstpos[5].setEnabled(false);
            sg.obstpos[6].setEnabled(true);
        }

        else if(answer == "block") {
            obst="block";
            if(lbd==2)
                sg.z0.setEnabled(false);
            else
                sg.z0.setEnabled(true);
            sg.dx.setEnabled(true);
            sg.dy.setEnabled(true);
            if(lbd==2)
                sg.dz.setEnabled(false);
            else
                sg.dz.setEnabled(true);
            sg.radius.setEnabled(false);
            if(lbd==2)
                sg.obstpos[2].setEnabled(false);
            else
                sg.obstpos[2].setEnabled(true);
            sg.obstpos[3].setEnabled(true);
            sg.obstpos[4].setEnabled(true);
            if(lbd==2)
                sg.obstpos[5].setEnabled(false);
            else
                sg.obstpos[5].setEnabled(true);
            sg.obstpos[6].setEnabled(false);
        }

        else if(event.getSource() == sg.obstbbtype && answer == "on-grid")
            obstbb="ONBOUNCEBACK";

        else if(event.getSource() == sg.obstbbtype && answer == "mid-grid")
            obstbb="MIDBOUNCEBACK";

        else if(event.getSource() == sg.porebbtype && answer == "on-grid")
            porebb="ONBOUNCEBACK";

        else if(event.getSource() == sg.porebbtype && answer == "mid-grid")
            porebb="MIDBOUNCEBACK";
    }


    void topBoundIssue(String topbis) {
        if(lbd>2) {
            addblock(topbis+"PSD", 1, ny-1, 1, nx-2, 1, nz-2);
            if(lf>2)
                addblock(topbis+"CEDR", 0, ny-1, 1, 1, 1, nz-2);
            else if(lf==0)
                addblock(topbis+"PSD", 0, ny-1, 1, 1, 1, nz-2);
            if(rt>2)
                addblock(topbis+"CEDL", nx-1, ny-1, 1, 1, 1, nz-2);
            else if(rt==0)
                addblock(topbis+"PSD", nx-1, ny-1, 1, 1, 1, nz-2);
            if(ft>2)
                addblock(topbis+"CEDB", 1, ny-1, nz-1, nx-2, 1, 1);
            else if(ft==0)
                addblock(topbis+"PSD", 1, ny-1, nz-1, nx-2, 1, 1);
            if(bk>2)
                addblock(topbis+"CEDF", 1, ny-1, 0, nx-2, 1, 1);
            else if(bk==0)
                addblock(topbis+"PSD", 1, ny-1, 0, nx-2, 1, 1);
            if(lf==0 || lf>2) {
                if(ft==0)
                    addblock(topbis+"PSD", 0, ny-1, nz-1, 1, 1, 1);
                else if(ft>2)
                    addblock(topbis+"CCDRB", 0, ny-1, nz-1, 1, 1, 1);
                if(bk==0)
                    addblock(topbis+"PSD", 0, ny-1, 0, 1, 1, 1);
                else if(bk>2)
                    addblock(topbis+"CCDRF", 0, ny-1, 0, 1, 1, 1);
            }
            if(rt==0 || rt>2) {
                if(ft==0)
                    addblock(topbis+"PSD", nx-1, ny-1, nz-1, 1, 1, 1);
                else if(ft>2)
                    addblock(topbis+"CCDLB", nx-1, ny-1, nz-1, 1, 1, 1);
                if(bk==0)
                    addblock(topbis+"PSD", nx-1, ny-1, 0, 1, 1, 1);
                else if(bk>2)
                    addblock(topbis+"CCDLF", nx-1, ny-1, 0, 1, 1, 1);
            }
        }
        else {
            addblock(topbis+"CEDF", 1, ny-1, 0, nx-2, 1, 1);
            if(lf>2)
                addblock(topbis+"CCDRF", 0, ny-1, 0, 1, 1, 1);
            else if(lf==0)
                addblock(topbis+"CEDF", 0, ny-1, 0, 1, 1, 1);
            if(rt>2)
                addblock(topbis+"CCDLF", nx-1, ny-1, 0, 1, 1, 1);
            else if(rt==0)
                addblock(topbis+"CEDF", nx-1, ny-1, 0, 1, 1, 1);
        }
    }
    
    void downBoundIssue(String topbis) {
        if(lbd>2) {
            addblock(topbis+"PST", 1, 0, 1, nx-2, 1, nz-2);
            if(lf>2)
                addblock(topbis+"CETR", 0, 0, 1, 1, 1, nz-2);
            else if(lf==0)
                addblock(topbis+"PST", 0, 0, 1, 1, 1, nz-2);
            if(rt>2)
                addblock(topbis+"CETL", nx-1, 0, 1, 1, 1, nz-2);
            else if(rt==0)
                addblock(topbis+"PST", nx-1, 0, 1, 1, 1, nz-2);
            if(ft>2)
                addblock(topbis+"CETB", 1, 0, nz-1, nx-2, 1, 1);
            else if(ft==0)
                addblock(topbis+"PST", 1, 0, nz-1, nx-2, 1, 1);
            if(bk>2)
                addblock(topbis+"CETF", 1, 0, 0, nx-2, 1, 1);
            else if(bk==0)
                addblock(topbis+"PST", 1, 0, 0, nx-2, 1, 1);
            if(lf==0 || lf>2) {
                if(ft==0)
                    addblock(topbis+"PST", 0, 0, nz-1, 1, 1, 1);
                else if(ft>2)
                    addblock(topbis+"CCTRB", 0, 0, nz-1, 1, 1, 1);
                if(bk==0)
                    addblock(topbis+"PST", 0, 0, 0, 1, 1, 1);
                else if(bk>2)
                    addblock(topbis+"CCTRF", 0, 0, 0, 1, 1, 1);
            }
            if(rt==0 || rt>2) {
                if(ft==0)
                    addblock(topbis+"PST", nx-1, 0, nz-1, 1, 1, 1);
                else if(ft>2)
                    addblock(topbis+"CCTLB", nx-1, 0, nz-1, 1, 1, 1);
                if(bk==0)
                    addblock(topbis+"PST", nx-1, 0, 0, 1, 1, 1);
                else if(bk>2)
                    addblock(topbis+"CCTLF", nx-1, 0, 0, 1, 1, 1);
            }
        }
        else {
            addblock(topbis+"CETF", 1, 0, 0, nx-2, 1, 1);
            if(lf>2)
                addblock(topbis+"CCTRF", 0, 0, 0, 1, 1, 1);
            else if(lf==0)
                addblock(topbis+"CETF", 0, 0, 0, 1, 1, 1);
            if(rt>2)
                addblock(topbis+"CCTLF", nx-1, 0, 0, 1, 1, 1);
            else if(rt==0)
                addblock(topbis+"CETF", nx-1, 0, 0, 1, 1, 1);
        }
    }

    void leftBoundIssue(String topbis) {
        if(lbd>2) {
            addblock(topbis+"PSR", 0, 1, 1, 1, ny-2, nz-2);
            if(tp>2)
                addblock(topbis+"CEDR", 0, ny-1, 1, 1, 1, nz-2);
            else if(tp==0)
                addblock(topbis+"PSR", 0, ny-1, 1, 1, 1, nz-2);
            if(bt>2)
                addblock(topbis+"CETR", 0, 0, 1, 1, 1, nz-2);
            else if(bt==0)
                addblock(topbis+"PSR", 0, 0, 1, 1, 1, nz-2);
            if(ft>2)
                addblock(topbis+"CERB", 0, 1, nz-1, 1, ny-2, 1);
            else if(ft==0)
                addblock(topbis+"PSR", 0, 1, nz-1, 1, ny-2, 1);
            if(bk>2)
                addblock(topbis+"CERF", 0, 1, 0, 1, ny-2, 1);
            else if(bk==0)
                addblock(topbis+"PSR", 0, 1, 0, 1, ny-2, 1);
            if(tp==0 || tp>2) {
                if(ft==0)
                    addblock(topbis+"PSR", 0, ny-1, nz-1, 1, 1, 1);
                else if(ft>2)
                    addblock(topbis+"CCDRB", 0, ny-1, nz-1, 1, 1, 1);
                if(bk==0)
                    addblock(topbis+"PSR", 0, ny-1, 0, 1, 1, 1);
                else if(bk>2)
                    addblock(topbis+"CCDRF", 0, ny-1, 0, 1, 1, 1);
            }
            if(bt==0 || bt>2) {
                if(ft==0)
                    addblock(topbis+"PSR", 0, 0, nz-1, 1, 1, 1);
                else if(ft>2)
                    addblock(topbis+"CCTRB", 0, 0, nz-1, 1, 1, 1);
                if(bk==0)
                    addblock(topbis+"PSR", 0, 0, 0, 1, 1, 1);
                else if(bk>2)
                    addblock(topbis+"CCTRF", 0, 0, 0, 1, 1, 1);
            }
        }
        else {
            addblock(topbis+"CERF", 0, 1, 0, 1, ny-2, 1);
            if(tp>2)
                addblock(topbis+"CCDRF", 0, ny-1, 0, 1, 1, 1);
            else if(tp==0)
                addblock(topbis+"CERF", 0, ny-1, 0, 1, 1, 1);
            if(bt>2)
                addblock(topbis+"CCTRF", 0, 0, 0, 1, 1, 1);
            else if(bt==0)
                addblock(topbis+"CERF", 0, 0, 0, 1, 1, 1);
        }
    }
    
    void rightBoundIssue(String topbis) {
        if(lbd>2) {
            addblock(topbis+"PSL", nx-1, 1, 1, 1, ny-2, nz-2);
            if(tp>2)
                addblock(topbis+"CEDL", nx-1, ny-1, 1, 1, 1, nz-2);
            else if(tp==0)
                addblock(topbis+"PSL", nx-1, ny-1, 1, 1, 1, nz-2);
            if(bt>2)
                addblock(topbis+"CETL", nx-1, 0, 1, 1, 1, nz-2);
            else if(bt==0)
                addblock(topbis+"PSL", nx-1, 0, 1, 1, 1, nz-2);
            if(ft>2)
                addblock(topbis+"CELB", nx-1, 1, nz-1, 1, ny-2, 1);
            else if(ft==0)
                addblock(topbis+"PSL", nx-1, 1, nz-1, 1, ny-2, 1);
            if(bk>2)
                addblock(topbis+"CELF", nx-1, 1, 0, 1, ny-2, 1);
            else if(bk==0)
                addblock(topbis+"PSL", nx-1, 1, 0, 1, ny-2, 1);
            if(tp==0 || tp>2) {
                if(ft==0)
                    addblock(topbis+"PSL", nx-1, ny-1, nz-1, 1, 1, 1);
                else if(ft>2)
                    addblock(topbis+"CCDLB", nx-1, ny-1, nz-1, 1, 1, 1);
                if(bk==0)
                    addblock(topbis+"PSL", nx-1, ny-1, 0, 1, 1, 1);
                else if(bk>2)
                    addblock(topbis+"CCDLF", nx-1, ny-1, 0, 1, 1, 1);
            }
            if(bt==0 || bt>2) {
                if(ft==0)
                    addblock(topbis+"PSL", nx-1, 0, nz-1, 1, 1, 1);
                else if(ft>2)
                    addblock(topbis+"CCTLB", nx-1, 0, nz-1, 1, 1, 1);
                if(bk==0)
                    addblock(topbis+"PSL", nx-1, 0, 0, 1, 1, 1);
                else if(bk>2)
                    addblock(topbis+"CCTLF", nx-1, 0, 0, 1, 1, 1);
            }
        }
        else {
            addblock(topbis+"CELF", nx-1, 1, 0, 1, ny-2, 1);
            if(tp>2)
                addblock(topbis+"CCDLF", nx-1, ny-1, 0, 1, 1, 1);
            else if(tp==0)
                addblock(topbis+"CELF", nx-1, ny-1, 0, 1, 1, 1);
            if(bt>2)
                addblock(topbis+"CCTLF", nx-1, 0, 0, 1, 1, 1);
            else if(bt==0)
                addblock(topbis+"CELF", nx-1, 0, 0, 1, 1, 1);
        }
    }

    void frontBoundIssue(String topbis) {
        if(lbd>2) {
            addblock(topbis+"PSB", 1, 1, nz-1, nx-1, ny-2, 1);
            if(tp>2)
                addblock(topbis+"CEDB", 1, ny-1, nz-1, nx-2, 1, 1);
            else if(tp==0)
                addblock(topbis+"PSB", 1, ny-1, nz-1, nx-2, 1, 1);
            if(bt>2)
                addblock(topbis+"CETB", 1, 0, nz-1, nx-2, 1, 1);
            else if(bt==0)
                addblock(topbis+"PSB", 1, 0, nz-1, nx-2, 1, 1);
            if(lf>2)
                addblock(topbis+"CERB", 0, 1, nz-1, 1, ny-2, 1);
            else if(lf==0)
                addblock(topbis+"PSB", 0, 1, nz-1, 1, ny-2, 1);
            if(rt>2)
                addblock(topbis+"CELB", nx-1, 1, nz-1, 1, ny-2, 1);
            else if(rt==0)
                addblock(topbis+"PSB", nx-1, 1, nz-1, 1, ny-2, 1);
            if(tp==0 || tp>2) {
                if(lf==0)
                    addblock(topbis+"PSB", 0, ny-1, nz-1, 1, 1, 1);
                else if(lf>2)
                    addblock(topbis+"CCDRB", 0, ny-1, nz-1, 1, 1, 1);
                if(rt==0)
                    addblock(topbis+"PSB", nx-1, ny-1, nz-1, 1, 1, 1);
                else if(rt>2)
                    addblock(topbis+"CCDLB", nx-1, ny-1, nz-1, 1, 1, 1);
            }
            if(bt==0 || bt>2) {
                if(lf==0)
                    addblock(topbis+"PSB", 0, ny-1, nz-1, 1, 1, 1);
                else if(lf>2)
                    addblock(topbis+"CCTRB", 0, ny-1, nz-1, 1, 1, 1);
                if(rt==0)
                    addblock(topbis+"PSB", nx-1, 0, nz-1, 1, 1, 1);
                else if(rt>2)
                    addblock(topbis+"CCTLB", nx-1, 0, nz-1, 1, 1, 1);
            }
        }
    }

    void backBoundIssue(String topbis) {
        if(lbd>2) {
            addblock(topbis+"PSF", 1, 1, 0, nx-1, ny-2, 1);
            if(tp>2)
                addblock(topbis+"CEDF", 1, ny-1, 0, nx-2, 1, 1);
            else if(tp==0)
                addblock(topbis+"PSF", 1, ny-1, 0, nx-2, 1, 1);
            if(bt>2)
                addblock(topbis+"CETF", 1, 0, 0, nx-2, 1, 1);
            else if(bt==0)
                addblock(topbis+"PSF", 1, 0, 0, nx-2, 1, 1);
            if(lf>2)
                addblock(topbis+"CERF", 0, 1, 0, 1, ny-2, 1);
            else if(lf==0)
                addblock(topbis+"PSF", 0, 1, 0, 1, ny-2, 1);
            if(rt>2)
                addblock(topbis+"CELF", nx-1, 1, 0, 1, ny-2, 1);
            else if(rt==0)
                addblock(topbis+"PSF", nx-1, 1, 0, 1, ny-2, 1);
            if(tp==0 || tp>2) {
                if(lf==0)
                    addblock(topbis+"PSF", 0, ny-1, 0, 1, 1, 1);
                else if(lf>2)
                    addblock(topbis+"CCDRF", 0, ny-1, 0, 1, 1, 1);
                if(rt==0)
                    addblock(topbis+"PSF", nx-1, ny-1, 0, 1, 1, 1);
                else if(rt>2)
                    addblock(topbis+"CCDLF", nx-1, ny-1, 0, 1, 1, 1);
            }
            if(bt==0 || bt>2) {
                if(lf==0)
                    addblock(topbis+"PSF", 0, ny-1, 0, 1, 1, 1);
                else if(lf>2)
                    addblock(topbis+"CCTRF", 0, ny-1, 0, 1, 1, 1);
                if(rt==0)
                    addblock(topbis+"PSF", nx-1, 0, 0, 1, 1, 1);
                else if(rt>2)
                    addblock(topbis+"CCTLF", nx-1, 0, 0, 1, 1, 1);
            }
        }
    }
  

    void checkexist() {
        try {
            if(istate == 0) {
                ot = new FileWriter(filename, false);
                istate = 1;
            }
            else
                ot = new FileWriter(filename, true);
            ot.write("\n");
        } catch (IOException e) {
            ierr(" cannot create "+filename+" file ");
        }
        try {
            switch (tp) {
                case 0:
                    break;
                case 1:
                    addblock("ONBOUNCEBACK", 0, ny-1, 0, nx, 1, nz);
                    break;
                case 2:
                    addblock("MIDBOUNCEBACK", 0, ny-1, 0, nx, 1, nz);
                    break;
                case 3:
                    topBoundIssue("VCT");
                    break;
                case 4:
                    topBoundIssue("VCB");
                    break;
                case 5:
                    topBoundIssue("VBT");
                    break;
                case 6:
                    topBoundIssue("VBB");
                    break;
                case 7:
                    topBoundIssue("PCT");
                    break;
                case 8:
                    topBoundIssue("PCB");
                    break;
                case 9:
                    topBoundIssue("PBT");
                    break;
                case 10:
                    topBoundIssue("PBB");
                    break;
            }
            switch (bt) {
                case 0:
                    break;
                case 1:
                    addblock("ONBOUNCEBACK", 0, 0, 0, nx, 1, nz);
                    break;
                case 2:
                    addblock("MIDBOUNCEBACK", 0, 0, 0, nx, 1, nz);
                    break;
                case 3:
                    downBoundIssue("VCT");
                    break;
                case 4:
                    downBoundIssue("VCB");
                    break;
                case 5:
                    downBoundIssue("VBT");
                    break;
                case 6:
                    downBoundIssue("VBB");
                    break;
                case 7:
                    downBoundIssue("PCT");
                    break;
                case 8:
                    downBoundIssue("PCB");
                    break;
                case 9:
                    downBoundIssue("PBT");
                    break;
                case 10:
                    downBoundIssue("PBB");
                    break;
            }
            switch (lf) {
                case 0:
                    break;
                case 1:
                    addblock("ONBOUNCEBACK", 0, 0, 0, 1, ny, nz);
                    break;
                case 2:
                    addblock("MIDBOUNCEBACK", 0, 0, 0, 1, ny, nz);
                    break;
                case 3:
                    leftBoundIssue("VCT");
                    break;
                case 4:
                    leftBoundIssue("VCB");
                    break;
                case 5:
                    leftBoundIssue("VBT");
                    break;
                case 6:
                    leftBoundIssue("VBB");
                    break;
                case 7:
                    leftBoundIssue("PCT");
                    break;
                case 8:
                    leftBoundIssue("PCB");
                    break;
                case 9:
                    leftBoundIssue("PBT");
                    break;
                case 10:
                    leftBoundIssue("PBB");
                    break;
            }
            switch (rt) {
                case 0:
                    break;
                case 1:
                    addblock("ONBOUNCEBACK", nx-1, 0, 0, 1, ny, nz);
                    break;
                case 2:
                    addblock("MIDBOUNCEBACK", nx-1, 0, 0, 1, ny, nz);
                    break;
                case 3:
                    rightBoundIssue("VCT");
                    break;
                case 4:
                    rightBoundIssue("VCB");
                    break;
                case 5:
                    rightBoundIssue("VBT");
                    break;
                case 6:
                    rightBoundIssue("VBB");
                    break;
                case 7:
                    rightBoundIssue("PCT");
                    break;
                case 8:
                    rightBoundIssue("PCB");
                    break;
                case 9:
                    rightBoundIssue("PBT");
                    break;
                case 10:
                    rightBoundIssue("PBB");
                    break;
            }
            switch (ft) {
                case 0:
                    break;
                case 1:
                    addblock("ONBOUNCEBACK", 0, 0, nz-1, nx, ny, 1);
                    break;
                case 2:
                    addblock("MIDBOUNCEBACK", 0, 0, nz-1, nx, ny, 1);
                    break;
                case 3:
                    frontBoundIssue("VCT");
                    break;
                case 4:
                    frontBoundIssue("VCB");
                    break;
                case 5:
                    frontBoundIssue("VBT");
                    break;
                case 6:
                    frontBoundIssue("VBB");
                    break;
                case 7:
                    frontBoundIssue("PCT");
                    break;
                case 8:
                    frontBoundIssue("PCB");
                    break;
                case 9:
                    frontBoundIssue("PBT");
                    break;
                case 10:
                    frontBoundIssue("PBB");
                    break;
            }
            switch (bk) {
                case 0:
                    break;
                case 1:
                    addblock("ONBOUNCEBACK", 0, 0, 0, nx, ny, 1);
                    break;
                case 2:
                    addblock("MIDBOUNCEBACK", 0, 0, 0, nx, ny, 1);
                    break;
                case 3:
                    backBoundIssue("VCT");
                    break;
                case 4:
                    backBoundIssue("VCB");
                    break;
                case 5:
                    backBoundIssue("VBT");
                    break;
                case 6:
                    backBoundIssue("VBB");
                    break;
                case 7:
                    backBoundIssue("PCT");
                    break;
                case 8:
                    backBoundIssue("PCB");
                    break;
                case 9:
                    backBoundIssue("PBT");
                    break;
                case 10:
                    backBoundIssue("PBB");
                    break;
            }
            ot.close();
        } catch (IOException es) {
            ierr(" error when closing "+filename+" ");
            System.out.println("Exception: "+es.getMessage());
        }
        try {
            ot2 = new FileWriter(filename2, true);
            if(tp>0 || bt>0 || lf>0 || rt>0 || ft>0 || bk>0) {
                ot2.write("gradient_order               "+(sg.gradord.getSelectedIndex()+1)+"\n");
            }
            ot2.close();
        } catch (IOException es) {
            ierr(" error when opening/closing "+filename2+" ");
            System.out.println("Exception: "+es.getMessage());
        }
    }

    void addpore(String str1, double porefr, int tx, int ty, int tz) {
        int xpos, ypos, zpos;
        int totdim = tx * ty * tz;
        int totpoint = (int)((1 - porefr / 100.0) * totdim);
        int putpoint =0;
        int posi;
        boolean[] phi = new boolean[totdim];
        for(int i=0; i<totdim; i++)
            phi[i] = true;
        totpoint = (int)((1 - porefr / 100.0) * totdim);
        try {
            if(istate == 0) {
                ot = new FileWriter(filename, false);
                istate =1;
            }
            else
                ot = new FileWriter(filename, true);
        } catch (IOException e) {
            ierr(" cannot create "+filename+" file ");
        }
        try {
            while(putpoint < totpoint) {
                xpos = (int)(tx * Math.random());
                ypos = (int)(ty * Math.random());
                zpos = (int)(tz * Math.random());
                posi = (xpos * ty +ypos)*tz +zpos;
                if(phi[posi]) {
                    ot.write(""+xpos+" "+ypos+" "+zpos+" ");
                    ot.write(""+fConvert(str1)+"\n");
                    phi[posi] = false;
                    putpoint ++;
                }
            }
        } catch (NumberFormatException enfc) {
            ierr(" porous media parameter: format error or no value ");
        } catch (IOException e) {
            ierr(" error when saving "+filename+" ");
            System.out.println("Exception: "+e.getMessage());
        }
        try {
            ot.close();
        } catch (IOException es) {
            ierr(" error when closing "+filename+" ");
            System.out.println("Exception: "+es.getMessage());
        }
    }

    void addBlock(String str1, int xpos, int ypos, int xdis, int ydis) {
        int i, j;
        try {
            if(istate == 0) {
                ot = new FileWriter(filename, false);
                istate =1;
            }
            else
                ot = new FileWriter(filename, true);
        } catch (IOException e) {
            ierr(" cannot create "+filename+" file ");
        }
        try {
            for(i=xpos+1; i<xpos+xdis-1; i++)
                for(j=ypos+1; j<ypos+ydis-1; j++) {
                    ot.write(""+i+" "+j+" "+0+" ");
                    ot.write(""+fConvert("INSIDE")+"\n");
                }
            i=xpos;
            for(j=ypos; j<ypos+ydis; j++) {
                ot.write(""+i+" "+j+" "+0+" ");
                ot.write(""+fConvert(str1)+"\n");
            }
            if(xdis >1) {
                i=xpos+xdis-1;
                for(j=ypos; j<ypos+ydis; j++) {
                    ot.write(""+i+" "+j+" "+0+" ");
                    ot.write(""+fConvert(str1)+"\n");
                }
            }
            j=ypos;
            for(i=xpos+1; i<xpos+xdis-1; i++) {
                ot.write(""+i+" "+j+" "+0+" ");
                ot.write(""+fConvert(str1)+"\n");
            }
            if(ydis >1) {
                j=ypos+ydis-1;
                for(i=xpos+1; i<xpos+xdis-1; i++) {
                    ot.write(""+i+" "+j+" "+0+" ");
                    ot.write(""+fConvert(str1)+"\n");
                }
            }
        } catch (NumberFormatException enfc) {
            ierr(" thermal parameter: format error or no value ");
        } catch (IOException e) {
            ierr(" error when saving "+filename+" ");
            System.out.println("Exception: "+e.getMessage());
        }
        try {
            ot.close();
        } catch (IOException es) {
            ierr(" error when closing "+filename+" ");
            System.out.println("Exception: "+es.getMessage());
        }
    }


    void addblock(String str1, int xpos, int ypos, int zpos, int xdis, int ydis, int zdis) {
        int i, j, k;
        try {
            if(istate == 0) {
                ot = new FileWriter(filename, false);
                istate =1;
            }
            else
                ot = new FileWriter(filename, true);
        } catch (IOException e) {
            ierr(" cannot create "+filename+" file ");
        }
        try {
            for(i=xpos+1; i<xpos+xdis-1; i++)
                for(j=ypos+1; j<ypos+ydis-1; j++)
                    for(k=zpos+1; k<zpos+zdis-1; k++) {
                        ot.write(""+i+" "+j+" "+k+" ");
                        ot.write(""+fConvert("INSIDE")+"\n");
                    }
            i=xpos;
            for(j=ypos; j<ypos+ydis; j++)
                for(k=zpos; k<zpos+zdis; k++) {
                    ot.write(""+i+" "+j+" "+k+" ");
                    ot.write(""+fConvert(str1)+"\n");
                }
            if(xdis > 1) {
                i=xpos+xdis-1;
                for(j=ypos; j<ypos+ydis; j++)
                    for(k=zpos; k<zpos+zdis; k++) {
                        ot.write(""+i+" "+j+" "+k+" ");
                        ot.write(""+fConvert(str1)+"\n");
                    }
            }
            j=ypos;
            for(i=xpos+1; i<xpos+xdis-1; i++)
                for(k=zpos; k<zpos+zdis; k++) {
                    ot.write(""+i+" "+j+" "+k+" ");
                    ot.write(""+fConvert(str1)+"\n");
                }
            if(ydis > 1) {
                j=ypos+ydis-1;
                for(i=xpos+1; i<xpos+xdis-1; i++)
                    for(k=zpos; k< zpos+zdis; k++) {
                        ot.write(""+i+" "+j+" "+k+" ");
                        ot.write(""+fConvert(str1)+"\n");
                    }
            }
            k=zpos;
            for(i=xpos+1; i<xpos+xdis-1; i++)
                for(j=ypos+1; j<ypos+ydis-1; j++) {
                    ot.write(""+i+" "+j+" "+k+" ");
                    ot.write(""+fConvert(str1)+"\n");
                }
            if(zdis > 1) {
                k=zpos+zdis-1;
                for(i=xpos+1; i<xpos+xdis-1; i++)
                    for(j=ypos+1; j<ypos+ydis-1; j++) {
                        ot.write(""+i+" "+j+" "+k+" ");
                        ot.write(""+fConvert(str1)+"\n");
                    }
            }
        } catch (NumberFormatException enfc) {
            ierr(" block obstacle parameter: format error or no value ");
        } catch (IOException e) {
            ierr(" error when saving "+filename+" ");
            System.out.println("Exception: "+e.getMessage());
        }
        try {
            ot.close();
        } catch (IOException es) {
            ierr(" error when closing "+filename+" ");
            System.out.println("Exception: "+es.getMessage());
        }
    }

    void addsphere(String str1) {
        int i, j, k;
        int r, rmax, rinner;
        try {
            if(istate == 0) {
                ot = new FileWriter(filename, false);
                istate =1;
            }
            else
                ot = new FileWriter(filename, true);
        } catch (IOException e) {
            ierr(" cannot create "+filename+" file ");
        }
        try {
            for(i=0; i<3; i++)
                ins[i] = Integer.parseInt(sg.obstpos[i].getText());
            ins[3] = Integer.parseInt(sg.obstpos[6].getText());
            rmax=ins[3]*ins[3];
            rinner=(int)(Math.signum(ins[3]-2))*(ins[3]-2)*(ins[3]-2);
            if(lbd>2){
                for(i=(ins[0]-ins[3]); i<=(ins[0]+ins[3]); i++)
                    for(j=(ins[1]-ins[3]); j<=(ins[1]+ins[3]); j++)
                        for(k=(ins[2]-ins[3]); k<=(ins[2]+ins[3]);k++) {
                            r = (i-ins[0])*(i-ins[0])+(j-ins[1])*(j-ins[1])+(k-ins[2])*(k-ins[2]);
                            if(r<rinner) {
                                ot.write(""+i+" "+j+" "+k+" ");
                                ot.write(""+fConvert("INSIDE")+"\n");
                            }
                            else if(r<rmax){
                                ot.write(""+i+" "+j+" "+k+" ");
                                ot.write(""+fConvert(str1)+"\n");
                            }
                        }
            }
            else {
                for(i=(ins[0]-ins[3]); i<=(ins[0]+ins[3]); i++)
                    for(j=(ins[1]-ins[3]); j<=(ins[1]+ins[3]); j++) {
                        r = (i-ins[0])*(i-ins[0])+(j-ins[1])*(j-ins[1]);
                        if(r<rinner) {
                            ot.write(""+i+" "+j+" 0 ");
                            ot.write(""+fConvert("INSIDE")+"\n");
                        }
                        else if(r<rmax){
                            ot.write(""+i+" "+j+" 0 ");
                            ot.write(""+fConvert(str1)+"\n");
                        }
                    }
            }
        } catch (NumberFormatException enfc) {
            ierr(" spherical obstacle parameter: format error or no value ");
        } catch (IOException e) {
            ierr(" error when saving "+filename+" ");
            System.out.println("Exception: "+e.getMessage());
        }
        try {
            ot.close();
        } catch (IOException es) {
            ierr(" error when closing "+filename+" ");
            System.out.println("Exception: "+es.getMessage());
        }
    }

    void addcylinder(String str1) {
        int i, j, k;
        int r, rmax, rinner;
        try {
            if(istate == 0) {
                ot = new FileWriter(filename, false);
                istate =1;
            }
            else
                ot = new FileWriter(filename, true);
        } catch (IOException e) {
            ierr(" cannot create "+filename+" file ");
        }
        try {
            for(i=0; i<2; i++)
                ins[i] = Integer.parseInt(sg.obstpos[i].getText());
            ins[3] = Integer.parseInt(sg.obstpos[6].getText());
            rmax=ins[3]*ins[3];
            rinner=(int)(Math.signum(ins[3]-2))*(ins[3]-2)*(ins[3]-2);
            for(i=(ins[0]-ins[3]); i<=(ins[0]+ins[3]); i++)
                for(j=(ins[1]-ins[3]); j<=(ins[1]+ins[3]); j++) {
                    r = (i-ins[0])*(i-ins[0])+(j-ins[1])*(j-ins[1]);
                    if(r<rinner) {
                        ot.write(""+i+" "+j+" 0 ");
                        ot.write(""+fConvert("INSIDE")+"\n");
                    }
                    else if(r<rmax){
                        ot.write(""+i+" "+j+" 0 ");
                        ot.write(""+fConvert(str1)+"\n");
                    }
                }
        } catch (NumberFormatException enfc) {
            ierr(" cylindrical obstacle parameter: format error or no value ");
        } catch (IOException e) {
            ierr(" error when saving "+filename+" ");
            System.out.println("Exception: "+e.getMessage());
        }
        try {
            ot.close();
        } catch (IOException es) {
            ierr(" error when closing "+filename+" ");
            System.out.println("Exception: "+es.getMessage());
        }
    }

    void addpoint(String str1) {
        try {
            if(istate == 0) {
                ot = new FileWriter(filename, false);
                istate =1;
            }
            else
                ot = new FileWriter(filename, true);
        } catch (IOException e) {
            ierr(" cannot create "+filename+" file ");
        }
        try {
            for(int i=0; i<3; i++) {
                ins[i] = Integer.parseInt(sg.obstpos[i].getText());
                if(lbd==2 && i==2)
                    ins[2] = 0;
                ot.write(""+ins[i]+" ");
            }
            ot.write(""+fConvert(str1)+"\n");
        } catch (NumberFormatException enfc) {
            ierr(" point obstacle parameter: format error or no value ");
        } catch (IOException e) {
            ierr(" error when saving "+filename+" ");
            System.out.println("Exception: "+e.getMessage());
        }
        try {
            ot.close();
        } catch (IOException es) {
            ierr(" error when closing "+filename+" ");
            System.out.println("Exception: "+es.getMessage());
        }
	
    }

    void ierr(String errinfo) {
        msgPanel fcer=new msgPanel(errinfo);
    }

    int fConvert(String str1) {
        int spos = 0;
        if(str1.equals("INSIDE"))
            spos = 11;
        else if(str1.equals("ONBOUNCEBACK"))
            spos = 12;
        else if(str1.equals("MIDBOUNCEBACK"))
            spos = 13;
        else if(str1.equals("WETTING"))
            spos = 14;
        else if(str1.equals("DEWETTING"))
            spos = 15;
        else if(str1.equals("SLIP"))
            spos = 16;
        else if(str1.equals("VCTPST"))
            spos = 121;
        else if(str1.equals("VCTPSD"))
            spos = 122;
        else if(str1.equals("VCTPSL"))
            spos = 123;
        else if(str1.equals("VCTPSR"))
            spos = 124;
        else if(str1.equals("VCTPSF"))
            spos = 125;
        else if(str1.equals("VCTPSB"))
            spos = 126;
        else if(str1.equals("VCTCCTRB"))
            spos = 127;
        else if(str1.equals("VCTCCTLB"))
            spos = 128;
        else if(str1.equals("VCTCCDLB"))
            spos = 129;
        else if(str1.equals("VCTCCDRB"))
            spos = 130;
        else if(str1.equals("VCTCCTRF"))
            spos = 131;
        else if(str1.equals("VCTCCTLF"))
            spos = 132;
        else if(str1.equals("VCTCCDLF"))
            spos = 133;
        else if(str1.equals("VCTCCDRF"))
            spos = 134;
        else if(str1.equals("VCTCETR"))
            spos = 143;
        else if(str1.equals("VCTCETL"))
            spos = 144;
        else if(str1.equals("VCTCEDL"))
            spos = 145;
        else if(str1.equals("VCTCEDR"))
            spos = 146;
        else if(str1.equals("VCTCETF"))
            spos = 147;
        else if(str1.equals("VCTCELF"))
            spos = 148;
        else if(str1.equals("VCTCEDF"))
            spos = 149;
        else if(str1.equals("VCTCERF"))
            spos = 150;
        else if(str1.equals("VCTCETB"))
            spos = 151;
        else if(str1.equals("VCTCELB"))
            spos = 152;
        else if(str1.equals("VCTCEDB"))
            spos = 153;
        else if(str1.equals("VCTCERB"))
            spos = 154;
        else if(str1.equals("VCBPST"))
            spos = 221;
        else if(str1.equals("VCBPSD"))
            spos = 222;
        else if(str1.equals("VCBPSL"))
            spos = 223;
        else if(str1.equals("VCBPSR"))
            spos = 224;
        else if(str1.equals("VCBPSF"))
            spos = 225;
        else if(str1.equals("VCBPSB"))
            spos = 226;
        else if(str1.equals("VCBCCTRB"))
            spos = 227;
        else if(str1.equals("VCBCCTLB"))
            spos = 228;
        else if(str1.equals("VCBCCDLB"))
            spos = 229;
        else if(str1.equals("VCBCCDRB"))
            spos = 230;
        else if(str1.equals("VCBCCTRF"))
            spos = 231;
        else if(str1.equals("VCBCCTLF"))
            spos = 232;
        else if(str1.equals("VCBCCDLF"))
            spos = 233;
        else if(str1.equals("VCBCCDRF"))
            spos = 234;
        else if(str1.equals("VCBCETR"))
            spos = 243;
        else if(str1.equals("VCBCETL"))
            spos = 244;
        else if(str1.equals("VCBCEDL"))
            spos = 245;
        else if(str1.equals("VCBCEDR"))
            spos = 246;
        else if(str1.equals("VCBCETF"))
            spos = 247;
        else if(str1.equals("VCBCELF"))
            spos = 248;
        else if(str1.equals("VCBCEDF"))
            spos = 249;
        else if(str1.equals("VCBCERF"))
            spos = 250;
        else if(str1.equals("VCBCETB"))
            spos = 251;
        else if(str1.equals("VCBCELB"))
            spos = 252;
        else if(str1.equals("VCBCEDB"))
            spos = 253;
        else if(str1.equals("VCBCERB"))
            spos = 254;
        else if(str1.equals("VBTPST"))
            spos = 321;
        else if(str1.equals("VBTPSD"))
            spos = 322;
        else if(str1.equals("VBTPSL"))
            spos = 323;
        else if(str1.equals("VBTPSR"))
            spos = 324;
        else if(str1.equals("VBTPSF"))
            spos = 325;
        else if(str1.equals("VBTPSB"))
            spos = 326;
        else if(str1.equals("VBTCCTRB"))
            spos = 327;
        else if(str1.equals("VBTCCTLB"))
            spos = 328;
        else if(str1.equals("VBTCCDLB"))
            spos = 329;
        else if(str1.equals("VBTCCDRB"))
            spos = 330;
        else if(str1.equals("VBTCCTRF"))
            spos = 331;
        else if(str1.equals("VBTCCTLF"))
            spos = 332;
        else if(str1.equals("VBTCCDLF"))
            spos = 333;
        else if(str1.equals("VBTCCDRF"))
            spos = 334;
        else if(str1.equals("VBTCETR"))
            spos = 343;
        else if(str1.equals("VBTCETL"))
            spos = 344;
        else if(str1.equals("VBTCEDL"))
            spos = 345;
        else if(str1.equals("VBTCEDR"))
            spos = 346;
        else if(str1.equals("VBTCETF"))
            spos = 347;
        else if(str1.equals("VBTCELF"))
            spos = 348;
        else if(str1.equals("VBTCEDF"))
            spos = 349;
        else if(str1.equals("VBTCERF"))
            spos = 350;
        else if(str1.equals("VBTCETB"))
            spos = 351;
        else if(str1.equals("VBTCELB"))
            spos = 352;
        else if(str1.equals("VBTCEDB"))
            spos = 353;
        else if(str1.equals("VBTCERB"))
            spos = 354;
        else if(str1.equals("VBBPST"))
            spos = 421;
        else if(str1.equals("VBBPSD"))
            spos = 422;
        else if(str1.equals("VBBPSL"))
            spos = 423;
        else if(str1.equals("VBBPSR"))
            spos = 424;
        else if(str1.equals("VBBPSF"))
            spos = 425;
        else if(str1.equals("VBBPSB"))
            spos = 426;
        else if(str1.equals("VBBCCTRB"))
            spos = 427;
        else if(str1.equals("VBBCCTLB"))
            spos = 428;
        else if(str1.equals("VBBCCDLB"))
            spos = 429;
        else if(str1.equals("VBBCCDRB"))
            spos = 430;
        else if(str1.equals("VBBCCTRF"))
            spos = 431;
        else if(str1.equals("VBBCCTLF"))
            spos = 432;
        else if(str1.equals("VBBCCDLF"))
            spos = 433;
        else if(str1.equals("VBBCCDRF"))
            spos = 434;
        else if(str1.equals("VBBCETR"))
            spos = 443;
        else if(str1.equals("VBBCETL"))
            spos = 444;
        else if(str1.equals("VBBCEDL"))
            spos = 445;
        else if(str1.equals("VBBCEDR"))
            spos = 446;
        else if(str1.equals("VBBCETF"))
            spos = 447;
        else if(str1.equals("VBBCELF"))
            spos = 448;
        else if(str1.equals("VBBCEDF"))
            spos = 449;
        else if(str1.equals("VBBCERF"))
            spos = 450;
        else if(str1.equals("VBBCETB"))
            spos = 451;
        else if(str1.equals("VBBCELB"))
            spos = 452;
        else if(str1.equals("VBBCEDB"))
            spos = 453;
        else if(str1.equals("VBBCERB"))
            spos = 454;
        else if(str1.equals("PCTPST"))
            spos = 521;
        else if(str1.equals("PCTPSD"))
            spos = 522;
        else if(str1.equals("PCTPSL"))
            spos = 523;
        else if(str1.equals("PCTPSR"))
            spos = 524;
        else if(str1.equals("PCTPSF"))
            spos = 525;
        else if(str1.equals("PCTPSB"))
            spos = 526;
        else if(str1.equals("PCTCCTRB"))
            spos = 527;
        else if(str1.equals("PCTCCTLB"))
            spos = 528;
        else if(str1.equals("PCTCCDLB"))
            spos = 529;
        else if(str1.equals("PCTCCDRB"))
            spos = 530;
        else if(str1.equals("PCTCCTRF"))
            spos = 531;
        else if(str1.equals("PCTCCTLF"))
            spos = 532;
        else if(str1.equals("PCTCCDLF"))
            spos = 533;
        else if(str1.equals("PCTCCDRF"))
            spos = 534;
        else if(str1.equals("PCTCETR"))
            spos = 543;
        else if(str1.equals("PCTCETL"))
            spos = 544;
        else if(str1.equals("PCTCEDL"))
            spos = 545;
        else if(str1.equals("PCTCEDR"))
            spos = 546;
        else if(str1.equals("PCTCETF"))
            spos = 547;
        else if(str1.equals("PCTCELF"))
            spos = 548;
        else if(str1.equals("PCTCEDF"))
            spos = 549;
        else if(str1.equals("PCTCERF"))
            spos = 550;
        else if(str1.equals("PCTCETB"))
            spos = 551;
        else if(str1.equals("PCTCELB"))
            spos = 552;
        else if(str1.equals("PCTCEDB"))
            spos = 553;
        else if(str1.equals("PCTCERB"))
            spos = 554;
        else if(str1.equals("PCBPST"))
            spos = 621;
        else if(str1.equals("PCBPSD"))
            spos = 622;
        else if(str1.equals("PCBPSL"))
            spos = 623;
        else if(str1.equals("PCBPSR"))
            spos = 624;
        else if(str1.equals("PCBPSF"))
            spos = 625;
        else if(str1.equals("PCBPSB"))
            spos = 626;
        else if(str1.equals("PCBCCTRB"))
            spos = 627;
        else if(str1.equals("PCBCCTLB"))
            spos = 628;
        else if(str1.equals("PCBCCDLB"))
            spos = 629;
        else if(str1.equals("PCBCCDRB"))
            spos = 630;
        else if(str1.equals("PCBCCTRF"))
            spos = 631;
        else if(str1.equals("PCBCCTLF"))
            spos = 632;
        else if(str1.equals("PCBCCDLF"))
            spos = 633;
        else if(str1.equals("PCBCCDRF"))
            spos = 634;
        else if(str1.equals("PCBCETR"))
            spos = 643;
        else if(str1.equals("PCBCETL"))
            spos = 644;
        else if(str1.equals("PCBCEDL"))
            spos = 645;
        else if(str1.equals("PCBCEDR"))
            spos = 646;
        else if(str1.equals("PCBCETF"))
            spos = 647;
        else if(str1.equals("PCBCELF"))
            spos = 648;
        else if(str1.equals("PCBCEDF"))
            spos = 649;
        else if(str1.equals("PCBCERF"))
            spos = 650;
        else if(str1.equals("PCBCETB"))
            spos = 651;
        else if(str1.equals("PCBCELB"))
            spos = 652;
        else if(str1.equals("PCBCEDB"))
            spos = 653;
        else if(str1.equals("PCBCERB"))
            spos = 654;
        else if(str1.equals("PBTPST"))
            spos = 721;
        else if(str1.equals("PBTPSD"))
            spos = 722;
        else if(str1.equals("PBTPSL"))
            spos = 723;
        else if(str1.equals("PBTPSR"))
            spos = 724;
        else if(str1.equals("PBTPSF"))
            spos = 725;
        else if(str1.equals("PBTPSB"))
            spos = 726;
        else if(str1.equals("PBTCCTRB"))
            spos = 727;
        else if(str1.equals("PBTCCTLB"))
            spos = 728;
        else if(str1.equals("PBTCCDLB"))
            spos = 729;
        else if(str1.equals("PBTCCDRB"))
            spos = 730;
        else if(str1.equals("PBTCCTRF"))
            spos = 731;
        else if(str1.equals("PBTCCTLF"))
            spos = 732;
        else if(str1.equals("PBTCCDLF"))
            spos = 733;
        else if(str1.equals("PBTCCDRF"))
            spos = 734;
        else if(str1.equals("PBTCETR"))
            spos = 743;
        else if(str1.equals("PBTCETL"))
            spos = 744;
        else if(str1.equals("PBTCEDL"))
            spos = 745;
        else if(str1.equals("PBTCEDR"))
            spos = 746;
        else if(str1.equals("PBTCETF"))
            spos = 747;
        else if(str1.equals("PBTCELF"))
            spos = 748;
        else if(str1.equals("PBTCEDF"))
            spos = 749;
        else if(str1.equals("PBTCERF"))
            spos = 750;
        else if(str1.equals("PBTCETB"))
            spos = 751;
        else if(str1.equals("PBTCELB"))
            spos = 752;
        else if(str1.equals("PBTCEDB"))
            spos = 753;
        else if(str1.equals("PBTCERB"))
            spos = 754;
        else if(str1.equals("PBBPST"))
            spos = 821;
        else if(str1.equals("PBBPSD"))
            spos = 822;
        else if(str1.equals("PBBPSL"))
            spos = 823;
        else if(str1.equals("PBBPSR"))
            spos = 824;
        else if(str1.equals("PBBPSF"))
            spos = 825;
        else if(str1.equals("PBBPSB"))
            spos = 826;
        else if(str1.equals("PBBCCTRB"))
            spos = 827;
        else if(str1.equals("PBBCCTLB"))
            spos = 828;
        else if(str1.equals("PBBCCDLB"))
            spos = 829;
        else if(str1.equals("PBBCCDRB"))
            spos = 830;
        else if(str1.equals("PBBCCTRF"))
            spos = 831;
        else if(str1.equals("PBBCCTLF"))
            spos = 832;
        else if(str1.equals("PBBCCDLF"))
            spos = 833;
        else if(str1.equals("PBBCCDRF"))
            spos = 834;
        else if(str1.equals("PBBCETR"))
            spos = 843;
        else if(str1.equals("PBBCETL"))
            spos = 844;
        else if(str1.equals("PBBCEDL"))
            spos = 845;
        else if(str1.equals("PBBCEDR"))
            spos = 846;
        else if(str1.equals("PBBCETF"))
            spos = 847;
        else if(str1.equals("PBBCELF"))
            spos = 848;
        else if(str1.equals("PBBCEDF"))
            spos = 849;
        else if(str1.equals("PBBCERF"))
            spos = 850;
        else if(str1.equals("PBBCETB"))
            spos = 851;
        else if(str1.equals("PBBCELB"))
            spos = 852;
        else if(str1.equals("PBBCEDB"))
            spos = 853;
        else if(str1.equals("PBBCERB"))
            spos = 854;
        else
            ierr(str1+" has not been defined: please contact michael.seaton@stfc.ac.uk");
        return spos;
    }
}
