int fDefineSystem(const char* filename);
int fInputParameters(const char* filename);
int fReadSpace2D(const char* filename);
int fReadSpace3D(const char* filename);
int fReadSpaceParameter(const char* filename);
int fReadInitialState2D(const char* filename);
int fReadInitialState3D(const char* filename);
int fReadInitialState(const char* filename);
int fSetoffSteer();
int fCheckSteer();
int fPrintSystemInfo();
int fPrintEndEquilibration();
int fPrintDomainMass();
int fPrintDomainMomentum();
int fOutput(const char* filename);
int fReadSystemDump(const char* filename, int rank);
int fWriteSystemDump(const char* filename, int rank);

