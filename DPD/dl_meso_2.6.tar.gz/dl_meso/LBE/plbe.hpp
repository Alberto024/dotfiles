#include <mpi.h>

struct sNeighbour
{
  int rank;
  unsigned long int spos;
  unsigned long int rpos;
  unsigned long int bspos;
  unsigned long int brpos;
  unsigned long int fspos;
  unsigned long int frpos;
  unsigned long int ispos;
  unsigned long int irpos;
};
sNeighbour lbnb[6];
// messages to be communicated 
MPI_Datatype lbmsg2x; 
MPI_Datatype lbmsg2y; 
MPI_Datatype lbmsg3x; 
MPI_Datatype lbmsg3y; 
MPI_Datatype lbmsg3z; 
MPI_Datatype lbbmsg2x; 
MPI_Datatype lbbmsg2y; 
MPI_Datatype lbbmsg3x; 
MPI_Datatype lbbmsg3y; 
MPI_Datatype lbbmsg3z;
MPI_Datatype lbfmsg2x; 
MPI_Datatype lbfmsg2y; 
MPI_Datatype lbfmsg3x; 
MPI_Datatype lbfmsg3y; 
MPI_Datatype lbfmsg3z;
MPI_Datatype lbimsg2x; 
MPI_Datatype lbimsg2y; 
MPI_Datatype lbimsg3x; 
MPI_Datatype lbimsg3y; 
MPI_Datatype lbimsg3z;

#ifdef Packbuf
double *recvbuf_0_x, *recvbuf_1_x, *sendbuf_0_x,  *sendbuf_1_x ;
double *recvbuf_0_y, *recvbuf_1_y, *sendbuf_0_y,  *sendbuf_1_y ;
double *recvbuf_0_z, *recvbuf_1_z, *sendbuf_0_z,  *sendbuf_1_z ;
#endif

#include "slbe.hpp"
#include "lbpMPI.hpp"
#include "lbpMPI.cpp"
#include "lbpRUNPAR.hpp"
#include "lbpRUNPAR.cpp"
