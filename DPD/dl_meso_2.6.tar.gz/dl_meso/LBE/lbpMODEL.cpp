/***********************************************
 *   DL_MESO       Version 2.6                 *
 *   Authors   :   R. S. Qin, M. A. Seaton     *
 *   Copyright :   STFC Daresbury Laboratory   *
 *             :   22/10/2015                  *
 ***********************************************/

// D2Q9, D3Q15, D3Q19 and D3Q27 models

int D2Q9()
{
  int i;
  
  lbcs = 1.0/sqrt(3.0);
  lbcssq = 1.0/3.0;
  lbrcssq = 3.0;

  lbw[0]=4.0/9.0;
  for(i=1; i<5; i++) {
    lbw[2*i]=1.0/9.0;
    lbw[2*i-1]=1.0/36.0;
  }

  if(interact==5) {
    lbwi[0]=4.0/3.0;
    lbw0[0]=1.0;
    lbwpt[0]=-5.0/3.0;
    lbwxx[0]=lbwyy[0]=-1.0/6.0;
    lbwzz[0]=lbwxy[0]=lbwxz[0]=lbwyz[0]=0.0;
    lbwgam[0]=0.0;
    lbwdel[0]=-2.625;
    for(i=1; i<5; i++) {
      lbwi[2*i]=1.0/3.0;
      lbwi[2*i-1]=1.0/12.0;
      lbw0[2*i]=lbw0[2*i-1]=0.0;
      lbwpt[2*i]=1.0/3.0;
      lbwpt[2*i-1]=1.0/12.0;
      lbwxx[2*i-1]=-1.0/24.0;
      lbwyy[2*i-1]=-1.0/24.0;
      lbwzz[2*i]=lbwzz[2*i-1]=0.0;
      lbwxy[2*i]=0.0;
      lbwxz[2*i]=lbwxz[2*i-1]=0.0;
      lbwyz[2*i]=lbwyz[2*i-1]=0.0;
      lbwgam[2*i]=lbwgam[2*i-1]=1.5;
      lbwdel[2*i]=lbwdel[2*i-1]=-1.5;
    }
    lbwxx[2] = lbwxx[6] = 1.0/3.0;
    lbwxx[4] = lbwxx[8] = -1.0/6.0;
    lbwyy[2] = lbwyy[6] = -1.0/6.0;
    lbwyy[4] = lbwyy[8] = 1.0/3.0;
  }

  lbvx[0]=0;    lbvy[0]=0;    lbvz[0]=0;

  lbvx[1]=-1;   lbvy[1]=1;    lbvz[1]=0;
  lbvx[2]=-1;   lbvy[2]=0;    lbvz[2]=0;
  lbvx[3]=-1;   lbvy[3]=-1;   lbvz[3]=0;
  lbvx[4]=0;    lbvy[4]=-1;   lbvz[4]=0;

  lbvx[5]=1;    lbvy[5]=-1;   lbvz[5]=0;
  lbvx[6]=1;    lbvy[6]=0;    lbvz[6]=0;
  lbvx[7]=1;    lbvy[7]=1;    lbvz[7]=0;
  lbvx[8]=0;    lbvy[8]=1;    lbvz[8]=0;
  
  if(interact==5) {
    lbfevx[0]  = -1; lbfevy[0]  =  0; lbfevz[0]  = 0;
    lbfevx[1]  = -1; lbfevy[1]  = -1; lbfevz[1]  = 0;
    lbfevx[2]  = -1; lbfevy[2]  =  0; lbfevz[2]  = 0;
    lbfevx[3]  = -1; lbfevy[3]  =  1; lbfevz[3]  = 0;
    lbfevx[4]  = -1; lbfevy[4]  =  0; lbfevz[4]  = 0;
    lbfevx[5]  =  0; lbfevy[5]  = -1; lbfevz[5]  = 0;
    lbfevx[6]  =  0; lbfevy[6]  =  0; lbfevz[6]  = 0;
    lbfevx[7]  =  0; lbfevy[7]  =  1; lbfevz[7]  = 0;
    lbfevx[8]  =  0; lbfevy[8]  = -1; lbfevz[8]  = 0;
    lbfevx[9]  =  0; lbfevy[9]  =  0; lbfevz[9]  = 0;
    lbfevx[10] =  0; lbfevy[10] =  1; lbfevz[10] = 0;
    lbfevx[11] =  0; lbfevy[11] = -1; lbfevz[11] = 0;
    lbfevx[12] =  0; lbfevy[12] =  0; lbfevz[12] = 0;
    lbfevx[13] =  0; lbfevy[13] =  1; lbfevz[13] = 0;
    lbfevx[14] =  1; lbfevy[14] =  0; lbfevz[14] = 0;
    lbfevx[15] =  1; lbfevy[15] = -1; lbfevz[15] = 0;
    lbfevx[16] =  1; lbfevy[16] =  0; lbfevz[16] = 0;
    lbfevx[17] =  1; lbfevy[17] =  1; lbfevz[17] = 0;
    lbfevx[18] =  1; lbfevy[18] =  0; lbfevz[18] = 0;
  }
    
  lbopv[0]=0;   lbopv[1]=5;   lbopv[2]=6;
  lbopv[3]=7;   lbopv[4]=8;   lbopv[5]=1;
  lbopv[6]=2;   lbopv[7]=3;   lbopv[8]=4;
    
  lbvwx[0] = lbvwy[0] = lbvwz[0] = 0.0;
  for(i=1; i<9; i++) {
    lbvwx[i] = lbvx[i] * lbw[i];
    lbvwy[i] = lbvy[i] * lbw[i];
    lbvwz[i] = lbvz[i] * lbw[i];
  }

// MRT scheme transformation matrix

   double trd2q9[81] =  { 1,  1,  1,  1,  1,  1,  1,  1,  1, 
                         -4,  2, -1,  2, -1,  2, -1,  2, -1, 
                          4,  1, -2,  1, -2,  1, -2,  1, -2,
                          0, -1, -1, -1,  0,  1,  1,  1,  0,
                          0, -1,  2, -1,  0,  1, -2,  1,  0,
                          0,  1,  0, -1, -1, -1,  0,  1,  1,
                          0,  1,  0, -1,  2, -1,  0,  1, -2,
                          0,  0,  1,  0, -1,  0,  1,  0, -1,
                          0, -1,  0,  1,  0, -1,  0,  1,  0 };

  std::copy (trd2q9, trd2q9+lbsy.nq*lbsy.nq, lbtr);

// MRT scheme inverse transformation matrix

  double trinvd2q9[81] = { 1.0/9.0,  -1.0/9.0,   1.0/9.0,        0,        0,        0,         0,     0,     0,
                           1.0/9.0,  1.0/18.0,  1.0/36.0, -1.0/6.0,-1.0/12.0,  1.0/6.0,  1.0/12.0,     0, -0.25,
                           1.0/9.0, -1.0/36.0, -1.0/18.0, -1.0/6.0,  1.0/6.0,        0,         0,  0.25,     0,
                           1.0/9.0,  1.0/18.0,  1.0/36.0, -1.0/6.0,-1.0/12.0, -1.0/6.0, -1.0/12.0,     0,  0.25,
                           1.0/9.0, -1.0/36.0, -1.0/18.0,        0,        0, -1.0/6.0,   1.0/6.0, -0.25,     0,
                           1.0/9.0,  1.0/18.0,  1.0/36.0,  1.0/6.0, 1.0/12.0, -1.0/6.0, -1.0/12.0,     0, -0.25,
                           1.0/9.0, -1.0/36.0, -1.0/18.0,  1.0/6.0, -1.0/6.0,        0,         0,  0.25,     0,
                           1.0/9.0,  1.0/18.0,  1.0/36.0,  1.0/6.0, 1.0/12.0,  1.0/6.0,  1.0/12.0,     0,  0.25,
                           1.0/9.0, -1.0/36.0, -1.0/18.0,        0,        0,  1.0/6.0,  -1.0/6.0, -0.25,     0  };

  std::copy (trinvd2q9, trinvd2q9+lbsy.nq*lbsy.nq, lbtrinv);

// MRT collision and moment parameters

  lbmrts[0] = 1.14;  // s2   - tuneable collision parameter
  lbmrts[1] = 1.92;  // s4   - tuneable collision parameter

  lbmrtw[0] = 1.0;   // w_e  - moment parameter
  lbmrtw[1] = -3.0;  // w_ej - moment parameter

  if(lbdm.rank == 0)
    cout << "armed with D2Q9 LB model" << endl;
  
  return 0;

}

int D3Q15()
{
  int i;

  lbcs = 1.0/sqrt(3.0);
  lbcssq = 1.0/3.0;
  lbrcssq = 3.0;

  lbw[0]=2.0/9.0;
  for(i=1; i<4; i++) {
    lbw[i]=1.0/9.0;
    lbw[i+7]=1.0/9.0;
  }
  for(i=4; i<8; i++) {
    lbw[i]=1.0/72.0;
    lbw[i+7]=1.0/72.0;
  }

  if(interact==5) {
    lbwi[0]=2.0/3.0;
    lbw0[0]=1.0;
    lbwpt[0]=-7.0/3.0;
    lbwxx[0]=lbwyy[0]=lbwzz[0]=4.0/3.0;
    lbwxy[0]=lbwxz[0]=lbwyz[0]=0.0;
    lbwgam[0]=0.0;
    lbwdel[0]=-6.5;
    for(i=1; i<4; i++) {
      lbwi[i]=lbw[i+7]=1.0/3.0;
      lbw0[i]=lbw0[i+7]=0.0;
      lbwpt[i]=lbwpt[i+7]=1.0/3.0;
      lbwxy[i]=lbwxy[i+7]=0.0;
      lbwxz[i]=lbwxz[i+7]=0.0;
      lbwyz[i]=lbwyz[i+7]=0.0;
      lbwgam[i]=lbwgam[i+7]=0.0;
      lbwdel[i]=lbwdel[i+7]=1.0;
    }
    lbwxx[1]=lbwxx[8]=1.0/6.0;
    lbwxx[2]=lbwxx[3]=lbwxx[9]=lbwxx[10]=-1.0/3.0;
    lbwyy[2]=lbwyy[9]=1.0/6.0;
    lbwyy[1]=lbwyy[3]=lbwyy[8]=lbwyy[10]=-1.0/3.0;
    lbwzz[3]=lbwzz[10]=1.0/6.0;
    lbwzz[1]=lbwzz[2]=lbwzz[8]=lbwzz[9]=-1.0/3.0;
    for(i=4; i<8; i++) {
      lbwi[i]=lbw[i+7]=1.0/24.0;
      lbw0[i]=lbw0[i+7]=0.0;
      lbwpt[i]=lbwpt[i+7]=1.0/24.0;
      lbwxx[i]=lbwxx[i+7]=-1.0/24.0;
      lbwyy[i]=lbwyy[i+7]=-1.0/24.0;
      lbwzz[i]=lbwzz[i+7]=-1.0/24.0;
      lbwgam[i]=lbwgam[i+7]=0.0;
      lbwdel[i]=lbwdel[i+7]=-2.0;
    }
    lbwxy[4]=lbwxy[5]=lbwxy[11]=lbwxy[12]=0.125;
    lbwxy[6]=lbwxy[7]=lbwxy[13]=lbwxy[14]=-0.125;
    lbwxz[4]=lbwxz[6]=lbwxz[11]=lbwxz[13]=0.125;
    lbwxz[5]=lbwxz[7]=lbwxz[12]=lbwxz[14]=-0.125;
    lbwyz[4]=lbwyz[7]=lbwyz[11]=lbwyz[14]=0.125;
    lbwyz[5]=lbwyz[6]=lbwyz[12]=lbwyz[13]=-0.125;
  }

  lbvx[0]=0;    lbvy[0]=0;    lbvz[0]=0;

  lbvx[1]=-1;   lbvy[1]=0;    lbvz[1]=0;
  lbvx[2]=0;    lbvy[2]=-1;   lbvz[2]=0;
  lbvx[3]=0;    lbvy[3]=0;    lbvz[3]=-1;
  lbvx[4]=-1;   lbvy[4]=-1;   lbvz[4]=-1;
  lbvx[5]=-1;   lbvy[5]=-1;   lbvz[5]=1;
  lbvx[6]=-1;   lbvy[6]=1;    lbvz[6]=-1;
  lbvx[7]=-1;   lbvy[7]=1;    lbvz[7]=1;

  lbvx[8]=1;    lbvy[8]=0;    lbvz[8]=0;
  lbvx[9]=0;    lbvy[9]=1;    lbvz[9]=0;
  lbvx[10]=0;   lbvy[10]=0;   lbvz[10]=1;
  lbvx[11]=1;   lbvy[11]=1;   lbvz[11]=1;
  lbvx[12]=1;   lbvy[12]=1;   lbvz[12]=-1;
  lbvx[13]=1;   lbvy[13]=-1;  lbvz[13]=1;
  lbvx[14]=1;   lbvy[14]=-1;  lbvz[14]=-1;
  
  if(interact==5) {
    lbfevx[0]  = -1; lbfevy[0]  =  0; lbfevz[0]  = -1;
    lbfevx[1]  = -1; lbfevy[1]  = -1; lbfevz[1]  =  0;
    lbfevx[2]  = -1; lbfevy[2]  =  0; lbfevz[2]  =  0;
    lbfevx[3]  = -1; lbfevy[3]  =  1; lbfevz[3]  =  0;
    lbfevx[4]  = -1; lbfevy[4]  =  0; lbfevz[4]  =  1;
    lbfevx[5]  =  0; lbfevy[5]  = -1; lbfevz[5]  = -1;
    lbfevx[6]  =  0; lbfevy[6]  =  0; lbfevz[6]  = -1;
    lbfevx[7]  =  0; lbfevy[7]  =  1; lbfevz[7]  = -1;
    lbfevx[8]  =  0; lbfevy[8]  = -1; lbfevz[8]  =  0;
    lbfevx[9]  =  0; lbfevy[9]  =  0; lbfevz[9]  =  0;
    lbfevx[10] =  0; lbfevy[10] =  1; lbfevz[10] =  0;
    lbfevx[11] =  0; lbfevy[11] = -1; lbfevz[11] =  1;
    lbfevx[12] =  0; lbfevy[12] =  0; lbfevz[12] =  1;
    lbfevx[13] =  0; lbfevy[13] =  1; lbfevz[13] =  1;
    lbfevx[14] =  1; lbfevy[14] =  0; lbfevz[14] = -1;
    lbfevx[15] =  1; lbfevy[15] = -1; lbfevz[15] =  0;
    lbfevx[16] =  1; lbfevy[16] =  0; lbfevz[16] =  0;
    lbfevx[17] =  1; lbfevy[17] =  1; lbfevz[17] =  0;
    lbfevx[18] =  1; lbfevy[18] =  0; lbfevz[18] =  1;
  }
    
  lbopv[0]=0;   lbopv[1]=8;   lbopv[2]=9;
  lbopv[3]=10;  lbopv[4]=11;  lbopv[5]=12;
  lbopv[6]=13;  lbopv[7]=14;  lbopv[8]=1;
  lbopv[9]=2;   lbopv[10]=3;  lbopv[11]=4;
  lbopv[12]=5;  lbopv[13]=6;  lbopv[14]=7;

  lbvwx[0] = lbvwy[0] = lbvwz[0] = 0.0;
  for(i=1; i<15; i++) {
    lbvwx[i] = lbvx[i] * lbw[i];
    lbvwy[i] = lbvy[i] * lbw[i];
    lbvwz[i] = lbvz[i] * lbw[i];
  }

// MRT scheme transformation matrix

  double trd3q15[] = {  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,
                       -2, -1, -1, -1,  1,  1,  1,  1, -1, -1, -1,  1,  1,  1,  1,
                       16, -4, -4, -4,  1,  1,  1,  1, -4, -4, -4,  1,  1,  1,  1,
                        0, -1,  0,  0, -1, -1, -1, -1,  1,  0,  0,  1,  1,  1,  1,
                        0,  4,  0,  0, -1, -1, -1, -1, -4,  0,  0,  1,  1,  1,  1,
                        0,  0, -1,  0, -1, -1,  1,  1,  0,  1,  0,  1,  1, -1, -1,
                        0,  0,  4,  0, -1, -1,  1,  1,  0, -4,  0,  1,  1, -1, -1,
                        0,  0,  0, -1, -1,  1, -1,  1,  0,  0,  1,  1, -1,  1, -1,
                        0,  0,  0,  4, -1,  1, -1,  1,  0,  0, -4,  1, -1,  1, -1,
                        0,  2, -1, -1,  0,  0,  0,  0,  2, -1, -1,  0,  0,  0,  0,
                        0,  0,  1, -1,  0,  0,  0,  0,  0,  1, -1,  0,  0,  0,  0,
                        0,  0,  0,  0,  1,  1, -1, -1,  0,  0,  0,  1,  1, -1, -1,
                        0,  0,  0,  0,  1, -1, -1,  1,  0,  0,  0,  1, -1, -1,  1,
                        0,  0,  0,  0,  1, -1,  1, -1,  0,  0,  0,  1, -1,  1, -1,
                        0,  0,  0,  0, -1,  1,  1, -1,  0,  0,  0,  1, -1, -1,  1 };

  std::copy (trd3q15, trd3q15+lbsy.nq*lbsy.nq, lbtr);

// MRT scheme inverse transformation matrix

  double trinvd3q15[] = { 1.0/15.0,  -1.0/9.0,  2.0/45.0,    0,      0,    0,      0,    0,      0,         0,     0,      0,      0,      0,      0,
                          1.0/15.0, -1.0/18.0, -1.0/90.0, -0.1,    0.1,    0,      0,    0,      0,   1.0/6.0,     0,      0,      0,      0,      0,
                          1.0/15.0, -1.0/18.0, -1.0/90.0,    0,      0  -0.1,    0.1,    0,      0, -1.0/12.0,  0.25,      0,      0,      0,      0,
                          1.0/15.0, -1.0/18.0, -1.0/90.0,    0,      0,    0,      0, -0.1,    0.1, -1.0/12.0, -0.25,      0,      0,      0,      0,
                          1.0/15.0,  1.0/18.0, 1.0/360.0, -0.1, -0.025, -0.1, -0.025, -0.1, -0.025,         0,     0,  0.125,  0.125,  0.125, -0.125,
                          1.0/15.0,  1.0/18.0, 1.0/360.0, -0.1, -0.025, -0.1, -0.025,  0.1,  0.025,         0,     0,  0.125, -0.125, -0.125,  0.125,
                          1.0/15.0,  1.0/18.0, 1.0/360.0, -0.1, -0.025,  0.1,  0.025, -0.1, -0.025,         0,     0, -0.125, -0.125,  0.125,  0.125,
                          1.0/15.0,  1.0/18.0, 1.0/360.0, -0.1, -0.025,  0.1,  0.025,  0.1,  0.025,         0,     0, -0.125,  0.125, -0.125, -0.125,
                          1.0/15.0, -1.0/18.0, -1.0/90.0,  0.1,   -0.1,    0,      0,    0,      0,   1.0/6.0,     0,      0,      0,      0,      0,
                          1.0/15.0, -1.0/18.0, -1.0/90.0,    0,      0,  0.1,   -0.1,    0,      0, -1.0/12.0,  0.25,      0,      0,      0,      0,
                          1.0/15.0, -1.0/18.0, -1.0/90.0,    0,      0,    0,      0,  0.1,   -0.1, -1.0/12.0, -0.25,      0,      0,      0,      0,
                          1.0/15.0,  1.0/18.0, 1.0/360.0,  0.1,  0.025,  0.1,  0.025,  0.1,  0.025,         0,     0,  0.125,  0.125,  0.125,  0.125,
                          1.0/15.0,  1.0/18.0, 1.0/360.0,  0.1,  0.025,  0.1,  0.025, -0.1, -0.025,         0,     0,  0.125, -0.125, -0.125, -0.125,
                          1.0/15.0,  1.0/18.0, 1.0/360.0,  0.1,  0.025, -0.1, -0.025,  0.1,  0.025,         0,     0, -0.125, -0.125,  0.125, -0.125,
                          1.0/15.0,  1.0/18.0, 1.0/360.0,  0.1,  0.025, -0.1, -0.025, -0.1, -0.025,         0,     0, -0.125,  0.125, -0.125,  0.125 };

  std::copy (trinvd3q15, trinvd3q15+lbsy.nq*lbsy.nq, lbtrinv);

// MRT collision and moment parameters

  lbmrts[0] = 1.2;   // s2   - tuneable collision parameter
  lbmrts[1] = 1.6;   // s4   - tuneable collision parameter
  lbmrts[2] = 1.2;   // s14  - tuneable collision parameter

  lbmrtw[0] = 1.0;   // w_e  - moment parameter
  lbmrtw[1] = -5.0;  // w_ej - moment parameter

  if(lbdm.rank == 0)
    cout << "armed with D3Q15 LB model" << endl;
  
  return 0;
  
}

int D3Q19()
{
  int i;

  lbcs = 1.0/sqrt(3.0);
  lbcssq = 1.0/3.0;
  lbrcssq = 3.0;

  lbw[0]=1.0/3.0;
  for(i=1; i<4; i++) {
    lbw[i]=1.0/18.0;
    lbw[i+9]=1.0/18.0;
  }
  for(i=4; i<10; i++) {
    lbw[i]=1.0/36.0;
    lbw[i+9]=1.0/36.0;
  }

  if(interact==5) {
    lbwi[0]=1.0;
    lbw0[0]=1.0;
    lbwpt[0]=-2.0;
    lbwxx[0]=0.5;
    lbwyy[0]=0.5;
    lbwzz[0]=0.5;
    lbwxy[0]=lbwxz[0]=lbwyz[0]=0.0;
    lbwgam[0]=0.0;
    lbwdel[0]=-4.5;
    for(i=1; i<4; i++) {
      lbwi[i]=lbw[i+9]=1.0/6.0;
      lbw0[i]=lbw0[i+9]=0.0;
      lbwpt[i]=lbwpt[i+9]=1.0/6.0;
      lbwxy[i]=lbwxy[i+9]=0.0;
      lbwxz[i]=lbwxz[i+9]=0.0;
      lbwyz[i]=lbwyz[i+9]=0.0;
      lbwgam[i]=lbwgam[i+9]=1.5;
      lbwdel[i]=lbwdel[i+9]=-1.5;
    }
    lbwxx[1]=lbwxx[10]=5.0/12.0;
    lbwxx[2]=lbwxx[3]=lbwxx[11]=lbwxx[12]=-1.0/3.0;
    lbwyy[2]=lbwyy[11]=5.0/12.0;
    lbwyy[1]=lbwyy[3]=lbwyy[10]=lbwyy[12]=-1.0/3.0;
    lbwzz[3]=lbwzz[12]=5.0/12.0;
    lbwzz[1]=lbwzz[2]=lbwzz[10]=lbwzz[11]=-1.0/3.0;
    for(i=4; i<10; i++) {
      lbwi[i]=lbw[i+9]=1.0/12.0;
      lbw0[i]=lbw0[i+9]=0.0;
      lbwpt[i]=lbwpt[i+9]=1.0/12.0;
      lbwgam[i]=lbwgam[i+9]=1.5;
      lbwdel[i]=lbwdel[i+9]=-1.5;
    }
    lbwxx[4]=lbwxx[5]=lbwxx[6]=lbwxx[7]=lbwxx[13]=lbwxx[14]=lbwxx[15]=lbwxx[16]=-1.0/24.0;
    lbwxx[8]=lbwxx[9]=lbwxx[17]=lbwxx[18]=1.0/12.0;
    lbwyy[4]=lbwyy[5]=lbwyy[8]=lbwyy[9]=lbwyy[13]=lbwyy[14]=lbwyy[17]=lbwyy[18]=-1.0/24.0;
    lbwyy[6]=lbwyy[7]=lbwyy[15]=lbwyy[16]=1.0/12.0;
    lbwzz[6]=lbwzz[7]=lbwzz[8]=lbwzz[9]=lbwzz[15]=lbwzz[16]=lbwzz[17]=lbwzz[18]=-1.0/24.0;
    lbwzz[4]=lbwzz[5]=lbwzz[13]=lbwzz[14]=1.0/12.0;
    lbwxy[4]=lbwxy[13]=0.25;
    lbwxy[5]=lbwxy[14]=-0.25;
    lbwxy[6]=lbwxy[7]=lbwxy[8]=lbwxy[9]=lbwxy[15]=lbwxy[16]=lbwxy[17]=lbwxy[18]=0.0;
    lbwxz[6]=lbwxz[15]=0.25;
    lbwxz[7]=lbwxz[16]=-0.25;
    lbwxz[4]=lbwxz[5]=lbwxz[8]=lbwxz[9]=lbwxz[13]=lbwxz[14]=lbwxz[17]=lbwxz[18]=0.0;
    lbwyz[8]=lbwyz[17]=0.25;
    lbwyz[9]=lbwyz[18]=-0.25;
    lbwyz[4]=lbwyz[5]=lbwyz[6]=lbwyz[7]=lbwyz[13]=lbwyz[14]=lbwyz[15]=lbwyz[16]=0.0;
  }

  lbvx[0]=0;    lbvy[0]=0;    lbvz[0]=0;

  lbvx[1]=-1;   lbvy[1]=0;    lbvz[1]=0;
  lbvx[2]=0;    lbvy[2]=-1;   lbvz[2]=0;
  lbvx[3]=0;    lbvy[3]=0;    lbvz[3]=-1;
  lbvx[4]=-1;   lbvy[4]=-1;   lbvz[4]=0;
  lbvx[5]=-1;   lbvy[5]=1;    lbvz[5]=0;
  lbvx[6]=-1;   lbvy[6]=0;    lbvz[6]=-1;
  lbvx[7]=-1;   lbvy[7]=0;    lbvz[7]=1;
  lbvx[8]=0;    lbvy[8]=-1;   lbvz[8]=-1;
  lbvx[9]=0;    lbvy[9]=-1;   lbvz[9]=1;

  lbvx[10]=1;   lbvy[10]=0;   lbvz[10]=0;
  lbvx[11]=0;   lbvy[11]=1;   lbvz[11]=0;
  lbvx[12]=0;   lbvy[12]=0;   lbvz[12]=1;
  lbvx[13]=1;   lbvy[13]=1;   lbvz[13]=0;
  lbvx[14]=1;   lbvy[14]=-1;  lbvz[14]=0;
  lbvx[15]=1;   lbvy[15]=0;   lbvz[15]=1;
  lbvx[16]=1;   lbvy[16]=0;   lbvz[16]=-1;
  lbvx[17]=0;   lbvy[17]=1;   lbvz[17]=1;
  lbvx[18]=0;   lbvy[18]=1;   lbvz[18]=-1;

  if(interact==5) {
    lbfevx[0]  = -1; lbfevy[0]  =  0; lbfevz[0]  = -1;
    lbfevx[1]  = -1; lbfevy[1]  = -1; lbfevz[1]  =  0;
    lbfevx[2]  = -1; lbfevy[2]  =  0; lbfevz[2]  =  0;
    lbfevx[3]  = -1; lbfevy[3]  =  1; lbfevz[3]  =  0;
    lbfevx[4]  = -1; lbfevy[4]  =  0; lbfevz[4]  =  1;
    lbfevx[5]  =  0; lbfevy[5]  = -1; lbfevz[5]  = -1;
    lbfevx[6]  =  0; lbfevy[6]  =  0; lbfevz[6]  = -1;
    lbfevx[7]  =  0; lbfevy[7]  =  1; lbfevz[7]  = -1;
    lbfevx[8]  =  0; lbfevy[8]  = -1; lbfevz[8]  =  0;
    lbfevx[9]  =  0; lbfevy[9]  =  0; lbfevz[9]  =  0;
    lbfevx[10] =  0; lbfevy[10] =  1; lbfevz[10] =  0;
    lbfevx[11] =  0; lbfevy[11] = -1; lbfevz[11] =  1;
    lbfevx[12] =  0; lbfevy[12] =  0; lbfevz[12] =  1;
    lbfevx[13] =  0; lbfevy[13] =  1; lbfevz[13] =  1;
    lbfevx[14] =  1; lbfevy[14] =  0; lbfevz[14] = -1;
    lbfevx[15] =  1; lbfevy[15] = -1; lbfevz[15] =  0;
    lbfevx[16] =  1; lbfevy[16] =  0; lbfevz[16] =  0;
    lbfevx[17] =  1; lbfevy[17] =  1; lbfevz[17] =  0;
    lbfevx[18] =  1; lbfevy[18] =  0; lbfevz[18] =  1;
  }

  lbopv[0]=0;   lbopv[1]=10;  lbopv[2]=11;
  lbopv[3]=12;  lbopv[4]=13;  lbopv[5]=14;
  lbopv[6]=15;  lbopv[7]=16;  lbopv[8]=17;
  lbopv[9]=18;  lbopv[10]=1;  lbopv[11]=2;
  lbopv[12]=3;  lbopv[13]=4;  lbopv[14]=5;
  lbopv[15]=6;  lbopv[16]=7;  lbopv[17]=8;
  lbopv[18]=9;

  lbvwx[0] = lbvwy[0] = lbvwz[0] = 0.0;
  for(i=1; i<19; i++) {
    lbvwx[i] = lbvx[i] * lbw[i];
    lbvwy[i] = lbvy[i] * lbw[i];
    lbvwz[i] = lbvz[i] * lbw[i];
  }

// MRT scheme transformation matrix

  double trd3q19[] = {  1,   1,   1,   1,   1,   1,   1,   1,   1,   1,   1,   1,   1,   1,   1,   1,   1,   1,   1,
                      -30, -11, -11, -11,   8,   8,   8,   8,   8,   8, -11, -11, -11,   8,   8,   8,   8,   8,   8,
                       12,  -4,  -4,  -4,   1,   1,   1,   1,   1,   1,  -4,  -4,  -4,   1,   1,   1,   1,   1,   1,
                        0,  -1,   0,   0,  -1,  -1,  -1,  -1,   0,   0,   1,   0,   0,   1,   1,   1,   1,   0,   0,
                        0,   4,   0,   0,  -1,  -1,  -1,  -1,   0,   0,  -4,   0,   0,   1,   1,   1,   1,   0,   0,
                        0,   0,  -1,   0,  -1,   1,   0,   0,  -1,  -1,   0,   1,   0,   1,  -1,   0,   0,   1,   1,
                        0,   0,   4,   0,  -1,   1,   0,   0,  -1,  -1,   0,  -4,   0,   1,  -1,   0,   0,   1,   1,
                        0,   0,   0,  -1,   0,   0,  -1,   1,  -1,   1,   0,   0,   1,   0,   0,   1,  -1,   1,  -1,
                        0,   0,   0,   4,   0,   0,  -1,   1,  -1,   1,   0,   0,  -4,   0,   0,   1,  -1,   1,  -1,
                        0,   2,  -1,  -1,   1,   1,   1,   1,  -2,  -2,   2,  -1,  -1,   1,   1,   1,   1,  -2,  -2,
                        0,  -4,   2,   2,   1,   1,   1,   1,  -2,  -2,  -4,   2,   2,   1,   1,   1,   1,  -2,  -2,
                        0,   0,   1,  -1,   1,   1,  -1,  -1,   0,   0,   0,   1,  -1,   1,   1,  -1,  -1,   0,   0,
                        0,   0,  -2,   2,   1,   1,  -1,  -1,   0,   0,   0,  -2,   2,   1,   1,  -1,  -1,   0,   0,
                        0,   0,   0,   0,   1,  -1,   0,   0,   0,   0,   0,   0,   0,   1,  -1,   0,   0,   0,   0,
                        0,   0,   0,   0,   0,   0,   0,   0,   1,  -1,   0,   0,   0,   0,   0,   0,   0,   1,  -1,
                        0,   0,   0,   0,   0,   0,   1,  -1,   0,   0,   0,   0,   0,   0,   0,   1,  -1,   0,   0,
                        0,   0,   0,   0,  -1,  -1,   1,   1,   0,   0,   0,   0,   0,   1,   1,  -1,  -1,   0,   0,
                        0,   0,   0,   0,   1,  -1,   0,   0,  -1,  -1,   0,   0,   0,  -1,   1,   0,   0,   1,   1,
                        0,   0,   0,   0,   0,   0,  -1,   1,   1,  -1,   0,   0,   0,   0,   0,   1,  -1,  -1,   1 };

  std::copy (trd3q19, trd3q19+lbsy.nq*lbsy.nq, lbtr);

// MRT scheme inverse transformation matrix

  double trinvd3q19[] = { 1.0/19.0,  -10.0/798.0,  1.0/21.0,    0,      0,    0,      0,    0,      0,         0,         0,         0,         0,     0,     0,     0,      0,      0,      0,
                          1.0/19.0, -33.0/7182.0, -1.0/63.0, -0.1,    0.1,    0,      0,    0,      0,  1.0/18.0, -1.0/18.0,         0,         0,     0,     0,     0,      0,      0,      0,
                          1.0/19.0, -33.0/7182.0, -1.0/63.0,    0,      0, -0.1,    0.1,    0,      0, -1.0/36.0,  1.0/36.0,  1.0/12.0, -1.0/12.0,     0,     0,     0,      0,      0,      0,
                          1.0/19.0, -33.0/7182.0, -1.0/63.0,    0,      0,    0,      0, -0.1,    0.1, -1.0/36.0,  1.0/36.0, -1.0/12.0,  1.0/12.0,     0,     0,     0,      0,      0,      0,
                          1.0/19.0,   4.0/1197.0, 1.0/252.0, -0.1, -0.025, -0.1, -0.025,    0,      0,  1.0/36.0,  1.0/72.0,  1.0/12.0,  1.0/24.0,  0.25,     0,     0, -0.125,  0.125,      0,
                          1.0/19.0,   4.0/1197.0, 1.0/252.0, -0.1, -0.025,  0.1,  0.025,    0,      0,  1.0/36.0,  1.0/72.0,  1.0/12.0,  1.0/24.0, -0.25,     0,     0, -0.125, -0.125,      0,
                          1.0/19.0,   4.0/1197.0, 1.0/252.0, -0.1, -0.025,    0,      0, -0.1, -0.025,  1.0/36.0,  1.0/72.0, -1.0/12.0, -1.0/24.0,     0,     0,  0.25,  0.125,      0, -0.125,
                          1.0/19.0,   4.0/1197.0, 1.0/252.0, -0.1, -0.025,    0,      0,  0.1,  0.025,  1.0/36.0,  1.0/72.0, -1.0/12.0, -1.0/24.0,     0,     0, -0.25,  0.125,      0,  0.125,
                          1.0/19.0,   4.0/1197.0, 1.0/252.0,    0,      0, -0.1, -0.025, -0.1, -0.025, -1.0/18.0, -1.0/36.0,         0,         0,     0,  0.25,     0,      0, -0.125,  0.125,
                          1.0/19.0,   4.0/1197.0, 1.0/252.0,    0,      0, -0.1, -0.025,  0.1,  0.025, -1.0/18.0, -1.0/36.0,         0,         0,     0, -0.25,     0,      0, -0.125, -0.125,
                          1.0/19.0, -33.0/7182.0, -1.0/63.0,  0.1,   -0.1,    0,      0,    0,      0,  1.0/18.0, -1.0/18.0,         0,         0,     0,     0,     0,      0,      0,      0,
                          1.0/19.0, -33.0/7182.0, -1.0/63.0,    0,      0,  0.1,   -0.1,    0,      0, -1.0/36.0,  1.0/36.0,  1.0/12.0, -1.0/12.0,     0,     0,     0,      0,      0,      0,
                          1.0/19.0, -33.0/7182.0, -1.0/63.0,    0,      0,    0,      0,  0.1,   -0.1, -1.0/36.0,  1.0/36.0, -1.0/12.0,  1.0/12.0,     0,     0,     0,      0,      0,      0,
                          1.0/19.0,   4.0/1197.0, 1.0/252.0,  0.1,  0.025,  0.1,  0.025,    0,      0,  1.0/36.0,  1.0/72.0,  1.0/12.0,  1.0/24.0,  0.25,     0,     0,  0.125, -0.125,      0,
                          1.0/19.0,   4.0/1197.0, 1.0/252.0,  0.1,  0.025, -0.1, -0.025,    0,      0,  1.0/36.0,  1.0/72.0,  1.0/12.0,  1.0/24.0, -0.25,     0,     0,  0.125,  0.125,      0,
                          1.0/19.0,   4.0/1197.0, 1.0/252.0,  0.1,  0.025,    0,      0,  0.1,  0.025,  1.0/36.0,  1.0/72.0, -1.0/12.0, -1.0/24.0,     0,     0,  0.25, -0.125,      0,  0.125,
                          1.0/19.0,   4.0/1197.0, 1.0/252.0,  0.1,  0.025,    0,      0, -0.1, -0.025,  1.0/36.0,  1.0/72.0, -1.0/12.0, -1.0/24.0,     0,     0, -0.25, -0.125,      0, -0.125,
                          1.0/19.0,   4.0/1197.0, 1.0/252.0,    0,      0,  0.1,  0.025,  0.1,  0.025, -1.0/18.0, -1.0/36.0,         0,         0,     0,  0.25,     0,      0,  0.125, -0.125,
                          1.0/19.0,   4.0/1197.0, 1.0/252.0,    0,      0,  0.1,  0.025, -0.1, -0.025, -1.0/18.0, -1.0/36.0,         0,         0,     0, -0.25,     0,      0,  0.125,  0.125 };

  std::copy (trinvd3q19, trinvd3q19+lbsy.nq*lbsy.nq, lbtrinv);

// MRT collision and moment parameters

  lbmrts[0] = 1.4;   // s2   - tuneable collision parameter
  lbmrts[1] = 1.2;   // s4   - tuneable collision parameter
  lbmrts[2] = 1.98;  // s16  - tuneable collision parameter

  lbmrtw[0] = 3.0;   // w_e  - moment parameter
  lbmrtw[1] = -5.5;  // w_ej - moment parameter
  lbmrtw[2] = -0.5;  // w_xx - moment parameter

  if(lbdm.rank == 0)
    cout << "armed with D3Q19 LB model" << endl;

  return 0;

}


int D3Q27()
{
  // note: no MRT or Swift free energy schemes are available for D3Q27
    
  int i;

  lbcs = 1.0/sqrt(3.0);
  lbcssq = 1.0/3.0;
  lbrcssq = 3.0;

  lbw[0]=8.0/27.0;
  
  for(i=1; i<4; i++) {
    lbw[i]=lbw[i+13]=2.0/27.0;
  }

  for(i=4; i<10; i++) {
    lbw[i]=lbw[i+13]=1.0/54.0;
  }

  for(i=10; i<14; i++) {
    lbw[i]=lbw[i+13]=1.0/216.0;
  }
  
  lbvx[0]=0;    lbvy[0]=0;    lbvz[0]=0;

  lbvx[1]=-1;   lbvy[1]=0;    lbvz[1]=0;
  lbvx[2]=0;    lbvy[2]=-1;   lbvz[2]=0;
  lbvx[3]=0;    lbvy[3]=0;    lbvz[3]=-1;
  lbvx[4]=-1;   lbvy[4]=-1;   lbvz[4]=0;
  lbvx[5]=-1;   lbvy[5]=1;    lbvz[5]=0;
  lbvx[6]=-1;   lbvy[6]=0;    lbvz[6]=-1;
  lbvx[7]=-1;   lbvy[7]=0;    lbvz[7]=1;
  lbvx[8]=0;    lbvy[8]=-1;   lbvz[8]=-1;
  lbvx[9]=0;    lbvy[9]=-1;   lbvz[9]=1;
  lbvx[10]=-1;  lbvy[10]=-1;  lbvz[10]=-1;
  lbvx[11]=-1;  lbvy[11]=-1;  lbvz[11]=1;
  lbvx[12]=-1;  lbvy[12]=1;   lbvz[12]=-1;
  lbvx[13]=-1;  lbvy[13]=1;   lbvz[13]=1;

  lbvx[14]=1;   lbvy[14]=0;   lbvz[14]=0;
  lbvx[15]=0;   lbvy[15]=1;   lbvz[15]=0;
  lbvx[16]=0;   lbvy[16]=0;   lbvz[16]=1;
  lbvx[17]=1;   lbvy[17]=1;   lbvz[17]=0;
  lbvx[18]=1;   lbvy[18]=-1;  lbvz[18]=0;
  lbvx[19]=1;   lbvy[19]=0;   lbvz[19]=1;
  lbvx[20]=1;   lbvy[20]=0;   lbvz[20]=-1;
  lbvx[21]=0;   lbvy[21]=1;   lbvz[21]=1;
  lbvx[22]=0;   lbvy[22]=1;   lbvz[22]=-1;
  lbvx[23]=1;   lbvy[23]=1;   lbvz[23]=1;
  lbvx[24]=1;   lbvy[24]=1;   lbvz[24]=-1;
  lbvx[25]=1;   lbvy[25]=-1;  lbvz[25]=1;
  lbvx[26]=1;   lbvy[26]=-1;  lbvz[26]=-1;
  
  lbopv[0]=0;   lbopv[1]=14;  lbopv[2]=15;
  lbopv[3]=16;  lbopv[4]=17;  lbopv[5]=18;
  lbopv[6]=19;  lbopv[7]=20;  lbopv[8]=21;
  lbopv[9]=22;  lbopv[10]=23; lbopv[11]=24;
  lbopv[12]=25; lbopv[13]=26; lbopv[14]=1;
  lbopv[15]=2;  lbopv[16]=3;  lbopv[17]=4;
  lbopv[18]=5;  lbopv[19]=6;  lbopv[20]=7;
  lbopv[21]=8;  lbopv[22]=9;  lbopv[23]=10;
  lbopv[24]=11; lbopv[25]=12; lbopv[26]=13;

  lbvwx[0] = lbvwy[0] = lbvwz[0] = 0.0;
  for(i=1; i<27; i++) {
    lbvwx[i] = lbvx[i] * lbw[i];
    lbvwy[i] = lbvy[i] * lbw[i];
    lbvwz[i] = lbvz[i] * lbw[i];
  }

  if(lbdm.rank == 0)
    cout << "armed with D3Q27 LB model" << endl;
  
  return 0;
  
}


