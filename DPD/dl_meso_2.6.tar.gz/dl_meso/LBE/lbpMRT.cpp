/***********************************************
 *   DL_MESO       Version 2.6                 *
 *   Authors   :   R. S. Qin, M. A. Seaton     *
 *   Amended   :   L. Grinberg                 *
 *   Copyright :   STFC Daresbury Laboratory   *
 *             :   22/10/2015                  *
 ***********************************************/

int fGetMomentEquilibriumF(double *meq, double *p, double rho)
{

  // calculate equilibrium moments of compressible fluid for MRT collision schemes:
  // not suitable for incompressible fluid
  const double c1 = -7.0/3.0;
  const double c2 = -2.0/3.0;

  if(lbsy.nq == 9) {
    // D2Q9 (Lallemand and Luo, 2000)
    meq[0] = rho;                                                                              // density
    meq[1] = -2.0 * rho + 3.0 * (p[0] * p[0] + p[1] * p[1]) / rho;                             // energy
    meq[2] = lbmrtw[0] * rho + lbmrtw[1] * (p[0] * p[0] + p[1] * p[1]) / rho;                  // energy-squared
    meq[3] = p[0];                                                                             // x-momentum
    meq[4] = -p[0];                                                                            // x-energy flux
    meq[5] = p[1];                                                                             // y-momentum
    meq[6] = -p[1];                                                                            // y-energy flux
    meq[7] = (p[0] * p[0] - p[1] * p[1]) / rho;                                                // diagonal (xx) stress tensor
    meq[8] = p[0] * p[1] / rho;                                                                // off-diagonal (xy) stress tensor
  }
  else if(lbsy.nq == 15) {
    // D3Q15 (d'Humieres et al., 2002)
    meq[0]  = rho;                                                                             // density
    meq[1]  = -rho + (p[0] * p[0] + p[1] * p[1] + p[2] * p[2]) / rho;                          // energy
    meq[2]  = lbmrtw[0] * rho + lbmrtw[1] * (p[0] * p[0] + p[1] * p[1] + p[2] * p[2]) / rho;   // energy-squared
    meq[3]  = p[0];                                                                            // x-momentum
    meq[4]  = c1 * p[0];                                                                       // x-energy flux
    meq[5]  = p[1];                                                                            // y-momentum
    meq[6]  = c1 * p[1];                                                                       // y-energy flux
    meq[7]  = p[2];                                                                            // z-momentum
    meq[8]  = c1 * p[2];                                                                       // z-energy flux
    meq[9]  = (2.0 * p[0] * p[0] - p[1] * p[1] - p[2] * p[2]) / rho;                           // diagonal (xx) stress tensor (3p_xx)
    meq[10] = (p[1] * p[1] - p[2] * p[2]) / rho;                                               // diagonal (yy/zz) stress tensor (p_yy - p_zz)
    meq[11] = p[0] * p[1] / rho;                                                               // off-diagonal (xy) stress tensor
    meq[12] = p[1] * p[2] / rho;                                                               // off-diagonal (yz) stress tensor
    meq[13] = p[0] * p[2] / rho;                                                               // off-diagonal (zx) stress tensor
    meq[14] = 0.0;                                                                             // antisymmetric (xyz) third-order moment
  }
  else if(lbsy.nq == 19) {
    // D3Q19 (d'Humieres et al., 2002)
    meq[0]  = rho;                                                                             // density
    meq[1]  = -11.0 * rho + 19.0 * (p[0] * p[0] + p[1] * p[1] + p[2] * p[2]) / rho;            // energy
    meq[2]  = lbmrtw[0] * rho + lbmrtw[1] * (p[0] * p[0] + p[1] * p[1] + p[2] * p[2]) / rho;   // energy-squared
    meq[3]  = p[0];                                                                            // x-momentum
    meq[4]  = c2 * p[0];                                                                       // x-energy flux
    meq[5]  = p[1];                                                                            // y-momentum
    meq[6]  = c2 * p[1];                                                                       // y-energy flux
    meq[7]  = p[2];                                                                            // z-momentum
    meq[8]  = c2 * p[2];                                                                       // z-energy flux
    meq[9]  = (2.0 * p[0] * p[0] - p[1] * p[1] - p[2] * p[2]) / rho;                           // diagonal (xx) stress tensor (3p_xx)
    meq[10] = lbmrtw[2] * (2.0 * p[0] * p[0] - p[1] * p[1] - p[2] * p[2]) / rho;               // diagonal (xx) fourth-order moment (3 pi_xx)
    meq[11] = (p[1] * p[1] - p[2] * p[2]) / rho;                                               // diagonal (yy/zz) stress tensor (p_yy - p_zz)
    meq[12] = lbmrtw[2] * (p[1] * p[1] - p[2] * p[2]) / rho;                                   // diagonal (yy/zz) fourth-order moment (pi_yy - pi_zz)
    meq[13] = p[0] * p[1] / rho;                                                               // off-diagonal (xy) stress tensor
    meq[14] = p[1] * p[2] / rho;                                                               // off-diagonal (yz) stress tensor
    meq[15] = p[0] * p[2] / rho;                                                               // off-diagonal (zx) stress tensor
    meq[16] = 0.0;                                                                             // symmetric (x) third-order moment
    meq[17] = 0.0;                                                                             // symmetric (y) third-order moment
    meq[18] = 0.0;                                                                             // symmetric (z) third-order moment
  }
  else if(lbdm.rank ==0) {
    cout << "the multiple-relaxation-time scheme for D" << lbsy.nd << "Q" << lbsy.nq << " model has not been defined" << endl;
    if(lbsy.nd == 2)
      cout << "the D2Q9 model can be used" << endl;
    else
      cout << "the D3Q15 or D3Q19 models can be used" << endl;
    exit(1);
  }  
  return 0;
}


int fGetMomentEquilibriumFIncom(double *meq, double *p, double rho, double rho0)
{

  // calculate equilibrium moments of incompressible fluid for MRT collision schemes
  const double c1 = -7.0/3.0;
  const double c2 = -2.0/3.0;
    
  if(lbsy.nq == 9) {
    // D2Q9 (Lallemand and Luo, 2000)
    meq[0] = rho;                                                                              // density
    meq[1] = -2.0 * rho + 3.0 * (p[0] * p[0] + p[1] * p[1]) / rho0;                            // energy
    meq[2] = lbmrtw[0] * rho + lbmrtw[1] * (p[0] * p[0] + p[1] * p[1]) / rho0;                 // energy-squared
    meq[3] = p[0];                                                                             // x-momentum
    meq[4] = -p[0];                                                                            // x-energy flux
    meq[5] = p[1];                                                                             // y-momentum
    meq[6] = -p[1];                                                                            // y-energy flux
    meq[7] = (p[0] * p[0] - p[1] * p[1]) / rho0;                                               // diagonal (xx) stress tensor
    meq[8] = p[0] * p[1] / rho0;                                                               // off-diagonal (xy) stress tensor
  }
  else if(lbsy.nq == 15) {
    // D3Q15 (d'Humieres et al., 2002)
    meq[0]  = rho;                                                                             // density
    meq[1]  = -rho + (p[0] * p[0] + p[1] * p[1] + p[2] * p[2]) / rho0;                         // energy
    meq[2]  = lbmrtw[0] * rho + lbmrtw[1] * (p[0] * p[0] + p[1] * p[1] + p[2] * p[2]) / rho0;  // energy-squared
    meq[3]  = p[0];                                                                            // x-momentum
    meq[4]  = c1 * p[0];                                                                       // x-energy flux
    meq[5]  = p[1];                                                                            // y-momentum
    meq[6]  = c1 * p[1];                                                                       // y-energy flux
    meq[7]  = p[2];                                                                            // z-momentum
    meq[8]  = c1 * p[2];                                                                       // z-energy flux
    meq[9]  = (2.0 * p[0] * p[0] - p[1] * p[1] - p[2] * p[2]) / rho0;                          // diagonal (xx) stress tensor (3p_xx)
    meq[10] = (p[1] * p[1] - p[2] * p[2]) / rho0;                                              // diagonal (yy/zz) stress tensor (p_yy - p_zz)
    meq[11] = p[0] * p[1] / rho0;                                                              // off-diagonal (xy) stress tensor
    meq[12] = p[1] * p[2] / rho0;                                                              // off-diagonal (yz) stress tensor
    meq[13] = p[0] * p[2] / rho0;                                                              // off-diagonal (zx) stress tensor
    meq[14] = 0.0;                                                                             // antisymmetric (xyz) third-order moment
  }
  else if(lbsy.nq == 19) {
    // D3Q19 (d'Humieres et al., 2002)
    meq[0]  = rho;                                                                             // density
    meq[1]  = -11.0 * rho + 19.0 * (p[0] * p[0] + p[1] * p[1] + p[2] * p[2]) / rho0;           // energy
    meq[2]  = lbmrtw[0] * rho + lbmrtw[1] * (p[0] * p[0] + p[1] * p[1] + p[2] * p[2]) / rho0;  // energy-squared
    meq[3]  = p[0];                                                                            // x-momentum
    meq[4]  = c2 * p[0];                                                                       // x-energy flux
    meq[5]  = p[1];                                                                            // y-momentum
    meq[6]  = c2 * p[1];                                                                       // y-energy flux
    meq[7]  = p[2];                                                                            // z-momentum
    meq[8]  = c2 * p[2];                                                                       // z-energy flux
    meq[9]  = (2.0 * p[0] * p[0] - p[1] * p[1] - p[2] * p[2]) / rho0;                          // diagonal (xx) stress tensor (3p_xx)
    meq[10] = lbmrtw[2] * (2.0 * p[0] * p[0] - p[1] * p[1] - p[2] * p[2]) / rho0;              // diagonal (xx) fourth-order moment (3 pi_xx)
    meq[11] = (p[1] * p[1] - p[2] * p[2]) / rho0;                                              // diagonal (yy/zz) stress tensor (p_yy - p_zz)
    meq[12] = lbmrtw[2] * (p[1] * p[1] - p[2] * p[2]) / rho0;                                  // diagonal (yy/zz) fourth-order moment (pi_yy - pi_zz)
    meq[13] = p[0] * p[1] / rho0;                                                              // off-diagonal (xy) stress tensor
    meq[14] = p[1] * p[2] / rho0;                                                              // off-diagonal (yz) stress tensor
    meq[15] = p[0] * p[2] / rho0;                                                              // off-diagonal (zx) stress tensor
    meq[16] = 0.0;                                                                             // symmetric (x) third-order moment
    meq[17] = 0.0;                                                                             // symmetric (y) third-order moment
    meq[18] = 0.0;                                                                             // symmetric (z) third-order moment
  }
  else if(lbdm.rank ==0) {
    cout << "the multiple-relaxation-time scheme for D" << lbsy.nd << "Q" << lbsy.nq << " model has not been defined" << endl;
    if(lbsy.nd == 2)
      cout << "the D2Q9 model can be used" << endl;
    else
      cout << "the D3Q15 or D3Q19 models can be used" << endl;
    exit(1);
  }  
  return 0;
}


int fGetMomentEquilibriumFSwiftOneFluid(double *meq, double *p, double rho, double pb, double lambda, double* grad)
{

  // calculate equilibrium moments of one fluid with Swift free-energy interactions for MRT collision schemes

  const double c1 = -7.0/3.0;
  const double c2 = -2.0/3.0;
  double drdx = grad[0];
  double drdy = grad[1];
  double drdz = grad[2];
  double nabr = grad[3];

  if(lbsy.nq == 9) {
    // D2Q9 (Lallemand and Luo, 2000)
    meq[0] = rho;                                                                              // density
    meq[1] = -4.0*rho + 3.0*(p[0]*p[0]+p[1]*p[1])/rho + 6.0*(pb-lbkappa*rho*nabr)
           + 15.0*lambda*(p[0]*drdx+p[1]*drdy)/rho;                                            // energy
    meq[2] = 4.0*rho - 3.0*(p[0]*p[0]+p[1]*p[1])/rho - 9.0*(pb-lbkappa*rho*nabr)
           - 1.5*lbkappa*(drdx*drdx+drdy*drdy) - 16.5*lambda*(p[0]*drdx+p[1]*drdy)/rho;        // energy-squared
    meq[3] = p[0];                                                                             // x-momentum
    meq[4] = -p[0];                                                                            // x-energy flux
    meq[5] = p[1];                                                                             // y-momentum
    meq[6] = -p[1];                                                                            // y-energy flux
    meq[7] = (p[0]*p[0]-p[1]*p[1])/rho + lbkappa*(drdx*drdx-drdy*drdy)
           + 2.0*lambda*(p[0]*drdx-p[1]*drdy)/rho;                                             // diagonal (xx) stress tensor
    meq[8] = p[0]*p[1]/rho + lbkappa*drdx*drdy + lambda*(p[0]*drdy+p[1]*drdx)/rho;             // off-diagonal (xy) stress tensor
  }
  else if(lbsy.nq == 15) {
    // D3Q15 (d'Humieres et al., 2002)
    meq[0]  = rho;                                                                             // density
    meq[1]  = -2.0*rho + (p[0]*p[0]+p[1]*p[1]+p[2]*p[2])/rho + 3.0*(pb-lbkappa*rho*nabr)
            - 2.0*lbkappa*(drdx*drdx+drdy*drdy+drdz*drdz)
            + 5.0*lambda*(p[0]*drdx+p[1]*drdy+p[2]*drdz)/rho;                                  // energy
    meq[2]  = 16.0*rho - 5.0*(p[0]*p[0]+p[1]*p[1]+p[2]*p[2])/rho - 45.0*(pb-lbkappa*rho*nabr)
            + 25.0*lbkappa*(drdx*drdx+drdy*drdy+drdz*drdz)
            - 85.0*lambda*(p[0]*drdx+p[1]*drdy+p[2]*drdz)/rho;                                 // energy-squared
    meq[3]  = p[0];                                                                            // x-momentum
    meq[4]  = c1*p[0];                                                                         // x-energy flux
    meq[5]  = p[1];                                                                            // y-momentum
    meq[6]  = c1*p[1];                                                                         // y-energy flux
    meq[7]  = p[2];                                                                            // z-momentum
    meq[8]  = c1*p[2];                                                                         // z-energy flux
    meq[9]  = (2.0*p[0]*p[0]-p[1]*p[1]-p[2]*p[2])/rho
            + lbkappa*(2.0*drdx*drdx-drdy*drdy-drdz*drdz)
            + 2.0*lambda*(2.0*p[0]*drdx-p[1]*drdy-p[2]*drdz)/rho;                              // diagonal (xx) stress tensor (3p_xx)
    meq[10] = (p[1]*p[1]-p[2]*p[2])/rho + lbkappa*(drdy*drdy-drdz*drdz)
            + 2.0*lambda*(p[1]*drdy-p[2]*drdz)/rho;                                            // diagonal (yy/zz) stress tensor (p_yy - p_zz)
    meq[11] = p[0]*p[1]/rho + lbkappa*drdx*drdy + lambda*(p[0]*drdy+p[1]*drdx)/rho;            // off-diagonal (xy) stress tensor
    meq[12] = p[1]*p[2]/rho + lbkappa*drdy*drdz + lambda*(p[1]*drdz+p[2]*drdy)/rho;            // off-diagonal (yz) stress tensor
    meq[13] = p[0]*p[2]/rho + lbkappa*drdx*drdz + lambda*(p[0]*drdz+p[2]*drdx)/rho;            // off-diagonal (zx) stress tensor
    meq[14] = 0.0;                                                                             // antisymmetric (xyz) third-order moment
  }
  else if(lbsy.nq == 19) {
    // D3Q19 (d'Humieres et al., 2002)
    meq[0]  = rho;                                                                             // density
    meq[1]  = -30.0*rho + 19.0*(p[0]*p[0]+p[1]*p[1]+p[2]*p[2])/rho
            + 57.0*(pb-lbkappa*rho*nabr) - 9.5*lbkappa*(drdx*drdx+drdy*drdy+drdz*drdz)
            + 152.0*lambda*(p[0]*drdx+p[1]*drdy+p[2]*drdz)/rho;                                // energy
    meq[2]  = 12.0*rho - 5.5*(p[0]*p[0]+p[1]*p[1]+p[2]*p[2])/rho - 27.0*(pb-lbkappa*rho*nabr)
            + 8.0*lbkappa*(drdx*drdx+drdy*drdy+drdz*drdz)
            - 54.5*lambda*(p[0]*drdx+p[1]*drdy+p[2]*drdz)/rho;                                 // energy-squared
    meq[3]  = p[0];                                                                            // x-momentum
    meq[4]  = c2*p[0];                                                                         // x-energy flux
    meq[5]  = p[1];                                                                            // y-momentum
    meq[6]  = c2*p[1];                                                                         // y-energy flux
    meq[7]  = p[2];                                                                            // z-momentum
    meq[8]  = c2*p[2];                                                                         // z-energy flux
    meq[9]  = (2.0*p[0]*p[0]-p[1]*p[1]-p[2]*p[2])/rho
            + lbkappa*(2.0*drdx*drdx-drdy*drdy-drdz*drdz)
            + 2.0*lambda*(2.0*p[0]*drdx-p[1]*drdy-p[2]*drdz)/rho;                              // diagonal (xx) stress tensor (3p_xx)
    meq[10] = -0.5*(2.0*p[0]*p[0]-p[1]*p[1]-p[2]*p[2])/rho
            - 3.5*lbkappa*(2.0*drdx*drdx-drdy*drdy-drdz*drdz)
            - lambda*(2.0*p[0]*drdx-p[1]*drdy-p[2]*drdz)/rho;                                  // diagonal (xx) fourth-order moment (3 pi_xx)
    meq[11] = (p[1]*p[1]-p[2]*p[2])/rho + lbkappa*(drdy*drdy-drdz*drdz)
            + 2.0*lambda*(p[1]*drdy-p[2]*drdz)/rho;                                            // diagonal (yy/zz) stress tensor (p_yy - p_zz)
    meq[12] = -0.5*(p[1]*p[1]-p[2]*p[2])/rho - 3.5*lbkappa*(drdy*drdy-drdz*drdz)
            - lambda*(p[1]*drdy-p[2]*drdz)/rho;                                                // diagonal (yy/zz) fourth-order moment (pi_yy - pi_zz)
    meq[13] = p[0]*p[1]/rho + lbkappa*drdx*drdy + lambda*(p[0]*drdy+p[1]*drdx)/rho;            // off-diagonal (xy) stress tensor
    meq[14] = p[1]*p[2]/rho + lbkappa*drdy*drdz + lambda*(p[1]*drdz+p[2]*drdy)/rho;            // off-diagonal (yz) stress tensor
    meq[15] = p[0]*p[2]/rho + lbkappa*drdx*drdz + lambda*(p[0]*drdz+p[2]*drdx)/rho;            // off-diagonal (zx) stress tensor
    meq[16] = 0.0;                                                                             // symmetric (x) third-order moment
    meq[17] = 0.0;                                                                             // symmetric (y) third-order moment
    meq[18] = 0.0;                                                                             // symmetric (z) third-order moment
  }
  else if(lbdm.rank ==0) {
    cout << "the multiple-relaxation-time scheme for D" << lbsy.nd << "Q" << lbsy.nq << " model has not been defined" << endl;
    if(lbsy.nd == 2)
      cout << "the D2Q9 model can be used" << endl;
    else
      cout << "the D3Q15 or D3Q19 models can be used" << endl;
    exit(1);
  }  
  return 0;
}

int fGetMomentEquilibriumFSwiftTwoFluid(double *meq, double *p, double rho, double phi, double pb, double mu, double lambda, double* grad)
{

  // calculate equilibrium moments of one fluid with Swift free-energy interactions for MRT collision schemes

  const double c1 = -7.0/3.0;
  const double c2 = -2.0/3.0;
  double drdx = (lbfeeos>0)?grad[0]:0.0;
  double drdy = (lbfeeos>0)?grad[1]:0.0;
  double drdz = (lbfeeos>0)?grad[2]:0.0;
  double nabr = (lbfeeos>0)?grad[3]:0.0;
  double dpdx = grad[4];
  double dpdy = grad[5];
  double dpdz = grad[6];
  double nabp = grad[7];
  double modv, uv;
  double v[3];
  double rrho = fReciprocal(rho);

  if(lbsy.nq == 9) {
    // D2Q9 (Lallemand and Luo, 2000)
    meq[0] = rho;                                                                              // density
    meq[1] = -4.0*rho + 3.0*(p[0]*p[0]+p[1]*p[1])*rrho + 6.0*(pb-lbkappa*(rho*nabr+phi*nabp))
           + 15.0*lambda*(p[0]*drdx+p[1]*drdy)*rrho;                                           // energy
    meq[2] = 4.0*rho - 3.0*(p[0]*p[0]+p[1]*p[1])*rrho - 9.0*(pb-lbkappa*(rho*nabr+phi*nabp))
           - 1.5*lbkappa*(drdx*drdx+drdy*drdy+dpdx*dpdx+dpdy*dpdy)
           - 16.5*lambda*(p[0]*drdx+p[1]*drdy)*rrho;                                           // energy-squared
    meq[3] = p[0];                                                                             // x-momentum
    meq[4] = -p[0];                                                                            // x-energy flux
    meq[5] = p[1];                                                                             // y-momentum
    meq[6] = -p[1];                                                                            // y-energy flux
    meq[7] = (p[0]*p[0]-p[1]*p[1])*rrho + lbkappa*(drdx*drdx+dpdx*dpdx-drdy*drdy-dpdy*dpdy)
           + 2.0*lambda*(p[0]*drdx-p[1]*drdy)*rrho;                                            // diagonal (xx) stress tensor
    meq[8] = p[0]*p[1]*rrho + lbkappa*(drdx*drdy+dpdx*dpdy)
           + lambda*(p[0]*drdy+p[1]*drdx)*rrho;                                                // off-diagonal (xy) stress tensor
  }
  else if(lbsy.nq == 15) {
    // D3Q15 (d'Humieres et al., 2002)
    meq[0]  = rho;                                                                             // density
    meq[1]  = -2.0*rho + (p[0]*p[0]+p[1]*p[1]+p[2]*p[2])*rrho
            + 3.0*(pb-lbkappa*(rho*nabr+phi*nabp))
            - 2.0*lbkappa*(drdx*drdx+drdy*drdy+drdz*drdz+dpdx*dpdx+dpdy*dpdy+dpdz*dpdz)
            + 5.0*lambda*(p[0]*drdx+p[1]*drdy+p[2]*drdz)*rrho;                                 // energy
    meq[2]  = 16.0*rho - 5.0*(p[0]*p[0]+p[1]*p[1]+p[2]*p[2])*rrho
            - 45.0*(pb-lbkappa*(rho*nabr+phi*nabp))
            + 25.0*lbkappa*(drdx*drdx+drdy*drdy+drdz*drdz+dpdx*dpdx+dpdy*dpdy+dpdz*dpdz)
            - 85.0*lambda*(p[0]*drdx+p[1]*drdy+p[2]*drdz)*rrho;                                // energy-squared
    meq[3]  = p[0];                                                                            // x-momentum
    meq[4]  = c1*p[0];                                                                         // x-energy flux
    meq[5]  = p[1];                                                                            // y-momentum
    meq[6]  = c1*p[1];                                                                         // y-energy flux
    meq[7]  = p[2];                                                                            // z-momentum
    meq[8]  = c1*p[2];                                                                         // z-energy flux
    meq[9]  = (2.0*p[0]*p[0]-p[1]*p[1]-p[2]*p[2])*rrho
            + lbkappa*(2.0*(drdx*drdx+dpdx*dpdx)-drdy*drdy-dpdy*dpdy-drdz*drdz-dpdz*dpdz)
            + 2.0*lambda*(2.0*p[0]*drdx-p[1]*drdy-p[2]*drdz)*rrho;                             // diagonal (xx) stress tensor (3p_xx)
    meq[10] = (p[1]*p[1]-p[2]*p[2])/rho + lbkappa*(drdy*drdy+dpdy*dpdy-drdz*drdz-dpdz*dpdz)
            + 2.0*lambda*(p[1]*drdy-p[2]*drdz)*rrho;                                           // diagonal (yy/zz) stress tensor (p_yy - p_zz)
    meq[11] = p[0]*p[1]/rho + lbkappa*(drdx*drdy+dpdx*dpdy)
            + lambda*(p[0]*drdy+p[1]*drdx)*rrho;                                               // off-diagonal (xy) stress tensor
    meq[12] = p[1]*p[2]/rho + lbkappa*(drdy*drdz+dpdy*dpdz)
            + lambda*(p[1]*drdz+p[2]*drdy)*rrho;                                               // off-diagonal (yz) stress tensor
    meq[13] = p[0]*p[2]/rho + lbkappa*(drdx*drdz+dpdx*dpdz)
            + lambda*(p[0]*drdz+p[2]*drdx)*rrho;                                               // off-diagonal (zx) stress tensor
    meq[14] = 0.0;                                                                             // antisymmetric (xyz) third-order moment
  }
  else if(lbsy.nq == 19) {
    // D3Q19 (d'Humieres et al., 2002)
    meq[0]  = rho;                                                                             // density
    meq[1]  = -30.0*rho + 19.0*(p[0]*p[0]+p[1]*p[1]+p[2]*p[2])*rrho
            + 57.0*(pb-lbkappa*(rho*nabr+phi*nabp))
            - 9.5*lbkappa*(drdx*drdx+drdy*drdy+drdz*drdz+dpdx*dpdx+dpdy*dpdy+dpdz*dpdz)
            + 152.0*lambda*(p[0]*drdx+p[1]*drdy+p[2]*drdz)*rrho;                               // energy
    meq[2]  = 12.0*rho - 5.5*(p[0]*p[0]+p[1]*p[1]+p[2]*p[2])*rrho
            - 27.0*(pb-lbkappa*(rho*nabr+phi*nabp))
            + 8.0*lbkappa*(drdx*drdx+drdy*drdy+drdz*drdz+dpdx*dpdx+dpdy*dpdy+dpdz*dpdz)
            - 54.5*lambda*(p[0]*drdx+p[1]*drdy+p[2]*drdz)*rrho;                                // energy-squared
    meq[3]  = p[0];                                                                            // x-momentum
    meq[4]  = c2*p[0];                                                                         // x-energy flux
    meq[5]  = p[1];                                                                            // y-momentum
    meq[6]  = c2*p[1];                                                                         // y-energy flux
    meq[7]  = p[2];                                                                            // z-momentum
    meq[8]  = c2*p[2];                                                                         // z-energy flux
    meq[9]  = (2.0*p[0]*p[0]-p[1]*p[1]-p[2]*p[2])*rrho
            + lbkappa*(2.0*(drdx*drdx+dpdx*dpdx)-drdy*drdy-dpdy*dpdy-drdz*drdz-dpdz*dpdz)
            + 2.0*lambda*(2.0*p[0]*drdx-p[1]*drdy-p[2]*drdz)*rrho;                             // diagonal (xx) stress tensor (3p_xx)
    meq[10] = -0.5*(2.0*p[0]*p[0]-p[1]*p[1]-p[2]*p[2])*rrho
            - 3.5*lbkappa*(2.0*(drdx*drdx+dpdx*dpdx)-drdy*drdy-dpdy*dpdy-drdz*drdz-dpdz*dpdz)
            - lambda*(2.0*p[0]*drdx-p[1]*drdy-p[2]*drdz)*rrho;                                 // diagonal (xx) fourth-order moment (3 pi_xx)
    meq[11] = (p[1]*p[1]-p[2]*p[2])*rrho + lbkappa*(drdy*drdy+dpdy*dpdy-drdz*drdz-dpdz*dpdz)
            + 2.0*lambda*(p[1]*drdy-p[2]*drdz)*rrho;                                           // diagonal (yy/zz) stress tensor (p_yy - p_zz)
    meq[12] = -0.5*(p[1]*p[1]-p[2]*p[2])*rrho
            - 3.5*lbkappa*(drdy*drdy+dpdy*dpdy-drdz*drdz-dpdz*dpdz)
            - lambda*(p[1]*drdy-p[2]*drdz)*rrho;                                               // diagonal (yy/zz) fourth-order moment (pi_yy - pi_zz)
    meq[13] = p[0]*p[1]/rho + lbkappa*(drdx*drdy+dpdx*dpdy)
            + lambda*(p[0]*drdy+p[1]*drdx)*rrho;                                               // off-diagonal (xy) stress tensor
    meq[14] = p[1]*p[2]/rho + lbkappa*(drdy*drdz+dpdy*dpdz)
            + lambda*(p[1]*drdz+p[2]*drdy)*rrho;                                               // off-diagonal (yz) stress tensor
    meq[15] = p[0]*p[2]/rho + lbkappa*(drdx*drdz+dpdx*dpdz)
            + lambda*(p[0]*drdz+p[2]*drdx)*rrho;                                               // off-diagonal (zx) stress tensor
    meq[16] = 0.0;                                                                             // symmetric (x) third-order moment
    meq[17] = 0.0;                                                                             // symmetric (y) third-order moment
    meq[18] = 0.0;                                                                             // symmetric (z) third-order moment
  }
  else if(lbdm.rank ==0) {
    cout << "the multiple-relaxation-time scheme for D" << lbsy.nd << "Q" << lbsy.nq << " model has not been defined" << endl;
    if(lbsy.nd == 2)
      cout << "the D2Q9 model can be used" << endl;
    else
      cout << "the D3Q15 or D3Q19 models can be used" << endl;
    exit(1);
  }
  v[0] = p[0]*rrho; v[1] = p[1]*rrho; v[2] = p[2]*rrho;
  modv = v[0]*v[0] + v[1]*v[1] + v[2]*v[2];
  for(int i=0; i<lbsy.nq; i++) {
    uv = lbvx[i] * v[0] + lbvy[i] * v[1] + lbvz[i] * v[2];
    meq[lbsy.nq+i] = lbfemob * mu * lbwpt[i] + lbw0[i] * phi + lbw[i] * phi * (uv + 1.5 * uv * uv - 0.5 * modv);
  }
  return 0;
}


int fGetMomentForce(double *source, double *v, double *force)
{

  // calculate forcing terms in terms of moments for MRT collision schemes
  // (Premnath and Abraham, 2007)

  const double c1 = -7.0/3.0;
  const double c2 = -2.0/3.0;
    
  if(lbsy.nq == 9) {
    // D2Q9
    source[0] = 0.0;
    source[1] = 6.0 * (v[0] * force[0] + v[1] * force[1]);
    source[2] = -6.0 * (v[0] * force[0] + v[1] * force[1]);
    source[3] = force[0];
    source[4] = -force[0];
    source[5] = force[1];
    source[6] = -force[1];
    source[7] = 2.0 * (v[0] * force[0] - v[1] * force[1]);
    source[8] = v[0] * force[1] + v[1] * force[0];
  }
  else if(lbsy.nq == 15) {
    // D3Q15
    source[0]  = 0.0;
    source[1]  = 2.0 * (v[0] * force[0] + v[1] * force[1] + v[2] * force[2]);
    source[2]  = -10.0 * (v[0] * force[0] + v[1] * force[1] + v[2] * force[2]);
    source[3]  = force[0];
    source[4]  = c1 * force[0];
    source[5]  = force[1];
    source[6]  = c1 * force[1];
    source[7]  = force[2];
    source[8]  = c1 * force[2];
    source[9]  = 2.0 * (2.0 * v[0] * force[0] - v[1] * force[1] - v[2] * force[2]);
    source[10] = 2.0 * (v[1] * force[1] - v[2] * force[2]);
    source[11] = v[0] * force[1] + v[1] * force[0];
    source[12] = v[1] * force[2] + v[2] * force[1];
    source[13] = v[0] * force[2] + v[2] * force[0];
    source[14] = 0.0;
  }
  else if(lbsy.nq == 19) {
    // D3Q19
    source[0]  = 0.0;
    source[1]  = 38.0 * (v[0] * force[0] + v[1] * force[1] + v[2] * force[2]);
    source[2]  = -11.0 * (v[0] * force[0] + v[1] * force[1] + v[2] * force[2]);
    source[3]  = force[0];
    source[4]  = c2 * force[0];
    source[5]  = force[1];
    source[6]  = c2 * force[1];
    source[7]  = force[2];
    source[8]  = c2 * force[2];
    source[9]  = 2.0 * (2.0 * v[0] * force[0] - v[1] * force[1] - v[2] * force[2]);
    source[10] = -(2.0 * v[0] * force[0] - v[1] * force[1] - v[2] * force[2]);
    source[11] = 2.0 * (v[1] * force[1] - v[2] * force[2]);
    source[12] = -(v[1] * force[1] - v[2] * force[2]);
    source[13] = v[0] * force[1] + v[1] * force[0];
    source[14] = v[1] * force[2] + v[2] * force[1];
    source[15] = v[0] * force[2] + v[2] * force[0];
    source[16] = 0.0;
    source[17] = 0.0;
    source[18] = 0.0;
  }
  else if(lbdm.rank ==0) {
    cout << "the multiple-relaxation-time scheme for D" << lbsy.nd << "Q" << lbsy.nq << " model has not been defined" << endl;
    if(lbsy.nd == 2)
      cout << "the D2Q9 model can be used" << endl;
    else
      cout << "the D3Q15 or D3Q19 models can be used" << endl;
    exit(1);
  }  
  return 0;
}


int fGetMRTCollide(double *collide, double omegashear, double omegabulk)
{

  // calculate collision parameters for MRT collision schemes:
  // tuneable parameters (lbmrts) can be modified by user if required

  if(lbsy.nq == 9) {
    // D2Q9
    collide[0] = 1.0;         // fixed parameter for conserved moment (density)
    collide[1] = omegabulk;
    collide[2] = lbmrts[0];
    collide[3] = 1.0;         // fixed parameter for conserved moment (x-momentum)
    collide[4] = lbmrts[1];
    collide[5] = 1.0;         // fixed parameter for conserved moment (y-momentum)
    collide[6] = lbmrts[1];
    collide[7] = omegashear;
    collide[8] = omegashear;
  }
  else if(lbsy.nq == 15) {
    // D3Q15
    collide[0]  = 1.0;        // fixed parameter for conserved moment (density)
    collide[1]  = omegabulk;
    collide[2]  = lbmrts[0];
    collide[3]  = 1.0;        // fixed parameter for conserved moment (x-momentum)
    collide[4]  = lbmrts[1];
    collide[5]  = 1.0;        // fixed parameter for conserved moment (y-momentum)
    collide[6]  = lbmrts[1];
    collide[7]  = 1.0;        // fixed parameter for conserved moment (z-momentum)
    collide[8]  = lbmrts[1];
    collide[9]  = omegashear;
    collide[10] = omegashear;
    collide[11] = omegashear;
    collide[12] = omegashear;
    collide[13] = omegashear;
    collide[14] = lbmrts[2];
  }
  else if(lbsy.nq == 19) {
    // D3Q19
    collide[0]  = 1.0;        // fixed parameter for conserved moment (density)
    collide[1]  = omegabulk;
    collide[2]  = lbmrts[0];
    collide[3]  = 1.0;        // fixed parameter for conserved moment (x-momentum)
    collide[4]  = lbmrts[1];
    collide[5]  = 1.0;        // fixed parameter for conserved moment (y-momentum)
    collide[6]  = lbmrts[1];
    collide[7]  = 1.0;        // fixed parameter for conserved moment (z-momentum)
    collide[8]  = lbmrts[1];
    collide[9]  = omegashear;
    collide[10] = lbmrts[0];
    collide[11] = omegashear;
    collide[12] = lbmrts[0];
    collide[13] = omegashear;
    collide[14] = omegashear;
    collide[15] = omegashear;
    collide[16] = lbmrts[2];
    collide[17] = lbmrts[2];
    collide[18] = lbmrts[2];
  }
  else if(lbdm.rank ==0) {
    cout << "the multiple-relaxation-time scheme for D" << lbsy.nd << "Q" << lbsy.nq << " model has not been defined" << endl;
    if(lbsy.nd == 2)
      cout << "the D2Q9 model can be used" << endl;
    else
      cout << "the D3Q15 or D3Q19 models can be used" << endl;
    exit(1);
  }  
  return 0;
}

// Standard fluid collisions

int fSiteFluidCollisionMRT(double* startpos, double *sitespeed, double* bodyforce)
{
  
  // calculate fluid collisions at grid point: uses MRT schemes

  double speed[3], meq[lbsy.nq], rho[lbsy.nf];
  double moment[lbsy.nq], collide[lbsy.nq];
  double relax;
  double *pt2 = &startpos[0];
  double *pt3 = &bodyforce[0];
  int qdim = lbsy.nf+lbsy.nc+lbsy.nt;

  fGetAllMassSite(rho, pt2);
    
  // collision of fluids

  for(int k=0; k<lbsy.nf; k++) {
    relax = fReciprocal(lbtf[k]);
    speed[0] = rho[k] * sitespeed[0] + pt3[3*k]   * relax;
    speed[1] = rho[k] * sitespeed[1] + pt3[3*k+1] * relax;
    speed[2] = rho[k] * sitespeed[2] + pt3[3*k+2] * relax;
    fGetMomentEquilibriumF(&meq[0], speed, rho[k]);
    fGetMRTCollide(collide, lbtf[k], lbtfbulk[k]);
    for(int i=0; i<lbsy.nq; i++) {
      moment[i] = 0;
      for(int j=0; j<lbsy.nq; j++) {
        moment[i] += pt2[j*qdim+k] * lbtr[i*lbsy.nq+j];
      }
      moment[i] = collide[i] * (meq[i] - moment[i]);
    }
    for(int i=0; i<lbsy.nq; i++) {
      for(int j=0; j<lbsy.nq; j++) {
        pt2[i*qdim+k] = pt2[i*qdim+k] + moment[j] * lbtrinv[i*lbsy.nq+j];
      }
    }
  }

  pt2 = NULL;
  pt3 = NULL;  
  return 0;
}

int fSiteFluidIncomCollisionMRT(double* startpos, double *sitespeed, double* bodyforce)
{
  
  // calculate fluid collisions at grid point: uses MRT schemes for incompressible fluids

  double speed[3], meq[lbsy.nq], rho[lbsy.nf];
  double moment[lbsy.nq], collide[lbsy.nq];
  double density, relax;
  double *pt2 = &startpos[0];
  double *pt3 = &bodyforce[0];
  int qdim = lbsy.nf+lbsy.nc+lbsy.nt;

  fGetAllMassSite(rho, pt2);
    
  for(int k=0; k<lbsy.nf; k++) {
    density = lbincp[k];
    relax = fReciprocal(lbtf[k]);
    speed[0] = density * sitespeed[0] + pt3[3*k]   * relax;
    speed[1] = density * sitespeed[1] + pt3[3*k+1] * relax;
    speed[2] = density * sitespeed[2] + pt3[3*k+2] * relax;
    fGetMomentEquilibriumFIncom(&meq[0], speed, rho[k], density);
    fGetMRTCollide(collide, lbtf[k], lbtfbulk[k]);
    for(int i=0; i<lbsy.nq; i++) {
      moment[i] = 0;
      for(int j=0; j<lbsy.nq; j++) {
        moment[i] += pt2[j*qdim+k] * lbtr[i*lbsy.nq+j];
      }
      moment[i] = collide[i] * (meq[i] - moment[i]);
    }
    for(int i=0; i<lbsy.nq; i++) {
      for(int j=0; j<lbsy.nq; j++) {
        pt2[i*qdim+k] = pt2[i*qdim+k] + moment[j] * lbtrinv[i*lbsy.nq+j];
      }
    }
  }

  pt2 = NULL;
  pt3 = NULL;  
  return 0;
}

int fSiteFluidCollisionMRTEDM(double* startpos, double *sitespeed, double* bodyforce)
{
  
  // calculate fluid collisions at grid point: uses MRT schemes with
  // Exact Difference Method forcing term

  double dv[3], meq[lbsy.nq], moment[lbsy.nq], collide[lbsy.nq], rho[lbsy.nf];
  double invmass, source;
  double modv,eixux,eiyuy,eizuz,eixdux,eiyduy,eizduz;
  double *pt2 = &startpos[0];
  double *pt3 = &bodyforce[0];
  int qdim = lbsy.nf+lbsy.nc+lbsy.nt;

  fGetAllMassSite(rho, pt2);

  // collision of fluids

  for(int k=0; k<lbsy.nf; k++) {
    invmass = fReciprocal(rho[k]);
    dv[0] = pt3[3*k]   * invmass;
    dv[1] = pt3[3*k+1] * invmass;
    dv[2] = pt3[3*k+2] * invmass;
    fGetMomentEquilibriumF(&meq[0], sitespeed, rho[k]);
    fGetMRTCollide(collide, lbtf[k], lbtfbulk[k]);
    modv = dv[0]*(2.0*sitespeed[0]+dv[0]) + dv[1]*(2.0*sitespeed[1]+dv[1]) + dv[2]*(2.0*sitespeed[2]+dv[2]);
    for(int i=0; i<lbsy.nq; i++) {
      moment[i] = 0;
      for(int j=0; j<lbsy.nq; j++) {
        moment[i] += pt2[j*qdim+k] * lbtr[i*lbsy.nq+j];
      }
      moment[i] = collide[i] * (meq[i] - moment[i]);
    }
    for(int i=0; i<lbsy.nq; i++) {
      eixux =  lbvx[i]*sitespeed[0];
      eiyuy =  lbvy[i]*sitespeed[1];
      eizuz =  lbvz[i]*sitespeed[2];
      eixdux = lbvx[i]*dv[0];
      eiyduy = lbvy[i]*dv[1];
      eizduz = lbvz[i]*dv[2];
      source = rho[k] * lbw[i] * (3.0 * (eixdux+eiyduy+eizduz) +
                                  4.5 * (eixdux*(eixdux+2.0*(eixux+eiyuy+eizuz+eiyduy+eizduz)) +
                                         eiyduy*(eiyduy+2.0*(eixux+eiyuy+eizuz+eizduz)) +
                                         eizduz*(eizduz+2.0*(eixux+eiyuy+eizuz))) -
                                  1.5 * modv);
      for(int j=0; j<lbsy.nq; j++) {
        pt2[i*qdim+k] = pt2[i*qdim+k] + moment[j] * lbtrinv[i*lbsy.nq+j];
      }
      pt2[i*qdim+k] = pt2[i*qdim+k] + source;
    }
  }

  pt2 = NULL;
  pt3 = NULL;  
  return 0;
}

int fSiteFluidIncomCollisionMRTEDM(double* startpos, double *sitespeed, double* bodyforce)
{
  
  // calculate fluid collisions at grid point: uses MRT schemes
  // for incompressible fluids with Exact Difference Method forcing term

  double dv[3], meq[lbsy.nq], moment[lbsy.nq], collide[lbsy.nq], rho[lbsy.nf];
  double density, invmass, source;
  double modv,eixux,eiyuy,eizuz,eixdux,eiyduy,eizduz;
  double *pt2 = &startpos[0];
  double *pt3 = &bodyforce[0];
  int qdim = lbsy.nf+lbsy.nc+lbsy.nt;

  fGetAllMassSite(rho, pt2);
    
  for(int k=0; k<lbsy.nf; k++) {
    density = lbincp[k];
    invmass = fReciprocal(density);
    dv[0] = pt3[3*k]   * invmass;
    dv[1] = pt3[3*k+1] * invmass;
    dv[2] = pt3[3*k+2] * invmass;
    fGetMomentEquilibriumFIncom(&meq[0], sitespeed, rho[k], density);
    fGetMRTCollide(collide, lbtf[k], lbtfbulk[k]);
    modv = dv[0]*(2.0*sitespeed[0]+dv[0]) + dv[1]*(2.0*sitespeed[1]+dv[1]) + dv[2]*(2.0*sitespeed[2]+dv[2]);
    for(int i=0; i<lbsy.nq; i++) {
      moment[i] = 0;
      for(int j=0; j<lbsy.nq; j++) {
        moment[i] += pt2[j*qdim+k] * lbtr[i*lbsy.nq+j];
      }
      moment[i] = collide[i] * (meq[i] - moment[i]);
    }
    for(int i=0; i<lbsy.nq; i++) {
      eixux =  lbvx[i]*sitespeed[0];
      eiyuy =  lbvy[i]*sitespeed[1];
      eizuz =  lbvz[i]*sitespeed[2];
      eixdux = lbvx[i]*dv[0];
      eiyduy = lbvy[i]*dv[1];
      eizduz = lbvz[i]*dv[2];
      source = density * lbw[i] * (3.0 * (eixdux+eiyduy+eizduz) +
                                   4.5 * (eixdux*(eixdux+2.0*(eixux+eiyuy+eizuz+eiyduy+eizduz)) +
                                          eiyduy*(eiyduy+2.0*(eixux+eiyuy+eizuz+eizduz)) +
                                          eizduz*(eizduz+2.0*(eixux+eiyuy+eizuz))) -
                                   1.5 * modv);
      for(int j=0; j<lbsy.nq; j++) {
        pt2[i*qdim+k] = pt2[i*qdim+k] + moment[j] * lbtrinv[i*lbsy.nq+j];
      }
      pt2[i*qdim+k] = pt2[i*qdim+k] + source;
    }
  }

  pt2 = NULL;
  pt3 = NULL;  
  return 0;
}

int fSiteFluidCollisionMRTGuo(double* startpos, double *sitespeed, double* bodyforce)
{
  
  // calculate collisions at grid point: uses MRT schemes with Guo-like source terms
  // for fluids only (BGK collisions used for solutes and heat transfers)

  double speed[3], force[3], meq[lbsy.nq], rho[lbsy.nf];
  double moment[lbsy.nq], collide[lbsy.nq], source[lbsy.nq];
  double invmass;
  double *pt2 = &startpos[0];
  double *pt3 = &bodyforce[0];
  int qdim = lbsy.nf+lbsy.nc+lbsy.nt;

  fGetAllMassSite(rho, pt2);

  // collision of fluids

  for(int k=0; k<lbsy.nf; k++) {
    invmass = fReciprocal(rho[k]);
    force[0] = pt3[3*k];
    force[1] = pt3[3*k+1];
    force[2] = pt3[3*k+2];
    speed[0] = rho[k] * sitespeed[0] + 0.5 * force[0];
    speed[1] = rho[k] * sitespeed[1] + 0.5 * force[1];
    speed[2] = rho[k] * sitespeed[2] + 0.5 * force[2];
    fGetMomentEquilibriumF(&meq[0], speed, rho[k]);
    speed[0] *= invmass;
    speed[1] *= invmass;
    speed[2] *= invmass;
    fGetMomentForce(source, speed, force);
    fGetMRTCollide(collide, lbtf[k], lbtfbulk[k]);
    for(int i=0; i<lbsy.nq; i++) {
      moment[i] = 0;
      for(int j=0; j<lbsy.nq; j++) {
        moment[i] += pt2[j*qdim+k] * lbtr[i*lbsy.nq+j];
      }
      moment[i] = collide[i] * (meq[i] - moment[i]) + (1.0 - 0.5 * collide[i]) * source[i];
    }
    for(int i=0; i<lbsy.nq; i++) {
      for(int j=0; j<lbsy.nq; j++) {
        pt2[i*qdim+k] = pt2[i*qdim+k] + moment[j] * lbtrinv[i*lbsy.nq+j];
      }
    }
  }

  pt2 = NULL;
  pt3 = NULL;  
  return 0;
}

int fSiteFluidIncomCollisionMRTGuo(double* startpos, double *sitespeed, double* bodyforce)
{
  
  // calculate collisions at grid point: uses MRT schemes with Guo-like source terms
  // for incompressible fluids only (BGK collisions used for solutes and heat transfers)

  double speed[3], force[3], meq[lbsy.nq], rho[lbsy.nf];
  double moment[lbsy.nq], collide[lbsy.nq], source[lbsy.nq];
  double density, invdensity;
  double *pt2 = &startpos[0];
  double *pt3 = &bodyforce[0];
  int qdim = lbsy.nf+lbsy.nc+lbsy.nt;

  fGetAllMassSite(rho, pt2);

  // collision of fluids

  for(int k=0; k<lbsy.nf; k++) {
    density = lbincp[k];
    invdensity = fReciprocal(density);
    force[0] = pt3[3*k];
    force[1] = pt3[3*k+1];
    force[2] = pt3[3*k+2];
    speed[0] = density * sitespeed[0] + 0.5 * force[0];
    speed[1] = density * sitespeed[1] + 0.5 * force[1];
    speed[2] = density * sitespeed[2] + 0.5 * force[2];
    fGetMomentEquilibriumFIncom(&meq[0], speed, rho[k], density);
    speed[0] *= invdensity;
    speed[1] *= invdensity;
    speed[2] *= invdensity;
    fGetMomentForce(source, speed, force);
    fGetMRTCollide(collide, lbtf[k], lbtfbulk[k]);
    for(int i=0; i<lbsy.nq; i++) {
      moment[i] = 0;
      for(int j=0; j<lbsy.nq; j++) {
        moment[i] += pt2[j*qdim+k] * lbtr[i*lbsy.nq+j];
      }
      moment[i] = collide[i] * (meq[i] - moment[i]) + (1.0 - 0.5 * collide[i]) * source[i];
    }
    for(int i=0; i<lbsy.nq; i++) {
      for(int j=0; j<lbsy.nq; j++) {
        pt2[i*qdim+k] = pt2[i*qdim+k] + moment[j] * lbtrinv[i*lbsy.nq+j];
      }
    }
  }

  pt2 = NULL;
  pt3 = NULL;  
  return 0;
}

// Achromatic fluid collisions with pre-calculated interfacial forces and phase segregation

int fSiteFluidCollisionMRTLishchuk(double* startpos, double *sitespeed, double* bodyforce, double* phaseindex)
{

  // MRT collision of achromatic fluid and D'Ortona segregation
  // calculate fluid collisions at grid point: using MRT schemes

  double speed[3], meq[lbsy.nq];
  double allmass, invallmass, omega, omegabulk, relax, nx, ny, nz, segcomp, segpiece;
  double rho[lbsy.nf], seg[lbsy.nf*lbsy.nq], lbfac[lbsy.nq], moment[lbsy.nq], collide[lbsy.nq];
  double *pt2 = &startpos[0];
  double *pt3 = &bodyforce[0];
  double *pt4 = &phaseindex[0];
  int numpair = lbsy.nf*(lbsy.nf-1)/2;
  int qdim = lbsy.nf+lbsy.nc+lbsy.nt;

  // collision of achromatic fluid

  fGetAllMassSite(rho, pt2);
  allmass = 0.0;
  omega = 0.0;
  omegabulk = 0.0;

  for(int j=0; j<lbsy.nf; j++) {
    allmass += rho[j];
    omega += lbtf[j] * rho[j];
    omegabulk += lbtfbulk[j] * rho[j];
  }

  invallmass = fReciprocal(allmass);
  omega *= invallmass;
  omegabulk *= invallmass;

  for(int i=0; i<lbsy.nq; i++) {
    lbfac[i] = 0.0;
    for(int j=0; j<lbsy.nf; i++) {
      lbfac[i] += pt2[i*qdim+j];
      seg[i*lbsy.nf+j] = 0.0;
    }
  }

  invallmass = fReciprocal(allmass);
    
  relax = fReciprocal(omega);
  speed[0] = allmass * sitespeed[0] + pt3[0] * relax;
  speed[1] = allmass * sitespeed[1] + pt3[1] * relax;
  speed[2] = allmass * sitespeed[2] + pt3[2] * relax;

  fGetMomentEquilibriumF(&meq[0], speed, allmass);
  fGetMRTCollide(collide, omega, omegabulk);
  for(int i=0; i<lbsy.nq; i++) {
    moment[i] = 0;
    for(int j=0; j<lbsy.nq; j++) {
      moment[i] += lbfac[j] * lbtr[i*lbsy.nq+j];
    }
    moment[i] = collide[i] * (meq[i] - moment[i]);
  }
  for(int i=0; i<lbsy.nq; i++) {
    for(int j=0; j<lbsy.nq; j++) {
      lbfac[i] = lbfac[i] + moment[j] * lbtrinv[i*lbsy.nq+j];
    }
  }

  // segregation of fluids

  for(int k=0; k<numpair; k++) {
    int i = lbspair[2*k  ];
    int j = lbspair[2*k+1];
    nx = pt4[3*k  ];
    ny = pt4[3*k+1];
    nz = pt4[3*k+2];
    segpiece = lbseg[lbsy.nf*j+i] * rho[i] * rho[j] * invallmass * invallmass;
    for(int m=0; m<lbsy.nq; m++) {
      segcomp = segpiece * (lbvwx[m]*nx + lbvwy[m]*ny + lbvwz[m]*nz);
      seg[m*lbsy.nf+i] += segcomp;
      seg[m*lbsy.nf+j] -= segcomp;
    }
  }

  for(int m=0; m<lbsy.nq; m++) {
    for(int i=0; i<lbsy.nf; i++) {
      pt2[m*qdim+i] = rho[i] * lbfac[m] * invallmass + seg[m*lbsy.nf+i];
    }
  }

  pt2 = NULL;
  pt3 = NULL;  
  pt4 = NULL;  
  return 0;
}

int fSiteFluidIncomCollisionMRTLishchuk(double* startpos, double *sitespeed, double* bodyforce, double* phaseindex)
{

  // MRT collision of achromatic fluid and D'Ortona segregation
  // calculate collisions at grid point: using MRT schemes for incompressible fluids

  double speed[3], meq[lbsy.nq];
  double density, allmass, invallmass, omega, omegabulk, relax, nx, ny, nz, segcomp, segpiece;
  double rho[lbsy.nf], seg[lbsy.nf*lbsy.nq], lbfac[lbsy.nq], moment[lbsy.nq], collide[lbsy.nq];
  double *pt2 = &startpos[0];
  double *pt3 = &bodyforce[0];
  double *pt4 = &phaseindex[0];
  int numpair = lbsy.nf*(lbsy.nf-1)/2;
  int qdim = lbsy.nf+lbsy.nc+lbsy.nt;

  // collision of achromatic fluid

  fGetAllMassSite(rho, pt2);
  allmass = 0.0;
  omega = 0.0;
  omegabulk = 0.0;
  density = 0.0;

  for(int j=0; j<lbsy.nf; j++) {
    allmass += rho[j];
    omega += lbtf[j] * rho[j];
    omegabulk += lbtfbulk[j] * rho[j];
    density += lbincp[j] * rho[j];
  }

  invallmass = fReciprocal(allmass);
  omega *= invallmass;
  omegabulk *= invallmass;
  density *= invallmass;
    
  for(int i=0; i<lbsy.nq; i++) {
    lbfac[i] = 0.0;
    for(int j=0; j<lbsy.nf; j++) {
      lbfac[i] += pt2[i*qdim+j];
      seg[i*lbsy.nf+j] = 0.0;
    }
  }

  relax = fReciprocal(omega);
  speed[0] = density * sitespeed[0] + pt3[0] * relax;
  speed[1] = density * sitespeed[1] + pt3[1] * relax;
  speed[2] = density * sitespeed[2] + pt3[2] * relax;

  fGetMomentEquilibriumFIncom(&meq[0], speed, allmass, density);
  fGetMRTCollide(collide, omega, omegabulk);
  for(int i=0; i<lbsy.nq; i++) {
    moment[i] = 0;
    for(int j=0; j<lbsy.nq; j++) {
      moment[i] += lbfac[j] * lbtr[i*lbsy.nq+j];
    }
    moment[i] = collide[i] * (lbfeq[i] - moment[i]);
  }
  for(int i=0; i<lbsy.nq; i++) {
    for(int j=0; j<lbsy.nq; j++) {
      lbfac[i] = lbfac[i] + moment[j] * lbtrinv[i*lbsy.nq+j];
    }
  }

  // segregation of fluids

  for(int k=0; k<numpair; k++) {
    int i = lbspair[2*k  ];
    int j = lbspair[2*k+1];
    nx = pt4[3*k  ];
    ny = pt4[3*k+1];
    nz = pt4[3*k+2];
    segpiece = lbseg[lbsy.nf*j+i] * rho[i] * rho[j] * invallmass * invallmass;
    for(int m=0; m<lbsy.nq; m++) {
      segcomp = segpiece * (lbvwx[m]*nx + lbvwy[m]*ny + lbvwz[m]*nz);
      seg[m*lbsy.nf+i] += segcomp;
      seg[m*lbsy.nf+j] -= segcomp;
    }
  }

  for(int m=0; m<lbsy.nq; m++) {
    for(int i=0; i<lbsy.nf; i++) {
      pt2[m*qdim+i] = rho[i] * lbfac[m] * invallmass + seg[m*lbsy.nf+i];
    }
  }

  pt2 = NULL;
  pt3 = NULL;  
  pt4 = NULL;  
  return 0;
}

int fSiteFluidCollisionMRTEDMLishchuk(double* startpos, double *sitespeed, double* bodyforce, double* phaseindex)
{

  // MRT collision of achromatic fluid and D'Ortona segregation
  // calculate fluid collisions at grid point: using MRT schemes
  // with Exact Difference Method forcing term

  double dv[3], meq[lbsy.nq];
  double allmass, invallmass, omega, omegabulk, relax, nx, ny, nz, segcomp, segpiece, source;
  double modv,eixux,eiyuy,eizuz,eixdux,eiyduy,eizduz;
  double rho[lbsy.nf], seg[lbsy.nf*lbsy.nq], lbfac[lbsy.nq], moment[lbsy.nq], collide[lbsy.nq];
  double *pt2 = &startpos[0];
  double *pt3 = &bodyforce[0];
  double *pt4 = &phaseindex[0];
  int numpair = lbsy.nf*(lbsy.nf-1)/2;
  int qdim = lbsy.nf+lbsy.nc+lbsy.nt;

  // collision of achromatic fluid

  fGetAllMassSite(rho, pt2);
  allmass = 0.0;
  omega = 0.0;
  omegabulk = 0.0;

  for(int j=0; j<lbsy.nf; j++) {
    allmass += rho[j];
    omega += lbtf[j] * rho[j] * invallmass;
    omegabulk += lbtfbulk[j] * rho[j] * invallmass;
  }
    
  invallmass = fReciprocal(allmass);
  omega *= invallmass;
  omegabulk *= invallmass;
    
  for(int i=0; i<lbsy.nq; i++) {
    lbfac[i] = 0.0;
    for(int j=0; j<lbsy.nf; j++) {
      lbfac[i] += pt2[i*qdim+j];
      seg[i*lbsy.nf+j] = 0.0;
    }
  }

  dv[0] = pt3[0] * invallmass;
  dv[1] = pt3[1] * invallmass;
  dv[2] = pt3[2] * invallmass;

  fGetMomentEquilibriumF(&meq[0], sitespeed, allmass);
  fGetMRTCollide(collide, omega, omegabulk);
  modv = dv[0]*(2.0*sitespeed[0]+dv[0]) + dv[1]*(2.0*sitespeed[1]+dv[1]) + dv[2]*(2.0*sitespeed[2]+dv[2]);
  for(int i=0; i<lbsy.nq; i++) {
    moment[i] = 0;
    for(int j=0; j<lbsy.nq; j++) {
      moment[i] += lbfac[j] * lbtr[i*lbsy.nq+j];
    }
    moment[i] = collide[i] * (meq[i] - moment[i]);
  }
  for(int i=0; i<lbsy.nq; i++) {
    eixux =  lbvx[i]*sitespeed[0];
    eiyuy =  lbvy[i]*sitespeed[1];
    eizuz =  lbvz[i]*sitespeed[2];
    eixdux = lbvx[i]*dv[0];
    eiyduy = lbvy[i]*dv[1];
    eizduz = lbvz[i]*dv[2];
    source = allmass * lbw[i] * (3.0 * (eixdux+eiyduy+eizduz) +
                                 4.5 * (eixdux*(eixdux+2.0*(eixux+eiyuy+eizuz+eiyduy+eizduz)) +
                                        eiyduy*(eiyduy+2.0*(eixux+eiyuy+eizuz+eizduz)) +
                                        eizduz*(eizduz+2.0*(eixux+eiyuy+eizuz))) -
                                 1.5 * modv);
    for(int j=0; j<lbsy.nq; j++) {
      lbfac[i] = lbfac[i] + moment[j] * lbtrinv[i*lbsy.nq+j];
    }
    lbfac[i] = lbfac[i] + source;
  }

  // segregation of fluids

  for(int k=0; k<numpair; k++) {
    int i = lbspair[2*k  ];
    int j = lbspair[2*k+1];
    nx = pt4[3*k  ];
    ny = pt4[3*k+1];
    nz = pt4[3*k+2];
    segpiece = lbseg[lbsy.nf*j+i] * rho[i] * rho[j] * invallmass * invallmass;
    for(int m=0; m<lbsy.nq; m++) {
      segcomp = segpiece * (lbvwx[m]*nx + lbvwy[m]*ny + lbvwz[m]*nz);
      seg[m*lbsy.nf+i] += segcomp;
      seg[m*lbsy.nf+j] -= segcomp;
    }
  }

  for(int m=0; m<lbsy.nq; m++) {
    for(int i=0; i<lbsy.nf; i++) {
      pt2[m*qdim+i] = rho[i] * lbfac[m] * invallmass + seg[m*lbsy.nf+i];
    }
  }

  pt2 = NULL;
  pt3 = NULL;  
  pt4 = NULL;  
  return 0;
}

int fSiteFluidIncomCollisionMRTEDMLishchuk(double* startpos, double *sitespeed, double* bodyforce, double* phaseindex)
{

  // MRT collision of achromatic fluid and D'Ortona segregation
  // calculate collisions at grid point: using MRT schemes
  // for incompressible fluids with Exact Difference Method forcing term

  double dv[3], meq[lbsy.nq];
  double density, allmass, invallmass, invmass, omega, omegabulk, nx, ny, nz, segcomp, segpiece, source;
  double modv,eixux,eiyuy,eizuz,eixdux,eiyduy,eizduz;
  double rho[lbsy.nf], seg[lbsy.nf*lbsy.nq], lbfac[lbsy.nq], moment[lbsy.nq], collide[lbsy.nq];
  double *pt2 = &startpos[0];
  double *pt3 = &bodyforce[0];
  double *pt4 = &phaseindex[0];
  int numpair = lbsy.nf*(lbsy.nf-1)/2;
  int qdim = lbsy.nf+lbsy.nc+lbsy.nt;

  // collision of achromatic fluid

  fGetAllMassSite(rho, pt2);
  allmass = 0.0;
  omega = 0.0;
  omegabulk = 0.0;
  density = 0.0;

  for(int j=0; j<lbsy.nf; j++) {
    allmass += rho[j];
    omega += lbtf[j] * rho[j];
    omegabulk += lbtfbulk[j] * rho[j];
    density += lbincp[j] * rho[j];
  }
    
  invallmass = fReciprocal(allmass);
  omega *= invallmass;
  omegabulk *= invallmass;
  density *= invallmass;
    
  for(int i=0; i<lbsy.nq; i++) {
    lbfac[i] = 0.0;
    for(int j=0; j<lbsy.nf; j++) {
      lbfac[i] += pt2[i*qdim+j];
      seg[i*lbsy.nf+j] = 0.0;
    }
  }

  invmass = fReciprocal(density);
  dv[0] = pt3[0] * invmass;
  dv[1] = pt3[1] * invmass;
  dv[2] = pt3[2] * invmass;

  fGetMomentEquilibriumFIncom(&meq[0], sitespeed, allmass, density);
  fGetMRTCollide(collide, omega, omegabulk);
  modv = dv[0]*(2.0*sitespeed[0]+dv[0]) + dv[1]*(2.0*sitespeed[1]+dv[1]) + dv[2]*(2.0*sitespeed[2]+dv[2]);
  for(int i=0; i<lbsy.nq; i++) {
    moment[i] = 0;
    for(int j=0; j<lbsy.nq; j++) {
      moment[i] += lbfac[j] * lbtr[i*lbsy.nq+j];
    }
    moment[i] = collide[i] * (lbfeq[i] - moment[i]);
  }
  for(int i=0; i<lbsy.nq; i++) {
    eixux =  lbvx[i]*sitespeed[0];
    eiyuy =  lbvy[i]*sitespeed[1];
    eizuz =  lbvz[i]*sitespeed[2];
    eixdux = lbvx[i]*dv[0];
    eiyduy = lbvy[i]*dv[1];
    eizduz = lbvz[i]*dv[2];
    source = density * lbw[i] * (3.0 * (eixdux+eiyduy+eizduz) +
                                 4.5 * (eixdux*(eixdux+2.0*(eixux+eiyuy+eizuz+eiyduy+eizduz)) +
                                        eiyduy*(eiyduy+2.0*(eixux+eiyuy+eizuz+eizduz)) +
                                        eizduz*(eizduz+2.0*(eixux+eiyuy+eizuz))) -
                                 1.5 * modv);
    for(int j=0; j<lbsy.nq; j++) {
      lbfac[i] = lbfac[i] + moment[j] * lbtrinv[i*lbsy.nq+j];
    }
    lbfac[i] = lbfac[i] + source;
  }

  // segregation of fluids

  for(int k=0; k<numpair; k++) {
    int i = lbspair[2*k  ];
    int j = lbspair[2*k+1];
    nx = pt4[3*k  ];
    ny = pt4[3*k+1];
    nz = pt4[3*k+2];
    segpiece = lbseg[lbsy.nf*j+i] * rho[i] * rho[j] * invallmass * invallmass;
    for(int m=0; m<lbsy.nq; m++) {
      segcomp = segpiece * (lbvwx[m]*nx + lbvwy[m]*ny + lbvwz[m]*nz);
      seg[m*lbsy.nf+i] += segcomp;
      seg[m*lbsy.nf+j] -= segcomp;
    }
  }

  for(int m=0; m<lbsy.nq; m++) {
    for(int i=0; i<lbsy.nf; i++) {
      pt2[m*qdim+i] = rho[i] * lbfac[m] * invallmass + seg[m*lbsy.nf+i];
    }
  }

  pt2 = NULL;
  pt3 = NULL;  
  pt4 = NULL;  
  return 0;
}

int fSiteFluidCollisionMRTGuoLishchuk(double* startpos, double *sitespeed, double* bodyforce, double* phaseindex)
{

  // MRT collision of achromatic fluid and D'Ortona segregation
  // calculate collisions at grid point: using MRT schemes with 
  // Guo-like source terms for fluids only (BGK collisions used
  // for solutes and heat transfers)

  double speed[3], force[3], meq[lbsy.nq];
  double allmass, invallmass, omega, omegabulk, nx, ny, nz, segcomp, segpiece;
  double rho[lbsy.nf], seg[lbsy.nf*lbsy.nq], lbfac[lbsy.nq], moment[lbsy.nq], collide[lbsy.nq], source[lbsy.nq];
  double *pt2 = &startpos[0];
  double *pt3 = &bodyforce[0];
  double *pt4 = &phaseindex[0];
  int numpair = lbsy.nf*(lbsy.nf-1)/2;
  int qdim = lbsy.nf+lbsy.nc+lbsy.nt;

  // collision of achromatic fluid

  fGetAllMassSite(rho, pt2);
  allmass = 0.0;
  omega = 0.0;
  omegabulk = 0.0;

  for(int j=0; j<lbsy.nf; j++) {
    allmass += rho[j];
    omega += lbtf[j] * rho[j];
    omegabulk += lbtfbulk[j] * rho[j];
  }
    
  invallmass = fReciprocal(allmass);
  omega *= invallmass;
  omegabulk *= invallmass;
    
  for(int i=0; i<lbsy.nq; i++) {
    lbfac[i] = 0.0;
    for(int j=0; j<lbsy.nf; j++) {
      lbfac[i] += pt2[i*qdim+j];
      seg[i*lbsy.nf+j] = 0.0;
    }
  }

  force[0] = pt3[0];
  force[1] = pt3[1];
  force[2] = pt3[2];
  speed[0] = allmass * sitespeed[0] + 0.5 * force[0];
  speed[1] = allmass * sitespeed[1] + 0.5 * force[1];
  speed[2] = allmass * sitespeed[2] + 0.5 * force[2];

  fGetMomentEquilibriumF(&meq[0], speed, allmass);
  speed[0] *= invallmass;
  speed[1] *= invallmass;
  speed[2] *= invallmass;
  fGetMomentForce(source, speed, force);
  fGetMRTCollide(collide, omega, omegabulk);
  for(int i=0; i<lbsy.nq; i++) {
    moment[i] = 0;
    for(int j=0; j<lbsy.nq; j++) {
      moment[i] += lbfac[j] * lbtr[i*lbsy.nq+j];
    }
    moment[i] = collide[i] * (meq[i] - moment[i]) + (1.0 - 0.5 * collide[i]) * source[i];
  }
  for(int i=0; i<lbsy.nq; i++) {
    for(int j=0; j<lbsy.nq; j++) {
      lbfac[i] = lbfac[i] + moment[j] * lbtrinv[i*lbsy.nq+j];
    }
  }

  // segregation of fluids

  for(int k=0; k<numpair; k++) {
    int i = lbspair[2*k  ];
    int j = lbspair[2*k+1];
    nx = pt4[3*k  ];
    ny = pt4[3*k+1];
    nz = pt4[3*k+2];
    segpiece = lbseg[lbsy.nf*j+i] * rho[i] * rho[j] * invallmass * invallmass;
    for(int m=0; m<lbsy.nq; m++) {
      segcomp = segpiece * (lbvwx[m]*nx + lbvwy[m]*ny + lbvwz[m]*nz);
      seg[m*lbsy.nf+i] += segcomp;
      seg[m*lbsy.nf+j] -= segcomp;
    }
  }

  for(int m=0; m<lbsy.nq; m++) {
    for(int i=0; i<lbsy.nf; i++) {
      pt2[m*qdim+i] = rho[i] * lbfac[m] * invallmass + seg[m*lbsy.nf+i];
    }
  }

  pt2 = NULL;
  pt3 = NULL;  
  pt4 = NULL;  
  return 0;
}

int fSiteFluidIncomCollisionMRTGuoLishchuk(double* startpos, double *sitespeed, double* bodyforce, double* phaseindex)
{

  // MRT collision of achromatic fluid and D'Ortona segregation
  // calculate collisions at grid point: using MRT schemes with 
  // Guo-like source terms for incompressible fluids only
  // (BGK collisions used for solutes and heat transfers)

  double speed[3], force[3], meq[lbsy.nq];
  double allmass, invallmass, density, omega, omegabulk, nx, ny, nz, segcomp, segpiece;
  double rho[lbsy.nf], seg[lbsy.nf*lbsy.nq], lbfac[lbsy.nq], moment[lbsy.nq], collide[lbsy.nq], source[lbsy.nq];
  double *pt2 = &startpos[0];
  double *pt3 = &bodyforce[0];
  double *pt4 = &phaseindex[0];
  int numpair = lbsy.nf*(lbsy.nf-1)/2;
  int qdim = lbsy.nf+lbsy.nc+lbsy.nt;

  // collision of achromatic fluid

  fGetAllMassSite(rho, pt2);
  allmass = 0.0;
  omega = 0.0;
  omegabulk = 0.0;
  density = 0.0;

  for(int j=0; j<lbsy.nf; j++) {
    allmass += rho[j];
    omega += lbtf[j] * rho[j] * invallmass;
    omegabulk += lbtfbulk[j] * rho[j] * invallmass;
    density += lbincp[j] * rho[j] * invallmass;
  }

  invallmass = fReciprocal(allmass);
  omega *= invallmass;
  omegabulk *= invallmass;
  density *= invallmass;
    
  for(int i=0; i<lbsy.nq; i++) {
    lbfac[i] = 0.0;
    for(int j=0; j<lbsy.nf; j++) {
      lbfac[i] += pt2[i*qdim+j];
      seg[i*lbsy.nf+j] = 0.0;
    }
  }

  force[0] = pt3[0];
  force[1] = pt3[1];
  force[2] = pt3[2];
  speed[0] = allmass * sitespeed[0] + 0.5 * force[0];
  speed[1] = allmass * sitespeed[1] + 0.5 * force[1];
  speed[2] = allmass * sitespeed[2] + 0.5 * force[2];

  fGetMomentEquilibriumFIncom(&meq[0], speed, allmass, density);
  speed[0] *= invallmass;
  speed[1] *= invallmass;
  speed[2] *= invallmass;
  fGetMomentForce(source, speed, force);
  fGetMRTCollide(collide, omega, omegabulk);
  for(int i=0; i<lbsy.nq; i++) {
    moment[i] = 0;
    for(int j=0; j<lbsy.nq; j++) {
      moment[i] += lbfac[j] * lbtr[i*lbsy.nq+j];
    }
    moment[i] = collide[i] * (meq[i] - moment[i]) + (1.0 - 0.5 * collide[i]) * source[i];
  }
  for(int i=0; i<lbsy.nq; i++) {
    for(int j=0; j<lbsy.nq; j++) {
      lbfac[i] = lbfac[i] + moment[j] * lbtrinv[i*lbsy.nq+j];
    }
  }

  // segregation of fluids

  for(int k=0; k<numpair; k++) {
    int i = lbspair[2*k  ];
    int j = lbspair[2*k+1];
    nx = pt4[3*k  ];
    ny = pt4[3*k+1];
    nz = pt4[3*k+2];
    segpiece = lbseg[lbsy.nf*j+i] * rho[i] * rho[j] * invallmass * invallmass;
    for(int m=0; m<lbsy.nq; m++) {
      segcomp = segpiece * (lbvwx[m]*nx + lbvwy[m]*ny + lbvwz[m]*nz);
      seg[m*lbsy.nf+i] += segcomp;
      seg[m*lbsy.nf+j] -= segcomp;
    }
  }

  for(int m=0; m<lbsy.nq; m++) {
    for(int i=0; i<lbsy.nf; i++) {
      pt2[m*qdim+i] = rho[i] * lbfac[m] * invallmass + seg[m*lbsy.nf+i];
    }
  }

  pt2 = NULL;
  pt3 = NULL;  
  pt4 = NULL;  
  return 0;
}

// Achromatic fluid collisions with local forcing terms and phase segregation

int fSiteFluidCollisionMRTLishchukLocal(double* startpos, double *sitespeed, double* bodyforce, double* phaseindex, int threed)
{

  // MRT collision of achromatic fluid and D'Ortona segregation
  // calculate interfacial forcing terms and fluid collisions at grid point:
  // using MRT schemes

  double speed[3], meq[lbsy.nq];
  double allmass, invallmass, omega, omegabulk, ex, ey, ez, nx, ny, nz;
  double forceconst, segcomp, segpiece, relax;
  double rho[lbsy.nf], seg[lbsy.nf*lbsy.nq], lbfac[lbsy.nq], moment[lbsy.nq], collide[lbsy.nq], phaseforce[lbsy.nq];
  double *pt2 = &startpos[0];
  double *pt3 = &bodyforce[0];
  double *pt4 = &phaseindex[0];
  int numpair = lbsy.nf*(lbsy.nf-1)/2;
  int qdim = lbsy.nf+lbsy.nc+lbsy.nt;

  // collision of achromatic fluid

  fGetAllMassSite(rho, pt2);
  allmass = 0.0;
  omega = 0.0;
  omegabulk = 0.0;

  for(int j=0; j<lbsy.nf; j++) {
    allmass += rho[j];
    omega += lbtf[j] * rho[j];
    omegabulk += lbtfbulk[j] * rho[j];
  }

  invallmass = fReciprocal(allmass);
  omega *= invallmass;
  omegabulk *= invallmass;
    
  for(int i=0; i<lbsy.nq; i++) {
    lbfac[i] = 0.0;
    phaseforce[i] = 0.0;
    for(int j=0; j<lbsy.nf; j++) {
      lbfac[i] += pt2[i*qdim+j];
      seg[i*lbsy.nf+j] = 0.0;
    }
  }

  // calculate local forcing terms
    
  for(int k=0; k<numpair; k++) {
    int i = lbspair[2*k  ];
    int j = lbspair[2*k+1];
    nx = pt4[3*k  ];
    ny = pt4[3*k+1];
    nz = pt4[3*k+2];
    forceconst = lbseg[lbsy.nf*j+i] * lbg[lbsy.nf*j+i] * rho[i] * rho[j];
    for(int m=0; m<lbsy.nq; m++) {
      ex = lbvx[m];
      ey = lbvy[m];
      ez = lbvz[m];
      phaseforce[m] += forceconst * ((nx*nx-1.0)*(ex*ex-lbcssq) + (ny*ny-1.0)*(ey*ey-lbcssq) + 2.0*nx*ny*ex*ey
                     + threed*((nz*nz-1.0)*(ez*ez-lbcssq) + 2.0*nz*ez*(nx*ex+ny*ey)));
    }
  }
  
  relax = fReciprocal(omega);
  speed[0] = allmass * sitespeed[0] + pt3[0] * relax;
  speed[1] = allmass * sitespeed[1] + pt3[1] * relax;
  speed[2] = allmass * sitespeed[2] + pt3[2] * relax;
  forceconst = omega * invallmass * invallmass * invallmass * lbrcssq * lbrcssq;

  fGetMomentEquilibriumF(&meq[0], speed, allmass);
  fGetMRTCollide(collide, omega, omegabulk);
  for(int i=0; i<lbsy.nq; i++) {
    moment[i] = 0;
    for(int j=0; j<lbsy.nq; j++) {
      moment[i] += lbfac[j] * lbtr[i*lbsy.nq+j];
    }
    moment[i] = collide[i] * (meq[i] - moment[i]);
  }
  for(int i=0; i<lbsy.nq; i++) {
    for(int j=0; j<lbsy.nq; j++) {
      lbfac[i] = lbfac[i] + moment[j] * lbtrinv[i*lbsy.nq+j];
    }
    lbfac[i] = lbfac[i] + lbw[i]*forceconst*phaseforce[i];
  }

  // segregation of fluids

  for(int k=0; k<numpair; k++) {
    int i = lbspair[2*k  ];
    int j = lbspair[2*k+1];
    nx = pt4[3*k  ];
    ny = pt4[3*k+1];
    nz = pt4[3*k+2];
    segpiece = lbseg[lbsy.nf*j+i] * rho[i] * rho[j] * invallmass * invallmass;
    for(int m=0; m<lbsy.nq; m++) {
      segcomp = segpiece * (lbvwx[m]*nx + lbvwy[m]*ny + lbvwz[m]*nz);
      seg[m*lbsy.nf+i] += segcomp;
      seg[m*lbsy.nf+j] -= segcomp;
    }
  }

  for(int m=0; m<lbsy.nq; m++) {
    for(int i=0; i<lbsy.nf; i++) {
      pt2[m*qdim+i] = rho[i] * lbfac[m] * invallmass + seg[m*lbsy.nf+i];
    }
  }

  pt2 = NULL;
  pt3 = NULL;  
  pt4 = NULL;  
  return 0;
}

int fSiteFluidIncomCollisionMRTLishchukLocal(double* startpos, double *sitespeed, double* bodyforce, double* phaseindex, int threed)
{

  // MRT collision of achromatic fluid and D'Ortona segregation
  // calculate interfacial forcing terms and collisions at grid point:
  // using MRT schemes for incompressible fluids

  double speed[3], meq[lbsy.nq];
  double density, allmass, invallmass, omega, omegabulk, ex, ey, ez, nx, ny, nz;
  double forceconst, relax, segcomp, segpiece;
  double rho[lbsy.nf], seg[lbsy.nf*lbsy.nq], lbfac[lbsy.nq], moment[lbsy.nq], collide[lbsy.nq], phaseforce[lbsy.nq];
  double *pt2 = &startpos[0];
  double *pt3 = &bodyforce[0];
  double *pt4 = &phaseindex[0];
  int numpair = lbsy.nf*(lbsy.nf-1)/2;
  int qdim = lbsy.nf+lbsy.nc+lbsy.nt;

  // collision of achromatic fluid

  fGetAllMassSite(rho, pt2);
  allmass = 0.0;
  omega = 0.0;
  omegabulk = 0.0;
  density = 0.0;

  for(int j=0; j<lbsy.nf; j++) {
    allmass += rho[j];
    omega += lbtf[j] * rho[j];
    omegabulk += lbtfbulk[j] * rho[j];
    density += lbincp[j] * rho[j];
  }
    
  invallmass = fReciprocal(allmass);
  omega *= invallmass;
  omegabulk *= invallmass;
  density *= invallmass;
    
  for(int i=0; i<lbsy.nq; i++) {
    lbfac[i] = 0.0;
    phaseforce[i] = 0.0;
    for(int j=0; j<lbsy.nf; j++) {
      lbfac[i] += pt2[i*qdim+j];
      seg[i*lbsy.nf+j] = 0.0;
    }
  }

  // calculate local forcing terms
    
  for(int k=0; k<numpair; k++) {
    int i = lbspair[2*k  ];
    int j = lbspair[2*k+1];
    nx = pt4[3*k  ];
    ny = pt4[3*k+1];
    nz = pt4[3*k+2];
    forceconst = lbseg[lbsy.nf*j+i] * lbg[lbsy.nf*j+i] * rho[i] * rho[j];
    for(int m=0; m<lbsy.nq; m++) {
      ex = lbvx[m];
      ey = lbvy[m];
      ez = lbvz[m];
      phaseforce[m] += forceconst * ((nx*nx-1.0)*(ex*ex-lbcssq) + (ny*ny-1.0)*(ey*ey-lbcssq) + 2.0*nx*ny*ex*ey
                     + threed*((nz*nz-1.0)*(ez*ez-lbcssq) + 2.0*nz*ez*(nx*ex+ny*ey)));
    }
  }

  relax = fReciprocal(omega);
  speed[0] = density * sitespeed[0] + pt3[0] * relax;
  speed[1] = density * sitespeed[1] + pt3[1] * relax;
  speed[2] = density * sitespeed[2] + pt3[2] * relax;
  forceconst = omega * invallmass * invallmass * lbrcssq * lbrcssq * fReciprocal(density);

  fGetMomentEquilibriumFIncom(&meq[0], speed, allmass, density);
  fGetMRTCollide(collide, omega, omegabulk);
  for(int i=0; i<lbsy.nq; i++) {
    moment[i] = 0;
    for(int j=0; j<lbsy.nq; j++) {
      moment[i] += lbfac[j] * lbtr[i*lbsy.nq+j];
    }
    moment[i] = collide[i] * (lbfeq[i] - moment[i]);
  }
  for(int i=0; i<lbsy.nq; i++) {
    for(int j=0; j<lbsy.nq; j++) {
      lbfac[i] = lbfac[i] + moment[j] * lbtrinv[i*lbsy.nq+j];
    }
    lbfac[i] = lbfac[i] + lbw[i]*forceconst*phaseforce[i];
  }

  // segregation of fluids

  for(int k=0; k<numpair; k++) {
    int i = lbspair[2*k  ];
    int j = lbspair[2*k+1];
    nx = pt4[3*k  ];
    ny = pt4[3*k+1];
    nz = pt4[3*k+2];
    segpiece = lbseg[lbsy.nf*j+i] * rho[i] * rho[j] * invallmass * invallmass;
    for(int m=0; m<lbsy.nq; m++) {
      segcomp = segpiece * (lbvwx[m]*nx + lbvwy[m]*ny + lbvwz[m]*nz);
      seg[m*lbsy.nf+i] += segcomp;
      seg[m*lbsy.nf+j] -= segcomp;
    }
  }

  for(int m=0; m<lbsy.nq; m++) {
    for(int i=0; i<lbsy.nf; i++) {
      pt2[m*qdim+i] = rho[i] * lbfac[m] * invallmass + seg[m*lbsy.nf+i];
    }
  }

  pt2 = NULL;
  pt3 = NULL;  
  pt4 = NULL;  
  return 0;
}

int fSiteFluidCollisionMRTEDMLishchukLocal(double* startpos, double *sitespeed, double* bodyforce, double* phaseindex, int threed)
{

  // MRT collision of achromatic fluid and D'Ortona segregation
  // calculate interfacial forcing terms and fluid collisions at grid point:
  // using MRT schemes with Exact Difference Method forcing term

  double dv[3], meq[lbsy.nq];
  double allmass, invallmass, omega, omegabulk, relax, ex, ey, ez, nx, ny, nz;
  double forceconst, segcomp, segpiece, source;
  double modv,eixux,eiyuy,eizuz,eixdux,eiyduy,eizduz;
  double rho[lbsy.nf], seg[lbsy.nf*lbsy.nq], lbfac[lbsy.nq], moment[lbsy.nq], collide[lbsy.nq], phaseforce[lbsy.nq];
  double *pt2 = &startpos[0];
  double *pt3 = &bodyforce[0];
  double *pt4 = &phaseindex[0];
  int numpair = lbsy.nf*(lbsy.nf-1)/2;
  int qdim = lbsy.nf+lbsy.nc+lbsy.nt;

  // collision of achromatic fluid

  fGetAllMassSite(rho, pt2);
  allmass = 0.0;
  omega = 0.0;
  omegabulk = 0.0;

  for(int j=0; j<lbsy.nf; j++) {
    allmass += rho[j];
    omega += lbtf[j] * rho[j];
    omegabulk += lbtfbulk[j] * rho[j];
  }

  invallmass = fReciprocal(allmass);
  omega *= invallmass;
  omegabulk *= invallmass;
    
  for(int i=0; i<lbsy.nq; i++) {
    lbfac[i] = 0.0;
    phaseforce[i] = 0.0;
    for(int j=0; j<lbsy.nf; j++) {
      lbfac[i] += pt2[i*qdim+j];
      seg[i*lbsy.nf+j] = 0.0;
    }
  }

  // calculate local forcing terms
    
  for(int k=0; k<numpair; k++) {
    int i = lbspair[2*k  ];
    int j = lbspair[2*k+1];
    nx = pt4[3*k  ];
    ny = pt4[3*k+1];
    nz = pt4[3*k+2];
    forceconst = lbseg[lbsy.nf*j+i] * lbg[lbsy.nf*j+i] * rho[i] * rho[j];
    for(int m=0; m<lbsy.nq; m++) {
      ex = lbvx[m];
      ey = lbvy[m];
      ez = lbvz[m];
      phaseforce[m] += forceconst * ((nx*nx-1.0)*(ex*ex-lbcssq) + (ny*ny-1.0)*(ey*ey-lbcssq) + 2.0*nx*ny*ex*ey
                     + threed*((nz*nz-1.0)*(ez*ez-lbcssq) + 2.0*nz*ez*(nx*ex+ny*ey)));
    }
  }
  
  dv[0] = pt3[0] * invallmass;
  dv[1] = pt3[1] * invallmass;
  dv[2] = pt3[2] * invallmass;
  forceconst = omega * invallmass * invallmass * invallmass * lbrcssq * lbrcssq;

  fGetMomentEquilibriumF(&meq[0], sitespeed, allmass);
  fGetMRTCollide(collide, omega, omegabulk);
  modv = dv[0]*(2.0*sitespeed[0]+dv[0]) + dv[1]*(2.0*sitespeed[1]+dv[1]) + dv[2]*(2.0*sitespeed[2]+dv[2]);
  for(int i=0; i<lbsy.nq; i++) {
    moment[i] = 0;
    for(int j=0; j<lbsy.nq; j++) {
      moment[i] += lbfac[j] * lbtr[i*lbsy.nq+j];
    }
    moment[i] = collide[i] * (meq[i] - moment[i]);
  }
  for(int i=0; i<lbsy.nq; i++) {
    eixux =  lbvx[i]*sitespeed[0];
    eiyuy =  lbvy[i]*sitespeed[1];
    eizuz =  lbvz[i]*sitespeed[2];
    eixdux = lbvx[i]*dv[0];
    eiyduy = lbvy[i]*dv[1];
    eizduz = lbvz[i]*dv[2];
    source = allmass * lbw[i] * (3.0 * (eixdux+eiyduy+eizduz) +
                                 4.5 * (eixdux*(eixdux+2.0*(eixux+eiyuy+eizuz+eiyduy+eizduz)) +
                                        eiyduy*(eiyduy+2.0*(eixux+eiyuy+eizuz+eizduz)) +
                                        eizduz*(eizduz+2.0*(eixux+eiyuy+eizuz))) -
                                 1.5 * modv);
    for(int j=0; j<lbsy.nq; j++) {
      lbfac[i] = lbfac[i] + moment[j] * lbtrinv[i*lbsy.nq+j];
    }
    lbfac[i] = lbfac[i] + source + lbw[i]*forceconst*phaseforce[i];
  }

  // segregation of fluids

  for(int k=0; k<numpair; k++) {
    int i = lbspair[2*k  ];
    int j = lbspair[2*k+1];
    nx = pt4[3*k  ];
    ny = pt4[3*k+1];
    nz = pt4[3*k+2];
    segpiece = lbseg[lbsy.nf*j+i] * rho[i] * rho[j] * invallmass * invallmass;
    for(int m=0; m<lbsy.nq; m++) {
      segcomp = segpiece * (lbvwx[m]*nx + lbvwy[m]*ny + lbvwz[m]*nz);
      seg[m*lbsy.nf+i] += segcomp;
      seg[m*lbsy.nf+j] -= segcomp;
    }
  }

  for(int m=0; m<lbsy.nq; m++) {
    for(int i=0; i<lbsy.nf; i++) {
      pt2[m*qdim+i] = rho[i] * lbfac[m] * invallmass + seg[m*lbsy.nf+i];
    }
  }

  pt2 = NULL;
  pt3 = NULL;  
  pt4 = NULL;  
  return 0;
}

int fSiteFluidIncomCollisionMRTEDMLishchukLocal(double* startpos, double *sitespeed, double* bodyforce, double* phaseindex, int threed)
{

  // MRT collision of achromatic fluid and D'Ortona segregation
  // calculate interfacial forcing terms and collisions at grid point:
  // using MRT schemes for incompressible fluids with
  // Exact Difference Method forcing term

  double dv[3], meq[lbsy.nq];
  double density, allmass, invallmass, invmass, omega, omegabulk, ex, ey, ez, nx, ny, nz;
  double forceconst, segcomp, segpiece, source;
  double modv,eixux,eiyuy,eizuz,eixdux,eiyduy,eizduz;
  double rho[lbsy.nf], seg[lbsy.nf*lbsy.nq], lbfac[lbsy.nq], moment[lbsy.nq], collide[lbsy.nq], phaseforce[lbsy.nq];
  double *pt2 = &startpos[0];
  double *pt3 = &bodyforce[0];
  double *pt4 = &phaseindex[0];
  int numpair = lbsy.nf*(lbsy.nf-1)/2;
  int qdim = lbsy.nf+lbsy.nc+lbsy.nt;

  // collision of achromatic fluid

  fGetAllMassSite(rho, pt2);
  allmass = 0.0;
  omega = 0.0;
  omegabulk = 0.0;
  density = 0.0;

  for(int j=0; j<lbsy.nf; j++) {
    allmass += rho[j];
    omega += lbtf[j] * rho[j];
    omegabulk += lbtfbulk[j] * rho[j];
    density += lbincp[j] * rho[j];
  }
    
  invallmass = fReciprocal(allmass);
  omega *= invallmass;
  omegabulk *= invallmass;
  density *= invallmass;
    
  for(int i=0; i<lbsy.nq; i++) {
    lbfac[i] = 0.0;
    phaseforce[i] = 0.0;
    for(int j=0; j<lbsy.nf; j++) {
      lbfac[i] += pt2[i*qdim+j];
      seg[i*lbsy.nf+j] = 0.0;
    }
  }

  // calculate local forcing terms
    
  for(int k=0; k<numpair; k++) {
    int i = lbspair[2*k  ];
    int j = lbspair[2*k+1];
    nx = pt4[3*k  ];
    ny = pt4[3*k+1];
    nz = pt4[3*k+2];
    forceconst = lbseg[lbsy.nf*j+i] * lbg[lbsy.nf*j+i] * rho[i] * rho[j];
    for(int m=0; m<lbsy.nq; m++) {
      ex = lbvx[m];
      ey = lbvy[m];
      ez = lbvz[m];
      phaseforce[m] += forceconst * ((nx*nx-1.0)*(ex*ex-lbcssq) + (ny*ny-1.0)*(ey*ey-lbcssq) + 2.0*nx*ny*ex*ey
                     + threed*((nz*nz-1.0)*(ez*ez-lbcssq) + 2.0*nz*ez*(nx*ex+ny*ey)));
    }
  }

  invmass = fReciprocal(density);
  dv[0] = pt3[0] * invmass;
  dv[1] = pt3[1] * invmass;
  dv[2] = pt3[2] * invmass;
  forceconst = omega * invallmass * invallmass * lbrcssq * lbrcssq * invmass;

  fGetMomentEquilibriumFIncom(&meq[0], sitespeed, allmass, density);
  fGetMRTCollide(collide, omega, omegabulk);
  modv = dv[0]*(2.0*sitespeed[0]+dv[0]) + dv[1]*(2.0*sitespeed[1]+dv[1]) + dv[2]*(2.0*sitespeed[2]+dv[2]);
  for(int i=0; i<lbsy.nq; i++) {
    moment[i] = 0;
    for(int j=0; j<lbsy.nq; j++) {
      moment[i] += lbfac[j] * lbtr[i*lbsy.nq+j];
    }
    moment[i] = collide[i] * (lbfeq[i] - moment[i]);
  }
  for(int i=0; i<lbsy.nq; i++) {
    eixux =  lbvx[i]*sitespeed[0];
    eiyuy =  lbvy[i]*sitespeed[1];
    eizuz =  lbvz[i]*sitespeed[2];
    eixdux = lbvx[i]*dv[0];
    eiyduy = lbvy[i]*dv[1];
    eizduz = lbvz[i]*dv[2];
    source = density * lbw[i] * (3.0 * (eixdux+eiyduy+eizduz) +
                                 4.5 * (eixdux*(eixdux+2.0*(eixux+eiyuy+eizuz+eiyduy+eizduz)) +
                                        eiyduy*(eiyduy+2.0*(eixux+eiyuy+eizuz+eizduz)) +
                                        eizduz*(eizduz+2.0*(eixux+eiyuy+eizuz))) -
                                 1.5 * modv);
    for(int j=0; j<lbsy.nq; j++) {
      lbfac[i] = lbfac[i] + moment[j] * lbtrinv[i*lbsy.nq+j];
    }
    lbfac[i] = lbfac[i] + source + lbw[i]*forceconst*phaseforce[i];
  }

  // segregation of fluids

  for(int k=0; k<numpair; k++) {
    int i = lbspair[2*k  ];
    int j = lbspair[2*k+1];
    nx = pt4[3*k  ];
    ny = pt4[3*k+1];
    nz = pt4[3*k+2];
    segpiece = lbseg[lbsy.nf*j+i] * rho[i] * rho[j] * invallmass * invallmass;
    for(int m=0; m<lbsy.nq; m++) {
      segcomp = segpiece * (lbvwx[m]*nx + lbvwy[m]*ny + lbvwz[m]*nz);
      seg[m*lbsy.nf+i] += segcomp;
      seg[m*lbsy.nf+j] -= segcomp;
    }
  }

  for(int m=0; m<lbsy.nq; m++) {
    for(int i=0; i<lbsy.nf; i++) {
      pt2[m*qdim+i] = rho[i] * lbfac[m] * invallmass + seg[m*lbsy.nf+i];
    }
  }

  pt2 = NULL;
  pt3 = NULL;  
  pt4 = NULL;  
  return 0;
}

int fSiteFluidCollisionMRTGuoLishchukLocal(double* startpos, double *sitespeed, double* bodyforce, double* phaseindex, int threed)
{

  // MRT collision of achromatic fluid and D'Ortona segregation
  // calculate interfacial forcing terms and collisions at grid point:
  // using MRT schemes with Guo-like source terms for fluids only
  // (BGK collisions used for solutes and heat transfers)

  double speed[3], force[3], meq[lbsy.nq];
  double allmass, invallmass, omega, omegabulk, ex, ey, ez, nx, ny, nz;
  double forceconst, segcomp, segpiece;
  double rho[lbsy.nf], seg[lbsy.nf*lbsy.nq], lbfac[lbsy.nq], moment[lbsy.nq], collide[lbsy.nq], source[lbsy.nq], phaseforce[lbsy.nq];
  double *pt2 = &startpos[0];
  double *pt3 = &bodyforce[0];
  double *pt4 = &phaseindex[0];
  int numpair = lbsy.nf*(lbsy.nf-1)/2;
  int qdim = lbsy.nf+lbsy.nc+lbsy.nt;

  // collision of achromatic fluid

  fGetAllMassSite(rho, pt2);
  allmass = 0.0;
  omega = 0.0;
  omegabulk = 0.0;

  for(int j=0; j<lbsy.nf; j++) {
    allmass += rho[j];
    omega += lbtf[j] * rho[j];
    omegabulk += lbtfbulk[j] * rho[j];
  }

  invallmass = fReciprocal(allmass);
  omega *= invallmass;
  omegabulk *= invallmass;
    
  for(int i=0; i<lbsy.nq; i++) {
    lbfac[i] = 0.0;
    phaseforce[i] = 0.0;
    for(int j=0; j<lbsy.nf; j++) {
      lbfac[i] += pt2[i*qdim+j];
      seg[i*lbsy.nf+j] = 0.0;
    }
  }

  // calculate local forcing terms
    
  for(int k=0; k<numpair; k++) {
    int i = lbspair[2*k  ];
    int j = lbspair[2*k+1];
    nx = pt4[3*k  ];
    ny = pt4[3*k+1];
    nz = pt4[3*k+2];
    forceconst = lbseg[lbsy.nf*j+i] * lbg[lbsy.nf*j+i] * rho[i] * rho[j];
    for(int m=0; m<lbsy.nq; m++) {
      ex = lbvx[m];
      ey = lbvy[m];
      ez = lbvz[m];
      phaseforce[m] += forceconst * ((nx*nx-1.0)*(ex*ex-lbcssq) + (ny*ny-1.0)*(ey*ey-lbcssq) + 2.0*nx*ny*ex*ey
                     + threed*((nz*nz-1.0)*(ez*ez-lbcssq) + 2.0*nz*ez*(nx*ex+ny*ey)));
    }
  }

  force[0] = pt3[0];
  force[1] = pt3[1];
  force[2] = pt3[2];
  speed[0] = allmass * sitespeed[0] + 0.5 * force[0];
  speed[1] = allmass * sitespeed[1] + 0.5 * force[1];
  speed[2] = allmass * sitespeed[2] + 0.5 * force[2];

  fGetMomentEquilibriumF(&meq[0], speed, allmass);
  speed[0] *= invallmass;
  speed[1] *= invallmass;
  speed[2] *= invallmass;
  forceconst = omega * invallmass * invallmass * invallmass * lbrcssq * lbrcssq;

  fGetMomentForce(source, speed, force);
  fGetMRTCollide(collide, omega, omegabulk);
  for(int i=0; i<lbsy.nq; i++) {
    moment[i] = 0;
    for(int j=0; j<lbsy.nq; j++) {
      moment[i] += lbfac[j] * lbtr[i*lbsy.nq+j];
    }
    moment[i] = collide[i] * (meq[i] - moment[i]) + (1.0 - 0.5 * collide[i]) * source[i];
  }
  for(int i=0; i<lbsy.nq; i++) {
    for(int j=0; j<lbsy.nq; j++) {
      lbfac[i] = lbfac[i] + moment[j] * lbtrinv[i*lbsy.nq+j];
    }
    lbfac[i] = lbfac[i] + lbw[i]*forceconst*phaseforce[i];
  }

  // segregation of fluids

  for(int k=0; k<numpair; k++) {
    int i = lbspair[2*k  ];
    int j = lbspair[2*k+1];
    nx = pt4[3*k  ];
    ny = pt4[3*k+1];
    nz = pt4[3*k+2];
    segpiece = lbseg[lbsy.nf*j+i] * rho[i] * rho[j] * invallmass * invallmass;
    for(int m=0; m<lbsy.nq; m++) {
      segcomp = segpiece * (lbvwx[m]*nx + lbvwy[m]*ny + lbvwz[m]*nz);
      seg[m*lbsy.nf+i] += segcomp;
      seg[m*lbsy.nf+j] -= segcomp;
    }
  }

  for(int m=0; m<lbsy.nq; m++) {
    for(int i=0; i<lbsy.nf; i++) {
      pt2[m*qdim+i] = rho[i] * lbfac[m] * invallmass + seg[m*lbsy.nf+i];
    }
  }

  pt2 = NULL;
  pt3 = NULL;  
  pt4 = NULL;  
  return 0;
}

int fSiteFluidIncomCollisionMRTGuoLishchukLocal(double* startpos, double *sitespeed, double* bodyforce, double* phaseindex, int threed)
{

  // MRT collision of achromatic fluid and D'Ortona segregation
  // calculate interfacial forcing terms and collisions at grid point:
  // using MRT schemes with Guo-like source terms for incompressible fluids only
  // (BGK collisions used for solutes and heat transfers)

  double speed[3], force[3], meq[lbsy.nq];
  double allmass, invallmass, density, invdensity, omega, omegabulk, ex, ey, ez, nx, ny, nz;
  double forceconst, segcomp, segpiece;
  double rho[lbsy.nf], seg[lbsy.nf*lbsy.nq], lbfac[lbsy.nq], moment[lbsy.nq], collide[lbsy.nq], source[lbsy.nq], phaseforce[lbsy.nq];
  double *pt2 = &startpos[0];
  double *pt3 = &bodyforce[0];
  double *pt4 = &phaseindex[0];
  int numpair = lbsy.nf*(lbsy.nf-1)/2;
  int qdim = lbsy.nf+lbsy.nc+lbsy.nt;

  // collision of achromatic fluid

  fGetAllMassSite(rho, pt2);
  allmass = 0.0;
  omega = 0.0;
  omegabulk = 0.0;
  density = 0.0;

  for(int j=0; j<lbsy.nf; j++) {
    allmass += rho[j];
    omega += lbtf[j] * rho[j];
    omegabulk += lbtfbulk[j] * rho[j];
    density += lbincp[j] * rho[j];
  }
    
  invallmass = fReciprocal(allmass);
  omega *= invallmass;
  omegabulk *= invallmass;
  density *= invallmass;
    
  for(int i=0; i<lbsy.nq; i++) {
    lbfac[i] = 0.0;
    phaseforce[i] = 0.0;
    for(int j=0; j<lbsy.nf; j++) {
      lbfac[i] += pt2[i*qdim+j];
      seg[i*lbsy.nf+j] = 0.0;
    }
  }

  // calculate local forcing terms
    
  for(int k=0; k<numpair; k++) {
    int i = lbspair[2*k  ];
    int j = lbspair[2*k+1];
    nx = pt4[3*k  ];
    ny = pt4[3*k+1];
    nz = pt4[3*k+2];
    forceconst = lbseg[lbsy.nf*j+i] * lbg[lbsy.nf*j+i] * rho[i] * rho[j];
    for(int m=0; m<lbsy.nq; m++) {
      ex = lbvx[m];
      ey = lbvy[m];
      ez = lbvz[m];
      phaseforce[m] += forceconst * ((nx*nx-1.0)*(ex*ex-lbcssq) + (ny*ny-1.0)*(ey*ey-lbcssq) + 2.0*nx*ny*ex*ey
                     + threed*((nz*nz-1.0)*(ez*ez-lbcssq) + 2.0*nz*ez*(nx*ex+ny*ey)));
    }
  }

  force[0] = pt3[0];
  force[1] = pt3[1];
  force[2] = pt3[2];
  speed[0] = density * sitespeed[0] + 0.5 * force[0];
  speed[1] = density * sitespeed[1] + 0.5 * force[1];
  speed[2] = density * sitespeed[2] + 0.5 * force[2];

  fGetMomentEquilibriumFIncom(&meq[0], speed, allmass, density);
  invdensity = fReciprocal(density);
  speed[0] *= invdensity;
  speed[1] *= invdensity;
  speed[2] *= invdensity;
  forceconst = omega * invallmass * invallmass * lbrcssq * lbrcssq * invdensity;

  fGetMomentForce(source, speed, force);
  fGetMRTCollide(collide, omega, omegabulk);
  for(int i=0; i<lbsy.nq; i++) {
    moment[i] = 0;
    for(int j=0; j<lbsy.nq; j++) {
      moment[i] += lbfac[j] * lbtr[i*lbsy.nq+j];
    }
    moment[i] = collide[i] * (meq[i] - moment[i]) + (1.0 - 0.5 * collide[i]) * source[i];
  }
  for(int i=0; i<lbsy.nq; i++) {
    for(int j=0; j<lbsy.nq; j++) {
      lbfac[i] = lbfac[i] + moment[j] * lbtrinv[i*lbsy.nq+j];
    }
    lbfac[i] = lbfac[i] + lbw[i]*forceconst*phaseforce[i];
  }

  // segregation of fluids

  for(int k=0; k<numpair; k++) {
    int i = lbspair[2*k  ];
    int j = lbspair[2*k+1];
    nx = pt4[3*k  ];
    ny = pt4[3*k+1];
    nz = pt4[3*k+2];
    segpiece = lbseg[lbsy.nf*j+i] * rho[i] * rho[j] * invallmass * invallmass;
    for(int m=0; m<lbsy.nq; m++) {
      segcomp = segpiece * (lbvwx[m]*nx + lbvwy[m]*ny + lbvwz[m]*nz);
      seg[m*lbsy.nf+i] += segcomp;
      seg[m*lbsy.nf+j] -= segcomp;
    }
  }

  for(int m=0; m<lbsy.nq; m++) {
    for(int i=0; i<lbsy.nf; i++) {
      pt2[m*qdim+i] = rho[i] * lbfac[m] * invallmass + seg[m*lbsy.nf+i];
    }
  }

  pt2 = NULL;
  pt3 = NULL;  
  pt4 = NULL;  
  return 0;
}

// Swift free-energy collisions

int fSiteFluidCollisionMRTSwiftOneFluid(double* startpos, double *sitespeed, double* gradient, double* bodyforce, double T)
{
  
  // calculate fluid collisions at grid point: uses MRT schemes
  // and Swift free-energy interactions for one fluid

  double speed[3], meq[lbsy.nq], rho[lbsy.nf];
  double moment[lbsy.nq], collide[lbsy.nq];
  double relax, pb, lambda;
  double *pt2 = &startpos[0];
  double *pt3 = &gradient[0];
  double *pt4 = &bodyforce[0];
  int qdim = lbsy.nf+lbsy.nc+lbsy.nt;

  fGetAllMassSite(rho, pt2);
  pb = fGetBulkPressureSwift(rho[0], 0.0, T);
  lambda = fGetLambdaSwift(rho[0], lbtf[0], T);
    
  // collision of fluids

  relax = fReciprocal(lbtf[0]);
  speed[0] = rho[0] * sitespeed[0] + pt4[0] * relax;
  speed[1] = rho[0] * sitespeed[1] + pt4[1] * relax;
  speed[2] = rho[0] * sitespeed[2] + pt4[2] * relax;
  fGetMomentEquilibriumFSwiftOneFluid(&meq[0], speed, rho[0], pb, lambda, pt3);
  fGetMRTCollide(collide, lbtf[0], lbtfbulk[0]);
  for(int i=0; i<lbsy.nq; i++) {
    moment[i] = 0;
    for(int j=0; j<lbsy.nq; j++) {
      moment[i] += pt2[j*qdim] * lbtr[i*lbsy.nq+j];
    }
    moment[i] = collide[i] * (meq[i] - moment[i]);
  }
  for(int i=0; i<lbsy.nq; i++) {
    for(int j=0; j<lbsy.nq; j++) {
      pt2[i*qdim] = pt2[i*qdim] + moment[j] * lbtrinv[i*lbsy.nq+j];
    }
  }

  pt2 = NULL;
  pt3 = NULL;
  pt4 = NULL;
  return 0;
}

int fSiteFluidCollisionMRTSwiftTwoFluid(double* startpos, double *sitespeed, double* gradient, double* bodyforce, double T)
{
  
  // calculate fluid collisions at grid point: uses MRT schemes
  // and Swift free-energy interactions for two fluids (MRT for
  // density distribution, BGK for concentration distribution)

  double speed[3], meq[2*lbsy.nq], rho[lbsy.nf];
  double moment[lbsy.nq], collide[lbsy.nq];
  double omega, omegabulk, relax, relaxphi, pb, mu, lambda;
  double *pt2 = &startpos[0];
  double *pt3 = &gradient[0];
  double *pt4 = &bodyforce[0];
  int qdim = lbsy.nf+lbsy.nc+lbsy.nt;

  fGetAllMassSite(rho, pt2);
  omega = 2.0*lbtf[0]*lbtf[1]/(2.0*lbtf[0]+(1.0+rho[1])*(lbtf[1]-lbtf[0]));
  omegabulk = 2.0*lbtfbulk[0]*lbtfbulk[1]/(2.0*lbtfbulk[0]+(1.0+rho[1])*(lbtfbulk[1]-lbtfbulk[0]));
  pb = fGetBulkPressureSwift(rho[0], rho[1], T);
  lambda = fGetLambdaSwift(rho[0], omega, T);
  mu = fGetPotentialSwift(rho[1], pt3[7]);
    
  // collision of fluids

  relax = fReciprocal(omega);
  relaxphi = 1.0 - lbtmob;
  speed[0] = rho[0] * sitespeed[0] + pt4[0] * relax;
  speed[1] = rho[0] * sitespeed[1] + pt4[1] * relax;
  speed[2] = rho[0] * sitespeed[2] + pt4[2] * relax;
  fGetMomentEquilibriumFSwiftTwoFluid(&meq[0], speed, rho[0], rho[1], pb, mu, lambda, pt3);
  fGetMRTCollide(collide, omega, omegabulk);
  for(int i=0; i<lbsy.nq; i++) {
    moment[i] = 0;
    for(int j=0; j<lbsy.nq; j++) {
      moment[i] += pt2[j*qdim] * lbtr[i*lbsy.nq+j];
    }
    moment[i] = collide[i] * (meq[i] - moment[i]);
  }
  for(int i=0; i<lbsy.nq; i++) {
    for(int j=0; j<lbsy.nq; j++) {
      pt2[i*qdim] = pt2[i*qdim] + moment[j] * lbtrinv[i*lbsy.nq+j];
    }
    pt2[i*qdim+1] = relaxphi * pt2[i*qdim+1] + meq[lbsy.nq+i]*lbtmob;
  }

  pt2 = NULL;
  pt3 = NULL;
  pt4 = NULL;
  return 0;
}

int fSiteFluidCollisionMRTEDMSwiftOneFluid(double* startpos, double *sitespeed, double* gradient, double* bodyforce, double T)
{
  
  // calculate fluid collisions at grid point: uses MRT schemes with
  // Exact Difference Method forcing term and Swift free-energy
  // interactions for one fluid

  double dv[3], meq[lbsy.nq], moment[lbsy.nq], collide[lbsy.nq], rho[lbsy.nf];
  double invmass, source;
  double modv,eixux,eiyuy,eizuz,eixdux,eiyduy,eizduz;
  double pb, lambda;
  double *pt2 = &startpos[0];
  double *pt3 = &gradient[0];
  double *pt4 = &bodyforce[0];
  int qdim = lbsy.nf+lbsy.nc+lbsy.nt;

  fGetAllMassSite(rho, pt2);
  pb = fGetBulkPressureSwift(rho[0], 0.0, T);
  lambda = fGetLambdaSwift(rho[0], lbtf[0], T);

  // collision of fluids

  invmass = fReciprocal(rho[0]);
  dv[0] = pt4[0] * invmass;
  dv[1] = pt4[1] * invmass;
  dv[2] = pt4[2] * invmass;
  fGetMomentEquilibriumFSwiftOneFluid(&meq[0], sitespeed, rho[0], pb, lambda, pt3);
  fGetMRTCollide(collide, lbtf[0], lbtfbulk[0]);
  modv = dv[0]*(2.0*sitespeed[0]+dv[0]) + dv[1]*(2.0*sitespeed[1]+dv[1]) + dv[2]*(2.0*sitespeed[2]+dv[2]);
  for(int i=0; i<lbsy.nq; i++) {
    moment[i] = 0;
    for(int j=0; j<lbsy.nq; j++) {
      moment[i] += pt2[j*qdim] * lbtr[i*lbsy.nq+j];
    }
    moment[i] = collide[i] * (meq[i] - moment[i]);
  }
  for(int i=0; i<lbsy.nq; i++) {
    eixux =  lbvx[i]*sitespeed[0];
    eiyuy =  lbvy[i]*sitespeed[1];
    eizuz =  lbvz[i]*sitespeed[2];
    eixdux = lbvx[i]*dv[0];
    eiyduy = lbvy[i]*dv[1];
    eizduz = lbvz[i]*dv[2];
    source = rho[0] * lbw[i] * (3.0 * (eixdux+eiyduy+eizduz) +
                                4.5 * (eixdux*(eixdux+2.0*(eixux+eiyuy+eizuz+eiyduy+eizduz)) +
                                       eiyduy*(eiyduy+2.0*(eixux+eiyuy+eizuz+eizduz)) +
                                       eizduz*(eizduz+2.0*(eixux+eiyuy+eizuz))) -
                                1.5 * modv);
    for(int j=0; j<lbsy.nq; j++) {
      pt2[i*qdim] = pt2[i*qdim] + moment[j] * lbtrinv[i*lbsy.nq+j];
    }
    pt2[i*qdim] = pt2[i*qdim] + source;
  }

  pt2 = NULL;
  pt3 = NULL;
  pt4 = NULL;
  return 0;
}

int fSiteFluidCollisionMRTEDMSwiftTwoFluid(double* startpos, double *sitespeed, double* gradient, double* bodyforce, double T)
{
  
  // calculate fluid collisions at grid point: uses MRT schemes with
  // Exact Difference Method forcing term and Swift free-energy
  // interactions for two fluids (MRT for density distribution,
  // BGK for concentration distribution)

  double dv[3], meq[lbsy.nq], moment[2*lbsy.nq], collide[lbsy.nq], rho[lbsy.nf];
  double invmass, source;
  double modv,eixux,eiyuy,eizuz,eixdux,eiyduy,eizduz;
  double omega, omegabulk, relaxphi, pb, mu, lambda;
  double *pt2 = &startpos[0];
  double *pt3 = &gradient[0];
  double *pt4 = &bodyforce[0];
  int qdim = lbsy.nf+lbsy.nc+lbsy.nt;

  fGetAllMassSite(rho, pt2);
  omega = 2.0*lbtf[0]*lbtf[1]/(2.0*lbtf[0]+(1.0+rho[1])*(lbtf[1]-lbtf[0]));
  omegabulk = 2.0*lbtfbulk[0]*lbtfbulk[1]/(2.0*lbtfbulk[0]+(1.0+rho[1])*(lbtfbulk[1]-lbtfbulk[0]));
  pb = fGetBulkPressureSwift(rho[0], rho[1], T);
  lambda = fGetLambdaSwift(rho[0], omega, T);
  mu = fGetPotentialSwift(rho[1], pt3[7]);

  // collision of fluids

  invmass = fReciprocal(rho[0]);
  dv[0] = pt4[0] * invmass;
  dv[1] = pt4[1] * invmass;
  dv[2] = pt4[2] * invmass;
  relaxphi = 1.0 - lbtmob;
  fGetMomentEquilibriumFSwiftTwoFluid(&meq[0], sitespeed, rho[0], rho[1], pb, mu, lambda, pt3);
  fGetMRTCollide(collide, omega, omegabulk);
  modv = dv[0]*(2.0*sitespeed[0]+dv[0]) + dv[1]*(2.0*sitespeed[1]+dv[1]) + dv[2]*(2.0*sitespeed[2]+dv[2]);
  for(int i=0; i<lbsy.nq; i++) {
    moment[i] = 0;
    for(int j=0; j<lbsy.nq; j++) {
      moment[i] += pt2[j*qdim] * lbtr[i*lbsy.nq+j];
    }
    moment[i] = collide[i] * (meq[i] - moment[i]);
  }
  for(int i=0; i<lbsy.nq; i++) {
    eixux =  lbvx[i]*sitespeed[0];
    eiyuy =  lbvy[i]*sitespeed[1];
    eizuz =  lbvz[i]*sitespeed[2];
    eixdux = lbvx[i]*dv[0];
    eiyduy = lbvy[i]*dv[1];
    eizduz = lbvz[i]*dv[2];
    source = rho[0] * lbw[i] * (3.0 * (eixdux+eiyduy+eizduz) +
                                4.5 * (eixdux*(eixdux+2.0*(eixux+eiyuy+eizuz+eiyduy+eizduz)) +
                                       eiyduy*(eiyduy+2.0*(eixux+eiyuy+eizuz+eizduz)) +
                                       eizduz*(eizduz+2.0*(eixux+eiyuy+eizuz))) -
                                1.5 * modv);
    for(int j=0; j<lbsy.nq; j++) {
      pt2[i*qdim] = pt2[i*qdim] + moment[j] * lbtrinv[i*lbsy.nq+j];
    }
    pt2[i*qdim  ] = pt2[i*qdim] + source;
    pt2[i*qdim+1] = relaxphi * pt2[i*qdim+1] + meq[lbsy.nq+i]*lbtmob;
  }

  pt2 = NULL;
  pt3 = NULL;
  pt4 = NULL;
  return 0;
}

int fSiteFluidCollisionMRTGuoSwiftOneFluid(double* startpos, double *sitespeed, double* gradient, double* bodyforce, double T)
{
  
  // calculate collisions at grid point: uses MRT schemes with Guo-like source terms
  // and Swift free-energy interactions for one fluid

  double speed[3], force[3], meq[lbsy.nq], rho[lbsy.nf];
  double moment[lbsy.nq], collide[lbsy.nq], source[lbsy.nq];
  double invmass, pb, lambda;
  double *pt2 = &startpos[0];
  double *pt3 = &gradient[0];
  double *pt4 = &bodyforce[0];
  int qdim = lbsy.nf+lbsy.nc+lbsy.nt;

  fGetAllMassSite(rho, pt2);
  pb = fGetBulkPressureSwift(rho[0], 0.0, T);
  lambda = fGetLambdaSwift(rho[0], lbtf[0], T);

  // collision of fluids

  invmass = fReciprocal(rho[0]);
  force[0] = pt4[0];
  force[1] = pt4[1];
  force[2] = pt4[2];
  speed[0] = rho[0] * sitespeed[0] + 0.5 * force[0];
  speed[1] = rho[0] * sitespeed[1] + 0.5 * force[1];
  speed[2] = rho[0] * sitespeed[2] + 0.5 * force[2];
  fGetMomentEquilibriumFSwiftOneFluid(&meq[0], speed, rho[0], pb, lambda, pt3);
  speed[0] *= invmass;
  speed[1] *= invmass;
  speed[2] *= invmass;
  fGetMomentForce(source, speed, force);
  fGetMRTCollide(collide, lbtf[0], lbtfbulk[0]);
  for(int i=0; i<lbsy.nq; i++) {
    moment[i] = 0;
    for(int j=0; j<lbsy.nq; j++) {
      moment[i] += pt2[j*qdim] * lbtr[i*lbsy.nq+j];
    }
    moment[i] = collide[i] * (meq[i] - moment[i]) + (1.0 - 0.5 * collide[i]) * source[i];
  }
  for(int i=0; i<lbsy.nq; i++) {
    for(int j=0; j<lbsy.nq; j++) {
      pt2[i*qdim] = pt2[i*qdim] + moment[j] * lbtrinv[i*lbsy.nq+j];
    }
  }

  pt2 = NULL;
  pt3 = NULL;
  pt4 = NULL;
  return 0;
}

int fSiteFluidCollisionMRTGuoSwiftTwoFluid(double* startpos, double *sitespeed, double* gradient, double* bodyforce, double T)
{
  
  // calculate collisions at grid point: uses MRT schemes with Guo-like source terms
  // and Swift free-energy interactions for two fluids (MRT for density distribution,
  // BGK for concentration distribution)

  double speed[3], force[3], meq[lbsy.nq], rho[lbsy.nf];
  double moment[lbsy.nq], collide[lbsy.nq], source[lbsy.nq];
  double invmass, omega, omegabulk, relaxphi, pb, mu, lambda;
  double *pt2 = &startpos[0];
  double *pt3 = &gradient[0];
  double *pt4 = &bodyforce[0];
  int qdim = lbsy.nf+lbsy.nc+lbsy.nt;

  fGetAllMassSite(rho, pt2);
  omega = 2.0*lbtf[0]*lbtf[1]/(2.0*lbtf[0]+(1.0+rho[1])*(lbtf[1]-lbtf[0]));
  omegabulk = 2.0*lbtfbulk[0]*lbtfbulk[1]/(2.0*lbtfbulk[0]+(1.0+rho[1])*(lbtfbulk[1]-lbtfbulk[0]));
  pb = fGetBulkPressureSwift(rho[0], rho[1], T);
  lambda = fGetLambdaSwift(rho[0], omega, T);
  mu = fGetPotentialSwift(rho[1], pt3[7]);

  // collision of fluids

  invmass = fReciprocal(rho[0]);
  force[0] = pt4[0];
  force[1] = pt4[1];
  force[2] = pt4[2];
  speed[0] = rho[0] * sitespeed[0] + 0.5 * force[0];
  speed[1] = rho[0] * sitespeed[1] + 0.5 * force[1];
  speed[2] = rho[0] * sitespeed[2] + 0.5 * force[2];
  fGetMomentEquilibriumFSwiftTwoFluid(&meq[0], speed, rho[0], rho[1], pb, mu, lambda, pt3);
  speed[0] *= invmass;
  speed[1] *= invmass;
  speed[2] *= invmass;
  fGetMomentForce(source, speed, force);
  fGetMRTCollide(collide, omega, omegabulk);
  relaxphi = 1.0 - lbtmob;
  for(int i=0; i<lbsy.nq; i++) {
    moment[i] = 0;
    for(int j=0; j<lbsy.nq; j++) {
      moment[i] += pt2[j*qdim] * lbtr[i*lbsy.nq+j];
    }
    moment[i] = collide[i] * (meq[i] - moment[i]) + (1.0 - 0.5 * collide[i]) * source[i];
  }
  for(int i=0; i<lbsy.nq; i++) {
    for(int j=0; j<lbsy.nq; j++) {
      pt2[i*qdim] = pt2[i*qdim] + moment[j] * lbtrinv[i*lbsy.nq+j];
    }
    pt2[i*qdim+1] = relaxphi * pt2[i*qdim+1] + meq[lbsy.nq+i]*lbtmob;
  }

  pt2 = NULL;
  pt3 = NULL;
  pt4 = NULL;
  return 0;
}

// Collision loops over all grid points

int fCollisionMRT()
{
  long il;
  long Tmax = lbdm.touter;

  if(!incompress) {

    #pragma omp parallel
    {
      double interforce_t[3*lbsy.nf], sitespeed_t[3];
      double *interforce = &interforce_t[0];
      double *sitespeed = &sitespeed_t[0];
                                     
      #pragma omp for
      for(il=0; il<Tmax; il++) {
        fGetSpeedSite(sitespeed, &lbf[il*lbsitelength]);
        if(lbphi[il] != 11) {
          for(int ll=0; ll<3*lbsy.nf; ll++)
            interforce[ll] = lbinterforce[il*3*lbsy.nf+ll] + postequil*lbbdforce[ll];
          if(lbphi[il] != 12 && lbphi[il] != 13)
            fSiteFluidCollisionMRT(&lbf[il * lbsitelength], sitespeed, interforce);
          fSiteSoluteCollisionBGK(&lbf[il*lbsitelength + lbsy.nf], sitespeed);
          fSiteThermalCollisionBGK(&lbf[il*lbsitelength + (lbsy.nf+lbsy.nc)], sitespeed);
        }
      }
    }
  }
  else {

    #pragma omp parallel
    {
      double interforce_t[3*lbsy.nf], sitespeed_t[3];
      double *interforce = &interforce_t[0];
      double *sitespeed = &sitespeed_t[0];
                                     
      #pragma omp for
      for(il=0; il<Tmax; il++) {
        fGetSpeedIncomSite(sitespeed, &lbf[il*lbsitelength]);
        if(lbphi[il] != 11) {
          for(int ll=0; ll<3*lbsy.nf; ll++)
            interforce[ll] = lbinterforce[il*3*lbsy.nf+ll] + postequil*lbbdforce[ll];
          if(lbphi[il] != 12 && lbphi[il] != 13)
            fSiteFluidIncomCollisionMRT(&lbf[il * lbsitelength], sitespeed, interforce);
          fSiteSoluteCollisionBGK(&lbf[il*lbsitelength + lbsy.nf], sitespeed);
          fSiteThermalCollisionBGK(&lbf[il*lbsitelength + (lbsy.nf+lbsy.nc)], sitespeed);
        }
      }
    }
  }
  return 0;
}

int fCollisionMRTEDM()
{
  long il;
  long Tmax = lbdm.touter;

  if(!incompress) {

    #pragma omp parallel
    {
      double interforce_t[3*lbsy.nf], sitespeed_t[3];
      double *interforce = &interforce_t[0];
      double *sitespeed = &sitespeed_t[0];
                                     
      #pragma omp for
      for(il=0; il<Tmax; il++) {
        fGetSpeedSite(sitespeed, &lbf[il*lbsitelength]);
        if(lbphi[il] != 11) {
          for(int ll=0; ll<3*lbsy.nf; ll++)
            interforce[ll] = lbinterforce[il*3*lbsy.nf+ll] + postequil*lbbdforce[ll];
          if(lbphi[il] != 12 && lbphi[il] != 13)
            fSiteFluidCollisionMRTEDM(&lbf[il * lbsitelength], sitespeed, interforce);
          fSiteSoluteCollisionBGK(&lbf[il*lbsitelength + lbsy.nf], sitespeed);
          fSiteThermalCollisionBGK(&lbf[il*lbsitelength + (lbsy.nf+lbsy.nc)], sitespeed);
        }
      }
    }
  }
  else {

    #pragma omp parallel
    {
      double interforce_t[3*lbsy.nf], sitespeed_t[3];
      double *interforce = &interforce_t[0];
      double *sitespeed = &sitespeed_t[0];
                                     
      #pragma omp for
      for(il=0; il<Tmax; il++) {
        fGetSpeedIncomSite(sitespeed, &lbf[il*lbsitelength]);
        if(lbphi[il] != 11) {
          for(int ll=0; ll<3*lbsy.nf; ll++)
            interforce[ll] = lbinterforce[il*3*lbsy.nf+ll] + postequil*lbbdforce[ll];
          if(lbphi[il] != 12 && lbphi[il] != 13)
            fSiteFluidIncomCollisionMRTEDM(&lbf[il * lbsitelength], sitespeed, interforce);
          fSiteSoluteCollisionBGK(&lbf[il*lbsitelength + lbsy.nf], sitespeed);
          fSiteThermalCollisionBGK(&lbf[il*lbsitelength + (lbsy.nf+lbsy.nc)], sitespeed);
        }
      }
    }
                                     
  }
  return 0;
}

int fCollisionMRTGuo()
{
  long il;
  long Tmax = lbdm.touter;

  if(!incompress) {

    #pragma omp parallel
    {
      double interforce_t[3*lbsy.nf], sitespeed_t[3];
      double *interforce = &interforce_t[0];
      double *sitespeed = &sitespeed_t[0];
                                     
      #pragma omp for
      for(il=0; il<Tmax; il++) {
        fGetSpeedSite(sitespeed, &lbf[il*lbsitelength]);
        if(lbphi[il] != 11) {
          for(int ll=0; ll<3*lbsy.nf; ll++)
            interforce[ll] = lbinterforce[il*3*lbsy.nf+ll] + postequil*lbbdforce[ll];
          if(lbphi[il] != 12 && lbphi[il] != 13)
            fSiteFluidCollisionMRTGuo(&lbf[il * lbsitelength], sitespeed, interforce);
          fSiteSoluteCollisionBGK(&lbf[il*lbsitelength + lbsy.nf], sitespeed);
          fSiteThermalCollisionBGK(&lbf[il*lbsitelength + (lbsy.nf+lbsy.nc)], sitespeed);
        }
      }
    }
  }
  else {

    #pragma omp parallel
    {
      double interforce_t[3*lbsy.nf], sitespeed_t[3];
      double *interforce = &interforce_t[0];
      double *sitespeed = &sitespeed_t[0];
                                     
      #pragma omp for
      for(il=0; il<Tmax; il++) {
        fGetSpeedIncomSite(sitespeed, &lbf[il*lbsitelength]);
        if(lbphi[il] != 11) {
          for(int ll=0; ll<3*lbsy.nf; ll++)
            interforce[ll] = lbinterforce[il*3*lbsy.nf+ll] + postequil*lbbdforce[ll];
          if(lbphi[il] != 12 && lbphi[il] != 13)
            fSiteFluidIncomCollisionMRTGuo(&lbf[il * lbsitelength], sitespeed, interforce);
          fSiteSoluteCollisionBGK(&lbf[il*lbsitelength + lbsy.nf], sitespeed);
          fSiteThermalCollisionBGK(&lbf[il*lbsitelength + (lbsy.nf+lbsy.nc)], sitespeed);
        }
      }
    }
                                     
  }
  return 0;
}

int fCollisionMRTShanChen()
{
  long il;
  long Tmax = lbdm.touter;

  if(!incompress) {

    #pragma omp parallel
    {
      double interforce_t[3*lbsy.nf], sitespeed_t[3];
      double *interforce = &interforce_t[0];
      double *sitespeed = &sitespeed_t[0];
                                     
      #pragma omp for
      for(il=0; il<Tmax; il++) {
        fGetSpeedShanChenSite(sitespeed, &lbf[il*lbsitelength]);
        if(lbphi[il] != 11) {
          for(int ll=0; ll<3*lbsy.nf; ll++)
            interforce[ll] = lbinterforce[il*3*lbsy.nf+ll] + postequil*lbbdforce[ll];
          if(lbphi[il] != 12 && lbphi[il] != 13)
            fSiteFluidCollisionMRT(&lbf[il * lbsitelength], sitespeed, interforce);
          fSiteSoluteCollisionBGK(&lbf[il*lbsitelength + lbsy.nf], sitespeed);
          fSiteThermalCollisionBGK(&lbf[il*lbsitelength + (lbsy.nf+lbsy.nc)], sitespeed);
        }
      }
    }
  }
  else {

    #pragma omp parallel
    {
      double interforce_t[3*lbsy.nf], sitespeed_t[3];
      double *interforce = &interforce_t[0];
      double *sitespeed = &sitespeed_t[0];
                                     
      #pragma omp for
      for(il=0; il<Tmax; il++) {
        fGetSpeedShanChenIncomSite(sitespeed, &lbf[il*lbsitelength]);
        if(lbphi[il] != 11) {
          for(int ll=0; ll<3*lbsy.nf; ll++)
            interforce[ll] = lbinterforce[il*3*lbsy.nf+ll] + postequil*lbbdforce[ll];
          if(lbphi[il] != 12 && lbphi[il] != 13)
            fSiteFluidIncomCollisionMRT(&lbf[il * lbsitelength], sitespeed, interforce);
          fSiteSoluteCollisionBGK(&lbf[il*lbsitelength + lbsy.nf], sitespeed);
          fSiteThermalCollisionBGK(&lbf[il*lbsitelength + (lbsy.nf+lbsy.nc)], sitespeed);
        }
      }
    }
  }
  return 0;
}

int fCollisionMRTEDMShanChen()
{
  long il;
  long Tmax = lbdm.touter;

  if(!incompress) {

    #pragma omp parallel
    {
      double interforce_t[3*lbsy.nf], sitespeed_t[3];
      double *interforce = &interforce_t[0];
      double *sitespeed = &sitespeed_t[0];
                                     
      #pragma omp for
      for(il=0; il<Tmax; il++) {
        fGetSpeedShanChenSite(sitespeed, &lbf[il*lbsitelength]);
        if(lbphi[il] != 11) {
          for(int ll=0; ll<3*lbsy.nf; ll++)
            interforce[ll] = lbinterforce[il*3*lbsy.nf+ll] + postequil*lbbdforce[ll];
          if(lbphi[il] != 12 && lbphi[il] != 13)
            fSiteFluidCollisionMRTEDM(&lbf[il * lbsitelength], sitespeed, interforce);
          fSiteSoluteCollisionBGK(&lbf[il*lbsitelength + lbsy.nf], sitespeed);
          fSiteThermalCollisionBGK(&lbf[il*lbsitelength + (lbsy.nf+lbsy.nc)], sitespeed);
        }
      }
    }
  }
  else {

    #pragma omp parallel
    {
      double interforce_t[3*lbsy.nf], sitespeed_t[3];
      double *interforce = &interforce_t[0];
      double *sitespeed = &sitespeed_t[0];
                                     
      #pragma omp for
      for(il=0; il<Tmax; il++) {
        fGetSpeedShanChenIncomSite(sitespeed, &lbf[il*lbsitelength]);
        if(lbphi[il] != 11) {
          for(int ll=0; ll<3*lbsy.nf; ll++)
            interforce[ll] = lbinterforce[il*3*lbsy.nf+ll] + postequil*lbbdforce[ll];
          if(lbphi[il] != 12 && lbphi[il] != 13)
            fSiteFluidIncomCollisionMRTEDM(&lbf[il * lbsitelength], sitespeed, interforce);
          fSiteSoluteCollisionBGK(&lbf[il*lbsitelength + lbsy.nf], sitespeed);
          fSiteThermalCollisionBGK(&lbf[il*lbsitelength + (lbsy.nf+lbsy.nc)], sitespeed);
        }
      }
    }
                                     
  }
  return 0;
}

int fCollisionMRTGuoShanChen()
{
  long il;
  long Tmax = lbdm.touter;

  if(!incompress) {

    #pragma omp parallel
    {
      double interforce_t[3*lbsy.nf], sitespeed_t[3];
      double *interforce = &interforce_t[0];
      double *sitespeed = &sitespeed_t[0];
                                     
      #pragma omp for
      for(il=0; il<Tmax; il++) {
        fGetSpeedShanChenSite(sitespeed, &lbf[il*lbsitelength]);
        if(lbphi[il] != 11) {
          for(int ll=0; ll<3*lbsy.nf; ll++)
            interforce[ll] = lbinterforce[il*3*lbsy.nf+ll] + postequil*lbbdforce[ll];
          if(lbphi[il] != 12 && lbphi[il] != 13)
            fSiteFluidCollisionMRTGuo(&lbf[il * lbsitelength], sitespeed, interforce);
          fSiteSoluteCollisionBGK(&lbf[il*lbsitelength + lbsy.nf], sitespeed);
          fSiteThermalCollisionBGK(&lbf[il*lbsitelength + (lbsy.nf+lbsy.nc)], sitespeed);
        }
      }
    }
  }
  else {

    #pragma omp parallel
    {
      double interforce_t[3*lbsy.nf], sitespeed_t[3];
      double *interforce = &interforce_t[0];
      double *sitespeed = &sitespeed_t[0];
                                     
      #pragma omp for
      for(il=0; il<Tmax; il++) {
        fGetSpeedShanChenIncomSite(sitespeed, &lbf[il*lbsitelength]);
        if(lbphi[il] != 11) {
          for(int ll=0; ll<3*lbsy.nf; ll++)
            interforce[ll] = lbinterforce[il*3*lbsy.nf+ll] + postequil*lbbdforce[ll];
          if(lbphi[il] != 12 && lbphi[il] != 13)
            fSiteFluidIncomCollisionMRTGuo(&lbf[il * lbsitelength], sitespeed, interforce);
          fSiteSoluteCollisionBGK(&lbf[il*lbsitelength + lbsy.nf], sitespeed);
          fSiteThermalCollisionBGK(&lbf[il*lbsitelength + (lbsy.nf+lbsy.nc)], sitespeed);
        }
      }
    }
                                     
  }
  return 0;
}

int fCollisionMRTLishchuk()
{
  long il;
  double frac,invallmass;
  int numpair = 3 * lbsy.nf * (lbsy.nf-1) / 2;
  long Tmax = lbdm.touter;
    
  if(!incompress) {

    #pragma omp parallel private(frac,invallmass)
    {
      double interforce_t[3], sitespeed_t[3];
      double *interforce = &interforce_t[0];
      double *sitespeed = &sitespeed_t[0];

      #pragma omp for
      for(il=0; il<Tmax; il++) {
        fGetSpeedSite(sitespeed, &lbf[il*lbsitelength]);
        if(lbphi[il] != 11) {
          invallmass = fReciprocal(fGetTotMassSite(&lbf[il*lbsitelength]));
          interforce[0] = 0.0; interforce[1] = 0.0; interforce[2] = 0.0;
          for(int ll=0; ll<lbsy.nf; ll++) {
            frac = fGetOneMassSite(ll, il) * invallmass;
            interforce[0] += lbinterforce[il*3*lbsy.nf+3*ll  ]+postequil*frac*lbbdforce[3*ll  ];
            interforce[1] += lbinterforce[il*3*lbsy.nf+3*ll+1]+postequil*frac*lbbdforce[3*ll+1];
            interforce[2] += lbinterforce[il*3*lbsy.nf+3*ll+2]+postequil*frac*lbbdforce[3*ll+2];
          }
          if(lbphi[il] != 12 && lbphi[il] != 13)
            fSiteFluidCollisionMRTLishchuk(&lbf[il*lbsitelength], sitespeed, interforce, &lbft[il*numpair]);
          fSiteSoluteCollisionBGK(&lbf[il*lbsitelength + lbsy.nf], sitespeed);
          fSiteThermalCollisionBGK(&lbf[il*lbsitelength + (lbsy.nf+lbsy.nc)], sitespeed);
        }
      }
    }
  }
  else {
      
    #pragma omp parallel private(frac,invallmass)
    {
      double interforce_t[3], sitespeed_t[3];
      double *interforce = &interforce_t[0];
      double *sitespeed = &sitespeed_t[0];

      #pragma omp for
      for(il=0; il<Tmax; il++) {
        fGetSpeedIncomSite(sitespeed, &lbf[il*lbsitelength]);
        if(lbphi[il] != 11) {
          invallmass = fReciprocal(fGetTotMassSite(&lbf[il*lbsitelength]));
          interforce[0] = 0.0; interforce[1] = 0.0; interforce[2] = 0.0;
          for(int ll=0; ll<lbsy.nf; ll++) {
            frac = fGetOneMassSite(ll, il) * invallmass;
            interforce[0] += lbinterforce[il*3*lbsy.nf+3*ll  ]+postequil*frac*lbbdforce[3*ll  ];
            interforce[1] += lbinterforce[il*3*lbsy.nf+3*ll+1]+postequil*frac*lbbdforce[3*ll+1];
            interforce[2] += lbinterforce[il*3*lbsy.nf+3*ll+2]+postequil*frac*lbbdforce[3*ll+2];
          }
          if(lbphi[il] != 12 && lbphi[il] != 13)
            fSiteFluidIncomCollisionMRTLishchuk(&lbf[il*lbsitelength], sitespeed, interforce, &lbft[il*numpair]);
          fSiteSoluteCollisionBGK(&lbf[il*lbsitelength + lbsy.nf], sitespeed);
          fSiteThermalCollisionBGK(&lbf[il*lbsitelength + (lbsy.nf+lbsy.nc)], sitespeed);
        }
      }
    }
  }
  return 0;
}

int fCollisionMRTEDMLishchuk()
{
  long il;
  double frac,invallmass;
  int numpair = 3 * lbsy.nf * (lbsy.nf-1) / 2;
  long Tmax = lbdm.touter;
    
  if(!incompress) {

    #pragma omp parallel private(frac,invallmass)
    {
      double interforce_t[3], sitespeed_t[3];
      double *interforce = &interforce_t[0];
      double *sitespeed = &sitespeed_t[0];

      #pragma omp for
      for(il=0; il<Tmax; il++) {
        fGetSpeedSite(sitespeed, &lbf[il*lbsitelength]);
        if(lbphi[il] != 11) {
          invallmass = fReciprocal(fGetTotMassSite(&lbf[il*lbsitelength]));
          interforce[0] = 0.0; interforce[1] = 0.0; interforce[2] = 0.0;
          for(int ll=0; ll<lbsy.nf; ll++) {
            frac = fGetOneMassSite(ll, il) * invallmass;
            interforce[0] += lbinterforce[il*3*lbsy.nf+3*ll  ]+postequil*frac*lbbdforce[3*ll  ];
            interforce[1] += lbinterforce[il*3*lbsy.nf+3*ll+1]+postequil*frac*lbbdforce[3*ll+1];
            interforce[2] += lbinterforce[il*3*lbsy.nf+3*ll+2]+postequil*frac*lbbdforce[3*ll+2];
          }
          if(lbphi[il] != 12 && lbphi[il] != 13)
            fSiteFluidCollisionMRTEDMLishchuk(&lbf[il*lbsitelength], sitespeed, interforce, &lbft[il*numpair]);
          fSiteSoluteCollisionBGK(&lbf[il*lbsitelength + lbsy.nf], sitespeed);
          fSiteThermalCollisionBGK(&lbf[il*lbsitelength + (lbsy.nf+lbsy.nc)], sitespeed);
        }
      }
    }
  }
  else {

    #pragma omp parallel private(frac,invallmass)
    {
      double interforce_t[3], sitespeed_t[3];
      double *interforce = &interforce_t[0];
      double *sitespeed = &sitespeed_t[0];

      #pragma omp for
      for(il=0; il<Tmax; il++) {
        fGetSpeedIncomSite(sitespeed, &lbf[il*lbsitelength]);
        if(lbphi[il] != 11) {
          invallmass = fReciprocal(fGetTotMassSite(&lbf[il*lbsitelength]));
          interforce[0] = 0.0; interforce[1] = 0.0; interforce[2] = 0.0;
          for(int ll=0; ll<lbsy.nf; ll++) {
            frac = fGetOneMassSite(ll, il) * invallmass;
            interforce[0] += lbinterforce[il*3*lbsy.nf+3*ll  ]+postequil*frac*lbbdforce[3*ll  ];
            interforce[1] += lbinterforce[il*3*lbsy.nf+3*ll+1]+postequil*frac*lbbdforce[3*ll+1];
            interforce[2] += lbinterforce[il*3*lbsy.nf+3*ll+2]+postequil*frac*lbbdforce[3*ll+2];
          }
          if(lbphi[il] != 12 && lbphi[il] != 13)
            fSiteFluidIncomCollisionMRTEDMLishchuk(&lbf[il*lbsitelength], sitespeed, interforce, &lbft[il*numpair]);
          fSiteSoluteCollisionBGK(&lbf[il*lbsitelength + lbsy.nf], sitespeed);
          fSiteThermalCollisionBGK(&lbf[il*lbsitelength + (lbsy.nf+lbsy.nc)], sitespeed);
        }
      }
    }
  }
  return 0;
}


int fCollisionMRTGuoLishchuk()
{
  long il;
  double frac,invallmass;
  int numpair = 3 * lbsy.nf * (lbsy.nf-1) / 2;
  long Tmax = lbdm.touter;
    
  if(!incompress) {

    #pragma omp parallel private(frac,invallmass)
    {
      double interforce_t[3], sitespeed_t[3];
      double *interforce = &interforce_t[0];
      double *sitespeed = &sitespeed_t[0];

      #pragma omp for
      for(il=0; il<Tmax; il++) {
        fGetSpeedSite(sitespeed, &lbf[il*lbsitelength]);
        if(lbphi[il] != 11) {
          invallmass = fReciprocal(fGetTotMassSite(&lbf[il*lbsitelength]));
          interforce[0] = 0.0; interforce[1] = 0.0; interforce[2] = 0.0;
          for(int ll=0; ll<lbsy.nf; ll++) {
            frac = fGetOneMassSite(ll, il) * invallmass;
            interforce[0] += lbinterforce[il*3*lbsy.nf+3*ll  ]+postequil*frac*lbbdforce[3*ll  ];
            interforce[1] += lbinterforce[il*3*lbsy.nf+3*ll+1]+postequil*frac*lbbdforce[3*ll+1];
            interforce[2] += lbinterforce[il*3*lbsy.nf+3*ll+2]+postequil*frac*lbbdforce[3*ll+2];
          }
          if(lbphi[il] != 12 && lbphi[il] != 13)
            fSiteFluidCollisionMRTGuoLishchuk(&lbf[il*lbsitelength], sitespeed, interforce, &lbft[il*numpair]);
          fSiteSoluteCollisionBGK(&lbf[il*lbsitelength + lbsy.nf], sitespeed);
          fSiteThermalCollisionBGK(&lbf[il*lbsitelength + (lbsy.nf+lbsy.nc)], sitespeed);
        }
      }
    }
  }
  else {

    #pragma omp parallel private(frac,invallmass)
    {
      double interforce_t[3], sitespeed_t[3];
      double *interforce = &interforce_t[0];
      double *sitespeed = &sitespeed_t[0];

      #pragma omp for
      for(il=0; il<Tmax; il++) {
        fGetSpeedIncomSite(sitespeed, &lbf[il*lbsitelength]);
        if(lbphi[il] != 11) {
          invallmass = fReciprocal(fGetTotMassSite(&lbf[il*lbsitelength]));
          interforce[0] = 0.0; interforce[1] = 0.0; interforce[2] = 0.0;
          for(int ll=0; ll<lbsy.nf; ll++) {
            frac = fGetOneMassSite(ll, il) * invallmass;
            interforce[0] += lbinterforce[il*3*lbsy.nf+3*ll  ]+postequil*frac*lbbdforce[3*ll  ];
            interforce[1] += lbinterforce[il*3*lbsy.nf+3*ll+1]+postequil*frac*lbbdforce[3*ll+1];
            interforce[2] += lbinterforce[il*3*lbsy.nf+3*ll+2]+postequil*frac*lbbdforce[3*ll+2];
          }
          if(lbphi[il] != 12 && lbphi[il] != 13)
            fSiteFluidIncomCollisionMRTGuoLishchuk(&lbf[il*lbsitelength], sitespeed, interforce, &lbft[il*numpair]);
          fSiteSoluteCollisionBGK(&lbf[il*lbsitelength + lbsy.nf], sitespeed);
          fSiteThermalCollisionBGK(&lbf[il*lbsitelength + (lbsy.nf+lbsy.nc)], sitespeed);
        }
      }
    }
  }
  return 0;
}


int fCollisionMRTLishchukLocal()
{
  long il;
  double frac,invallmass;
  int numpair = 3 * lbsy.nf * (lbsy.nf-1) / 2;
  int threed = (lbsy.nd>2);
  long Tmax = lbdm.touter;

  if(!incompress) {
      
    #pragma omp parallel private(frac,invallmass)
    {
      double interforce_t[3], sitespeed_t[3];
      double *interforce = &interforce_t[0];
      double *sitespeed = &sitespeed_t[0];

      #pragma omp for
      for(il=0; il<Tmax; il++) {
        fGetSpeedSite(sitespeed, &lbf[il*lbsitelength]);
        if(lbphi[il] != 11) {
          invallmass = fReciprocal(fGetTotMassSite(&lbf[il*lbsitelength]));
          interforce[0] = 0.0; interforce[1] = 0.0; interforce[2] = 0.0;
          for(int ll=0; ll<lbsy.nf; ll++) {
            frac = fGetOneMassSite(ll, il) * invallmass;
	        interforce[0] += lbinterforce[il*3*lbsy.nf+3*ll  ]+postequil*frac*lbbdforce[3*ll  ];
            interforce[1] += lbinterforce[il*3*lbsy.nf+3*ll+1]+postequil*frac*lbbdforce[3*ll+1];
	        interforce[2] += lbinterforce[il*3*lbsy.nf+3*ll+2]+postequil*frac*lbbdforce[3*ll+2];
          }
          if(lbphi[il] != 12 && lbphi[il] != 13)
	        fSiteFluidCollisionMRTLishchukLocal(&lbf[il*lbsitelength], sitespeed, interforce, &lbft[il*numpair], threed);
          fSiteSoluteCollisionBGK(&lbf[il*lbsitelength + lbsy.nf], sitespeed);
          fSiteThermalCollisionBGK(&lbf[il*lbsitelength + (lbsy.nf+lbsy.nc)], sitespeed);
        }
      }
    }
  }
  else {
      
    #pragma omp parallel private(frac,invallmass)
    {
      double interforce_t[3], sitespeed_t[3];
      double *interforce = &interforce_t[0];
      double *sitespeed = &sitespeed_t[0];

      #pragma omp for
      for(il=0; il<Tmax; il++) {
        fGetSpeedIncomSite(sitespeed, &lbf[il*lbsitelength]);
        if(lbphi[il] != 11) {
          invallmass = fReciprocal(fGetTotMassSite(&lbf[il*lbsitelength]));
          interforce[0] = 0.0; interforce[1] = 0.0; interforce[2] = 0.0;
          for(int ll=0; ll<lbsy.nf; ll++) {
            frac = fGetOneMassSite(ll, il) * invallmass;
            interforce[0] += lbinterforce[il*3*lbsy.nf+3*ll  ]+postequil*frac*lbbdforce[3*ll  ];
            interforce[1] += lbinterforce[il*3*lbsy.nf+3*ll+1]+postequil*frac*lbbdforce[3*ll+1];
            interforce[2] += lbinterforce[il*3*lbsy.nf+3*ll+2]+postequil*frac*lbbdforce[3*ll+2];
          }
          if(lbphi[il] != 12 && lbphi[il] != 13)
            fSiteFluidIncomCollisionMRTLishchukLocal(&lbf[il*lbsitelength], sitespeed, interforce, &lbft[il*numpair], threed);
          fSiteSoluteCollisionBGK(&lbf[il*lbsitelength + lbsy.nf], sitespeed);
          fSiteThermalCollisionBGK(&lbf[il*lbsitelength + (lbsy.nf+lbsy.nc)], sitespeed);
        }
      }
    }
  }
  return 0;
}

int fCollisionMRTEDMLishchukLocal()
{
  long il;
  double frac,invallmass;
  int numpair = 3 * lbsy.nf * (lbsy.nf-1) / 2;
  int threed = (lbsy.nd>2);
  long Tmax = lbdm.touter;

  if(!incompress) {

    #pragma omp parallel private(frac,invallmass)
    {
      double interforce_t[3], sitespeed_t[3];
      double *interforce = &interforce_t[0];
      double *sitespeed = &sitespeed_t[0];

      #pragma omp for
      for(il=0; il<Tmax; il++) {
        fGetSpeedSite(sitespeed, &lbf[il*lbsitelength]);
        if(lbphi[il] != 11) {
          invallmass = fReciprocal(fGetTotMassSite(&lbf[il*lbsitelength]));
          interforce[0] = 0.0; interforce[1] = 0.0; interforce[2] = 0.0;
          for(int ll=0; ll<lbsy.nf; ll++) {
            frac = fGetOneMassSite(ll, il) * invallmass;
            interforce[0] += lbinterforce[il*3*lbsy.nf+3*ll  ]+postequil*frac*lbbdforce[3*ll  ];
            interforce[1] += lbinterforce[il*3*lbsy.nf+3*ll+1]+postequil*frac*lbbdforce[3*ll+1];
            interforce[2] += lbinterforce[il*3*lbsy.nf+3*ll+2]+postequil*frac*lbbdforce[3*ll+2];
          }
          if(lbphi[il] != 12 && lbphi[il] != 13)
            fSiteFluidCollisionMRTEDMLishchukLocal(&lbf[il*lbsitelength], sitespeed, interforce, &lbft[il*numpair], threed);
          fSiteSoluteCollisionBGK(&lbf[il*lbsitelength + lbsy.nf], sitespeed);
          fSiteThermalCollisionBGK(&lbf[il*lbsitelength + (lbsy.nf+lbsy.nc)], sitespeed);
        }
      }
    }
  }
  else {

    #pragma omp parallel private(frac,invallmass)
    {
      double interforce_t[3], sitespeed_t[3];
      double *interforce = &interforce_t[0];
      double *sitespeed = &sitespeed_t[0];

      #pragma omp for
      for(il=0; il<Tmax; il++) {
        fGetSpeedIncomSite(sitespeed, &lbf[il*lbsitelength]);
        if(lbphi[il] != 11) {
          invallmass = fReciprocal(fGetTotMassSite(&lbf[il*lbsitelength]));
          interforce[0] = 0.0; interforce[1] = 0.0; interforce[2] = 0.0;
          for(int ll=0; ll<lbsy.nf; ll++) {
            frac = fGetOneMassSite(ll, il) * invallmass;
            interforce[0] += lbinterforce[il*3*lbsy.nf+3*ll  ]+postequil*frac*lbbdforce[3*ll  ];
            interforce[1] += lbinterforce[il*3*lbsy.nf+3*ll+1]+postequil*frac*lbbdforce[3*ll+1];
            interforce[2] += lbinterforce[il*3*lbsy.nf+3*ll+2]+postequil*frac*lbbdforce[3*ll+2];
          }
          if(lbphi[il] != 12 && lbphi[il] != 13)
            fSiteFluidIncomCollisionMRTEDMLishchukLocal(&lbf[il*lbsitelength], sitespeed, interforce, &lbft[il*numpair], threed);
          fSiteSoluteCollisionBGK(&lbf[il*lbsitelength + lbsy.nf], sitespeed);
          fSiteThermalCollisionBGK(&lbf[il*lbsitelength + (lbsy.nf+lbsy.nc)], sitespeed);
        }
      }
    }
  }
  return 0;
}

int fCollisionMRTGuoLishchukLocal()
{
  long il;
  double frac,invallmass;
  int numpair = 3 * lbsy.nf * (lbsy.nf-1) / 2;
  int threed = (lbsy.nd>2);
  long Tmax = lbdm.touter;

  if(!incompress) {

    #pragma omp parallel private(frac,invallmass)
    {
      double interforce_t[3], sitespeed_t[3];
      double *interforce = &interforce_t[0];
      double *sitespeed = &sitespeed_t[0];

      #pragma omp for
      for(il=0; il<Tmax; il++) {
        fGetSpeedSite(sitespeed, &lbf[il*lbsitelength]);
        if(lbphi[il] != 11) {
          invallmass = fReciprocal(fGetTotMassSite(&lbf[il*lbsitelength]));
          interforce[0] = 0.0; interforce[1] = 0.0; interforce[2] = 0.0;
          for(int ll=0; ll<lbsy.nf; ll++) {
            frac = fGetOneMassSite(ll, il) * invallmass;
	        interforce[0] += lbinterforce[il*3*lbsy.nf+3*ll  ]+postequil*frac*lbbdforce[3*ll  ];
            interforce[1] += lbinterforce[il*3*lbsy.nf+3*ll+1]+postequil*frac*lbbdforce[3*ll+1];
            interforce[2] += lbinterforce[il*3*lbsy.nf+3*ll+2]+postequil*frac*lbbdforce[3*ll+2];
          }
          if(lbphi[il] != 12 && lbphi[il] != 13)
            fSiteFluidCollisionMRTGuoLishchukLocal(&lbf[il*lbsitelength], sitespeed, interforce, &lbft[il*numpair], threed);
          fSiteSoluteCollisionBGK(&lbf[il*lbsitelength + lbsy.nf], sitespeed);
          fSiteThermalCollisionBGK(&lbf[il*lbsitelength + (lbsy.nf+lbsy.nc)], sitespeed);
        }
      }
    }
  }
  else {

    #pragma omp parallel private(frac,invallmass)
    {
      double interforce_t[3], sitespeed_t[3];
      double *interforce = &interforce_t[0];
      double *sitespeed = &sitespeed_t[0];

      #pragma omp for
      for(il=0; il<Tmax; il++) {
        fGetSpeedIncomSite(sitespeed, &lbf[il*lbsitelength]);
        if(lbphi[il] != 11) {
          invallmass = fReciprocal(fGetTotMassSite(&lbf[il*lbsitelength]));
          interforce[0] = 0.0; interforce[1] = 0.0; interforce[2] = 0.0;
          for(int ll=0; ll<lbsy.nf; ll++) {
            frac = fGetOneMassSite(ll, il) * invallmass;
            interforce[0] += lbinterforce[il*3*lbsy.nf+3*ll  ]+postequil*frac*lbbdforce[3*ll  ];
            interforce[1] += lbinterforce[il*3*lbsy.nf+3*ll+1]+postequil*frac*lbbdforce[3*ll+1];
            interforce[2] += lbinterforce[il*3*lbsy.nf+3*ll+2]+postequil*frac*lbbdforce[3*ll+2];
          }
          if(lbphi[il] != 12 && lbphi[il] != 13)
            fSiteFluidIncomCollisionMRTGuoLishchukLocal(&lbf[il*lbsitelength], sitespeed, interforce, &lbft[il*numpair], threed);
          fSiteSoluteCollisionBGK(&lbf[il*lbsitelength + lbsy.nf], sitespeed);
          fSiteThermalCollisionBGK(&lbf[il*lbsitelength + (lbsy.nf+lbsy.nc)], sitespeed);
        }
      }
    }
  }
  return 0;
}

int fCollisionMRTSwift()
{

  long il;
  long Tmax = lbdm.touter;

  if(lbsy.nf>1) {

   #pragma omp parallel
   {
      double interforce_local_t[3], sitespeed_local_t[3];
      double *interforce = &interforce_local_t[0];
      double *sitespeed = &sitespeed_local_t[0];

      #pragma omp for
      for(il=0; il<Tmax; il++) {
        fGetOneSpeedSite(sitespeed, &lbf[il*lbsitelength]);
        double T = (lbsy.nt>0)?fGetTemperatureSite(il):lbsyst;
        double frac = fGetFracSwiftSite(0, &lbf[il*lbsitelength]);
        if(lbneigh[il]>0 && lbphi[il]==0) {
          sitespeed[0] = 0.0; sitespeed[1] = 0.0; sitespeed[2] = 0.0;
        }
        if(lbphi[il] != 11) {
          for(int ll=0; ll<3; ll++)
            interforce [ll] = frac*(lbinterforce[il*3*lbsy.nf+ll] + postequil*lbbdforce[ll]) + (1.0-frac)*(lbinterforce[il*3*lbsy.nf+3+ll] + postequil*lbbdforce[3+ll]);
          if(lbphi[il] != 12 && lbphi[il] != 13)
            fSiteFluidCollisionMRTSwiftTwoFluid(&lbf[il*lbsitelength], sitespeed, &lbft[8*il], interforce, T);
          fSiteSoluteCollisionBGK(&lbf[il*lbsitelength + lbsy.nf], sitespeed);
          fSiteThermalCollisionBGK(&lbf[il*lbsitelength + lbsy.nf+lbsy.nc], sitespeed);
        }
      }
    }
  }
  else {
      
   #pragma omp parallel
   {
      double interforce_local_t[3], sitespeed_local_t[3];
      double *interforce = &interforce_local_t[0];
      double *sitespeed = &sitespeed_local_t[0];

      #pragma omp for
      for(il=0; il<Tmax; il++) {
        fGetOneSpeedSite(sitespeed, &lbf[il*lbsitelength]);
        double T = (lbsy.nt>0)?fGetTemperatureSite(il):lbsyst;
        if(lbneigh[il]>0 && lbphi[il]==0) {
          sitespeed[0] = 0.0; sitespeed[1] = 0.0; sitespeed[2] = 0.0;
        }
        if(lbphi[il] != 11) {
          for(int ll=0; ll<3; ll++)
            interforce [ll] = lbinterforce[il*3*lbsy.nf+ll] + postequil*lbbdforce[ll];
          if(lbphi[il] != 12 && lbphi[il] != 13)
            fSiteFluidCollisionMRTSwiftOneFluid(&lbf[il*lbsitelength], sitespeed, &lbft[4*il], interforce, T);
          fSiteSoluteCollisionBGK(&lbf[il*lbsitelength + lbsy.nf], sitespeed);
          fSiteThermalCollisionBGK(&lbf[il*lbsitelength + lbsy.nf+lbsy.nc], sitespeed);
        }
      }
    }
  }
  return 0;
}

int fCollisionMRTEDMSwift()
{
  long il;
  long Tmax = lbdm.touter;

  if(lbsy.nf>1) {

   #pragma omp parallel
   {
      double interforce_local_t[3], sitespeed_local_t[3];
      double *interforce = &interforce_local_t[0];
      double *sitespeed = &sitespeed_local_t[0];

      #pragma omp for
      for(il=0; il<Tmax; il++) {
        fGetOneSpeedSite(sitespeed, &lbf[il*lbsitelength]);
        double T = (lbsy.nt>0)?fGetTemperatureSite(il):lbsyst;
        double frac = fGetFracSwiftSite(0, &lbf[il*lbsitelength]);
        if(lbneigh[il]>0 && lbphi[il]==0) {
          sitespeed[0] = 0.0; sitespeed[1] = 0.0; sitespeed[2] = 0.0;
        }
        if(lbphi[il] != 11) {
          for(int ll=0; ll<3; ll++)
            interforce [ll] = frac*(lbinterforce[il*3*lbsy.nf+ll] + postequil*lbbdforce[ll]) + (1.0-frac)*(lbinterforce[il*3*lbsy.nf+3+ll] + postequil*lbbdforce[3+ll]);
          if(lbphi[il] != 12 && lbphi[il] != 13)
            fSiteFluidCollisionMRTEDMSwiftTwoFluid(&lbf[il*lbsitelength], sitespeed, &lbft[8*il], interforce, T);
          fSiteSoluteCollisionBGK(&lbf[il*lbsitelength + lbsy.nf], sitespeed);
          fSiteThermalCollisionBGK(&lbf[il*lbsitelength + lbsy.nf+lbsy.nc], sitespeed);
        }
      }
    }
  }
  else {
      
   #pragma omp parallel
   {
      double interforce_local_t[3], sitespeed_local_t[3];
      double *interforce = &interforce_local_t[0];
      double *sitespeed = &sitespeed_local_t[0];

      #pragma omp for
      for(il=0; il<Tmax; il++) {
        fGetOneSpeedSite(sitespeed, &lbf[il*lbsitelength]);
        double T = (lbsy.nt>0)?fGetTemperatureSite(il):lbsyst;
        if(lbneigh[il]>0 && lbphi[il]==0) {
          sitespeed[0] = 0.0; sitespeed[1] = 0.0; sitespeed[2] = 0.0;
        }
        if(lbphi[il] != 11) {
          for(int ll=0; ll<3; ll++)
            interforce [ll] = lbinterforce[il*3*lbsy.nf+ll] + postequil*lbbdforce[ll];
          if(lbphi[il] != 12 && lbphi[il] != 13)
            fSiteFluidCollisionMRTEDMSwiftOneFluid(&lbf[il*lbsitelength], sitespeed, &lbft[4*il], interforce, T);
          fSiteSoluteCollisionBGK(&lbf[il*lbsitelength + lbsy.nf], sitespeed);
          fSiteThermalCollisionBGK(&lbf[il*lbsitelength + lbsy.nf+lbsy.nc], sitespeed);
        }
      }
    }
  }
  return 0;
}

int fCollisionMRTGuoSwift()
{
  long il;
  int Tmax = lbdm.touter;

  if(lbsy.nf>1) {

   #pragma omp parallel
   {
      double interforce_local_t[3], sitespeed_local_t[3];
      double *interforce = &interforce_local_t[0];
      double *sitespeed = &sitespeed_local_t[0];

      #pragma omp for
      for(il=0; il<Tmax; il++) {
        fGetOneSpeedSite(sitespeed, &lbf[il*lbsitelength]);
        double T = (lbsy.nt>0)?fGetTemperatureSite(il):lbsyst;
        double frac = fGetFracSwiftSite(0, &lbf[il*lbsitelength]);
        if(lbneigh[il]>0 && lbphi[il]==0) {
          sitespeed[0] = 0.0; sitespeed[1] = 0.0; sitespeed[2] = 0.0;
        }
        if(lbphi[il] != 11) {
          for(int ll=0; ll<3; ll++)
            interforce [ll] = frac*(lbinterforce[il*3*lbsy.nf+ll] + postequil*lbbdforce[ll]) + (1.0-frac)*(lbinterforce[il*3*lbsy.nf+3+ll] + postequil*lbbdforce[3+ll]);
          if(lbphi[il] != 12 && lbphi[il] != 13)
            fSiteFluidCollisionMRTGuoSwiftTwoFluid(&lbf[il*lbsitelength], sitespeed, &lbft[8*il], interforce, T);
          fSiteSoluteCollisionBGK(&lbf[il*lbsitelength + lbsy.nf], sitespeed);
          fSiteThermalCollisionBGK(&lbf[il*lbsitelength + lbsy.nf+lbsy.nc], sitespeed);
        }
      }
    }
  }
  else {
      
   #pragma omp parallel
   {
      double interforce_local_t[3], sitespeed_local_t[3];
      double *interforce = &interforce_local_t[0];
      double *sitespeed = &sitespeed_local_t[0];

      #pragma omp for
      for(il=0; il<Tmax; il++) {
        fGetOneSpeedSite(sitespeed, &lbf[il*lbsitelength]);
        double T = (lbsy.nt>0)?fGetTemperatureSite(il):lbsyst;
        if(lbneigh[il]>0 && lbphi[il]==0) {
          sitespeed[0] = 0.0; sitespeed[1] = 0.0; sitespeed[2] = 0.0;
        }
        if(lbphi[il] != 11) {
          for(int ll=0; ll<3; ll++)
            interforce [ll] = lbinterforce[il*3*lbsy.nf+ll] + postequil*lbbdforce[ll];
          if(lbphi[il] != 12 && lbphi[il] != 13)
            fSiteFluidCollisionMRTGuoSwiftOneFluid(&lbf[il*lbsitelength], sitespeed, &lbft[4*il], interforce, T);
          fSiteSoluteCollisionBGK(&lbf[il*lbsitelength + lbsy.nf], sitespeed);
          fSiteThermalCollisionBGK(&lbf[il*lbsitelength + lbsy.nf+lbsy.nc], sitespeed);
        }
      }
    }
  }
  return 0;
}


