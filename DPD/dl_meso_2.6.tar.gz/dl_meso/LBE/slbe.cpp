#include "slbe.hpp"

int main(int argc, char* argv[])
{
  bigend = fBigEndian();
  lbcurstep = 0;
  fDefineSystem();
  fSetSerialDomain();
  fStartDLMESO();
  fMemoryAllocation();
  fPrintSystemInfo();
  fsPrintDomainInfo();
  fInputParameters();
  fReadSpaceParameter();
  fGetModel();
  fNeighbourBoundary();
  fInitializeSystem();
  fReadInitialState();
  if(outformat==2)  // Grid for Plot3D output files
    fsOutputGrid(); 
  if(interact==1 || interact==2)
    fCalcPotential_ShanChen();
  timetotal=fCheckTimeSerial();
  switch (interact) {
    case 0:
    // no mesoscopic interactions
      switch (collide) {
        case 0:
          fsBGK();
          break;
        case 1:
          fsBGKEDM();
          break;
        case 2:
          fsBGKGuo();
          break;
        case 3:
          fsTRT();
          break;
        case 4:
          fsTRTEDM();
          break;
        case 5:
          fsTRTGuo();
          break;
        case 6:
          fsMRT();
          break;
        case 7:
          fsMRTEDM();
          break;
        case 8:
          fsMRTGuo();
          break;
      }
      break;
    case 1:
    // Shan/Chen pseudopotential interactions
      switch (collide) {
        case 0:
          fsBGKShanChen();
          break;
        case 1:
          fsBGKEDMShanChen();
          break;
        case 2:
          fsBGKGuoShanChen();
          break;
        case 3:
          fsTRTShanChen();
          break;
        case 4:
          fsTRTEDMShanChen();
          break;
        case 5:
          fsTRTGuoShanChen();
          break;
        case 6:
          fsMRTShanChen();
          break;
        case 7:
          fsMRTEDMShanChen();
          break;
        case 8:
          fsMRTGuoShanChen();
          break;
      }
      break;
    case 2:
    // Shan/Chen pseudopotential interactions with quadratic pseudopotential term
      switch (collide) {
        case 0:
          fsBGKShanChenQuadratic();
          break;
        case 1:
          fsBGKEDMShanChenQuadratic();
          break;
        case 2:
          fsBGKGuoShanChenQuadratic();
          break;
        case 3:
          fsTRTShanChenQuadratic();
          break;
        case 4:
          fsTRTEDMShanChenQuadratic();
          break;
        case 5:
          fsTRTGuoShanChenQuadratic();
          break;
        case 6:
          fsMRTShanChenQuadratic();
          break;
        case 7:
          fsMRTEDMShanChenQuadratic();
          break;
        case 8:
          fsMRTGuoShanChenQuadratic();
          break;
      }
      break;
    case 3:
    // Lishchuk continuum-based interactions (with interfacial normals determined non-locally)
      switch (collide) {
        case 0:
          fsBGKLishchuk();
          break;
        case 1:
          fsBGKEDMLishchuk();
          break;
        case 2:
          fsBGKGuoLishchuk();
          break;
        case 3:
          fsTRTLishchuk();
          break;
        case 4:
          fsTRTEDMLishchuk();
          break;
        case 5:
          fsTRTGuoLishchuk();
          break;
        case 6:
          fsMRTLishchuk();
          break;
        case 7:
          fsMRTEDMLishchuk();
          break;
        case 8:
          fsMRTGuoLishchuk();
          break;
      }
      break;
    case 4:
    // Lishchuk continuum-based interactions (with interfacial normals determined locally)
      switch (collide) {
        case 0:
          fsBGKLishchukLocal();
          break;
        case 1:
          fsBGKEDMLishchukLocal();
          break;
        case 2:
          fsBGKGuoLishchukLocal();
          break;
        case 3:
          fsTRTLishchukLocal();
          break;
        case 4:
          fsTRTEDMLishchukLocal();
          break;
        case 5:
          fsTRTGuoLishchukLocal();
          break;
        case 6:
          fsMRTLishchukLocal();
          break;
        case 7:
          fsMRTEDMLishchukLocal();
          break;
        case 8:
          fsMRTGuoLishchukLocal();
          break;
      }
      break;
    case 5:
    // Swift free-energy interactions
      switch (collide) {
        case 0:
          fsBGKSwift();
          break;
        case 1:
          fsBGKEDMSwift();
          break;
        case 2:
          fsBGKGuoSwift();
          break;
        case 3:
          fsTRTSwift();
          break;
        case 4:
          fsTRTEDMSwift();
          break;
        case 5:
          fsTRTGuoSwift();
          break;
        case 6:
          fsMRTSwift();
          break;
        case 7:
          fsMRTEDMSwift();
          break;
        case 8:
          fsMRTGuoSwift();
          break;
      }
      break;
  }
  timetotal=fCheckTimeSerial();
  fFreeMemory();
  fFinishDLMESO();
  return 0;
}

