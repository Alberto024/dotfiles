int fOutputVTK(const char* filename);
int fsOutputVTK(const char* filename);

int fOutputVTKP(const char* filename, int prop);
int fsOutputVTKP(const char* filename, int prop);

int fOutputVTKCA(const char* filename, int iprop);
int fsOutputVTKCA(const char* filename, int iprop);

int fOutputVTKCB(const char* filename, int iprop);
int fsOutputVTKCB(const char* filename, int iprop);

int fOutputVTKT(const char* filename);
int fsOutputVTKT(const char* filename);

int fOutputVTK3D(const char* filename);
int fsOutputVTK3D(const char* filename);
int fOutputVTK2D(const char* filename);
int fsOutputVTK2D(const char* filename);

int fOutputVTKP3D(const char* filename, int prop);
int fsOutputVTKP3D(const char* filename, int prop);
int fOutputVTKP2D(const char* filename, int prop);
int fsOutputVTKP2D(const char* filename, int prop);

int fOutputVTKCA3D(const char* filename, int iprop);
int fsOutputVTKCA3D(const char* filename, int iprop);
int fOutputVTKCA2D(const char* filename, int iprop);
int fsOutputVTKCA2D(const char* filename, int iprop);

int fOutputVTKCB3D(const char* filename, int iprop);
int fsOutputVTKCB3D(const char* filename, int iprop);
int fOutputVTKCB2D(const char* filename, int iprop);
int fsOutputVTKCB2D(const char* filename, int iprop);

int fOutputVTKT3D(const char* filename);
int fsOutputVTKT3D(const char* filename);
int fOutputVTKT2D(const char* filename);
int fsOutputVTKT2D(const char* filename);
