int fOutputLegacyVTK(const char* filename);
int fsOutputLegacyVTK(const char* filename);

int fOutputLegacyVTKP(const char* filename, int iprop);
int fsOutputLegacyVTKP(const char* filename, int iprop);

int fOutputLegacyVTKCA(const char* filename, int iprop);
int fsOutputLegacyVTKCA(const char* filename, int iprop);

int fOutputLegacyVTKCB(const char* filename, int iprop);
int fsOutputLegacyVTKCB(const char* filename, int iprop);

int fOutputLegacyVTKT(const char* filename);
int fsOutputLegacyVTKT(const char* filename);

int fOutputLegacyVTK3D(const char* filename);
int fsOutputLegacyVTK3D(const char* filename);
int fOutputLegacyVTK2D(const char* filename);
int fsOutputLegacyVTK2D(const char* filename);

int fOutputLegacyVTKP3D(const char* filename, int iprop);
int fsOutputLegacyVTKP3D(const char* filename, int iprop);
int fOutputLegacyVTKP2D(const char* filename, int iprop);
int fsOutputLegacyVTKP2D(const char* filename, int iprop);

int fOutputLegacyVTKCA3D(const char* filename, int iprop);
int fsOutputLegacyVTKCA3D(const char* filename, int iprop);
int fOutputLegacyVTKCA2D(const char* filename, int iprop);
int fsOutputLegacyVTKCA2D(const char* filename, int iprop);

int fOutputLegacyVTKCB3D(const char* filename, int iprop);
int fsOutputLegacyVTKCB3D(const char* filename, int iprop);
int fOutputLegacyVTKCB2D(const char* filename, int iprop);
int fsOutputLegacyVTKCB2D(const char* filename, int iprop);

int fOutputLegacyVTKT3D(const char* filename);
int fsOutputLegacyVTKT3D(const char* filename);
int fOutputLegacyVTKT2D(const char* filename);
int fsOutputLegacyVTKT2D(const char* filename);
