long fNextStep(int q, int xpos, int ypos, int zpos);
long fNextStep(int q, int xpos, int ypos);
long fNextStep(int dx, int dy, int dz, long tpos);
int fBounceBackF(long tpos);
int fBounceBackC(long tpos);
int fBounceBackT(long tpos);
int fMidBounceBackF(long tpos);
int fMidBounceBackC(long tpos);
int fMidBounceBackT(long tpos);
int fSiteBlankF(long tpos);
int fSiteBlankC(long tpos);
int fSiteBlankT(long tpos);

int fD2Q9VCE(double v0, double v1, double *f0, double *f1, double *f2,
             double *f3, double *f4, double *f5, double *f6, double *f7, double *f8);
int fD2Q9VCC(double *v, double * startpos, long tpos);
int fD2Q9VCCSwift(double *v, double * startpos, double * delpos, double dx, double dy, long tpos, double T);
int fD2Q9VF(int tpos, int prop, double *uwall);
int fD2Q9PCE(double *p, double *f0, double *f1, double *f2, double *f3,
             double *f4, double *f5, double *f6, double *f7, double *f8, double &vel);
int fD2Q9PCESwift(double *p, double *f0, double *f1, double *f2, double *f3,
                  double *f4, double *f5, double *f6, double *f7, double *f8, double &vel);
int fD2Q9PCC(double *p, double *v, double * startpos);
int fD2Q9PCCSwift(double *p, double *v, double * startpos, double * delpos, double T);
int fD2Q9PF(int tpos, int prop, double *uwall);
int fD2Q9CCE(double *p, double v0, double v1, double *f0, double *f1, double *f2,
             double *f3, double *f4, double *f5, double *f6, double *f7, double *f8);
int fD2Q9CCC(double *p, double *v, double * startpos);
int fD2Q9PC(int tpos, int prop, double *uwall);
int fD2Q9TCE(double p, double v0, double v1, double *f0, double *f1, double *f2,
             double *f3, double *f4, double *f5, double *f6, double *f7, double *f8);
int fD2Q9TCC(double p, double *v, double * startpos);
int fD2Q9PT(int tpos, int prop, double *uwall);

int fD3Q15VPS(double v0, double v1, double v2, double *f0, double *f1,
              double *f2, double *f3, double *f4, double *f5,
              double *f6, double *f7, double *f8, double *f9,
              double *f10, double *f11, double *f12, double *f13,
              double *f14);
int fD3Q15VCE(double *v, double * startpos, long tpos);
int fD3Q15VCESwift(double *v, double * startpos, double * delpos, double dx, double dy, double dz, long tpos, double T);
int fD3Q15VF(int tpos, int prop, double *uwall);
int fD3Q15PPS(double *p, double *f0, double *f1,
              double *f2, double *f3, double *f4, double *f5,
              double *f6, double *f7, double *f8, double *f9,
              double *f10, double *f11, double *f12, double *f13,
              double *f14, double &vel);
int fD3Q15PPSSwift(double *p, double *f0, double *f1,
                   double *f2, double *f3, double *f4, double *f5,
                   double *f6, double *f7, double *f8, double *f9,
                   double *f10, double *f11, double *f12, double *f13,
                   double *f14, double &vel);
int fD3Q15PCE(double *p, double *v, double * startpos);
int fD3Q15PCESwift(double *p, double *v, double * startpos, double * delpos, double T);
int fD3Q15PF(int tpos, int prop, double *uwall);
int fD3Q15CPS(double *p, double v0, double v1, double v2, double *f0, double *f1,
              double *f2, double *f3, double *f4, double *f5, double *f6,
              double *f7, double *f8, double *f9, double *f10, double *f11,
              double *f12, double *f13, double *f14);
int fD3Q15CCE(double *p, double *v, double * startpos);
int fD3Q15PC(int tpos, int prop, double *uwall);
int fD3Q15TPS(double p, double v0, double v1, double v2, double *f0, double *f1,
              double *f2, double *f3, double *f4, double *f5, double *f6,
              double *f7, double *f8, double *f9, double *f10, double *f11,
              double *f12, double *f13, double *f14);
int fD3Q15TCE(double p, double *v, double * startpos);
int fD3Q15PT(int tpos, int prop, double *uwall);

int fD3Q19VPS(double v0, double v1, double v2, double *f0, double *f1,
              double *f2, double *f3, double *f4, double *f5,
              double *f6, double *f7, double *f8, double *f9,
              double *f10, double *f11, double *f12, double *f13,
              double *f14, double *f15, double *f16, double *f17,
              double *f18);
int fD3Q19VCE(double *v, double * startpos, long tpos);
int fD3Q19VCESwift(double *v, double * startpos, double * delpos, double dx, double dy, double dz, long tpos, double T);
int fD3Q19VF(int tpos, int prop, double *uwall);
int fD3Q19PPS(double *p, double *f0, double *f1,
              double *f2, double *f3, double *f4, double *f5,
              double *f6, double *f7, double *f8, double *f9,
              double *f10, double *f11, double *f12, double *f13,
              double *f14, double *f15, double *f16, double *f17,
              double *f18, double &vel);
int fD3Q19PPSSwift(double *p, double *f0, double *f1,
                   double *f2, double *f3, double *f4, double *f5,
                   double *f6, double *f7, double *f8, double *f9,
                   double *f10, double *f11, double *f12, double *f13,
                   double *f14, double *f15, double *f16, double *f17,
                   double *f18, double &vel);
int fD3Q19PCE(double *p, double *v, double * startpos);
int fD3Q19PCESwift(double *p, double *v, double * startpos, double * delpos, double T);
int fD3Q19PF(int tpos, int prop, double *uwall);
int fD3Q19CPS(double *p, double v0, double v1, double v2, double *f0, double *f1,
              double *f2, double *f3, double *f4, double *f5, double *f6,
              double *f7, double *f8, double *f9, double *f10, double *f11,
              double *f12, double *f13, double *f14, double *f15, double *f16,
              double *f17, double *f18);
int fD3Q19CCE(double *p, double *v, double * startpos);
int fD3Q19PC(int tpos, int prop, double *uwall);
int fD3Q19TPS(double p, double v0, double v1, double v2, double *f0, double *f1,
              double *f2, double *f3, double *f4, double *f5, double *f6,
              double *f7, double *f8, double *f9, double *f10, double *f11,
              double *f12, double *f13, double *f14, double *f15, double *f16,
              double *f17, double *f18);
int fD3Q19TCE(double p, double *v, double * startpos);
int fD3Q19PT(int tpos, int prop, double *uwall);

int fD3Q27VPS(double v0, double v1, double v2, double *f0, double *f1,
              double *f2, double *f3, double *f4, double *f5,
              double *f6, double *f7, double *f8, double *f9,
              double *f10, double *f11, double *f12, double *f13,
              double *f14, double *f15, double *f16, double *f17,
              double *f18, double *f19, double *f20, double *f21,
              double *f22, double *f23, double *f24, double *f25,
              double *f26);
int fD3Q27VCE(double *v, double * startpos, long tpos);
int fD3Q27VF(int tpos, int prop, double *uwall);
int fD3Q27PPS(double *p, double *f0, double *f1,
              double *f2, double *f3, double *f4, double *f5,
              double *f6, double *f7, double *f8, double *f9,
              double *f10, double *f11, double *f12, double *f13,
              double *f14, double *f15, double *f16, double *f17,
              double *f18, double *f19, double *f20, double *f21,
              double *f22, double *f23, double *f24, double *f25,
              double *f26, double &vel);
int fD3Q27PCE(double *p, double *v, double * startpos);
int fD3Q27PF(int tpos, int prop, double *uwall);
int fD3Q27CPS(double *p, double v0, double v1, double v2, double *f0, double *f1,
              double *f2, double *f3, double *f4, double *f5, double *f6,
              double *f7, double *f8, double *f9, double *f10, double *f11,
              double *f12, double *f13, double *f14, double *f15, double *f16,
              double *f17, double *f18, double *f19, double *f20, double *f21,
              double *f22, double *f23, double *f24, double *f25, double *f26);
int fD3Q27CCE(double p, double *v, double * startpos);
int fD3Q27PC(int tpos, int prop, double *uwall);
int fD3Q27TPS(double p, double v0, double v1, double v2, double *f0, double *f1,
              double *f2, double *f3, double *f4, double *f5, double *f6,
              double *f7, double *f8, double *f9, double *f10, double *f11,
              double *f12, double *f13, double *f14, double *f15, double *f16,
              double *f17, double *f18, double *f19, double *f20, double *f21,
              double *f22, double *f23, double *f24, double *f25, double *f26);
int fD3Q27TCE(double p, double *v, double * startpos);
int fD3Q27PT(int tpos, int prop, double *uwall);

int fFixedSpeedFluid(int tpos, int prop, double *uwall);
int fFixedDensityFluid(int tpos, int prop, double *uwall);
int fFixedSoluteConcen(int tpos, int prop, double *uwall);
int fFixedTemperature(int tpos, int prop, double *uwall);
int fPostCollBoundary();
int fPostPropBoundary();
int fNeighbourBoundary();
int fsPeriodic();
int fsBoundPeriodic();
int fsForcePeriodic();
int fsIndexPeriodic();
int fsPeriodic2D();
int fsPeriodic3D();
int fsBoundPeriodic2D();
int fsBoundPeriodic3D();
int fsForcePeriodic2D();
int fsForcePeriodic3D();
int fsIndexPeriodic2D();
int fsIndexPeriodic3D();

