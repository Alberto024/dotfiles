#include "slbe.hpp"

int main(int argc, char* argv[])
{
  bigend = fBigEndian();
  fDefineSystem();
  fSetSerialDomain();
  fStartDLMESO();
  fMemoryAllocation();
  fPrintSystemInfo();
  fInputParameters();
  fReadSpaceParameter();
  fNeighbourBoundary();
  fGetModel();
  fInitializeSystem();
  fReadInitialState();
  if(outformat==2)                   // Grid for Plot3D output files
    fsOutputGrid(); 
  timetotal=fCheckTimeSerial();
  for(lbcurstep=0; lbcurstep<= lbtotstep; lbcurstep++) {
    if(i%lbsave  == 0) {
      fsOutputVTKP();                // Substitute with required file type and/or output
      qVersion++;
      cout << lbcurstep << " \t ";
      fPrintDomainMass();
      fPrintDomainMomentum();
    }
    fInteractionForceZero();         // Remove if no Boussinesq forces or mesophase interactions used
    fCalcPotential_ShanChen();       // Substitute with required potential/phase index/density/concentration gradients
                                     // (or remove if no mesophase interactions required)
    fsInteractionForceShanChen();    // Substitute with required mesophase interactions and/or add additional forces
    fCollisionBGK();                 // Substitute with required collision and forcing algorithm
    fPostCollBoundary();
    fPropagationSwap();
    fPostPropBoundary();
  }
  timetotal=fCheckTimeSerial();
  fFreeMemory();
  fFinishDLMESO();
  return 0;
}

    
