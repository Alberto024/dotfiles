/***********************************************
 *   DL_MESO       Version 2.6                 *
 *   Authors   :   R. S. Qin, M. A. Seaton     *
 *   Copyright :   STFC Daresbury Laboratory   *
 *             :   22/10/2015                  *
 ***********************************************/

inline long fGetNodePosi(int xpos, int ypos, int zpos)
{
  return (xpos * lbdm.youter + ypos) * lbdm.zouter + zpos;
}

inline long fGetNodePosi(int xpos, int ypos)
{
  return xpos * lbdm.youter + ypos;
}

int fGetCoord(long tpos, int& xpos, int& ypos, int& zpos)
{
  zpos = tpos % lbdm.zouter;
  xpos = int (tpos / (lbdm.youter * lbdm.zouter));
  ypos = int(tpos % (lbdm.youter * lbdm.zouter)) / lbdm.zouter;
  return 0;
}

int fGetCoord(long tpos, int& xpos, int& ypos)
{
  ypos = tpos % lbdm.youter;
  xpos = int(tpos / lbdm.youter);
  return 0;
}

double fGetOneMassSite(double* startpos)
{

  // calculate mass density at grid position starting from startpos in lbf[] 
  // array

  double mass=0.0;
  double *pt1=startpos;
  int qdim = lbsy.nf+lbsy.nc+lbsy.nt;

  for(int i=0; i<lbsy.nq; i++) {
    mass += pt1[i*qdim];
  }
  pt1 = NULL;
  return mass;
}


int fGetAllMassSite(double *rho, double* startpos)
{

  // calculate mass densities at grid position starting from startpos in lbf[]
  // array

  double *pt1 = startpos;
  int qdim = lbsy.nf+lbsy.nc+lbsy.nt;
    
  for(int i=0; i<lbsy.nf; i++)
    rho[i] = 0.0;
    
  for(int i=0; i<lbsy.nq; i++) {
    for(int j=0; j<lbsy.nf; j++) {
      rho[j] += pt1[i*qdim+j];
    }
  }
  pt1 = NULL;
  return 0;
}


double fGetTotMassSite(double* startpos)
{

  // calculate total mass at grid position starting from startpos in lbf[] 
  // array

  double mass=0.0;
  double *pt1 = startpos;
  int qdim = lbsy.nf+lbsy.nc+lbsy.nt;
    
  for(int i=0; i<lbsy.nq; i++) {
    for(int j=0; j<lbsy.nf; j++) {
      mass += pt1[i*qdim+j];
    }
  }
  pt1 = NULL;
  return mass;
}


int fGetAllConcSite(double *rho, double* startpos)
{

  // calculate concentrations at grid position starting from startpos in lbf[]
  // array

  double *pt1 = startpos;
  int qdim = lbsy.nf+lbsy.nc+lbsy.nt;
    
  for(int i=0; i<lbsy.nc; i++)
    rho[i] = 0.0;
    
  for(int i=0; i<lbsy.nq; i++) {
    for(int j=0; j<lbsy.nc; j++) {
      rho[j] += pt1[i*qdim+j];
    }
  }
  pt1 = NULL;
  return 0;
}


double fGetOneMassDomain(int fpos)
{

  // calculate total mass of one fluid in the domain

  double totmass =0;
  for(long il=0; il<lbdm.touter; il++)
    if(lbphi[il] == 0)
      totmass += fGetOneMassSite(&lbf[il * lbsitelength + fpos]);
  return totmass;
}


double fGetOneMassSwiftDomain(int fpos)
{

  // calculate total mass of one fluid in the domain with Swift free-energy interactions

  double totmass =0;
  double rho[lbsy.nf];
  if(lbsy.nf>1) {
    switch (fpos) {
      case 0:
        for(long il=0; il<lbdm.touter; il++) {
          if(lbphi[il]==0) {
            fGetAllMassSite(&lbf[il*lbsitelength], rho);
            totmass += 0.5*rho[0]*(1.0+rho[1]);
          }
        }
        break;
      case 1:
        for(long il=0; il<lbdm.touter; il++) {
          if(lbphi[il]==0) {
            fGetAllMassSite(&lbf[il*lbsitelength], rho);
            totmass += 0.5*rho[0]*(1.0-rho[1]);
          }
        }
        break;
    }
  }
  else {
    for(long il=0; il<lbdm.touter; il++) {
      if(lbphi[il]==0)
        totmass += fGetOneMassSite(&lbf[il*lbsitelength]);
    }
  }
  return totmass;
}


double fGetTotMassDomain()
{

  // calculate total mass of all fluids in the domain

  double totmass =0;
  for(long il=0; il<lbdm.touter; il++)
    if(lbphi[il] == 0)
      totmass +=  fGetTotMassSite(&lbf[il * lbsitelength]);
  return totmass;
}


double fGetFracSite(int fpos, double* startpos)
{

  // calculate mass fraction of fpos phase at grid position starting from 
  // startpos in lbf[] array

  int qdim = lbsy.nf+lbsy.nc+lbsy.nt;
  double mass=0.0, fmass=0.0;
  double *pt1 = startpos;
    
  for(int i=0; i<lbsy.nq; i++) {
    fmass += pt1[i*qdim + fpos];
    for(int j=0; j<lbsy.nf; j++) 
      mass += pt1[i*qdim+j];
  }
  pt1 = NULL;

  if(mass<lbevaplim) return 0.0;
    
  return fmass*fReciprocal(mass);
}

double fGetFracSwiftSite(int fpos, double* startpos)
{

  // calculate mass fraction of fpos phase at grid position starting from 
  // startpos in lbf[] array for Swift free-energy interactions

  int qdim = lbsy.nf+lbsy.nc+lbsy.nt;
  double phi=0.0, fmass;
  double *pt1 = startpos;
    
  for(int i=0; i<lbsy.nq; i++)
    phi += pt1[i*qdim+1];

  pt1 = NULL;

  switch (fpos) {
    case 0:
      fmass = 0.5*(1.0+phi);
      break;
    case 1:
      fmass = 0.5*(1.0-phi);
      break;
  }
  
  return fmass;
}

int fGetOneSpeedSite(double *speed, double* startpos)
{

  // calculate macroscopic speed of one fluid at grid position starting from 
  // startpos in lbf[] array
  
  double mass=0.0;
  double *pt1 = startpos;
  int qdim = lbsy.nf+lbsy.nc+lbsy.nt;
    
  speed[0]=0; speed[1]=0; speed[2]=0;
  for(int i=0; i<lbsy.nq; i++) {
    mass += pt1[i*qdim];
    speed[0] += pt1[i*qdim] * lbvx[i];
    speed[1] += pt1[i*qdim] * lbvy[i];
    speed[2] += pt1[i*qdim] * lbvz[i];
  }
  pt1 = NULL;

  speed[0] *= fReciprocal(mass);
  speed[1] *= fReciprocal(mass);
  speed[2] *= fReciprocal(mass); 
  return 0;
}

int fGetOneSpeedIncomSite(double *speed, double* startpos, double rho0)
{

  // calculate macroscopic speed of one incompressible fluid at grid position 
  // starting from startpos in lbf[] array
  
  double *pt1 = startpos;
  int qdim = lbsy.nf+lbsy.nc+lbsy.nt;

  speed[0]=0; speed[1]=0; speed[2]=0;
  for(int i=0; i<lbsy.nq; i++) {
    speed[0] += pt1[i*qdim] * lbvx[i];
    speed[1] += pt1[i*qdim] * lbvy[i];
    speed[2] += pt1[i*qdim] * lbvz[i];
  }
  pt1 = NULL;

  speed[0] *= fReciprocal(rho0);
  speed[1] *= fReciprocal(rho0);
  speed[2] *= fReciprocal(rho0); 
  return 0;
}

int fGetOneMomentSite(double *speed, double* startpos)
{
  
  // calculate momentum of one fluid at grid position starting from startpos 
  // in lbf[] array
  
  double *pt1 = startpos;
  int qdim = lbsy.nf+lbsy.nc+lbsy.nt;

  speed[0]=0; speed[1]=0; speed[2]=0;
  for(int i=0; i<lbsy.nq; i++) {
    speed[0] += pt1[i*qdim] * lbvx[i];
    speed[1] += pt1[i*qdim] * lbvy[i];
    speed[2] += pt1[i*qdim] * lbvz[i];
  }
  pt1 = NULL;
  return 0;
}



int fGetTotMomentSite(double *momentum, double* startpos)
{

  // calculate momentum of all fluids at grid position starting from startpos 
  // in lbf[] array
  
  double *pt1 = startpos;
  int qdim = lbsy.nf+lbsy.nc+lbsy.nt;
    
  momentum[0]=0; momentum[1]=0; momentum[2]=0;
  for(int i=0; i<lbsy.nq; i++) {
    for(int j=0; j<lbsy.nf; j++) {
      momentum[0] += pt1[i*qdim+j] * lbvx[i];
      momentum[1] += pt1[i*qdim+j] * lbvy[i];
      momentum[2] += pt1[i*qdim+j] * lbvz[i];
    }
  }
  pt1 = NULL;
  return 0;
}


int fGetTotMomentDomain(double *momentum)
{

  // calculate total momentum of all fluids in the domain

  double speed[3];
  for(int i=0; i<3; i++)
    momentum[i] = 0;
    
  for(long il=0; il<lbdm.touter; il++)
    if(lbphi[il] == 0) {
      fGetTotMomentSite(speed, &lbf[il * lbsitelength]);
      for(int i=0; i<3; i++) 
 	    momentum[i] += speed[i];
    }
    
  return 0;  
}


int fGetTotMomentSwiftDomain(double *momentum)
{

  // calculate total momentum of all fluids
  // with Swift free-energy interactions in the domain

  double speed[3];
  for(int i=0; i<3; i++)
    momentum[i] = 0;
    
  for(long il=0; il<lbdm.touter; il++)
    if(lbphi[il] == 0) {
      fGetOneMomentSite(speed, &lbf[il * lbsitelength]);
      for(int i=0; i<3; i++) 
 	    momentum[i] += speed[i];
    }
    
  return 0;  
}


int fGetSpeedSite(double *speed, double* startpos)
{

  // calculate macroscopic speed of all fluids at grid position starting from 
  // startpos in lbf[] array
  
  double mass=0.0,invmass;
  double *pt1 = startpos;
  int qdim = lbsy.nf+lbsy.nc+lbsy.nt;
    
  speed[0]=0; speed[1]=0; speed[2]=0;

  for(int i=0; i<lbsy.nq; i++) {
    for(int j=0; j<lbsy.nf; j++) {
      mass += pt1[i*qdim+j];
      speed[0] += pt1[i*qdim+j] * lbvx[i];
      speed[1] += pt1[i*qdim+j] * lbvy[i];
      speed[2] += pt1[i*qdim+j] * lbvz[i];
    }
  }
    
  invmass = fReciprocal(mass);
  speed[0] *= invmass;
  speed[1] *= invmass;
  speed[2] *= invmass; 
  return 0;
}


int fGetSpeedIncomSite(double *speed, double* startpos)
{

  // calculate macroscopic speed of all incompressible fluids at grid position
  // starting from startpos in lbf[] array
  
  double mass=0.0;
  double *pt1 = startpos;
  int qdim = lbsy.nf+lbsy.nc+lbsy.nt;

  speed[0]=0; speed[1]=0; speed[2]=0;

  for(int j=0; j<lbsy.nf; j++)
    mass += lbincp[j];

  for(int i=0; i<lbsy.nq; i++) {
    for(int j=0; j<lbsy.nf; j++) {
      speed[0] += pt1[i*qdim+j] * lbvx[i];
      speed[1] += pt1[i*qdim+j] * lbvy[i];
      speed[2] += pt1[i*qdim+j] * lbvz[i];
    }
  }
  pt1 = NULL;
  
  speed[0] *= fReciprocal(mass);
  speed[1] *= fReciprocal(mass);
  speed[2] *= fReciprocal(mass); 
  return 0;
}


int fGetSpeedShanChenSite(double *speed, double* startpos)
{

  // calculate macroscopic speed of all fluids at grid position starting from 
  // startpos in lbf[] array for Shan-Chen interactions
  
  double mass=0.0,invmass;
  double *pt1 = startpos;
  int qdim = lbsy.nf+lbsy.nc+lbsy.nt;
    
  speed[0]=0; speed[1]=0; speed[2]=0;

  for(int i=0; i<lbsy.nq; i++) {
    for(int j=0; j<lbsy.nf; j++) {
      mass += lbtf[j] * pt1[i*qdim+j];
      speed[0] += lbtf[j] * pt1[i*qdim+j] * lbvx[i];
      speed[1] += lbtf[j] * pt1[i*qdim+j] * lbvy[i];
      speed[2] += lbtf[j] * pt1[i*qdim+j] * lbvz[i];
    }
  }
    
  invmass = fReciprocal(mass);
  speed[0] *= invmass;
  speed[1] *= invmass;
  speed[2] *= invmass; 
  return 0;
}


int fGetSpeedShanChenIncomSite(double *speed, double* startpos)
{

  // calculate macroscopic speed of all incompressible fluids at grid position
  // starting from startpos in lbf[] array for Shan-Chen interactions
  
  double mass=0.0;
  double *pt1 = startpos;
  int qdim = lbsy.nf+lbsy.nc+lbsy.nt;

  speed[0]=0; speed[1]=0; speed[2]=0;

  for(int j=0; j<lbsy.nf; j++)
    mass += lbtf[j] * lbincp[j];

  for(int i=0; i<lbsy.nq; i++) {
    for(int j=0; j<lbsy.nf; j++) {
      speed[0] += lbtf[j] * pt1[i*qdim+j] * lbvx[i];
      speed[1] += lbtf[j] * pt1[i*qdim+j] * lbvy[i];
      speed[2] += lbtf[j] * pt1[i*qdim+j] * lbvz[i];
    }
  }
  pt1 = NULL;
  
  speed[0] *= fReciprocal(mass);
  speed[1] *= fReciprocal(mass);
  speed[2] *= fReciprocal(mass); 
  return 0;
}


float fGetOneDirecSpeedSite(int dire, double* startpos)
{

  // calculate site speed along direction dire at grid position starting from 
  // startpos in lbf[] array

  double speed=0.0;
  double mass=0.0;
  double *pt1 = startpos;
  int qdim = lbsy.nf+lbsy.nc+lbsy.nt;
    
  switch (dire) {
    case 0:
      for(int i=0; i<lbsy.nq; i++) {
        for(int j=0; j<lbsy.nf; j++) {
          mass += pt1[i*qdim+j];
          speed += pt1[i*qdim+j] * lbvx[i];
        }
      }
      break;
    case 1:
      for(int i=0; i<lbsy.nq; i++) {
        for(int j=0; j<lbsy.nf; j++) {
          mass += pt1[i*qdim+j];
          speed += pt1[i*qdim+j] * lbvy[i];
        }
      }
      break;
    case 2:
      for(int i=0; i<lbsy.nq; i++) {
        for(int j=0; j<lbsy.nf; j++) {
          mass += pt1[i*qdim+j];
          speed += pt1[i*qdim+j] * lbvz[i];
        }
      }
      break;
  }
  pt1 = NULL;
  if(mass<lbevaplim) return 0.0;
  return float(speed*fReciprocal(mass));
}


float fGetOneDirecSpeedIncomSite(int dire, double* startpos)
{

  // calculate site speed for incompressible fluid along direction dire
  // at grid position starting from startpos in lbf[] array

  double speed = 0;
  double mass=0.0;
  double *pt1 = startpos;
  int qdim = lbsy.nf+lbsy.nc+lbsy.nt;

  for(int j=0; j<lbsy.nf; j++)
    mass += lbincp[j];

  switch (dire) {
    case 0:
      for(int i=0; i<lbsy.nq; i++) {
        for(int j=0; j<lbsy.nf; j++) {
          speed += pt1[i*qdim+j] * lbvx[i];
        }
      }
      break;
    case 1:
      for(int i=0; i<lbsy.nq; i++) {
        for(int j=0; j<lbsy.nf; j++) {
          speed += pt1[i*qdim+j] * lbvy[i];
        }
      }
      break;
    case 2:
      for(int i=0; i<lbsy.nq; i++) {
        for(int j=0; j<lbsy.nf; j++) {
          speed += pt1[i*qdim+j] * lbvz[i];
        }
      }
      break;
  }
  pt1 = NULL;
  return float(speed*fReciprocal(mass));
}


float fGetOneDirecSpeedSwiftSite(int dire, double* startpos)
{

  // calculate site speed along direction dire at grid position starting from 
  // startpos in lbf[] array for Swift free-energy interactions

  double speed=0.0;
  double mass=0.0;
  double *pt1 = startpos;
  int qdim = lbsy.nf+lbsy.nc+lbsy.nt;
    
  switch (dire) {
    case 0:
      for(int i=0; i<lbsy.nq; i++) {
        mass += pt1[i*qdim];
        speed += pt1[i*qdim] * lbvx[i];
      }
      break;
    case 1:
      for(int i=0; i<lbsy.nq; i++) {
        mass += pt1[i*qdim];
        speed += pt1[i*qdim] * lbvy[i];
      }
      break;
    case 2:
      for(int i=0; i<lbsy.nq; i++) {
        mass += pt1[i*qdim];
        speed += pt1[i*qdim] * lbvz[i];
      }
      break;
  }
  pt1 = NULL;
  if(mass<lbevaplim) return 0.0;
  return float(speed*fReciprocal(mass));
}


double fGetOneMassSite(int fpos, long tpos)
{
  return fGetOneMassSite(&lbf[tpos * lbsitelength + fpos]);
}

double fGetOneMassSite(int fpos, int xpos, int ypos, int zpos)
{
  return fGetOneMassSite(&lbf[((xpos * lbdm.youter + ypos) * lbdm.zouter + zpos)
			    * lbsitelength + fpos]);
}

int fGetAllMassSite(double *rho, long tpos)
{
  fGetAllMassSite(rho, &lbf[tpos * lbsitelength]);
  return 0;
}

int fGetAllMassSite(double *rho, int xpos, int ypos, int zpos)
{
  fGetAllMassSite(rho, &lbf[((xpos *lbdm.youter + ypos)*lbdm.zouter+zpos)
                            * lbsitelength]);
  return 0;
}

double fGetTotMassSite(long tpos)
{
  return fGetTotMassSite(&lbf[tpos * lbsitelength]);
}

double fGetFracSite(int fpos, long tpos)
{
  return fGetFracSite(fpos, &lbf[tpos * lbsitelength]);
}

double fGetFracSite(int fpos, int xpos, int ypos, int zpos)
{
  return fGetFracSite(fpos,&lbf[((xpos *lbdm.youter + ypos)*lbdm.zouter+zpos)
			      * lbsitelength]);
}


double fGetFracSwiftSite(int fpos, long tpos)
{
  return fGetFracSwiftSite(fpos, &lbf[tpos * lbsitelength]);
}

double fGetFracSwiftSite(int fpos, int xpos, int ypos, int zpos)
{
  return fGetFracSwiftSite(fpos,&lbf[((xpos *lbdm.youter + ypos)*lbdm.zouter+zpos)
			      * lbsitelength]);
}


double fGetOneConcSite(int cpos, long tpos)
{
  return fGetOneMassSite(&lbf[tpos*lbsitelength+lbsy.nf+cpos]);
}

double fGetOneConcSite(int cpos, int xpos, int ypos, int zpos)
{
  return fGetOneMassSite(&lbf[((xpos * lbdm.youter + ypos) * lbdm.zouter 
			      + zpos) *lbsitelength+lbsy.nf + cpos]);
}


double fGetTemperatureSite(long tpos)
{
  return fGetOneMassSite(&lbf[tpos*lbsitelength + lbsy.nf + lbsy.nc]);
}

double fGetTemperatureSite(long xpos, long ypos, long zpos)
{
  return fGetOneMassSite(&lbf[((xpos * lbdm.youter + ypos) * lbdm.zouter + zpos)
                              * lbsitelength + lbsy.nf + lbsy.nc]);
}



int fGetOneSpeedSite(double *speed, int fpos, int xpos, int ypos, int zpos)
{
  fGetOneSpeedSite(speed, &lbf[((xpos * lbdm.youter + ypos) * lbdm.zouter + zpos)
                               * lbsitelength + fpos]);
  return 0;
}

int fGetOneSpeedSite(double *speed, int fpos, long tpos)
{
  fGetOneSpeedSite(speed, &lbf[tpos * lbsitelength + fpos]);
  return 0;
}

int fGetOneSpeedIncomSite(double *speed, int fpos, int xpos, int ypos, int zpos)
{
  fGetOneSpeedIncomSite(speed, &lbf[((xpos * lbdm.youter + ypos) * lbdm.zouter + zpos)
                                    * lbsitelength + fpos], lbincp[fpos]);
  return 0;
}

int fGetOneSpeedIncomSite(double *speed, int fpos, long tpos)
{
  fGetOneSpeedIncomSite(speed, &lbf[tpos * lbsitelength + fpos], lbincp[fpos]);
  return 0;
}


int fGetOneMomentSite(double *speed, int fpos, int xpos, int ypos, int zpos)
{
  fGetOneMomentSite(speed, &lbf[((xpos * lbdm.youter + ypos) * lbdm.zouter + zpos)
                                * lbsitelength + fpos]);
  return 0;
}

int fGetOneMomentSite(double *speed, int fpos, long tpos)
{
  fGetOneMomentSite(speed, &lbf[tpos * lbsitelength + fpos]);
  return 0;
}


int fGetSpeedSite(double *speed, int xpos, int ypos, int zpos)
{
  fGetSpeedSite(speed, &lbf[((xpos * lbdm.youter + ypos) * lbdm.zouter + zpos) * lbsitelength]);
  return 0;
}

int fGetSpeedSite(double *speed, long tpos)
{
  fGetSpeedSite(speed, &lbf[tpos * lbsitelength]);
  return 0;
}


int fGetSpeedIncomSite(double *speed, int xpos, int ypos, int zpos)
{
  fGetSpeedIncomSite(speed, &lbf[((xpos * lbdm.youter + ypos) * lbdm.zouter + zpos) * lbsitelength]);
  return 0;
}

int fGetSpeedIncomSite(double *speed, long tpos)
{
  fGetSpeedIncomSite(speed, &lbf[tpos * lbsitelength]);
  return 0;
}


int fGetSpeedShanChenSite(double *speed, int xpos, int ypos, int zpos)
{
  fGetSpeedShanChenSite(speed, &lbf[((xpos * lbdm.youter + ypos) * lbdm.zouter + zpos) * lbsitelength]);
  return 0;
}

int fGetSpeedShanChenSite(double *speed, long tpos)
{
  fGetSpeedShanChenSite(speed, &lbf[tpos * lbsitelength]);
  return 0;
}


int fGetSpeedShanChenIncomSite(double *speed, int xpos, int ypos, int zpos)
{
  fGetSpeedShanChenIncomSite(speed, &lbf[((xpos * lbdm.youter + ypos) * lbdm.zouter + zpos) * lbsitelength]);
  return 0;
}

int fGetSpeedShanChenIncomSite(double *speed, long tpos)
{
  fGetSpeedShanChenIncomSite(speed, &lbf[tpos * lbsitelength]);
  return 0;
}


float fGetOneDirecSpeedSite(int dire, int xpos, int ypos, int zpos)
{
  return fGetOneDirecSpeedSite(dire, &lbf[((xpos * lbdm.youter + ypos) * lbdm.zouter + zpos) * lbsitelength]);
}

float fGetOneDirecSpeedSite(int dire, long tpos)
{
  return fGetOneDirecSpeedSite(dire, &lbf[tpos * lbsitelength]);
}

float fGetOneDirecSpeedIncomSite(int dire, int xpos, int ypos, int zpos)
{
  return fGetOneDirecSpeedIncomSite(dire, &lbf[((xpos * lbdm.youter + ypos) * lbdm.zouter + zpos) * lbsitelength]);
}

float fGetOneDirecSpeedIncomSite(int dire, long tpos)
{
  return fGetOneDirecSpeedIncomSite(dire, &lbf[tpos * lbsitelength]);
}

float fGetOneDirecSpeedSwiftSite(int dire, int xpos, int ypos, int zpos)
{
  return fGetOneDirecSpeedSwiftSite(dire, &lbf[((xpos * lbdm.youter + ypos) * lbdm.zouter + zpos) * lbsitelength]);
}

float fGetOneDirecSpeedSwiftSite(int dire, long tpos)
{
  return fGetOneDirecSpeedSwiftSite(dire, &lbf[tpos * lbsitelength]);
}


