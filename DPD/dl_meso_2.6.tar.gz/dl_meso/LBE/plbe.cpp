#include "plbe.hpp"

int main(int argc, char** argv)
{
  bigend = fBigEndian();
  lbcurstep = 0;
  fStartMPI(argc, argv);
  fDefineSystem("lbin.sys");
  fDefineDomain();
  fStartDLMESO();
  fMemoryAllocation();
  fDefineNeighbours();
  fDefineMessage();
  fPrintSystemInfo();
  fAllReady();
  fPrintDomainInfo();
  fAllReady();
  fInputParameters("lbin.sys");
  fReadSpaceParameter("lbin.spa");
  fGetModel();
  fNeighbourBoundary();
  fBoundNonBlockCommunication();
  fMarkBoundArea();
  fInitializeSystem();
  fReadInitialState("lbin.init");
  fAllReady();
  fOutputInfo();
  if(outformat==2)  // Grid for Plot3D output files
    fOutputGrid();  
  if(interact==1 || interact==2)
    fCalcPotential_ShanChen();
  timetotal=fCheckTimeMPI();
  switch (interact) {
    case 0:
    // no mesoscopic interactions
      switch (collide) {
        case 0:
          fBGK();
          break;
        case 1:
          fBGKEDM();
          break;
        case 2:
          fBGKGuo();
          break;
        case 3:
          fTRT();
          break;
        case 4:
          fTRTEDM();
          break;
        case 5:
          fTRTGuo();
          break;
        case 6:
          fMRT();
          break;
        case 7:
          fMRTEDM();
          break;
        case 8:
          fMRTGuo();
          break;
      }
      break;
    case 1:
    // Shan/Chen pseudopotential interactions
      switch (collide) {
        case 0:
          fBGKShanChen();
          break;
        case 1:
          fBGKEDMShanChen();
          break;
        case 2:
          fBGKGuoShanChen();
          break;
        case 3:
          fTRTShanChen();
          break;
        case 4:
          fTRTEDMShanChen();
          break;
        case 5:
          fTRTGuoShanChen();
          break;
        case 6:
          fMRTShanChen();
          break;
        case 7:
          fMRTEDMShanChen();
          break;
        case 8:
          fMRTGuoShanChen();
          break;
      }
      break;
    case 2:
    // Shan/Chen pseudopotential interactions with quadratic pseudopotential term
      switch (collide) {
        case 0:
          fBGKShanChenQuadratic();
          break;
        case 1:
          fBGKEDMShanChenQuadratic();
          break;
        case 2:
          fBGKGuoShanChenQuadratic();
          break;
        case 3:
          fTRTShanChenQuadratic();
          break;
        case 4:
          fTRTEDMShanChenQuadratic();
          break;
        case 5:
          fTRTGuoShanChenQuadratic();
          break;
        case 6:
          fMRTShanChenQuadratic();
          break;
        case 7:
          fMRTEDMShanChenQuadratic();
          break;
        case 8:
          fMRTGuoShanChenQuadratic();
          break;
      }
      break;
    case 3:
    // Lishchuk continuum-based interactions (with interfacial normals determined non-locally)
      switch (collide) {
        case 0:
          fBGKLishchuk();
          break;
        case 1:
          fBGKEDMLishchuk();
          break;
        case 2:
          fBGKGuoLishchuk();
          break;
        case 3:
          fTRTLishchuk();
          break;
        case 4:
          fTRTEDMLishchuk();
          break;
        case 5:
          fTRTGuoLishchuk();
          break;
        case 6:
          fMRTLishchuk();
          break;
        case 7:
          fMRTEDMLishchuk();
          break;
        case 8:
          fMRTGuoLishchuk();
          break;
      }
      break;
    case 4:
    // Lishchuk continuum-based interactions (with interfacial normals determined locally)
      switch (collide) {
        case 0:
          fBGKLishchukLocal();
          break;
        case 1:
          fBGKEDMLishchukLocal();
          break;
        case 2:
          fBGKGuoLishchukLocal();
          break;
        case 3:
          fTRTLishchukLocal();
          break;
        case 4:
          fTRTEDMLishchukLocal();
          break;
        case 5:
          fTRTGuoLishchukLocal();
          break;
        case 6:
          fMRTLishchukLocal();
          break;
        case 7:
          fMRTEDMLishchukLocal();
          break;
        case 8:
          fMRTGuoLishchukLocal();
          break;
      }
      break;
    case 5:
    // Swift free-energy interactions
      switch (collide) {
        case 0:
          fBGKSwift();
          break;
        case 1:
          fBGKEDMSwift();
          break;
        case 2:
          fBGKGuoSwift();
          break;
        case 3:
          fTRTSwift();
          break;
        case 4:
          fTRTEDMSwift();
          break;
        case 5:
          fTRTGuoSwift();
          break;
        case 6:
          fMRTSwift();
          break;
        case 7:
          fMRTEDMSwift();
          break;
        case 8:
          fMRTGuoSwift();
          break;
      }
      break;
  }
  timetotal=fCheckTimeMPI();
  fFreeMemory();
  fFinishDLMESO();
  fCloseMPI();
  return 0;
}

