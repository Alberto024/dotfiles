#include "slbe.hpp"

int main(int argc, char* argv[])
{
  bigend = fBigEndian();
  fDefineSystem();
  fSetSerialDomainBuffer();
  fStartDLMESO();
  fMemoryAllocation();
  fInputParameters();
  fReadSpaceParameter();
  fGetModel();
  fsBoundPeriodic();
  fMarkBoundArea();
  fInitializeSystem();
  fReadInitialState();
//  fsOutputGrid();                    // Only needed for Plot3D output files
  timetotal=fCheckTimeSerial();
  for(int i=0; i<= lbtotstep; i++) {
    fsPeriodic();
    if(i%lbsave  == 0) {
      fsOutputVTK();                 // Substitute with required file type and/or output
      qVersion++;
        cout << i << " \t ";
      fPrintDomainMass();
      fPrintDomainMomentum();
    }
    fInteractionForceZero();         // Remove if no Boussinesq forces or mesophase interactions used
    fCalcPotential_ShanChen();       // Substitute with required potential/phase index/density/concentration gradients
                                     // (or remove if no mesophase interactions required)
//    fsIndexPeriodic();             // Only needed for Lishchuk mesophase interactions or Swift free-energy interactions
    fsInteractionForceShanChen();    // Substitute with required mesophase interactions and/or add additional forces
    fsForcePeriodic();
    fCollisionBGK();                 // Substitute with required collision and forcing algorithm
    fPostCollBoundary();
    fPropagationCombSwap();
    fPostPropBoundary();
  }
  timetotal=fCheckTimeSerial();
  fFreeMemory();
  fFinishDLMESO();
  return 0;
}

    
