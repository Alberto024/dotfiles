/***********************************************
 *   DL_MESO       Version 2.6                 *
 *   Authors   :   R. S. Qin, M. A. Seaton     *
 *   Copyright :   STFC Daresbury Laboratory   *
 *             :   22/10/2015                  *
 ***********************************************/

// Legacy VTK format output

int fOutputLegacyVTK(const char* filename="lbout")
{
  if(lbsy.nd ==3)
    fOutputLegacyVTK3D(filename);
  else
    fOutputLegacyVTK2D(filename);
  return 0;
}


int fsOutputLegacyVTK(const char* filename="lbout")
{
  if(lbsy.nd ==3)
    fsOutputLegacyVTK3D(filename);
  else
    fsOutputLegacyVTK2D(filename);
  return 0;
}


int fOutputLegacyVTKP(const char* filename="lbout", int iprop=0)
{
  if(lbsy.nd ==3)
    fOutputLegacyVTKP3D(filename, iprop);
  else
    fOutputLegacyVTKP2D(filename, iprop);
  return 0;
}


int fsOutputLegacyVTKP(const char* filename="lbout", int iprop=0)
{
  if(lbsy.nd ==3)
    fsOutputLegacyVTKP3D(filename, iprop);
  else
    fsOutputLegacyVTKP2D(filename, iprop);
  return 0;
}


int fOutputLegacyVTKCA(const char* filename="lbout", int iprop=0)
{
  if(lbsy.nd ==3)
    fOutputLegacyVTKCA3D(filename, iprop);
  else
    fOutputLegacyVTKCA2D(filename, iprop);
  return 0;
}


int fsOutputLegacyVTKCA(const char* filename="lbout", int iprop=0)
{
  if(lbsy.nd ==3)
    fsOutputLegacyVTKCA3D(filename, iprop);
  else
    fsOutputLegacyVTKCA2D(filename, iprop);
  return 0;
}


int fOutputLegacyVTKCB(const char* filename="lbout", int iprop=0)
{
  if(lbsy.nd ==3)
    fOutputLegacyVTKCB3D(filename, iprop);
  else
    fOutputLegacyVTKCB2D(filename, iprop);
  return 0;
}


int fsOutputLegacyVTKCB(const char* filename="lbout", int iprop=0)
{
  if(lbsy.nd ==3)
    fsOutputLegacyVTKCB3D(filename, iprop);
  else
    fsOutputLegacyVTKCB2D(filename, iprop);
  return 0;
}


int fOutputLegacyVTKT(const char* filename="lbout")
{
  if(lbsy.nd ==3)
    fOutputLegacyVTKT3D(filename);
  else
    fOutputLegacyVTKT2D(filename);
  return 0;
}


int fsOutputLegacyVTKT(const char* filename="lbout")
{
  if(lbsy.nd ==3)
    fsOutputLegacyVTKT3D(filename);
  else
    fsOutputLegacyVTKT2D(filename);
  return 0;
}


int fOutputLegacyVTK3D(const char* filename="lbout")
{

  // output .vtk file with properties for all fluids

  int i, j, k, iprop, istart, iend, jstart, jend, kstart, kend;
  float ipos[3];
  int jpos;
  int ilen=0, ilen1=0, ilen2=0, ilen3=0;
  char buf[80];
  double rho, frac;
    
  if(lbdm.size>1)
    sprintf(buf, "%s%.6dat%.6d.vtk", filename, lbdm.rank, qVersion);
  else
    sprintf(buf, "%s%.6d.vtk", filename, qVersion);
    
  ofstream file(buf, ios::binary);

  file<<"# vtk DataFile Version 3.0"<<endl;
  file<<"DL_MESO_LBE"<<endl;
  file<<"BINARY"<<endl;
  file<<"DATASET STRUCTURED_GRID"<<endl;

  ilen1=lbdm.xouter;
  if(lbdm.xcor == 0)
    ilen1 -= lbdm.bwid;
  if(lbdm.xcor == lbdm.xdim-1)
    ilen1 -= lbdm.bwid;

  ilen2=lbdm.youter;
  if(lbdm.ycor == 0)
    ilen2 -= lbdm.bwid;
  if(lbdm.ycor == lbdm.ydim-1)
    ilen2 -= lbdm.bwid;

  ilen3=lbdm.zouter;
  if(lbdm.zcor == 0)
    ilen3 -= lbdm.bwid;
  if(lbdm.zcor == lbdm.zdim-1)
    ilen3 -= lbdm.bwid;

  file<<"DIMENSIONS  "<<ilen1<<"  "<<ilen2<<"  "<<ilen3<<endl;
  file<<"POINTS  "<<(ilen1*ilen2*ilen3)<<"  float"<<endl;

  // write grid points
  istart = 0; iend = lbdm.xouter; 
  if(lbdm.xcor == 0)
    istart = lbdm.bwid;
  if(lbdm.xcor == lbdm.xdim-1)
    iend = lbdm.xouter - lbdm.bwid;

  jstart = 0; jend = lbdm.youter; 
  if(lbdm.ycor == 0)
    jstart = lbdm.bwid;
  if(lbdm.ycor == lbdm.ydim-1)
    jend = lbdm.youter - lbdm.bwid;

  kstart = 0; kend = lbdm.zouter; 
  if(lbdm.zcor == 0)
    kstart = lbdm.bwid;
  if(lbdm.zcor == lbdm.zdim-1)
    kend = lbdm.zouter - lbdm.bwid;

  for(k=kstart; k<kend; k++)
    for(j=jstart; j<jend; j++) {
      for(i=istart; i<iend; i++) {
	    ipos[0]=(lbdm.xs + i - lbdm.bwid)*float(lbdx);
	    ipos[1]=(lbdm.ys + j - lbdm.bwid)*float(lbdx);
	    ipos[2]=(lbdm.zs + k - lbdm.bwid)*float(lbdx);
        if (!bigend) fByteSwap(ipos,sizeof(float),3);
	    file.write((char*)&ipos, 3*sizeof(float));
      }
    }

  file<<"POINT_DATA  "<<(ilen1*ilen2*ilen3)<<endl;

  // write densities and mass fractions
  if(interact==5 && lbsy.nf>1) {
    for(iprop=0; iprop<lbsy.nf; iprop++) {
      file<<"SCALARS density_"<<iprop<<" float"<<endl;
      if(iprop==0)
        file<<"LOOKUP_TABLE default"<<endl;
      for(k=kstart; k<kend; k++) {
        for(j=jstart; j<jend; j++) {
          for(i=istart; i<iend; i++) {
	        ilen = (i* lbdm.youter + j) * lbdm.zouter + k;
            rho = fGetOneMassSite(&lbf[ilen*lbsitelength]);
            frac = fGetFracSwiftSite(iprop, &lbf[ilen*lbsitelength]);
            ipos[0] = float(rho*frac);
            if (!bigend) fByteSwap(ipos,sizeof(float),1);
  	        file.write((char*)&ipos[0], sizeof(float));
          }
        }
      }
    }
    for(iprop=0; iprop<lbsy.nf; iprop++) {
      file<<"SCALARS fraction_"<<iprop<<" float"<<endl;
      for(k=kstart; k<kend; k++) {
        for(j=jstart; j<jend; j++) {
          for(i=istart; i<iend; i++) {
	        ilen = (i* lbdm.youter + j) * lbdm.zouter + k;
  	        ipos[0] = float(fGetFracSwiftSite(iprop, &lbf[ilen*lbsitelength]));
            if (!bigend) fByteSwap(ipos,sizeof(float),1);
  	        file.write((char*)&ipos[0], sizeof(float));
          }
        }
      }
    }
  }
  else {
    for(iprop=0; iprop<lbsy.nf; iprop++) {
      file<<"SCALARS density_"<<iprop<<" float"<<endl;
      if(iprop==0)
        file<<"LOOKUP_TABLE default"<<endl;
      for(k=kstart; k<kend; k++) {
        for(j=jstart; j<jend; j++) {
          for(i=istart; i<iend; i++) {
	        ilen = (i* lbdm.youter + j) * lbdm.zouter + k;
            ipos[0] = float(fGetOneMassSite(&lbf[ilen*lbsitelength+iprop]));
            if (!bigend) fByteSwap(ipos,sizeof(float),1);
  	        file.write((char*)&ipos[0], sizeof(float));
          }
        }
      }
    }
    for(iprop=0; iprop<lbsy.nf; iprop++) {
      file<<"SCALARS fraction_"<<iprop<<" float"<<endl;
      for(k=kstart; k<kend; k++) {
        for(j=jstart; j<jend; j++) {
          for(i=istart; i<iend; i++) {
	        ilen = (i* lbdm.youter + j) * lbdm.zouter + k;
  	        ipos[0] = float(fGetFracSite(iprop, &lbf[ilen*lbsitelength]));
            if (!bigend) fByteSwap(ipos,sizeof(float),1);
  	        file.write((char*)&ipos[0], sizeof(float));
          }
        }
      }
    }
  }

  // write mass fractions

  // write solute concentrations
  for(iprop=0; iprop<lbsy.nc; iprop++) {
    file<<"SCALARS concentration_"<<iprop<<" float"<<endl;
    for(k=kstart; k<kend; k++) {
      for(j=jstart; j<jend; j++) {
        for(i=istart; i<iend; i++) {
	      ilen = (i* lbdm.youter + j) * lbdm.zouter + k;
  	      ipos[0] = float(fGetOneConcSite(iprop, ilen));
          if (!bigend) fByteSwap(ipos,sizeof(float),1);
  	      file.write((char*)&ipos[0], sizeof(float));
        }
      }
    }
  }

  // write temperatures
  if(lbsy.nt==1) {
    file<<"SCALARS temperature float"<<endl;
    for(k=kstart; k<kend; k++) {
      for(j=jstart; j<jend; j++) {
        for(i=istart; i<iend; i++) {
	      ilen = (i* lbdm.youter + j) * lbdm.zouter + k;
  	      ipos[0] = float(fGetTemperatureSite(ilen));
          if (!bigend) fByteSwap(ipos,sizeof(float),1);
  	      file.write((char*)&ipos[0], sizeof(float));
        }
      }
    }
  }

  file<<"VECTORS velocity float"<<endl;

  // write velocity
  if(interact==5) {
    for(k=kstart; k<kend; k++) {
      for(j=jstart; j<jend; j++) {
        for(i=istart; i<iend; i++) {
  	      ilen = (i* lbdm.youter + j) * lbdm.zouter + k;
  	      if(lbphi[ilen] == 12 || lbphi[ilen] == 13) {
	        ipos[0] = 0.0;
            ipos[1] = 0.0;
            ipos[2] = 0.0;
          }
  	      else {
            ipos[0] = fGetOneDirecSpeedSwiftSite(0, &lbf[ilen*lbsitelength]);
            ipos[1] = fGetOneDirecSpeedSwiftSite(1, &lbf[ilen*lbsitelength]);
            ipos[2] = fGetOneDirecSpeedSwiftSite(2, &lbf[ilen*lbsitelength]);
          }
          if (!bigend) fByteSwap(ipos,sizeof(float),3);
	      file.write((char*)&ipos, 3*sizeof(float));
        }
      }
    }
  }
  else if(!incompress) {
    for(k=kstart; k<kend; k++) {
      for(j=jstart; j<jend; j++) {
        for(i=istart; i<iend; i++) {
  	      ilen = (i* lbdm.youter + j) * lbdm.zouter + k;
  	      if(lbphi[ilen] == 12 || lbphi[ilen] == 13) {
	        ipos[0] = 0.0;
            ipos[1] = 0.0;
            ipos[2] = 0.0;
          }
  	      else {
            ipos[0] = fGetOneDirecSpeedSite(0, &lbf[ilen*lbsitelength]);
            ipos[1] = fGetOneDirecSpeedSite(1, &lbf[ilen*lbsitelength]);
            ipos[2] = fGetOneDirecSpeedSite(2, &lbf[ilen*lbsitelength]);
          }
          if (!bigend) fByteSwap(ipos,sizeof(float),3);
	      file.write((char*)&ipos, 3*sizeof(float));
        }
      }
    }
  }
  else {
    for(k=kstart; k<kend; k++) {
      for(j=jstart; j<jend; j++) {
        for(i=istart; i<iend; i++) {
  	      ilen = (i* lbdm.youter + j) * lbdm.zouter + k;
  	      if(lbphi[ilen] == 12 || lbphi[ilen] == 13) {
	        ipos[0] = 0.0;
            ipos[1] = 0.0;
            ipos[2] = 0.0;
          }
  	      else {
            ipos[0] = fGetOneDirecSpeedIncomSite(0, &lbf[ilen*lbsitelength]);
            ipos[1] = fGetOneDirecSpeedIncomSite(1, &lbf[ilen*lbsitelength]);
            ipos[2] = fGetOneDirecSpeedIncomSite(2, &lbf[ilen*lbsitelength]);
          }
          if (!bigend) fByteSwap(ipos,sizeof(float),3);
	      file.write((char*)&ipos, 3*sizeof(float));
        }
      }
    }
  }

  file<<"SCALARS phase_field int"<<endl;
  file<<"LOOKUP_TABLE default"<<endl;
  
  // write phase field/space property
  for(k=kstart; k<kend; k++)
    for(j=jstart; j<jend; j++) {
      for(i=istart; i<iend; i++) {
	    ilen=(i*lbdm.youter +j)*lbdm.zouter+k;
	    jpos=lbphi[ilen];
        if (!bigend) fByteSwap(&jpos,sizeof(int),1);
	    file.write(reinterpret_cast<const char*>(&jpos), sizeof(int));
      }
    }	
  file.close();
  
  return 0;
}

int fsOutputLegacyVTK3D(const char* filename="lbout")
{
  int i, j, k, iprop, istart, iend, jstart, jend, kstart, kend;
  float ipos[3];
  int jpos;
  long ilen=0, ilen1=0, ilen2=0, ilen3=0;
  char buf[80];
  double rho, frac;
    
  if(lbdm.size>1)
    sprintf(buf, "%s%.6dat%.6d.vtk", filename, lbdm.rank, qVersion);
  else
    sprintf(buf, "%s%.6d.vtk", filename, qVersion);

  ofstream file(buf);
  file<<"# vtk DataFile Version 3.0"<<endl;
  file<<"DL_MESO_LBE"<<endl;
  file<<"ASCII"<<endl;
  file<<"DATASET STRUCTURED_GRID"<<endl;

  ilen1=lbdm.xouter;
  if(lbdm.xcor == 0)
    ilen1 -= lbdm.bwid;
  if(lbdm.xcor == lbdm.xdim-1)
    ilen1 -= lbdm.bwid;

  ilen2=lbdm.youter;
  if(lbdm.ycor == 0)
    ilen2 -= lbdm.bwid;
  if(lbdm.ycor == lbdm.ydim-1)
    ilen2 -= lbdm.bwid;

  ilen3=lbdm.zouter;
  if(lbdm.zcor == 0)
    ilen3 -= lbdm.bwid;
  if(lbdm.zcor == lbdm.zdim-1)
    ilen3 -= lbdm.bwid;

  file<<"DIMENSIONS  "<<ilen1<<"  "<<ilen2<<"  "<<ilen3<<endl;
  file<<"POINTS  "<<(ilen1*ilen2*ilen3)<<"  float"<<endl;
  // write grid points
  istart = 0; iend = lbdm.xouter; 
  if(lbdm.xcor == 0)
    istart = lbdm.bwid;
  if(lbdm.xcor == lbdm.xdim-1)
    iend = lbdm.xouter - lbdm.bwid;

  jstart = 0; jend = lbdm.youter; 
  if(lbdm.ycor == 0)
    jstart = lbdm.bwid;
  if(lbdm.ycor == lbdm.ydim-1)
    jend = lbdm.youter - lbdm.bwid;

  kstart = 0; kend = lbdm.zouter; 
  if(lbdm.zcor == 0)
    kstart = lbdm.bwid;
  if(lbdm.zcor == lbdm.zdim-1)
    kend = lbdm.zouter - lbdm.bwid;

  for(k=kstart; k<kend; k++)
    for(j=jstart; j<jend; j++)
      for(i=istart; i<iend; i++)
	    file<<(lbdm.xs+i-lbdm.bwid)*float(lbdx)<<"  "<<(lbdm.ys+j-lbdm.bwid)*float(lbdx)<<"  "<<(lbdm.zs+k-lbdm.bwid)*float(lbdx)<<endl;
  file<<endl;
  file<<"POINT_DATA  "<<(ilen1*ilen2*ilen3)<<endl;
  // write densities and mass fractions
  if(interact==5 && lbsy.nf>1) {
    for(iprop=0; iprop<lbsy.nf; iprop++) {
      file<<"SCALARS density_"<<iprop<<" float"<<endl;
      if(iprop==0)
        file<<"LOOKUP_TABLE default"<<endl;
      for(k=kstart; k<kend; k++) {
        for(j=jstart; j<jend; j++) {
          for(i=istart; i<iend; i++) {
            ilen = (i * lbdm.youter + j) * lbdm.zouter + k;
            rho = fGetOneMassSite(&lbf[ilen*lbsitelength]);
            frac = fGetFracSwiftSite(iprop, &lbf[ilen*lbsitelength]);
	        ipos[0] = float(rho*frac);
	        file<<ipos[0]<<endl;
	      }
        }
      }
    }
    for(iprop=0; iprop<lbsy.nf; iprop++) {
      file<<"SCALARS fraction_"<<iprop<<" float"<<endl;
      if(iprop==0)
        file<<"LOOKUP_TABLE default"<<endl;
      for(k=kstart; k<kend; k++) {
        for(j=jstart; j<jend; j++) {
          for(i=istart; i<iend; i++) {
  	        ilen = (i * lbdm.youter + j) * lbdm.zouter + k;
	        ipos[0] = float(fGetFracSwiftSite(iprop, &lbf[ilen*lbsitelength]));
	        file<<ipos[0]<<endl;
	      }
        }
      }
    }
  }
  else {
    for(iprop=0; iprop<lbsy.nf; iprop++) {
      file<<"SCALARS density_"<<iprop<<" float"<<endl;
      if(iprop==0)
        file<<"LOOKUP_TABLE default"<<endl;
      for(k=kstart; k<kend; k++) {
        for(j=jstart; j<jend; j++) {
          for(i=istart; i<iend; i++) {
            ilen = (i * lbdm.youter + j) * lbdm.zouter + k;
	        ipos[0] = float(fGetOneMassSite(&lbf[ilen*lbsitelength+iprop]));
	        file<<ipos[0]<<endl;
	      }
        }
      }
    }
    for(iprop=0; iprop<lbsy.nf; iprop++) {
      file<<"SCALARS fraction_"<<iprop<<" float"<<endl;
      if(iprop==0)
        file<<"LOOKUP_TABLE default"<<endl;
      for(k=kstart; k<kend; k++) {
        for(j=jstart; j<jend; j++) {
          for(i=istart; i<iend; i++) {
  	        ilen = (i * lbdm.youter + j) * lbdm.zouter + k;
	        ipos[0] = float(fGetFracSite(iprop, &lbf[ilen*lbsitelength]));
	        file<<ipos[0]<<endl;
	      }
        }
      }
    }
  }
  // write mass fractions
  // write solute concentrations
  for(iprop=0; iprop<lbsy.nc; iprop++) {
    file<<"SCALARS concentration_"<<iprop<<" float"<<endl;
    if(iprop==0)
      file<<"LOOKUP_TABLE default"<<endl;
    for(k=kstart; k<kend; k++) {
      for(j=jstart; j<jend; j++) {
        for(i=istart; i<iend; i++) {
  	      ilen = (i * lbdm.youter + j) * lbdm.zouter + k;
	      ipos[0] = float(fGetOneConcSite(iprop, ilen));
	      file<<ipos[0]<<endl;
	    }
      }
    }
  }
  // write temperatures
  if(lbsy.nt==1) {
    file<<"SCALARS temperature float"<<endl;
    if(iprop==0)
      file<<"LOOKUP_TABLE default"<<endl;
    for(k=kstart; k<kend; k++) {
      for(j=jstart; j<jend; j++) {
        for(i=istart; i<iend; i++) {
  	      ilen = (i * lbdm.youter + j) * lbdm.zouter + k;
	      ipos[0] = float(fGetTemperatureSite(ilen));
	      file<<ipos[0]<<endl;
	    }
      }
    }
  }
  // write velocity
  file<<endl;
  file<<"VECTORS velocity float"<<endl;

  if(interact==5) {
    for(k=kstart; k<kend; k++) {
      for(j=jstart; j<jend; j++) {
        for(i=istart; i<iend; i++) {
  	      ilen = (i * lbdm.youter + j) * lbdm.zouter + k;
 	      if(lbphi[ilen] == 12 || lbphi[ilen] == 13) {
	        ipos[0] = 0.0;
            ipos[1] = 0.0;
            ipos[2] = 0.0;
          }
  	      else {
            ipos[0] = fGetOneDirecSpeedSwiftSite(0, &lbf[ilen*lbsitelength]);
            ipos[1] = fGetOneDirecSpeedSwiftSite(1, &lbf[ilen*lbsitelength]);
            ipos[2] = fGetOneDirecSpeedSwiftSite(2, &lbf[ilen*lbsitelength]);
          }
	      file<<ipos[0]<<"  "<<ipos[1]<<"  "<<ipos[2]<<endl;
	    }
      }
    }
  }
  else if(!incompress) {
    for(k=kstart; k<kend; k++) {
      for(j=jstart; j<jend; j++) {
        for(i=istart; i<iend; i++) {
  	      ilen = (i * lbdm.youter + j) * lbdm.zouter + k;
 	      if(lbphi[ilen] == 12 || lbphi[ilen] == 13) {
	        ipos[0] = 0.0;
            ipos[1] = 0.0;
            ipos[2] = 0.0;
          }
  	      else {
            ipos[0] = fGetOneDirecSpeedSite(0, &lbf[ilen*lbsitelength]);
            ipos[1] = fGetOneDirecSpeedSite(1, &lbf[ilen*lbsitelength]);
            ipos[2] = fGetOneDirecSpeedSite(2, &lbf[ilen*lbsitelength]);
          }
	      file<<ipos[0]<<"  "<<ipos[1]<<"  "<<ipos[2]<<endl;
	    }
      }
    }
  }
  else {
    for(k=kstart; k<kend; k++) {
      for(j=jstart; j<jend; j++) {
        for(i=istart; i<iend; i++) {
  	      ilen = (i * lbdm.youter + j) * lbdm.zouter + k;
 	      if(lbphi[ilen] == 12 || lbphi[ilen] == 13) {
	        ipos[0] = 0.0;
            ipos[1] = 0.0;
            ipos[2] = 0.0;
          }
  	      else {
            ipos[0] = fGetOneDirecSpeedIncomSite(0, &lbf[ilen*lbsitelength]);
            ipos[1] = fGetOneDirecSpeedIncomSite(1, &lbf[ilen*lbsitelength]);
            ipos[2] = fGetOneDirecSpeedIncomSite(2, &lbf[ilen*lbsitelength]);
          }
	      file<<ipos[0]<<"  "<<ipos[1]<<"  "<<ipos[2]<<endl;
	    }
      }
    }
  }
  file<<endl;

  // write phase field/space property
  file<<"SCALARS phase_field int"<<endl;
  file<<"LOOKUP_TABLE default"<<endl;
  for(k=kstart; k<kend; k++)
    for(j=jstart; j<jend; j++)
      for(i=istart; i<iend; i++) {
	    ilen = (i * lbdm.youter + j) * lbdm.zouter + k;
	    jpos=lbphi[ilen];
	    file<<jpos<<endl;
	  }
    
  file.close();
  return 0;
}


int fOutputLegacyVTK2D(const char* filename="lbout")
{

  // output .vtk file with properties for all fluids

  int i, j, iprop, istart, iend, jstart, jend;
  float ipos[3];
  int jpos;
  int ilen=0, ilen1=0, ilen2=0;
  char buf[80];
  double rho, frac;
    
  if(lbdm.size>1)
    sprintf(buf, "%s%.6dat%.6d.vtk", filename, lbdm.rank, qVersion);
  else
    sprintf(buf, "%s%.6d.vtk", filename, qVersion);
  ofstream file(buf, ios::binary);

  file<<"# vtk DataFile Version 3.0"<<endl;
  file<<"DL_MESO_LBE"<<endl;
  file<<"BINARY"<<endl;
  file<<"DATASET STRUCTURED_GRID"<<endl;

  ilen1=lbdm.xouter;
  if(lbdm.xcor == 0)
    ilen1 -= lbdm.bwid;
  if(lbdm.xcor == lbdm.xdim-1)
    ilen1 -= lbdm.bwid;

  ilen2=lbdm.youter;
  if(lbdm.ycor == 0)
    ilen2 -= lbdm.bwid;
  if(lbdm.ycor == lbdm.ydim-1)
    ilen2 -= lbdm.bwid;

  file<<"DIMENSIONS  "<<ilen1<<"  "<<ilen2<<"  1"<<endl;
  file<<"POINTS  "<<(ilen1*ilen2)<<"  float"<<endl;

  // write grid points
  istart = 0; iend = lbdm.xouter; 
  if(lbdm.xcor == 0)
    istart = lbdm.bwid;
  if(lbdm.xcor == lbdm.xdim-1)
    iend = lbdm.xouter - lbdm.bwid;

  jstart = 0; jend = lbdm.youter; 
  if(lbdm.ycor == 0)
    jstart = lbdm.bwid;
  if(lbdm.ycor == lbdm.ydim-1)
    jend = lbdm.youter - lbdm.bwid;

  for(j=jstart; j<jend; j++)
    for(i=istart; i<iend; i++) {
      ipos[0]=(lbdm.xs + i - lbdm.bwid)*float(lbdx);
      ipos[1]=(lbdm.ys + j - lbdm.bwid)*float(lbdx);
      ipos[2]=0.0;
      if (!bigend) fByteSwap(ipos,sizeof(float),3);
      file.write((char*)&ipos, 3*sizeof(float));
    }

  file<<"POINT_DATA  "<<(ilen1*ilen2)<<endl;

  // write densities and mass fractions
  if(interact==5 && lbsy.nf>1) {
    for(iprop=0; iprop<lbsy.nf; iprop++) {
      file<<"SCALARS density_"<<iprop<<" float"<<endl;
      if(iprop==0)
        file<<"LOOKUP_TABLE default"<<endl;
      for(j=jstart; j<jend; j++) {
        for(i=istart; i<iend; i++) {
	      ilen = i* lbdm.youter + j;
          rho = fGetOneMassSite(&lbf[ilen*lbsitelength]);
          frac = fGetFracSwiftSite(iprop, &lbf[ilen*lbsitelength]);
  	      ipos[0] = float(rho*frac);
          if (!bigend) fByteSwap(ipos,sizeof(float),1);
  	      file.write((char*)&ipos[0], sizeof(float));
        }
      }
    }
    for(iprop=0; iprop<lbsy.nf; iprop++) {
      file<<"SCALARS fraction_"<<iprop<<" float"<<endl;
      for(j=jstart; j<jend; j++) {
        for(i=istart; i<iend; i++) {
  	      ilen = i* lbdm.youter + j;
          ipos[0] = float(fGetFracSwiftSite(iprop, &lbf[ilen*lbsitelength]));
          if (!bigend) fByteSwap(ipos,sizeof(float),1);
  	      file.write((char*)&ipos[0], sizeof(float));
        }
      }
    }
  }
  else {
    for(iprop=0; iprop<lbsy.nf; iprop++) {
      file<<"SCALARS density_"<<iprop<<" float"<<endl;
      if(iprop==0)
        file<<"LOOKUP_TABLE default"<<endl;
      for(j=jstart; j<jend; j++) {
        for(i=istart; i<iend; i++) {
	      ilen = i* lbdm.youter + j;
  	      ipos[0] = float(fGetOneMassSite(&lbf[ilen*lbsitelength+iprop]));
          if (!bigend) fByteSwap(ipos,sizeof(float),1);
  	      file.write((char*)&ipos[0], sizeof(float));
        }
      }
    }
    for(iprop=0; iprop<lbsy.nf; iprop++) {
      file<<"SCALARS fraction_"<<iprop<<" float"<<endl;
      for(j=jstart; j<jend; j++) {
        for(i=istart; i<iend; i++) {
  	      ilen = i* lbdm.youter + j;
          ipos[0] = float(fGetFracSite(iprop, &lbf[ilen*lbsitelength]));
          if (!bigend) fByteSwap(ipos,sizeof(float),1);
  	      file.write((char*)&ipos[0], sizeof(float));
        }
      }
    }
  }

  // write solute concentrations
  for(iprop=0; iprop<lbsy.nc; iprop++) {
    file<<"SCALARS concentration_"<<iprop<<" float"<<endl;
    for(j=jstart; j<jend; j++) {
      for(i=istart; i<iend; i++) {
	    ilen = i* lbdm.youter + j;
  	    ipos[0] = float(fGetOneConcSite(iprop, ilen));
        if (!bigend) fByteSwap(ipos,sizeof(float),1);
  	    file.write((char*)&ipos[0], sizeof(float));
      }
    }
  }

  // write temperatures
  if(lbsy.nt==1) {
    file<<"SCALARS temperature float"<<endl;
    for(j=jstart; j<jend; j++) {
      for(i=istart; i<iend; i++) {
	    ilen = i* lbdm.youter + j;
  	    ipos[0] = float(fGetTemperatureSite(ilen));
        if (!bigend) fByteSwap(ipos,sizeof(float),1);
  	    file.write((char*)&ipos[0], sizeof(float));
      }
    }
  }

  file<<"VECTORS velocity float"<<endl;

  // write velocity
  if(interact==5) {
    for(j=jstart; j<jend; j++) {
      for(i=istart; i<iend; i++) {
        ilen = i* lbdm.youter + j;
        if(lbphi[ilen] == 12 || lbphi[ilen] == 13) {
	      ipos[0] = 0.0;
          ipos[1] = 0.0;
        }
        else {
          ipos[0] = fGetOneDirecSpeedSwiftSite(0, &lbf[ilen*lbsitelength]);
          ipos[1] = fGetOneDirecSpeedSwiftSite(1, &lbf[ilen*lbsitelength]);
        }
        ipos[2] = 0.0;
        if (!bigend) fByteSwap(ipos,sizeof(float),3);
        file.write((char*)&ipos, 3*sizeof(float));
      }
    }
  }
  else if(!incompress) {
    for(j=jstart; j<jend; j++) {
      for(i=istart; i<iend; i++) {
        ilen = i* lbdm.youter + j;
        if(lbphi[ilen] == 12 || lbphi[ilen] == 13) {
	      ipos[0] = 0.0;
          ipos[1] = 0.0;
        }
        else {
          ipos[0] = fGetOneDirecSpeedSite(0, &lbf[ilen*lbsitelength]);
          ipos[1] = fGetOneDirecSpeedSite(1, &lbf[ilen*lbsitelength]);
        }
        ipos[2] = 0.0;
        if (!bigend) fByteSwap(ipos,sizeof(float),3);
        file.write((char*)&ipos, 3*sizeof(float));
      }
    }
  }
  else {
    for(j=jstart; j<jend; j++) {
      for(i=istart; i<iend; i++) {
        ilen = i* lbdm.youter + j;
        if(lbphi[ilen] == 12 || lbphi[ilen] == 13) {
	      ipos[0] = 0.0;
          ipos[1] = 0.0;
        }
        else {
          ipos[0] = fGetOneDirecSpeedIncomSite(0, &lbf[ilen*lbsitelength]);
          ipos[1] = fGetOneDirecSpeedIncomSite(1, &lbf[ilen*lbsitelength]);
        }
        ipos[2] = 0.0;
        if (!bigend) fByteSwap(ipos,sizeof(float),3);
        file.write((char*)&ipos, 3*sizeof(float));
      }
    }
  }

  file<<"SCALARS phase_field int"<<endl;
  file<<"LOOKUP_TABLE default"<<endl;
  
  // write phase field/space property
  for(j=jstart; j<jend; j++)
    for(i=istart; i<iend; i++) {
      ilen=i*lbdm.youter +j;
      jpos=lbphi[ilen];
      if (!bigend) fByteSwap(&jpos,sizeof(int),1);
      file.write(reinterpret_cast<const char*>(&jpos), sizeof(int));
    }
	
  file.close();
  
  return 0;
}


int fsOutputLegacyVTK2D(const char* filename="lbout")
{
  int i, j, iprop, istart, iend, jstart, jend;
  float ipos[3];
  int jpos;
  int ilen=0, ilen1=0, ilen2=0;
  char buf[80];
  double rho, frac;
    
  if(lbdm.size>1)
    sprintf(buf, "%s%.6dat%.6d.vtk", filename, lbdm.rank, qVersion);
  else
    sprintf(buf, "%s%.6d.vtk", filename, qVersion);
  ofstream file(buf);
  file<<"# vtk DataFile Version 3.0"<<endl;
  file<<"DL_MESO_LBE"<<endl;
  file<<"ASCII"<<endl;
  file<<"DATASET STRUCTURED_GRID"<<endl;
  ilen1=lbdm.xouter;
  if(lbdm.xcor == 0)
    ilen1 -= lbdm.bwid;
  if(lbdm.xcor == lbdm.xdim-1)
    ilen1 -= lbdm.bwid;

  ilen2=lbdm.youter;
  if(lbdm.ycor == 0)
    ilen2 -= lbdm.bwid;
  if(lbdm.ycor == lbdm.ydim-1)
    ilen2 -= lbdm.bwid;

  file<<"DIMENSIONS  "<<ilen1<<"  "<<ilen2<<"  1"<<endl;
  file<<"POINTS  "<<(ilen1*ilen2)<<"  float"<<endl;
  // write grid points
  istart = 0; iend = lbdm.xouter; 
  if(lbdm.xcor == 0)
    istart = lbdm.bwid;
  if(lbdm.xcor == lbdm.xdim-1)
    iend = lbdm.xouter - lbdm.bwid;

  jstart = 0; jend = lbdm.youter; 
  if(lbdm.ycor == 0)
    jstart = lbdm.bwid;
  if(lbdm.ycor == lbdm.ydim-1)
    jend = lbdm.youter - lbdm.bwid;

  for(j=jstart; j<jend; j++)
    for(i=istart; i<iend; i++)
      file<<(lbdm.xs+i-lbdm.bwid)*float(lbdx)<<"  "<<(lbdm.ys+j-lbdm.bwid)*float(lbdx)<<"  "<<0.0<<endl;
  file<<endl;
  file<<"POINT_DATA  "<<(ilen1*ilen2)<<endl;
  // write densities and mass fractions
  if(interact==5 && lbsy.nf>1) {
    for(iprop=0; iprop<lbsy.nf; iprop++) {
      file<<"SCALARS density_"<<iprop<<" float"<<endl;
      if(iprop==0)
        file<<"LOOKUP_TABLE default"<<endl;
      for(j=jstart; j<jend; j++) {
        for(i=istart; i<iend; i++) {
  	      ilen = i * lbdm.youter + j;
          rho = fGetOneMassSite(&lbf[ilen*lbsitelength]);
          frac = fGetFracSwiftSite(iprop, &lbf[ilen*lbsitelength]);
	      ipos[0] = float(rho*frac);
	      file<<ipos[0]<<endl;
        }
      }
    }
    for(iprop=0; iprop<lbsy.nf; iprop++) {
      file<<"SCALARS fraction_"<<iprop<<" float"<<endl;
      if(iprop==0)
        file<<"LOOKUP_TABLE default"<<endl;
      for(j=jstart; j<jend; j++) {
        for(i=istart; i<iend; i++) {
  	      ilen = i * lbdm.youter + j;
	      ipos[0] = float(fGetFracSwiftSite(iprop, &lbf[ilen*lbsitelength]));
	      file<<ipos[0]<<endl;
        }
      }
    }
  }
  else {
    for(iprop=0; iprop<lbsy.nf; iprop++) {
      file<<"SCALARS density_"<<iprop<<" float"<<endl;
      if(iprop==0)
        file<<"LOOKUP_TABLE default"<<endl;
      for(j=jstart; j<jend; j++) {
        for(i=istart; i<iend; i++) {
  	      ilen = i * lbdm.youter + j;
	      ipos[0] = float(fGetOneMassSite(&lbf[ilen*lbsitelength+iprop]));
	      file<<ipos[0]<<endl;
        }
      }
    }
    for(iprop=0; iprop<lbsy.nf; iprop++) {
      file<<"SCALARS fraction_"<<iprop<<" float"<<endl;
      if(iprop==0)
        file<<"LOOKUP_TABLE default"<<endl;
      for(j=jstart; j<jend; j++) {
        for(i=istart; i<iend; i++) {
  	      ilen = i * lbdm.youter + j;
	      ipos[0] = float(fGetFracSite(iprop, &lbf[ilen*lbsitelength]));
	      file<<ipos[0]<<endl;
        }
      }
    }
  }
  // write solute concentrations
  for(iprop=0; iprop<lbsy.nc; iprop++) {
    file<<"SCALARS concentration_"<<iprop<<" float"<<endl;
    if(iprop==0)
      file<<"LOOKUP_TABLE default"<<endl;
    for(j=jstart; j<jend; j++) {
      for(i=istart; i<iend; i++) {
	    ilen = i * lbdm.youter + j;
	    ipos[0] = float(fGetOneConcSite(iprop, ilen));
	    file<<ipos[0]<<endl;
      }
    }
  }
  // write temperatures
  if(lbsy.nt==1) {
    file<<"SCALARS temperature float"<<endl;
    if(iprop==0)
      file<<"LOOKUP_TABLE default"<<endl;
    for(j=jstart; j<jend; j++) {
      for(i=istart; i<iend; i++) {
	    ilen = i * lbdm.youter + j;
	    ipos[0] = float(fGetTemperatureSite(ilen));
	    file<<ipos[0]<<endl;
      }
    }
  }

  // write velocity
  file<<endl;
  file<<"VECTORS velocity float"<<endl;
  if(interact==5) {
    for(j=jstart; j<jend; j++) {
      for(i=istart; i<iend; i++) {
	    ilen = i * lbdm.youter + j;
 	    if(lbphi[ilen] == 12 || lbphi[ilen] == 13) {
	      ipos[0] = 0.0;
          ipos[1] = 0.0;
        }
	    else {
          ipos[0] = fGetOneDirecSpeedSwiftSite(0, &lbf[ilen*lbsitelength]);
          ipos[1] = fGetOneDirecSpeedSwiftSite(1, &lbf[ilen*lbsitelength]);
        }
	    file<<ipos[0]<<"  "<<ipos[1]<<"  "<<0.0<<endl;
      }
    }
  }
  else if(!incompress) {
    for(j=jstart; j<jend; j++) {
      for(i=istart; i<iend; i++) {
	    ilen = i * lbdm.youter + j;
 	    if(lbphi[ilen] == 12 || lbphi[ilen] == 13) {
	      ipos[0] = 0.0;
          ipos[1] = 0.0;
        }
	    else {
          ipos[0] = fGetOneDirecSpeedSite(0, &lbf[ilen*lbsitelength]);
          ipos[1] = fGetOneDirecSpeedSite(1, &lbf[ilen*lbsitelength]);
        }
	    file<<ipos[0]<<"  "<<ipos[1]<<"  "<<0.0<<endl;
      }
    }
  }
  else {
    for(j=jstart; j<jend; j++) {
      for(i=istart; i<iend; i++) {
	    ilen = i * lbdm.youter + j;
 	    if(lbphi[ilen] == 12 || lbphi[ilen] == 13) {
	      ipos[0] = 0.0;
          ipos[1] = 0.0;
        }
	    else {
          ipos[0] = fGetOneDirecSpeedIncomSite(0, &lbf[ilen*lbsitelength]);
          ipos[1] = fGetOneDirecSpeedIncomSite(1, &lbf[ilen*lbsitelength]);
        }
	    file<<ipos[0]<<"  "<<ipos[1]<<"  "<<0.0<<endl;
      }
    }
  }

  // write phase field/space property
  file<<endl;
  file<<"SCALARS phase_field int"<<endl;
  file<<"LOOKUP_TABLE default"<<endl;
  for(j=jstart; j<jend; j++)
    for(i=istart; i<iend; i++) {
      ilen = i * lbdm.youter + j;
	  jpos=lbphi[ilen];
	  file<<jpos<<endl;
    }
  file.close();
  return 0;
}


int fOutputLegacyVTKP3D(const char* filename="lbout", int iprop=0)
{

  // output .vtk file with macroscopic mass density and velocity for fluid iprop

  int i, j, k, istart, iend, jstart, jend, kstart, kend;
  float ipos[3];
  int jpos;
  int ilen=0, ilen1=0, ilen2=0, ilen3=0;
  char buf[80];
  double rho, frac;
  if(lbdm.size>1)
    sprintf(buf, "%s%.6dat%.6d.vtk", filename, lbdm.rank, qVersion);
  else
    sprintf(buf, "%s%.6d.vtk", filename, qVersion);
  ofstream file(buf, ios::binary);

  file<<"# vtk DataFile Version 3.0"<<endl;
  file<<"DL_MESO_LBE"<<endl;
  file<<"BINARY"<<endl;
  file<<"DATASET STRUCTURED_GRID"<<endl;

  ilen1=lbdm.xouter;
  if(lbdm.xcor == 0)
    ilen1 -= lbdm.bwid;
  if(lbdm.xcor == lbdm.xdim-1)
    ilen1 -= lbdm.bwid;

  ilen2=lbdm.youter;
  if(lbdm.ycor == 0)
    ilen2 -= lbdm.bwid;
  if(lbdm.ycor == lbdm.ydim-1)
    ilen2 -= lbdm.bwid;

  ilen3=lbdm.zouter;
  if(lbdm.zcor == 0)
    ilen3 -= lbdm.bwid;
  if(lbdm.zcor == lbdm.zdim-1)
    ilen3 -= lbdm.bwid;

  file<<"DIMENSIONS  "<<ilen1<<"  "<<ilen2<<"  "<<ilen3<<endl;
  file<<"POINTS  "<<(ilen1*ilen2*ilen3)<<"  float"<<endl;

  // write grid points
  istart = 0; iend = lbdm.xouter; 
  if(lbdm.xcor == 0)
    istart = lbdm.bwid;
  if(lbdm.xcor == lbdm.xdim-1)
    iend = lbdm.xouter - lbdm.bwid;

  jstart = 0; jend = lbdm.youter; 
  if(lbdm.ycor == 0)
    jstart = lbdm.bwid;
  if(lbdm.ycor == lbdm.ydim-1)
    jend = lbdm.youter - lbdm.bwid;

  kstart = 0; kend = lbdm.zouter; 
  if(lbdm.zcor == 0)
    kstart = lbdm.bwid;
  if(lbdm.zcor == lbdm.zdim-1)
    kend = lbdm.zouter - lbdm.bwid;

  for(k=kstart; k<kend; k++)
    for(j=jstart; j<jend; j++) {
      for(i=istart; i<iend; i++) {
	    ipos[0]=(lbdm.xs + i - lbdm.bwid)*float(lbdx);
	    ipos[1]=(lbdm.ys + j - lbdm.bwid)*float(lbdx);
	    ipos[2]=(lbdm.zs + k - lbdm.bwid)*float(lbdx);
        if (!bigend) fByteSwap(ipos,sizeof(float),3);
	    file.write((char*)&ipos, 3*sizeof(float));
      }
    }

  file<<"POINT_DATA  "<<(ilen1*ilen2*ilen3)<<endl;
  file<<"SCALARS density float"<<endl;
  file<<"LOOKUP_TABLE default"<<endl;

  // write density
  if(interact==5 && lbsy.nf>1) {
    for(k=kstart; k<kend; k++) {
      for(j=jstart; j<jend; j++) {
        for(i=istart; i<iend; i++) {
	      ilen = (i* lbdm.youter + j) * lbdm.zouter + k;
          rho = fGetOneMassSite(&lbf[ilen*lbsitelength]);
          frac = fGetFracSwiftSite(iprop, &lbf[ilen*lbsitelength]);
 	      ipos[0] = float(rho*frac);
          if (!bigend) fByteSwap(ipos,sizeof(float),1);
	      file.write((char*)&ipos[0], sizeof(float));
        }
      }
    }
  }
  else {
    for(k=kstart; k<kend; k++) {
      for(j=jstart; j<jend; j++) {
        for(i=istart; i<iend; i++) {
	      ilen = (i* lbdm.youter + j) * lbdm.zouter + k;
 	      ipos[0] = float(fGetOneMassSite(&lbf[ilen*lbsitelength+iprop]));
          if (!bigend) fByteSwap(ipos,sizeof(float),1);
	      file.write((char*)&ipos[0], sizeof(float));
        }
      }
    }
  }

  file<<"VECTORS velocity float"<<endl;

  // write velocity
  if(interact==5) {
    for(k=kstart; k<kend; k++) {
      for(j=jstart; j<jend; j++) {
        for(i=istart; i<iend; i++) {
  	      ilen = (i* lbdm.youter + j) * lbdm.zouter + k;
  	      if(lbphi[ilen] == 12 || lbphi[ilen] == 13) {
	        ipos[0] = 0.0;
            ipos[1] = 0.0;
            ipos[2] = 0.0;
          }
  	      else {
            ipos[0] = fGetOneDirecSpeedSwiftSite(0, &lbf[ilen*lbsitelength]);
            ipos[1] = fGetOneDirecSpeedSwiftSite(1, &lbf[ilen*lbsitelength]);
            ipos[2] = fGetOneDirecSpeedSwiftSite(2, &lbf[ilen*lbsitelength]);
          }
          if (!bigend) fByteSwap(ipos,sizeof(float),3);
	      file.write((char*)&ipos, 3*sizeof(float));
        }
      }
    }
  }
  else if(!incompress) {
    for(k=kstart; k<kend; k++) {
      for(j=jstart; j<jend; j++) {
        for(i=istart; i<iend; i++) {
  	      ilen = (i* lbdm.youter + j) * lbdm.zouter + k;
  	      if(lbphi[ilen] == 12 || lbphi[ilen] == 13) {
	        ipos[0] = 0.0;
            ipos[1] = 0.0;
            ipos[2] = 0.0;
          }
  	      else {
            ipos[0] = fGetOneDirecSpeedSite(0, &lbf[ilen*lbsitelength]);
            ipos[1] = fGetOneDirecSpeedSite(1, &lbf[ilen*lbsitelength]);
            ipos[2] = fGetOneDirecSpeedSite(2, &lbf[ilen*lbsitelength]);
          }
          if (!bigend) fByteSwap(ipos,sizeof(float),3);
	      file.write((char*)&ipos, 3*sizeof(float));
        }
      }
    }
  }
  else {
    for(k=kstart; k<kend; k++) {
      for(j=jstart; j<jend; j++) {
        for(i=istart; i<iend; i++) {
  	      ilen = (i* lbdm.youter + j) * lbdm.zouter + k;
  	      if(lbphi[ilen] == 12 || lbphi[ilen] == 13) {
	        ipos[0] = 0.0;
            ipos[1] = 0.0;
            ipos[2] = 0.0;
          }
  	      else {
            ipos[0] = fGetOneDirecSpeedIncomSite(0, &lbf[ilen*lbsitelength]);
            ipos[1] = fGetOneDirecSpeedIncomSite(1, &lbf[ilen*lbsitelength]);
            ipos[2] = fGetOneDirecSpeedIncomSite(2, &lbf[ilen*lbsitelength]);
          }
          if (!bigend) fByteSwap(ipos,sizeof(float),3);
	      file.write((char*)&ipos, 3*sizeof(float));
        }
      }
    }
  }

  file<<"SCALARS phase_field int"<<endl;
  file<<"LOOKUP_TABLE default"<<endl;
  
  // write phase field/space property
  for(k=kstart; k<kend; k++)
    for(j=jstart; j<jend; j++) {
      for(i=istart; i<iend; i++) {
	    ilen=(i*lbdm.youter +j)*lbdm.zouter+k;
	    jpos=lbphi[ilen];
        if (!bigend) fByteSwap(&jpos,sizeof(int),1);
	    file.write(reinterpret_cast<const char*>(&jpos), sizeof(int));
      }
    }	
  file.close();
  
  return 0;
}

int fsOutputLegacyVTKP3D(const char* filename="lbout", int iprop=0)
{
  int i, j, k, istart, iend, jstart, jend, kstart, kend;
  float ipos[3];
  int jpos;
  int ilen=0, ilen1=0, ilen2=0, ilen3=0;
  char buf[80];
  double rho, frac;
  if(lbdm.size>1)
    sprintf(buf, "%s%.6dat%.6d.vtk", filename, lbdm.rank, qVersion);
  else
    sprintf(buf, "%s%.6d.vtk", filename, qVersion);
  ofstream file(buf);
  file<<"# vtk DataFile Version 3.0"<<endl;
  file<<"DL_MESO_LBE"<<endl;
  file<<"ASCII"<<endl;
  file<<"DATASET STRUCTURED_GRID"<<endl;
  ilen1=lbdm.xouter;
  if(lbdm.xcor == 0)
    ilen1 -= lbdm.bwid;
  if(lbdm.xcor == lbdm.xdim-1)
    ilen1 -= lbdm.bwid;

  ilen2=lbdm.youter;
  if(lbdm.ycor == 0)
    ilen2 -= lbdm.bwid;
  if(lbdm.ycor == lbdm.ydim-1)
    ilen2 -= lbdm.bwid;

  ilen3=lbdm.zouter;
  if(lbdm.zcor == 0)
    ilen3 -= lbdm.bwid;
  if(lbdm.zcor == lbdm.zdim-1)
    ilen3 -= lbdm.bwid;

  file<<"DIMENSIONS  "<<ilen1<<"  "<<ilen2<<"  "<<ilen3<<endl;
  file<<"POINTS  "<<(ilen1*ilen2*ilen3)<<"  float"<<endl;

  // write grid points
  istart = 0; iend = lbdm.xouter; 
  if(lbdm.xcor == 0)
    istart = lbdm.bwid;
  if(lbdm.xcor == lbdm.xdim-1)
    iend = lbdm.xouter - lbdm.bwid;

  jstart = 0; jend = lbdm.youter; 
  if(lbdm.ycor == 0)
    jstart = lbdm.bwid;
  if(lbdm.ycor == lbdm.ydim-1)
    jend = lbdm.youter - lbdm.bwid;

  kstart = 0; kend = lbdm.zouter; 
  if(lbdm.zcor == 0)
    kstart = lbdm.bwid;
  if(lbdm.zcor == lbdm.zdim-1)
    kend = lbdm.zouter - lbdm.bwid;

  for(k=kstart; k<kend; k++)
    for(j=jstart; j<jend; j++)
      for(i=istart; i<iend; i++)
	file<<(lbdm.xs+i-lbdm.bwid)*float(lbdx)<<"  "<<(lbdm.ys+j-lbdm.bwid)*float(lbdx)<<"  "<<(lbdm.zs+k-lbdm.bwid)*float(lbdx)<<endl;
  file<<endl;
  file<<"POINT_DATA  "<<(ilen1*ilen2*ilen3)<<endl;
  // write density
  file<<"SCALARS density float"<<endl;
  file<<"LOOKUP_TABLE default"<<endl;
  if(interact==5 && lbsy.nf>1) {
    for(k=kstart; k<kend; k++) {
      for(j=jstart; j<jend; j++) {
        for(i=istart; i<iend; i++) {
          ilen = (i * lbdm.youter + j) * lbdm.zouter + k;
          rho = fGetOneMassSite(&lbf[ilen*lbsitelength]);
          frac = fGetFracSwiftSite(iprop, &lbf[ilen*lbsitelength]);
	      ipos[0] = float(rho*frac);
	      file<<ipos[0]<<endl;
        }
      }
    }
  }
  else {
    for(k=kstart; k<kend; k++) {
      for(j=jstart; j<jend; j++) {
        for(i=istart; i<iend; i++) {
          ilen = (i * lbdm.youter + j) * lbdm.zouter + k;
	      ipos[0] = float(fGetOneMassSite(&lbf[ilen*lbsitelength+iprop]));
	      file<<ipos[0]<<endl;
        }
      }
    }
  }
  // write velocity
  file<<endl;
  file<<"VECTORS velocity float"<<endl;

  if(interact==5) {
    for(k=kstart; k<kend; k++) {
      for(j=jstart; j<jend; j++) {
        for(i=istart; i<iend; i++) {
	      ilen = (i * lbdm.youter + j) * lbdm.zouter + k;
 	      if(lbphi[ilen] == 12 || lbphi[ilen] == 13) {
	        ipos[0] = 0.0;
            ipos[1] = 0.0;
            ipos[2] = 0.0;
          }
  	      else {
            ipos[0] = fGetOneDirecSpeedSwiftSite(0, &lbf[ilen*lbsitelength]);
            ipos[1] = fGetOneDirecSpeedSwiftSite(1, &lbf[ilen*lbsitelength]);
            ipos[2] = fGetOneDirecSpeedSwiftSite(2, &lbf[ilen*lbsitelength]);
          }
	      file<<ipos[0]<<"  "<<ipos[1]<<"  "<<ipos[2]<<endl;
	    }
      }
    }
  }
  else if(!incompress) {
    for(k=kstart; k<kend; k++) {
      for(j=jstart; j<jend; j++) {
        for(i=istart; i<iend; i++) {
	      ilen = (i * lbdm.youter + j) * lbdm.zouter + k;
 	      if(lbphi[ilen] == 12 || lbphi[ilen] == 13) {
	        ipos[0] = 0.0;
            ipos[1] = 0.0;
            ipos[2] = 0.0;
          }
  	      else {
            ipos[0] = fGetOneDirecSpeedSite(0, &lbf[ilen*lbsitelength]);
            ipos[1] = fGetOneDirecSpeedSite(1, &lbf[ilen*lbsitelength]);
            ipos[2] = fGetOneDirecSpeedSite(2, &lbf[ilen*lbsitelength]);
          }
	      file<<ipos[0]<<"  "<<ipos[1]<<"  "<<ipos[2]<<endl;
	    }
      }
    }
  }
  else {
    for(k=kstart; k<kend; k++) {
      for(j=jstart; j<jend; j++) {
        for(i=istart; i<iend; i++) {
	      ilen = (i * lbdm.youter + j) * lbdm.zouter + k;
 	      if(lbphi[ilen] == 12 || lbphi[ilen] == 13) {
	        ipos[0] = 0.0;
            ipos[1] = 0.0;
            ipos[2] = 0.0;
          }
  	      else {
            ipos[0] = fGetOneDirecSpeedIncomSite(0, &lbf[ilen*lbsitelength]);
            ipos[1] = fGetOneDirecSpeedIncomSite(1, &lbf[ilen*lbsitelength]);
            ipos[2] = fGetOneDirecSpeedIncomSite(2, &lbf[ilen*lbsitelength]);
          }
	      file<<ipos[0]<<"  "<<ipos[1]<<"  "<<ipos[2]<<endl;
	    }
      }
    }
  }

  // write phase field/space property
  file<<endl;
  file<<"SCALARS phase_field int"<<endl;
  file<<"LOOKUP_TABLE default"<<endl;
  for(k=kstart; k<kend; k++)
    for(j=jstart; j<jend; j++)
      for(i=istart; i<iend; i++)
	    {
	      ilen = (i * lbdm.youter + j) * lbdm.zouter + k;
	      jpos=lbphi[ilen];
	      file<<jpos<<endl;
	    }
  file.close();
  return 0;
}


int fOutputLegacyVTKP2D(const char* filename="lbout", int iprop=0)
{

  // output .vtk file with macroscopic mass density and velocity for fluid iprop

  int i, j, istart, iend, jstart, jend;
  float ipos[3];
  int jpos;
  int ilen=0, ilen1=0, ilen2=0;
  char buf[80];
  double rho, frac;
  if(lbdm.size>1)
    sprintf(buf, "%s%.6dat%.6d.vtk", filename, lbdm.rank, qVersion);
  else
    sprintf(buf, "%s%.6d.vtk", filename, qVersion);
  ofstream file(buf, ios::binary);

  file<<"# vtk DataFile Version 3.0"<<endl;
  file<<"DL_MESO_LBE"<<endl;
  file<<"BINARY"<<endl;
  file<<"DATASET STRUCTURED_GRID"<<endl;

  ilen1=lbdm.xouter;
  if(lbdm.xcor == 0)
    ilen1 -= lbdm.bwid;
  if(lbdm.xcor == lbdm.xdim-1)
    ilen1 -= lbdm.bwid;

  ilen2=lbdm.youter;
  if(lbdm.ycor == 0)
    ilen2 -= lbdm.bwid;
  if(lbdm.ycor == lbdm.ydim-1)
    ilen2 -= lbdm.bwid;

  file<<"DIMENSIONS  "<<ilen1<<"  "<<ilen2<<"  1"<<endl;
  file<<"POINTS  "<<(ilen1*ilen2)<<"  float"<<endl;

  // write grid points
  istart = 0; iend = lbdm.xouter; 
  if(lbdm.xcor == 0)
    istart = lbdm.bwid;
  if(lbdm.xcor == lbdm.xdim-1)
    iend = lbdm.xouter - lbdm.bwid;

  jstart = 0; jend = lbdm.youter; 
  if(lbdm.ycor == 0)
    jstart = lbdm.bwid;
  if(lbdm.ycor == lbdm.ydim-1)
    jend = lbdm.youter - lbdm.bwid;

  for(j=jstart; j<jend; j++)
    for(i=istart; i<iend; i++) {
      ipos[0]=(lbdm.xs + i - lbdm.bwid)*float(lbdx);
      ipos[1]=(lbdm.ys + j - lbdm.bwid)*float(lbdx);
      ipos[2]=0.0;
      if (!bigend) fByteSwap(ipos,sizeof(float),3);
      file.write((char*)&ipos, 3*sizeof(float));
    }

  file<<"POINT_DATA  "<<(ilen1*ilen2)<<endl;
  file<<"SCALARS density float"<<endl;
  file<<"LOOKUP_TABLE default"<<endl;

  // write density
  if(interact==5 && lbsy.nf>1) {
    for(j=jstart; j<jend; j++) {
      for(i=istart; i<iend; i++) {
        ilen = i* lbdm.youter + j;
        rho = fGetOneMassSite(&lbf[ilen*lbsitelength]);
        frac = fGetFracSwiftSite(iprop, &lbf[ilen*lbsitelength]);
        ipos[0] = float(rho*frac);
        if (!bigend) fByteSwap(ipos,sizeof(float),1);
        file.write((char*)&ipos[0], sizeof(float));
      }
    }
  }
  else {
    for(j=jstart; j<jend; j++) {
      for(i=istart; i<iend; i++) {
        ilen = i* lbdm.youter + j;
        ipos[0] = float(fGetOneMassSite(&lbf[ilen*lbsitelength+iprop]));
        if (!bigend) fByteSwap(ipos,sizeof(float),1);
        file.write((char*)&ipos[0], sizeof(float));
      }
    }
  }

  file<<"VECTORS velocity float"<<endl;

  // write velocity
  if(interact==5) {
    for(j=jstart; j<jend; j++) {
      for(i=istart; i<iend; i++) {
        ilen = i* lbdm.youter + j;
        if(lbphi[ilen] == 12 || lbphi[ilen] == 13) {
	      ipos[0] = 0.0;
          ipos[1] = 0.0;
        }
        else {
          ipos[0] = fGetOneDirecSpeedSwiftSite(0, &lbf[ilen*lbsitelength]);
          ipos[1] = fGetOneDirecSpeedSwiftSite(1, &lbf[ilen*lbsitelength]);
        }
        ipos[2] = 0.0;
        if (!bigend) fByteSwap(ipos,sizeof(float),3);
        file.write((char*)&ipos, 3*sizeof(float));
      }
    }
  }
  else if(!incompress) {
    for(j=jstart; j<jend; j++) {
      for(i=istart; i<iend; i++) {
        ilen = i* lbdm.youter + j;
        if(lbphi[ilen] == 12 || lbphi[ilen] == 13) {
	      ipos[0] = 0.0;
          ipos[1] = 0.0;
        }
        else {
          ipos[0] = fGetOneDirecSpeedSite(0, &lbf[ilen*lbsitelength]);
          ipos[1] = fGetOneDirecSpeedSite(1, &lbf[ilen*lbsitelength]);
        }
        ipos[2] = 0.0;
        if (!bigend) fByteSwap(ipos,sizeof(float),3);
        file.write((char*)&ipos, 3*sizeof(float));
      }
    }
  }
  else {
    for(j=jstart; j<jend; j++) {
      for(i=istart; i<iend; i++) {
        ilen = i* lbdm.youter + j;
        if(lbphi[ilen] == 12 || lbphi[ilen] == 13) {
	      ipos[0] = 0.0;
          ipos[1] = 0.0;
        }
        else {
          ipos[0] = fGetOneDirecSpeedIncomSite(0, &lbf[ilen*lbsitelength]);
          ipos[1] = fGetOneDirecSpeedIncomSite(1, &lbf[ilen*lbsitelength]);
        }
        ipos[2] = 0.0;
        if (!bigend) fByteSwap(ipos,sizeof(float),3);
	    file.write((char*)&ipos, 3*sizeof(float));
      }
    }
  }

  file<<"SCALARS phase_field int"<<endl;
  file<<"LOOKUP_TABLE default"<<endl;
  
  // write phase field/space property
  for(j=jstart; j<jend; j++)
    for(i=istart; i<iend; i++) {
      ilen=i*lbdm.youter +j;
      jpos=lbphi[ilen];
      if (!bigend) fByteSwap(&jpos,sizeof(int),1);
      file.write(reinterpret_cast<const char*>(&jpos), sizeof(int));
    }
	
  file.close();
  
  return 0;
}


int fsOutputLegacyVTKP2D(const char* filename="lbout", int iprop=0)
{
  int i, j, istart, iend, jstart, jend;
  float ipos[3];
  int jpos;
  int ilen=0, ilen1=0, ilen2=0;
  char buf[80];
  double rho, frac;
  if(lbdm.size>1)
    sprintf(buf, "%s%.6dat%.6d.vtk", filename, lbdm.rank, qVersion);
  else
    sprintf(buf, "%s%.6d.vtk", filename, qVersion);
  ofstream file(buf);
  file<<"# vtk DataFile Version 3.0"<<endl;
  file<<"DL_MESO_LBE"<<endl;
  file<<"ASCII"<<endl;
  file<<"DATASET STRUCTURED_GRID"<<endl;
  ilen1=lbdm.xouter;
  if(lbdm.xcor == 0)
    ilen1 -= lbdm.bwid;
  if(lbdm.xcor == lbdm.xdim-1)
    ilen1 -= lbdm.bwid;

  ilen2=lbdm.youter;
  if(lbdm.ycor == 0)
    ilen2 -= lbdm.bwid;
  if(lbdm.ycor == lbdm.ydim-1)
    ilen2 -= lbdm.bwid;

  file<<"DIMENSIONS  "<<ilen1<<"  "<<ilen2<<"  1"<<endl;
  file<<"POINTS  "<<(ilen1*ilen2)<<"  float"<<endl;

  // write grid points
  istart = 0; iend = lbdm.xouter; 
  if(lbdm.xcor == 0)
    istart = lbdm.bwid;
  if(lbdm.xcor == lbdm.xdim-1)
    iend = lbdm.xouter - lbdm.bwid;

  jstart = 0; jend = lbdm.youter; 
  if(lbdm.ycor == 0)
    jstart = lbdm.bwid;
  if(lbdm.ycor == lbdm.ydim-1)
    jend = lbdm.youter - lbdm.bwid;

  for(j=jstart; j<jend; j++)
    for(i=istart; i<iend; i++)
      file<<(lbdm.xs+i-lbdm.bwid)*float(lbdx)<<"  "<<(lbdm.ys+j-lbdm.bwid)*float(lbdx)<<"  "<<0.0<<endl;
  file<<endl;
  file<<"POINT_DATA  "<<(ilen1*ilen2)<<endl;
  // write density
  file<<"SCALARS density float"<<endl;
  file<<"LOOKUP_TABLE default"<<endl;
  if(interact==5 && lbsy.nf>1) {
    for(j=jstart; j<jend; j++) {
      for(i=istart; i<iend; i++) {
        ilen = i * lbdm.youter + j;
        rho = fGetOneMassSite(&lbf[ilen*lbsitelength]);
        frac = fGetFracSwiftSite(iprop, &lbf[ilen*lbsitelength]);
        ipos[0] = float(rho*frac);
	    file<<ipos[0]<<endl;
      }
    }
  }
  else {
    for(j=jstart; j<jend; j++) {
      for(i=istart; i<iend; i++) {
        ilen = i * lbdm.youter + j;
        ipos[0] = float(fGetOneMassSite(&lbf[ilen*lbsitelength+iprop]));
	    file<<ipos[0]<<endl;
      }
    }
  }
  // write velocity
  file<<endl;
  file<<"VECTORS velocity float"<<endl;
  if(interact==5) {
    for(j=jstart; j<jend; j++) {
      for(i=istart; i<iend; i++) {
	    ilen = i * lbdm.youter + j;
 	    if(lbphi[ilen] == 12 || lbphi[ilen] == 13) {
	      ipos[0] = 0.0;
          ipos[1] = 0.0;
        }
	    else {
          ipos[0] = fGetOneDirecSpeedSwiftSite(0, &lbf[ilen*lbsitelength]);
          ipos[1] = fGetOneDirecSpeedSwiftSite(1, &lbf[ilen*lbsitelength]);
        }
	    file<<ipos[0]<<"  "<<ipos[1]<<"  "<<0.0<<endl;
      }
    }
  }
  else if(!incompress) {
    for(j=jstart; j<jend; j++) {
      for(i=istart; i<iend; i++) {
	    ilen = i * lbdm.youter + j;
 	    if(lbphi[ilen] == 12 || lbphi[ilen] == 13) {
	      ipos[0] = 0.0;
          ipos[1] = 0.0;
        }
	    else {
          ipos[0] = fGetOneDirecSpeedSite(0, &lbf[ilen*lbsitelength]);
          ipos[1] = fGetOneDirecSpeedSite(1, &lbf[ilen*lbsitelength]);
        }
	    file<<ipos[0]<<"  "<<ipos[1]<<"  "<<0.0<<endl;
      }
    }
  }
  else {
    for(j=jstart; j<jend; j++) {
      for(i=istart; i<iend; i++) {
	    ilen = i * lbdm.youter + j;
 	    if(lbphi[ilen] == 12 || lbphi[ilen] == 13) {
	      ipos[0] = 0.0;
          ipos[1] = 0.0;
        }
	    else {
          ipos[0] = fGetOneDirecSpeedIncomSite(0, &lbf[ilen*lbsitelength]);
          ipos[1] = fGetOneDirecSpeedIncomSite(1, &lbf[ilen*lbsitelength]);
        }
	    file<<ipos[0]<<"  "<<ipos[1]<<"  "<<0.0<<endl;
      }
    }
  }

  // write phase field/space property
  file<<endl;
  file<<"SCALARS phase_field int"<<endl;
  file<<"LOOKUP_TABLE default"<<endl;
  for(j=jstart; j<jend; j++)
    for(i=istart; i<iend; i++)
      {
	    ilen = i * lbdm.youter + j;
	    jpos=lbphi[ilen];
	    file<<jpos<<endl;
	  }
  file.close();
  return 0;
}


int fOutputLegacyVTKCA3D(const char* filename="lbout", int iprop=0)
{

  // output .vtk file with mass fraction and velocity for fluid iprop

  int i, j, k, istart, iend, jstart, jend, kstart, kend;
  float ipos[3];
  int jpos;
  int ilen=0, ilen1=0, ilen2=0, ilen3=0;
  char buf[80];
  if(lbdm.size>1)
    sprintf(buf, "%s%.6dat%.6d.vtk", filename, lbdm.rank, qVersion);
  else
    sprintf(buf, "%s%.6d.vtk", filename, qVersion);
  ofstream file(buf, ios::binary);

  file<<"# vtk DataFile Version 3.0"<<endl;
  file<<"DL_MESO_LBE"<<endl;
  file<<"BINARY"<<endl;
  file<<"DATASET STRUCTURED_GRID"<<endl;

  ilen1=lbdm.xouter;
  if(lbdm.xcor == 0)
    ilen1 -= lbdm.bwid;
  if(lbdm.xcor == lbdm.xdim-1)
    ilen1 -= lbdm.bwid;

  ilen2=lbdm.youter;
  if(lbdm.ycor == 0)
    ilen2 -= lbdm.bwid;
  if(lbdm.ycor == lbdm.ydim-1)
    ilen2 -= lbdm.bwid;

  ilen3=lbdm.zouter;
  if(lbdm.zcor == 0)
    ilen3 -= lbdm.bwid;
  if(lbdm.zcor == lbdm.zdim-1)
    ilen3 -= lbdm.bwid;

  file<<"DIMENSIONS  "<<ilen1<<"  "<<ilen2<<"  "<<ilen3<<endl;
  file<<"POINTS  "<<(ilen1*ilen2*ilen3)<<"  float"<<endl;

  // write grid points
  istart = 0; iend = lbdm.xouter; 
  if(lbdm.xcor == 0)
    istart = lbdm.bwid;
  if(lbdm.xcor == lbdm.xdim-1)
    iend = lbdm.xouter - lbdm.bwid;

  jstart = 0; jend = lbdm.youter; 
  if(lbdm.ycor == 0)
    jstart = lbdm.bwid;
  if(lbdm.ycor == lbdm.ydim-1)
    jend = lbdm.youter - lbdm.bwid;

  kstart = 0; kend = lbdm.zouter; 
  if(lbdm.zcor == 0)
    kstart = lbdm.bwid;
  if(lbdm.zcor == lbdm.zdim-1)
    kend = lbdm.zouter - lbdm.bwid;

  for(k=kstart; k<kend; k++)
    for(j=jstart; j<jend; j++) {
      for(i=istart; i<iend; i++) {
	    ipos[0]=(lbdm.xs + i - lbdm.bwid)*float(lbdx);
	    ipos[1]=(lbdm.ys + j - lbdm.bwid)*float(lbdx);
	    ipos[2]=(lbdm.zs + k - lbdm.bwid)*float(lbdx);
        if (!bigend) fByteSwap(ipos,sizeof(float),3);
	    file.write((char*)&ipos, 3*sizeof(float));
      }
    }

  file<<"POINT_DATA  "<<(ilen1*ilen2*ilen3)<<endl;
  file<<"SCALARS fraction float"<<endl;
  file<<"LOOKUP_TABLE default"<<endl;

  // write mass fraction
  if(interact==5 && lbsy.nf>1) {
    for(k=kstart; k<kend; k++) {
      for(j=jstart; j<jend; j++) {
        for(i=istart; i<iend; i++) {
	      ilen = (i* lbdm.youter + j) * lbdm.zouter + k;
	      ipos[0] = float(fGetFracSwiftSite(iprop, &lbf[ilen*lbsitelength]));
          if (!bigend) fByteSwap(ipos,sizeof(float),1);
	      file.write((char*)&ipos[0], sizeof(float));
        }
      }
    }
  }
  else {
    for(k=kstart; k<kend; k++) {
      for(j=jstart; j<jend; j++) {
        for(i=istart; i<iend; i++) {
	      ilen = (i* lbdm.youter + j) * lbdm.zouter + k;
	      ipos[0] = float(fGetFracSite(iprop, &lbf[ilen*lbsitelength]));
          if (!bigend) fByteSwap(ipos,sizeof(float),1);
	      file.write((char*)&ipos[0], sizeof(float));
        }
      }
    }
  }

  file<<"VECTORS velocity float"<<endl;

  // write velocity
  if(interact==5) {
    for(k=kstart; k<kend; k++) {
      for(j=jstart; j<jend; j++) {
        for(i=istart; i<iend; i++) {
	      ilen = (i* lbdm.youter + j) * lbdm.zouter + k;
  	      if(lbphi[ilen] == 12 || lbphi[ilen] == 13) {
	        ipos[0] = 0.0;
            ipos[1] = 0.0;
            ipos[2] = 0.0;
          }
	      else {
            ipos[0] = fGetOneDirecSpeedSwiftSite(0, &lbf[ilen*lbsitelength]);
            ipos[1] = fGetOneDirecSpeedSwiftSite(1, &lbf[ilen*lbsitelength]);
            ipos[2] = fGetOneDirecSpeedSwiftSite(2, &lbf[ilen*lbsitelength]);
          }
          if (!bigend) fByteSwap(ipos,sizeof(float),3);
	      file.write((char*)&ipos, 3*sizeof(float));
        }
      }
    }
  }
  else if(!incompress) {
    for(k=kstart; k<kend; k++) {
      for(j=jstart; j<jend; j++) {
        for(i=istart; i<iend; i++) {
	      ilen = (i* lbdm.youter + j) * lbdm.zouter + k;
  	      if(lbphi[ilen] == 12 || lbphi[ilen] == 13) {
	        ipos[0] = 0.0;
            ipos[1] = 0.0;
            ipos[2] = 0.0;
          }
	      else {
            ipos[0] = fGetOneDirecSpeedSite(0, &lbf[ilen*lbsitelength]);
            ipos[1] = fGetOneDirecSpeedSite(1, &lbf[ilen*lbsitelength]);
            ipos[2] = fGetOneDirecSpeedSite(2, &lbf[ilen*lbsitelength]);
          }
          if (!bigend) fByteSwap(ipos,sizeof(float),3);
	      file.write((char*)&ipos, 3*sizeof(float));
        }
      }
    }
  }
  else {
    for(k=kstart; k<kend; k++) {
      for(j=jstart; j<jend; j++) {
        for(i=istart; i<iend; i++) {
	      ilen = (i* lbdm.youter + j) * lbdm.zouter + k;
  	      if(lbphi[ilen] == 12 || lbphi[ilen] == 13) {
	        ipos[0] = 0.0;
            ipos[1] = 0.0;
            ipos[2] = 0.0;
          }
	      else {
            ipos[0] = fGetOneDirecSpeedIncomSite(0, &lbf[ilen*lbsitelength]);
            ipos[1] = fGetOneDirecSpeedIncomSite(1, &lbf[ilen*lbsitelength]);
            ipos[2] = fGetOneDirecSpeedIncomSite(2, &lbf[ilen*lbsitelength]);
          }
          if (!bigend) fByteSwap(ipos,sizeof(float),3);
	      file.write((char*)&ipos, 3*sizeof(float));
        }
      }
    }
  }

  file<<"SCALARS phase_field int"<<endl;
  file<<"LOOKUP_TABLE default"<<endl;
  
  // write phase field/space property
  for(k=kstart; k<kend; k++)
    for(j=jstart; j<jend; j++) {
      for(i=istart; i<iend; i++) {
	    ilen=(i*lbdm.youter +j)*lbdm.zouter+k;
	    jpos=lbphi[ilen];
        if (!bigend) fByteSwap(&jpos,sizeof(int),1);
	    file.write(reinterpret_cast<const char*>(&jpos), sizeof(int));
      }
    }	
  file.close();
  
  return 0;
}


int fsOutputLegacyVTKCA3D(const char* filename="lbout", int iprop=0)
{
  int i, j, k, istart, iend, jstart, jend, kstart, kend;
  float ipos[3];
  int jpos;
  int ilen=0, ilen1=0, ilen2=0, ilen3=0;
  char buf[80];
  if(lbdm.size>1)
    sprintf(buf, "%s%.6dat%.6d.vtk", filename, lbdm.rank, qVersion);
  else
    sprintf(buf, "%s%.6d.vtk", filename, qVersion);

  ofstream file(buf);
  file<<"# vtk DataFile Version 3.0"<<endl;
  file<<"DL_MESO_LBE"<<endl;
  file<<"ASCII"<<endl;
  file<<"DATASET STRUCTURED_GRID"<<endl;

  ilen1=lbdm.xouter;
  if(lbdm.xcor == 0)
    ilen1 -= lbdm.bwid;
  if(lbdm.xcor == lbdm.xdim-1)
    ilen1 -= lbdm.bwid;

  ilen2=lbdm.youter;
  if(lbdm.ycor == 0)
    ilen2 -= lbdm.bwid;
  if(lbdm.ycor == lbdm.ydim-1)
    ilen2 -= lbdm.bwid;

  ilen3=lbdm.zouter;
  if(lbdm.zcor == 0)
    ilen3 -= lbdm.bwid;
  if(lbdm.zcor == lbdm.zdim-1)
    ilen3 -= lbdm.bwid;

  file<<"DIMENSIONS  "<<ilen1<<"  "<<ilen2<<"  "<<ilen3<<endl;
  file<<"POINTS  "<<(ilen1*ilen2*ilen3)<<"  float"<<endl;

// write grid points
  istart = 0; iend = lbdm.xouter; 
  if(lbdm.xcor == 0)
    istart = lbdm.bwid;
  if(lbdm.xcor == lbdm.xdim-1)
    iend = lbdm.xouter - lbdm.bwid;

  jstart = 0; jend = lbdm.youter; 
  if(lbdm.ycor == 0)
    jstart = lbdm.bwid;
  if(lbdm.ycor == lbdm.ydim-1)
    jend = lbdm.youter - lbdm.bwid;

  kstart = 0; kend = lbdm.zouter; 
  if(lbdm.zcor == 0)
    kstart = lbdm.bwid;
  if(lbdm.zcor == lbdm.zdim-1)
    kend = lbdm.zouter - lbdm.bwid;

  for(k=kstart; k<kend; k++)
    for(j=jstart; j<jend; j++)
      for(i=istart; i<iend; i++)
	    file<<(lbdm.xs+i-lbdm.bwid)*float(lbdx)<<"  "<<(lbdm.ys+j-lbdm.bwid)*float(lbdx)<<"  "<<(lbdm.zs+k-lbdm.bwid)*float(lbdx)<<endl;
  file<<endl;
  file<<"POINT_DATA  "<<(ilen1*ilen2*ilen3)<<endl;
  // write mass fraction
  file<<"SCALARS fraction float"<<endl;
  file<<"LOOKUP_TABLE default"<<endl;
  if(interact==5 && lbsy.nf>1) {
    for(k=kstart; k<kend; k++) {
      for(j=jstart; j<jend; j++) {
        for(i=istart; i<iend; i++) {
	      ilen = (i * lbdm.youter + j) * lbdm.zouter + k;
	      ipos[0] = float(fGetFracSwiftSite(iprop, &lbf[ilen*lbsitelength]));
	      file<<ipos<<endl;
	    }
      }
    }
  }
  else {
    for(k=kstart; k<kend; k++) {
      for(j=jstart; j<jend; j++) {
        for(i=istart; i<iend; i++) {
	      ilen = (i * lbdm.youter + j) * lbdm.zouter + k;
	      ipos[0] = float(fGetFracSite(iprop, &lbf[ilen*lbsitelength]));
	      file<<ipos<<endl;
	    }
      }
    }
  }
  // write velocity
  file<<endl;
  file<<"VECTORS velocity float"<<endl;
  if(interact==5) {
    for(k=kstart; k<kend; k++) {
      for(j=jstart; j<jend; j++) {
        for(i=istart; i<iend; i++) {
	      ilen = (i * lbdm.youter + j) * lbdm.zouter + k;
 	      if(lbphi[ilen] == 12 || lbphi[ilen] == 13) {
	        ipos[0] = 0.0;
            ipos[1] = 0.0;
            ipos[2] = 0.0;
          }
	      else {
            ipos[0] = fGetOneDirecSpeedSite(0, &lbf[ilen*lbsitelength]);
            ipos[1] = fGetOneDirecSpeedSite(1, &lbf[ilen*lbsitelength]);
            ipos[2] = fGetOneDirecSpeedSite(2, &lbf[ilen*lbsitelength]);
          }
	      file<<ipos[0]<<"  "<<ipos[1]<<"  "<<ipos[2]<<endl;
	    }
      }
    }
  }
  else if(!incompress) {
    for(k=kstart; k<kend; k++) {
      for(j=jstart; j<jend; j++) {
        for(i=istart; i<iend; i++) {
	      ilen = (i * lbdm.youter + j) * lbdm.zouter + k;
 	      if(lbphi[ilen] == 12 || lbphi[ilen] == 13) {
	        ipos[0] = 0.0;
            ipos[1] = 0.0;
            ipos[2] = 0.0;
          }
	      else {
            ipos[0] = fGetOneDirecSpeedSite(0, &lbf[ilen*lbsitelength]);
            ipos[1] = fGetOneDirecSpeedSite(1, &lbf[ilen*lbsitelength]);
            ipos[2] = fGetOneDirecSpeedSite(2, &lbf[ilen*lbsitelength]);
          }
	      file<<ipos[0]<<"  "<<ipos[1]<<"  "<<ipos[2]<<endl;
	    }
      }
    }
  }
  else {
    for(k=kstart; k<kend; k++) {
      for(j=jstart; j<jend; j++) {
        for(i=istart; i<iend; i++) {
	      ilen = (i * lbdm.youter + j) * lbdm.zouter + k;
 	      if(lbphi[ilen] == 12 || lbphi[ilen] == 13) {
	        ipos[0] = 0.0;
            ipos[1] = 0.0;
            ipos[2] = 0.0;
          }
	      else {
            ipos[0] = fGetOneDirecSpeedIncomSite(0, &lbf[ilen*lbsitelength]);
            ipos[1] = fGetOneDirecSpeedIncomSite(1, &lbf[ilen*lbsitelength]);
            ipos[2] = fGetOneDirecSpeedIncomSite(2, &lbf[ilen*lbsitelength]);
          }
	      file<<ipos[0]<<"  "<<ipos[1]<<"  "<<ipos[2]<<endl;
	    }
      }
    }
  }
  // write phase field/space property
  file<<endl;
  file<<"SCALARS phase_field int"<<endl;
  file<<"LOOKUP_TABLE default"<<endl;
  for(k=kstart; k<kend; k++)
    for(j=jstart; j<jend; j++)
      for(i=istart; i<iend; i++)
	    {
	      ilen = (i * lbdm.youter + j) * lbdm.zouter + k;
	      jpos=lbphi[ilen];
	      file<<jpos<<endl;
	    }
  file.close();
  return 0;
}


int fOutputLegacyVTKCA2D(const char* filename="lbout", int iprop=0)
{

  // output .vtk file with mass fraction and velocity for fluid iprop

  int i, j, istart, iend, jstart, jend;
  float ipos[3];
  int jpos;
  int ilen=0, ilen1=0, ilen2=0;
  static int qVersion;
  char buf[80];
  if(lbdm.size>1)
    sprintf(buf, "%s%.6dat%.6d.vtk", filename, lbdm.rank, qVersion);
  else
    sprintf(buf, "%s%.6d.vtk", filename, qVersion);
  ofstream file(buf, ios::binary);

  file<<"# vtk DataFile Version 3.0"<<endl;
  file<<"DL_MESO_LBE"<<endl;
  file<<"BINARY"<<endl;
  file<<"DATASET STRUCTURED_GRID"<<endl;

  ilen1=lbdm.xouter;
  if(lbdm.xcor == 0)
    ilen1 -= lbdm.bwid;
  if(lbdm.xcor == lbdm.xdim-1)
    ilen1 -= lbdm.bwid;

  ilen2=lbdm.youter;
  if(lbdm.ycor == 0)
    ilen2 -= lbdm.bwid;
  if(lbdm.ycor == lbdm.ydim-1)
    ilen2 -= lbdm.bwid;

  file<<"DIMENSIONS  "<<ilen1<<"  "<<ilen2<<"  1"<<endl;
  file<<"POINTS  "<<(ilen1*ilen2)<<"  float"<<endl;

  // write grid points
  istart = 0; iend = lbdm.xouter; 
  if(lbdm.xcor == 0)
    istart = lbdm.bwid;
  if(lbdm.xcor == lbdm.xdim-1)
    iend = lbdm.xouter - lbdm.bwid;

  jstart = 0; jend = lbdm.youter; 
  if(lbdm.ycor == 0)
    jstart = lbdm.bwid;
  if(lbdm.ycor == lbdm.ydim-1)
    jend = lbdm.youter - lbdm.bwid;

  for(j=jstart; j<jend; j++)
    for(i=istart; i<iend; i++) {
      ipos[0]=(lbdm.xs + i - lbdm.bwid)*float(lbdx);
      ipos[1]=(lbdm.ys + j - lbdm.bwid)*float(lbdx);
      ipos[2]=0.0;
      if (!bigend) fByteSwap(ipos,sizeof(float),3);
      file.write((char*)&ipos, 3*sizeof(float));
    }

  file<<"POINT_DATA  "<<(ilen1*ilen2)<<endl;
  file<<"SCALARS fraction float"<<endl;
  file<<"LOOKUP_TABLE default"<<endl;

  // write mass fraction
  if(interact==5 && lbsy.nf>1) {
    for(j=jstart; j<jend; j++) {
      for(i=istart; i<iend; i++) {
        ilen = i* lbdm.youter + j;
        ipos[0] = float(fGetFracSwiftSite(iprop, &lbf[ilen*lbsitelength]));
        if (!bigend) fByteSwap(ipos,sizeof(float),1);
        file.write((char*)&ipos[0], sizeof(float));
      }
    }
  }
  else {
    for(j=jstart; j<jend; j++) {
      for(i=istart; i<iend; i++) {
        ilen = i* lbdm.youter + j;
        ipos[0] = float(fGetFracSite(iprop, &lbf[ilen*lbsitelength]));
        if (!bigend) fByteSwap(ipos,sizeof(float),1);
        file.write((char*)&ipos[0], sizeof(float));
      }
    }
  }

  file<<"VECTORS velocity float"<<endl;

  // write velocity
  if(!incompress) {
    for(j=jstart; j<jend; j++) {
      for(i=istart; i<iend; i++) {
        ilen = i* lbdm.youter + j;
        if(lbphi[ilen] == 12 || lbphi[ilen] == 13) {
	      ipos[0] = 0.0;
          ipos[1] = 0.0;
        }
        else {
          ipos[0] = fGetOneDirecSpeedSite(0, &lbf[ilen*lbsitelength]);
          ipos[1] = fGetOneDirecSpeedSite(1, &lbf[ilen*lbsitelength]);
        }
        ipos[2] = 0.0;
        if (!bigend) fByteSwap(ipos,sizeof(float),3);
        file.write((char*)&ipos, 3*sizeof(float));
      }
    }
  }
  else {
    for(j=jstart; j<jend; j++) {
      for(i=istart; i<iend; i++) {
        ilen = i* lbdm.youter + j;
        if(lbphi[ilen] == 12 || lbphi[ilen] == 13) {
	      ipos[0] = 0.0;
          ipos[1] = 0.0;
        }
        else {
          ipos[0] = fGetOneDirecSpeedIncomSite(0, &lbf[ilen*lbsitelength]);
          ipos[1] = fGetOneDirecSpeedIncomSite(1, &lbf[ilen*lbsitelength]);
        }
        ipos[2] = 0.0;
        if (!bigend) fByteSwap(ipos,sizeof(float),3);
        file.write((char*)&ipos, 3*sizeof(float));
      }
    }
  }

  file<<"SCALARS phase_field int"<<endl;
  file<<"LOOKUP_TABLE default"<<endl;
  
  // write phase field/space property
  for(j=jstart; j<jend; j++)
    for(i=istart; i<iend; i++) {
      ilen=i*lbdm.youter +j;
      jpos=lbphi[ilen];
      if (!bigend) fByteSwap(&jpos,sizeof(int),1);
      file.write(reinterpret_cast<const char*>(&jpos), sizeof(int));
    }
		
  file.close();
  
  return 0;
}


int fsOutputLegacyVTKCA2D(const char* filename="lbout", int iprop=0)
{
  int i, j, istart, iend, jstart, jend;
  float ipos[3];
  int jpos;
  int ilen=0, ilen1=0, ilen2=0;
  char buf[80];
  if(lbdm.size>1)
    sprintf(buf, "%s%.6dat%.6d.vtk", filename, lbdm.rank, qVersion);
  else
    sprintf(buf, "%s%.6d.vtk", filename, qVersion);
  ofstream file(buf);
  file<<"# vtk DataFile Version 3.0"<<endl;
  file<<"DL_MESO_LBE"<<endl;
  file<<"ASCII"<<endl;
  file<<"DATASET STRUCTURED_GRID"<<endl;

  ilen1=lbdm.xouter;
  if(lbdm.xcor == 0)
    ilen1 -= lbdm.bwid;
  if(lbdm.xcor == lbdm.xdim-1)
    ilen1 -= lbdm.bwid;

  ilen2=lbdm.youter;
  if(lbdm.ycor == 0)
    ilen2 -= lbdm.bwid;
  if(lbdm.ycor == lbdm.ydim-1)
    ilen2 -= lbdm.bwid;

  file<<"DIMENSIONS  "<<ilen1<<"  "<<ilen2<<"  1"<<endl;
  file<<"POINTS  "<<(ilen1*ilen2)<<"  float"<<endl;
    
  // write grid points
  istart = 0; iend = lbdm.xouter; 
  if(lbdm.xcor == 0)
    istart = lbdm.bwid;
  if(lbdm.xcor == lbdm.xdim-1)
    iend = lbdm.xouter - lbdm.bwid;

  jstart = 0; jend = lbdm.youter; 
  if(lbdm.ycor == 0)
    jstart = lbdm.bwid;
  if(lbdm.ycor == lbdm.ydim-1)
    jend = lbdm.youter - lbdm.bwid;
    
  for(j=jstart; j<jend; j++)
    for(i=istart; i<iend; i++)
      file<<(lbdm.xs+i-lbdm.bwid)*float(lbdx)<<"  "<<(lbdm.ys+j-lbdm.bwid)*float(lbdx)<<"  "<<0.0<<endl;
  file<<endl;
  file<<"POINT_DATA  "<<(ilen1*ilen2)<<endl;
  // write mass fraction
  file<<"SCALARS fraction float"<<endl;
  file<<"LOOKUP_TABLE default"<<endl;
  if(interact==5 && lbsy.nf>1) {
    for(j=jstart; j<jend; j++) {
      for(i=istart; i<iend; i++) {
	    ilen = i * lbdm.youter + j;
	    ipos[0] = float(fGetFracSwiftSite(iprop, &lbf[ilen*lbsitelength]));
	    file<<ipos[0]<<endl;
      }
    }
  }
  else {
    for(j=jstart; j<jend; j++) {
      for(i=istart; i<iend; i++) {
	    ilen = i * lbdm.youter + j;
	    ipos[0] = float(fGetFracSite(iprop, &lbf[ilen*lbsitelength]));
	    file<<ipos[0]<<endl;
      }
    }
  }
  // write velocity
  file<<endl;
  file<<"VECTORS velocity float"<<endl;
  if(interact==5) {
    for(j=jstart; j<jend; j++) {
      for(i=istart; i<iend; i++) {
	    ilen = i * lbdm.youter + j;
 	    if(lbphi[ilen] == 12 || lbphi[ilen] == 13) {
	      ipos[0] = 0.0;
          ipos[1] = 0.0;
        }
	    else {
          ipos[0] = fGetOneDirecSpeedSwiftSite(0, &lbf[ilen*lbsitelength]);
          ipos[1] = fGetOneDirecSpeedSwiftSite(1, &lbf[ilen*lbsitelength]);
        }
	    file<<ipos[0]<<"  "<<ipos[1]<<"  "<<0.0<<endl;
      }
    }
  }
  else if(!incompress) {
    for(j=jstart; j<jend; j++) {
      for(i=istart; i<iend; i++) {
	    ilen = i * lbdm.youter + j;
 	    if(lbphi[ilen] == 12 || lbphi[ilen] == 13) {
	      ipos[0] = 0.0;
          ipos[1] = 0.0;
        }
	    else {
          ipos[0] = fGetOneDirecSpeedSite(0, &lbf[ilen*lbsitelength]);
          ipos[1] = fGetOneDirecSpeedSite(1, &lbf[ilen*lbsitelength]);
        }
	    file<<ipos[0]<<"  "<<ipos[1]<<"  "<<0.0<<endl;
      }
    }
  }
  else {
    for(j=jstart; j<jend; j++) {
      for(i=istart; i<iend; i++) {
	    ilen = i * lbdm.youter + j;
 	    if(lbphi[ilen] == 12 || lbphi[ilen] == 13) {
	      ipos[0] = 0.0;
          ipos[1] = 0.0;
        }
	    else {
          ipos[0] = fGetOneDirecSpeedIncomSite(0, &lbf[ilen*lbsitelength]);
          ipos[1] = fGetOneDirecSpeedIncomSite(1, &lbf[ilen*lbsitelength]);
        }
	    file<<ipos[0]<<"  "<<ipos[1]<<"  "<<0.0<<endl;
      }
    }
  }

  // write phase field/space property
  file<<endl;
  file<<"SCALARS phase_field int"<<endl;
  file<<"LOOKUP_TABLE default"<<endl;
  for(j=jstart; j<jend; j++)
    for(i=istart; i<iend; i++)
      {
	    ilen = i * lbdm.youter + j;
	    jpos=lbphi[ilen];
	    file<<jpos<<endl;
	  }
  file.close();
  return 0;
}


int fOutputLegacyVTKCB3D(const char* filename="lbout", int iprop=0)
{

  // output .vtk file with concentration and velocity for solute iprop

  int i, j, k, istart, iend, jstart, jend, kstart, kend;
  float ipos[3];
  int jpos;
  int ilen=0, ilen1=0, ilen2=0, ilen3=0;
  char buf[80];
  if(lbdm.size>1)
    sprintf(buf, "%s%.6dat%.6d.vtk", filename, lbdm.rank, qVersion);
  else
    sprintf(buf, "%s%.6d.vtk", filename, qVersion);
  ofstream file(buf, ios::binary);

  file<<"# vtk DataFile Version 3.0"<<endl;
  file<<"DL_MESO_LBE"<<endl;
  file<<"BINARY"<<endl;
  file<<"DATASET STRUCTURED_GRID"<<endl;

  ilen1=lbdm.xouter;
  if(lbdm.xcor == 0)
    ilen1 -= lbdm.bwid;
  if(lbdm.xcor == lbdm.xdim-1)
    ilen1 -= lbdm.bwid;

  ilen2=lbdm.youter;
  if(lbdm.ycor == 0)
    ilen2 -= lbdm.bwid;
  if(lbdm.ycor == lbdm.ydim-1)
    ilen2 -= lbdm.bwid;

  ilen3=lbdm.zouter;
  if(lbdm.zcor == 0)
    ilen3 -= lbdm.bwid;
  if(lbdm.zcor == lbdm.zdim-1)
    ilen3 -= lbdm.bwid;

  file<<"DIMENSIONS  "<<ilen1<<"  "<<ilen2<<"  "<<ilen3<<endl;
  file<<"POINTS  "<<(ilen1*ilen2*ilen3)<<"  float"<<endl;

  // write grid points
  istart = 0; iend = lbdm.xouter; 
  if(lbdm.xcor == 0)
    istart = lbdm.bwid;
  if(lbdm.xcor == lbdm.xdim-1)
    iend = lbdm.xouter - lbdm.bwid;

  jstart = 0; jend = lbdm.youter; 
  if(lbdm.ycor == 0)
    jstart = lbdm.bwid;
  if(lbdm.ycor == lbdm.ydim-1)
    jend = lbdm.youter - lbdm.bwid;

  kstart = 0; kend = lbdm.zouter; 
  if(lbdm.zcor == 0)
    kstart = lbdm.bwid;
  if(lbdm.zcor == lbdm.zdim-1)
    kend = lbdm.zouter - lbdm.bwid;

  for(k=kstart; k<kend; k++)
    for(j=jstart; j<jend; j++) {
      for(i=istart; i<iend; i++) {
	    ipos[0]=(lbdm.xs + i - lbdm.bwid)*float(lbdx);
	    ipos[1]=(lbdm.ys + j - lbdm.bwid)*float(lbdx);
	    ipos[2]=(lbdm.zs + k - lbdm.bwid)*float(lbdx);
        if (!bigend) fByteSwap(ipos,sizeof(float),3);
	    file.write((char*)&ipos, 3*sizeof(float));
      }
    }

  file<<"POINT_DATA  "<<(ilen1*ilen2*ilen3)<<endl;
  file<<"SCALARS concentration float"<<endl;
  file<<"LOOKUP_TABLE default"<<endl;

  // write solute concentration
  for(k=kstart; k<kend; k++)
    for(j=jstart; j<jend; j++) {
      for(i=istart; i<iend; i++) {
	    ilen = (i* lbdm.youter + j) * lbdm.zouter + k;
	    ipos[0] = float(fGetOneConcSite(iprop, ilen));
        if (!bigend) fByteSwap(ipos,sizeof(float),1);
	    file.write((char*)&ipos[0], sizeof(float));
      }
    }

  file<<"VECTORS velocity float"<<endl;

  // write velocity
  if(interact==5) {
    for(k=kstart; k<kend; k++) {
      for(j=jstart; j<jend; j++) {
        for(i=istart; i<iend; i++) {
	      ilen = (i* lbdm.youter + j) * lbdm.zouter + k;
  	      if(lbphi[ilen] == 12 || lbphi[ilen] == 13) {
	        ipos[0] = 0.0;
            ipos[1] = 0.0;
            ipos[2] = 0.0;
          }
	      else {
            ipos[0] = fGetOneDirecSpeedSwiftSite(0, &lbf[ilen*lbsitelength]);
            ipos[1] = fGetOneDirecSpeedSwiftSite(1, &lbf[ilen*lbsitelength]);
            ipos[2] = fGetOneDirecSpeedSwiftSite(2, &lbf[ilen*lbsitelength]);
          }
          if (!bigend) fByteSwap(ipos,sizeof(float),3);
	      file.write((char*)&ipos, 3*sizeof(float));
        }
      }
    }
  }
  else if(!incompress) {
    for(k=kstart; k<kend; k++) {
      for(j=jstart; j<jend; j++) {
        for(i=istart; i<iend; i++) {
	      ilen = (i* lbdm.youter + j) * lbdm.zouter + k;
  	      if(lbphi[ilen] == 12 || lbphi[ilen] == 13) {
	        ipos[0] = 0.0;
            ipos[1] = 0.0;
            ipos[2] = 0.0;
          }
	      else {
            ipos[0] = fGetOneDirecSpeedSite(0, &lbf[ilen*lbsitelength]);
            ipos[1] = fGetOneDirecSpeedSite(1, &lbf[ilen*lbsitelength]);
            ipos[2] = fGetOneDirecSpeedSite(2, &lbf[ilen*lbsitelength]);
          }
          if (!bigend) fByteSwap(ipos,sizeof(float),3);
	      file.write((char*)&ipos, 3*sizeof(float));
        }
      }
    }
  }
  else {
    for(k=kstart; k<kend; k++) {
      for(j=jstart; j<jend; j++) {
        for(i=istart; i<iend; i++) {
	      ilen = (i* lbdm.youter + j) * lbdm.zouter + k;
  	      if(lbphi[ilen] == 12 || lbphi[ilen] == 13) {
	        ipos[0] = 0.0;
            ipos[1] = 0.0;
            ipos[2] = 0.0;
          }
	      else {
            ipos[0] = fGetOneDirecSpeedIncomSite(0, &lbf[ilen*lbsitelength]);
            ipos[1] = fGetOneDirecSpeedIncomSite(1, &lbf[ilen*lbsitelength]);
            ipos[2] = fGetOneDirecSpeedIncomSite(2, &lbf[ilen*lbsitelength]);
          }
          if (!bigend) fByteSwap(ipos,sizeof(float),3);
	      file.write((char*)&ipos, 3*sizeof(float));
        }
      }
    }
  }

  file<<"SCALARS phase_field int"<<endl;
  file<<"LOOKUP_TABLE default"<<endl;
  
  // write phase field/space property
  for(k=kstart; k<kend; k++)
    for(j=jstart; j<jend; j++) {
      for(i=istart; i<iend; i++) {
	    ilen=(i*lbdm.youter +j)*lbdm.zouter+k;
	    jpos=lbphi[ilen];
        if (!bigend) fByteSwap(&jpos,sizeof(int),1);
	    file.write(reinterpret_cast<const char*>(&jpos), sizeof(int));
      }
    }	
  file.close();
  
  return 0;
}


int fsOutputLegacyVTKCB3D(const char* filename="lbout", int iprop=0)
{
  int i, j, k, istart, iend, jstart, jend, kstart, kend;
  float ipos[3];
  int jpos;
  int ilen=0, ilen1=0, ilen2=0, ilen3=0;
  char buf[80];
  if(lbdm.size>1)
    sprintf(buf, "%s%.6dat%.6d.vtk", filename, lbdm.rank, qVersion);
  else
    sprintf(buf, "%s%.6d.vtk", filename, qVersion);
  ofstream file(buf);
  file<<"# vtk DataFile Version 3.0"<<endl;
  file<<"DL_MESO_LBE"<<endl;
  file<<"ASCII"<<endl;
  file<<"DATASET STRUCTURED_GRID"<<endl;
  ilen1=lbdm.xouter;
  if(lbdm.xcor == 0)
    ilen1 -= lbdm.bwid;
  if(lbdm.xcor == lbdm.xdim-1)
    ilen1 -= lbdm.bwid;

  ilen2=lbdm.youter;
  if(lbdm.ycor == 0)
    ilen2 -= lbdm.bwid;
  if(lbdm.ycor == lbdm.ydim-1)
    ilen2 -= lbdm.bwid;

  ilen3=lbdm.zouter;
  if(lbdm.zcor == 0)
    ilen3 -= lbdm.bwid;
  if(lbdm.zcor == lbdm.zdim-1)
    ilen3 -= lbdm.bwid;

  file<<"DIMENSIONS  "<<ilen1<<"  "<<ilen2<<"  "<<ilen3<<endl;
  file<<"POINTS  "<<(ilen1*ilen2*ilen3)<<"  float"<<endl;

  // write grid points
  istart = 0; iend = lbdm.xouter; 
  if(lbdm.xcor == 0)
    istart = lbdm.bwid;
  if(lbdm.xcor == lbdm.xdim-1)
    iend = lbdm.xouter - lbdm.bwid;

  jstart = 0; jend = lbdm.youter; 
  if(lbdm.ycor == 0)
    jstart = lbdm.bwid;
  if(lbdm.ycor == lbdm.ydim-1)
    jend = lbdm.youter - lbdm.bwid;

  kstart = 0; kend = lbdm.zouter; 
  if(lbdm.zcor == 0)
    kstart = lbdm.bwid;
  if(lbdm.zcor == lbdm.zdim-1)
    kend = lbdm.zouter - lbdm.bwid;

  for(k=kstart; k<kend; k++)
    for(j=jstart; j<jend; j++)
      for(i=istart; i<iend; i++)
	    file<<(lbdm.xs+i-lbdm.bwid)*float(lbdx)<<"  "<<(lbdm.ys+j-lbdm.bwid)*float(lbdx)<<"  "<<(lbdm.zs+k-lbdm.bwid)*float(lbdx)<<endl;
  file<<endl;
  file<<"POINT_DATA  "<<(ilen1*ilen2*ilen3)<<endl;
  // write solute concentration
  file<<"SCALARS concentration float"<<endl;
  file<<"LOOKUP_TABLE default"<<endl;
  for(k=kstart; k<kend; k++)
    for(j=jstart; j<jend; j++)
      for(i=istart; i<iend; i++)
	    {
	      ilen = (i * lbdm.youter + j) * lbdm.zouter + k;
	      ipos[0] = float(fGetOneConcSite(iprop, ilen));
	      file<<ipos[0]<<endl;
	    }
  // write velocity
  file<<endl;
  file<<"VECTORS velocity float"<<endl;
  if(interact==5) {
    for(k=kstart; k<kend; k++) {
      for(j=jstart; j<jend; j++) {
        for(i=istart; i<iend; i++) {
	      ilen = (i * lbdm.youter + j) * lbdm.zouter + k;
 	      if(lbphi[ilen] == 12 || lbphi[ilen] == 13) {
	        ipos[0] = 0.0;
            ipos[1] = 0.0;
            ipos[2] = 0.0;
          }
	      else {
            ipos[0] = fGetOneDirecSpeedSwiftSite(0, &lbf[ilen*lbsitelength]);
            ipos[1] = fGetOneDirecSpeedSwiftSite(1, &lbf[ilen*lbsitelength]);
            ipos[2] = fGetOneDirecSpeedSwiftSite(2, &lbf[ilen*lbsitelength]);
          }
	      file<<ipos[0]<<"  "<<ipos[1]<<"  "<<ipos[2]<<endl;
	    }
      }
    }
  }
  else if(!incompress) {
    for(k=kstart; k<kend; k++) {
      for(j=jstart; j<jend; j++) {
        for(i=istart; i<iend; i++) {
	      ilen = (i * lbdm.youter + j) * lbdm.zouter + k;
 	      if(lbphi[ilen] == 12 || lbphi[ilen] == 13) {
	        ipos[0] = 0.0;
            ipos[1] = 0.0;
            ipos[2] = 0.0;
          }
	      else {
            ipos[0] = fGetOneDirecSpeedSite(0, &lbf[ilen*lbsitelength]);
            ipos[1] = fGetOneDirecSpeedSite(1, &lbf[ilen*lbsitelength]);
            ipos[2] = fGetOneDirecSpeedSite(2, &lbf[ilen*lbsitelength]);
          }
	      file<<ipos[0]<<"  "<<ipos[1]<<"  "<<ipos[2]<<endl;
	    }
      }
    }
  }
  else {
    for(k=kstart; k<kend; k++) {
      for(j=jstart; j<jend; j++) {
        for(i=istart; i<iend; i++) {
	      ilen = (i * lbdm.youter + j) * lbdm.zouter + k;
 	      if(lbphi[ilen] == 12 || lbphi[ilen] == 13) {
	        ipos[0] = 0.0;
            ipos[1] = 0.0;
            ipos[2] = 0.0;
          }
	      else {
            ipos[0] = fGetOneDirecSpeedIncomSite(0, &lbf[ilen*lbsitelength]);
            ipos[1] = fGetOneDirecSpeedIncomSite(1, &lbf[ilen*lbsitelength]);
            ipos[2] = fGetOneDirecSpeedIncomSite(2, &lbf[ilen*lbsitelength]);
          }
	      file<<ipos[0]<<"  "<<ipos[1]<<"  "<<ipos[2]<<endl;
	    }
      }
    }
  }

  // write phase field/space property
  file<<endl;
  file<<"SCALARS phase_field int"<<endl;
  file<<"LOOKUP_TABLE default"<<endl;
  for(k=kstart; k<kend; k++)
    for(j=jstart; j<jend; j++)
      for(i=istart; i<iend; i++)
	    {
	      ilen = (i * lbdm.youter + j) * lbdm.zouter + k;
	      jpos=lbphi[ilen];
	      file<<jpos<<endl;
	    }
  file.close();
  return 0;
}


int fOutputLegacyVTKCB2D(const char* filename="lbout", int iprop=0)
{

  // output .vtk file with concentration and velocity for solute iprop

  int i, j, istart, iend, jstart, jend;
  float ipos[3];
  int jpos;
  int ilen=0, ilen1=0, ilen2=0;
  static int qVersion;
  char buf[80];
  if(lbdm.size>1)
    sprintf(buf, "%s%.6dat%.6d.vtk", filename, lbdm.rank, qVersion);
  else
    sprintf(buf, "%s%.6d.vtk", filename, qVersion);
  ofstream file(buf, ios::binary);

  file<<"# vtk DataFile Version 3.0"<<endl;
  file<<"DL_MESO_LBE"<<endl;
  file<<"BINARY"<<endl;
  file<<"DATASET STRUCTURED_GRID"<<endl;

  ilen1=lbdm.xouter;
  if(lbdm.xcor == 0)
    ilen1 -= lbdm.bwid;
  if(lbdm.xcor == lbdm.xdim-1)
    ilen1 -= lbdm.bwid;

  ilen2=lbdm.youter;
  if(lbdm.ycor == 0)
    ilen2 -= lbdm.bwid;
  if(lbdm.ycor == lbdm.ydim-1)
    ilen2 -= lbdm.bwid;

  file<<"DIMENSIONS  "<<ilen1<<"  "<<ilen2<<"  1"<<endl;
  file<<"POINTS  "<<(ilen1*ilen2)<<"  float"<<endl;

  // write grid points
  istart = 0; iend = lbdm.xouter; 
  if(lbdm.xcor == 0)
    istart = lbdm.bwid;
  if(lbdm.xcor == lbdm.xdim-1)
    iend = lbdm.xouter - lbdm.bwid;

  jstart = 0; jend = lbdm.youter; 
  if(lbdm.ycor == 0)
    jstart = lbdm.bwid;
  if(lbdm.ycor == lbdm.ydim-1)
    jend = lbdm.youter - lbdm.bwid;

  for(j=jstart; j<jend; j++)
    for(i=istart; i<iend; i++) {
      ipos[0]=(lbdm.xs + i - lbdm.bwid)*float(lbdx);
      ipos[1]=(lbdm.ys + j - lbdm.bwid)*float(lbdx);
      ipos[2]=0.0;
      if (!bigend) fByteSwap(ipos,sizeof(float),3);
      file.write((char*)&ipos, 3*sizeof(float));
    }


  file<<"POINT_DATA  "<<(ilen1*ilen2)<<endl;
  file<<"SCALARS concentration float"<<endl;
  file<<"LOOKUP_TABLE default"<<endl;

  // write solute concentration
  for(j=jstart; j<jend; j++)
    for(i=istart; i<iend; i++) {
      ilen = i* lbdm.youter + j;
      ipos[0] = float(fGetOneConcSite(iprop, ilen));
      if (!bigend) fByteSwap(ipos,sizeof(float),1);
      file.write((char*)&ipos[0], sizeof(float));
    }

  file<<"VECTORS velocity float"<<endl;

  // write velocity
  if(interact==5) {
    for(j=jstart; j<jend; j++) {
      for(i=istart; i<iend; i++) {
        ilen = i* lbdm.youter + j;
        if(lbphi[ilen] == 12 || lbphi[ilen] == 13) {
  	      ipos[0] = 0.0;
          ipos[1] = 0.0;
        }
        else {
          ipos[0] = fGetOneDirecSpeedSwiftSite(0, &lbf[ilen*lbsitelength]);
          ipos[1] = fGetOneDirecSpeedSwiftSite(1, &lbf[ilen*lbsitelength]);
        }
        ipos[2] = 0.0;
        if (!bigend) fByteSwap(ipos,sizeof(float),3);
        file.write((char*)&ipos, 3*sizeof(float));
      }
    }
  }
  else if(!incompress) {
    for(j=jstart; j<jend; j++) {
      for(i=istart; i<iend; i++) {
        ilen = i* lbdm.youter + j;
        if(lbphi[ilen] == 12 || lbphi[ilen] == 13) {
  	      ipos[0] = 0.0;
          ipos[1] = 0.0;
        }
        else {
          ipos[0] = fGetOneDirecSpeedSite(0, &lbf[ilen*lbsitelength]);
          ipos[1] = fGetOneDirecSpeedSite(1, &lbf[ilen*lbsitelength]);
        }
        ipos[2] = 0.0;
        if (!bigend) fByteSwap(ipos,sizeof(float),3);
        file.write((char*)&ipos, 3*sizeof(float));
      }
    }
  }
  else {
    for(j=jstart; j<jend; j++) {
      for(i=istart; i<iend; i++) {
        ilen = i* lbdm.youter + j;
        if(lbphi[ilen] == 12 || lbphi[ilen] == 13) {
  	      ipos[0] = 0.0;
          ipos[1] = 0.0;
        }
        else {
          ipos[0] = fGetOneDirecSpeedSite(0, &lbf[ilen*lbsitelength]);
          ipos[1] = fGetOneDirecSpeedSite(1, &lbf[ilen*lbsitelength]);
        }
        ipos[2] = 0.0;
        if (!bigend) fByteSwap(ipos,sizeof(float),3);
        file.write((char*)&ipos, 3*sizeof(float));
      }
    }
  }

  file<<"SCALARS phase_field int"<<endl;
  file<<"LOOKUP_TABLE default"<<endl;
  
  // write phase field/space property
  for(j=jstart; j<jend; j++)
    for(i=istart; i<iend; i++) {
      ilen=i*lbdm.youter +j;
      jpos=lbphi[ilen];
      if (!bigend) fByteSwap(&jpos,sizeof(int),1);
      file.write(reinterpret_cast<const char*>(&jpos), sizeof(int));
    }
	
  file.close();
  
  return 0;
}


int fsOutputLegacyVTKCB2D(const char* filename="lbout", int iprop=0)
{
  int i, j, istart, iend, jstart, jend;
  float ipos[3];
  int jpos;
  int ilen=0, ilen1=0, ilen2=0;
  static int qVersion;
  char buf[80];
  if(lbdm.size>1)
    sprintf(buf, "%s%.6dat%.6d.vtk", filename, lbdm.rank, qVersion);
  else
    sprintf(buf, "%s%.6d.vtk", filename, qVersion);
  ofstream file(buf);
  file<<"# vtk DataFile Version 3.0"<<endl;
  file<<"DL_MESO_LBE"<<endl;
  file<<"ASCII"<<endl;
  file<<"DATASET STRUCTURED_GRID"<<endl;

  ilen1=lbdm.xouter;
  if(lbdm.xcor == 0)
    ilen1 -= lbdm.bwid;
  if(lbdm.xcor == lbdm.xdim-1)
    ilen1 -= lbdm.bwid;

  ilen2=lbdm.youter;
  if(lbdm.ycor == 0)
    ilen2 -= lbdm.bwid;
  if(lbdm.ycor == lbdm.ydim-1)
    ilen2 -= lbdm.bwid;

  file<<"DIMENSIONS  "<<ilen1<<"  "<<ilen2<<"  1"<<endl;
  file<<"POINTS  "<<(ilen1*ilen2)<<"  float"<<endl;

  // write grid points
  istart = 0; iend = lbdm.xouter; 
  if(lbdm.xcor == 0)
    istart = lbdm.bwid;
  if(lbdm.xcor == lbdm.xdim-1)
    iend = lbdm.xouter - lbdm.bwid;

  jstart = 0; jend = lbdm.youter; 
  if(lbdm.ycor == 0)
    jstart = lbdm.bwid;
  if(lbdm.ycor == lbdm.ydim-1)
    jend = lbdm.youter - lbdm.bwid;

  for(j=jstart; j<jend; j++)
    for(i=istart; i<iend; i++)
      file<<(lbdm.xs+i-lbdm.bwid)*float(lbdx)<<"  "<<(lbdm.ys+j-lbdm.bwid)*float(lbdx)<<"  "<<0.0<<endl;
  file<<endl;
  file<<"POINT_DATA  "<<(ilen1*ilen2)<<endl;
  // write solute concentration
  file<<"SCALARS concentration float"<<endl;
  file<<"LOOKUP_TABLE default"<<endl;
  for(j=jstart; j<jend; j++)
    for(i=istart; i<iend; i++)
      {
	    ilen = i * lbdm.youter + j;
	    ipos[0] = float(fGetOneConcSite(iprop, ilen));
	    file<<ipos[0]<<endl;
      }
  // write velocity
  file<<endl;
  file<<"VECTORS velocity float"<<endl;
  if(interact==5) {
    for(j=jstart; j<jend; j++) {
      for(i=istart; i<iend; i++) {
	    ilen = i * lbdm.youter + j;
 	    if(lbphi[ilen] == 12 || lbphi[ilen] == 13) {
	      ipos[0] = 0.0;
          ipos[1] = 0.0;
        }
	    else {
          ipos[0] = fGetOneDirecSpeedSwiftSite(0, &lbf[ilen*lbsitelength]);
          ipos[1] = fGetOneDirecSpeedSwiftSite(1, &lbf[ilen*lbsitelength]);
        }
	    file<<ipos[0]<<"  "<<ipos[1]<<"  "<<0.0<<endl;
      }
    }
  }
  else if(!incompress) {
    for(j=jstart; j<jend; j++) {
      for(i=istart; i<iend; i++) {
	    ilen = i * lbdm.youter + j;
 	    if(lbphi[ilen] == 12 || lbphi[ilen] == 13) {
	      ipos[0] = 0.0;
          ipos[1] = 0.0;
        }
	    else {
          ipos[0] = fGetOneDirecSpeedSite(0, &lbf[ilen*lbsitelength]);
          ipos[1] = fGetOneDirecSpeedSite(1, &lbf[ilen*lbsitelength]);
        }
	    file<<ipos[0]<<"  "<<ipos[1]<<"  "<<0.0<<endl;
      }
    }
  }
  else {
    for(j=jstart; j<jend; j++) {
      for(i=istart; i<iend; i++) {
	    ilen = i * lbdm.youter + j;
 	    if(lbphi[ilen] == 12 || lbphi[ilen] == 13) {
	      ipos[0] = 0.0;
          ipos[1] = 0.0;
        }
	    else {
          ipos[0] = fGetOneDirecSpeedIncomSite(0, &lbf[ilen*lbsitelength]);
          ipos[1] = fGetOneDirecSpeedIncomSite(1, &lbf[ilen*lbsitelength]);
        }
	    file<<ipos[0]<<"  "<<ipos[1]<<"  "<<0.0<<endl;
      }
    }
  }
  // write phase field/space property
  file<<endl;
  file<<"SCALARS phase_field int"<<endl;
  file<<"LOOKUP_TABLE default"<<endl;
  for(j=jstart; j<jend; j++)
    for(i=istart; i<iend; i++)
      {
	    ilen = i * lbdm.youter + j;
	    jpos=lbphi[ilen];
	    file<<jpos<<endl;
	  }
  file.close();
  return 0;
}


int fOutputLegacyVTKT3D(const char* filename="lbout")
{

  // output .vtk file with scalar temperature and velocity

  int i, j, k, istart, iend, jstart, jend, kstart, kend;
  float ipos[3];
  int jpos;
  int ilen=0, ilen1=0, ilen2=0, ilen3=0;
  char buf[80];
  if(lbdm.size>1)
    sprintf(buf, "%s%.6dat%.6d.vtk", filename, lbdm.rank, qVersion);
  else
    sprintf(buf, "%s%.6d.vtk", filename, qVersion);
  ofstream file(buf, ios::binary);

  file<<"# vtk DataFile Version 3.0"<<endl;
  file<<"DL_MESO_LBE"<<endl;
  file<<"BINARY"<<endl;
  file<<"DATASET STRUCTURED_GRID"<<endl;

  ilen1=lbdm.xouter;
  if(lbdm.xcor == 0)
    ilen1 -= lbdm.bwid;
  if(lbdm.xcor == lbdm.xdim-1)
    ilen1 -= lbdm.bwid;

  ilen2=lbdm.youter;
  if(lbdm.ycor == 0)
    ilen2 -= lbdm.bwid;
  if(lbdm.ycor == lbdm.ydim-1)
    ilen2 -= lbdm.bwid;

  ilen3=lbdm.zouter;
  if(lbdm.zcor == 0)
    ilen3 -= lbdm.bwid;
  if(lbdm.zcor == lbdm.zdim-1)
    ilen3 -= lbdm.bwid;

  file<<"DIMENSIONS  "<<ilen1<<"  "<<ilen2<<"  "<<ilen3<<endl;
  file<<"POINTS  "<<(ilen1*ilen2*ilen3)<<"  float"<<endl;

  // write grid points
  istart = 0; iend = lbdm.xouter; 
  if(lbdm.xcor == 0)
    istart = lbdm.bwid;
  if(lbdm.xcor == lbdm.xdim-1)
    iend = lbdm.xouter - lbdm.bwid;

  jstart = 0; jend = lbdm.youter; 
  if(lbdm.ycor == 0)
    jstart = lbdm.bwid;
  if(lbdm.ycor == lbdm.ydim-1)
    jend = lbdm.youter - lbdm.bwid;

  kstart = 0; kend = lbdm.zouter; 
  if(lbdm.zcor == 0)
    kstart = lbdm.bwid;
  if(lbdm.zcor == lbdm.zdim-1)
    kend = lbdm.zouter - lbdm.bwid;

  for(k=kstart; k<kend; k++)
    for(j=jstart; j<jend; j++) {
      for(i=istart; i<iend; i++) {
	    ipos[0]=(lbdm.xs + i - lbdm.bwid)*float(lbdx);
	    ipos[1]=(lbdm.ys + j - lbdm.bwid)*float(lbdx);
	    ipos[2]=(lbdm.zs + k - lbdm.bwid)*float(lbdx);
        if (!bigend) fByteSwap(ipos,sizeof(float),3);
	    file.write((char*)&ipos, 3*sizeof(float));
      }
    }

  file<<"POINT_DATA  "<<(ilen1*ilen2*ilen3)<<endl;
  file<<"SCALARS temperature float"<<endl;
  file<<"LOOKUP_TABLE default"<<endl;

  // write temperature
  for(k=kstart; k<kend; k++)
    for(j=jstart; j<jend; j++) {
      for(i=istart; i<iend; i++) {
	    ilen = (i* lbdm.youter + j) * lbdm.zouter + k;
	    ipos[0] = float(fGetTemperatureSite(ilen));
        if (!bigend) fByteSwap(ipos,sizeof(float),1);
	    file.write((char*)&ipos[0], sizeof(float));
      }
    }

  file<<"VECTORS velocity float"<<endl;

  // write velocity
  if(interact==5) {
    for(k=kstart; k<kend; k++) {
      for(j=jstart; j<jend; j++) {
        for(i=istart; i<iend; i++) {
	      ilen = (i* lbdm.youter + j) * lbdm.zouter + k;
  	      if(lbphi[ilen] == 12 || lbphi[ilen] == 13) {
	        ipos[0] = 0.0;
            ipos[1] = 0.0;
            ipos[2] = 0.0;
          }
	      else {
            ipos[0] = fGetOneDirecSpeedSwiftSite(0, &lbf[ilen*lbsitelength]);
            ipos[1] = fGetOneDirecSpeedSwiftSite(1, &lbf[ilen*lbsitelength]);
            ipos[2] = fGetOneDirecSpeedSwiftSite(2, &lbf[ilen*lbsitelength]);
          }
          if (!bigend) fByteSwap(ipos,sizeof(float),3);
	      file.write((char*)&ipos, 3*sizeof(float));
        }
      }
    }
  }
  else if(!incompress) {
    for(k=kstart; k<kend; k++) {
      for(j=jstart; j<jend; j++) {
        for(i=istart; i<iend; i++) {
	      ilen = (i* lbdm.youter + j) * lbdm.zouter + k;
  	      if(lbphi[ilen] == 12 || lbphi[ilen] == 13) {
	        ipos[0] = 0.0;
            ipos[1] = 0.0;
            ipos[2] = 0.0;
          }
	      else {
            ipos[0] = fGetOneDirecSpeedSite(0, &lbf[ilen*lbsitelength]);
            ipos[1] = fGetOneDirecSpeedSite(1, &lbf[ilen*lbsitelength]);
            ipos[2] = fGetOneDirecSpeedSite(2, &lbf[ilen*lbsitelength]);
          }
          if (!bigend) fByteSwap(ipos,sizeof(float),3);
	      file.write((char*)&ipos, 3*sizeof(float));
        }
      }
    }
  }
  else {
    for(k=kstart; k<kend; k++) {
      for(j=jstart; j<jend; j++) {
        for(i=istart; i<iend; i++) {
	      ilen = (i* lbdm.youter + j) * lbdm.zouter + k;
  	      if(lbphi[ilen] == 12 || lbphi[ilen] == 13) {
	        ipos[0] = 0.0;
            ipos[1] = 0.0;
            ipos[2] = 0.0;
          }
	      else {
            ipos[0] = fGetOneDirecSpeedIncomSite(0, &lbf[ilen*lbsitelength]);
            ipos[1] = fGetOneDirecSpeedIncomSite(1, &lbf[ilen*lbsitelength]);
            ipos[2] = fGetOneDirecSpeedIncomSite(2, &lbf[ilen*lbsitelength]);
          }
          if (!bigend) fByteSwap(ipos,sizeof(float),3);
	      file.write((char*)&ipos, 3*sizeof(float));
        }
      }
    }
  }

  file<<"SCALARS phase_field int"<<endl;
  file<<"LOOKUP_TABLE default"<<endl;
  
  // write phase field/space property
  for(k=kstart; k<kend; k++)
    for(j=jstart; j<jend; j++) {
      for(i=istart; i<iend; i++) {
	    ilen=(i*lbdm.youter +j)*lbdm.zouter+k;
	    jpos=lbphi[ilen];
        if (!bigend) fByteSwap(&jpos,sizeof(int),1);
	    file.write(reinterpret_cast<const char*>(&jpos), sizeof(int));
      }
    }	
  file.close();
  
  return 0;
}


int fsOutputLegacyVTKT3D(const char* filename="lbout")
{
  int i, j, k, istart, iend, jstart, jend, kstart, kend;
  float ipos[3];
  int jpos;
  int ilen=0, ilen1=0, ilen2=0, ilen3=0;
  char buf[80];
  if(lbdm.size>1)
    sprintf(buf, "%s%.6dat%.6d.vtk", filename, lbdm.rank, qVersion);
  else
    sprintf(buf, "%s%.6d.vtk", filename, qVersion);
  ofstream file(buf);
  file<<"# vtk DataFile Version 3.0"<<endl;
  file<<"DL_MESO_LBE"<<endl;
  file<<"ASCII"<<endl;
  file<<"DATASET STRUCTURED_GRID"<<endl;

  ilen1=lbdm.xouter;
  if(lbdm.xcor == 0)
    ilen1 -= lbdm.bwid;
  if(lbdm.xcor == lbdm.xdim-1)
    ilen1 -= lbdm.bwid;

  ilen2=lbdm.youter;
  if(lbdm.ycor == 0)
    ilen2 -= lbdm.bwid;
  if(lbdm.ycor == lbdm.ydim-1)
    ilen2 -= lbdm.bwid;

  ilen3=lbdm.zouter;
  if(lbdm.zcor == 0)
    ilen3 -= lbdm.bwid;
  if(lbdm.zcor == lbdm.zdim-1)
    ilen3 -= lbdm.bwid;

  file<<"DIMENSIONS  "<<ilen1<<"  "<<ilen2<<"  "<<ilen3<<endl;
  file<<"POINTS  "<<(ilen1*ilen2*ilen3)<<"  float"<<endl;

  // write grid points
  istart = 0; iend = lbdm.xouter; 
  if(lbdm.xcor == 0)
    istart = lbdm.bwid;
  if(lbdm.xcor == lbdm.xdim-1)
    iend = lbdm.xouter - lbdm.bwid;

  jstart = 0; jend = lbdm.youter; 
  if(lbdm.ycor == 0)
    jstart = lbdm.bwid;
  if(lbdm.ycor == lbdm.ydim-1)
    jend = lbdm.youter - lbdm.bwid;

  kstart = 0; kend = lbdm.zouter; 
  if(lbdm.zcor == 0)
    kstart = lbdm.bwid;
  if(lbdm.zcor == lbdm.zdim-1)
    kend = lbdm.zouter - lbdm.bwid;

  for(k=kstart; k<kend; k++)
    for(j=jstart; j<jend; j++)
      for(i=istart; i<iend; i++)
	    file<<(lbdm.xs+i-lbdm.bwid)*float(lbdx)<<"  "<<(lbdm.ys+j-lbdm.bwid)*float(lbdx)<<"  "<<(lbdm.zs+k-lbdm.bwid)*float(lbdx)<<endl;
  file<<endl;
  file<<"POINT_DATA  "<<(ilen1*ilen2*ilen3)<<endl;
  // write temperature
  file<<"SCALARS temperature float"<<endl;
  file<<"LOOKUP_TABLE default"<<endl;
  for(k=kstart; k<kend; k++)
    for(j=jstart; j<jend; j++)
      for(i=istart; i<iend; i++)
	    {
	      ilen = (i * lbdm.youter + j) * lbdm.zouter + k;
	      ipos[0] = float(fGetTemperatureSite(ilen));
	      file<<ipos[0]<<endl;
   	    }
  // write velocity
  file<<endl;
  file<<"VECTORS velocity float"<<endl;
  if(interact==5) {
    for(k=kstart; k<kend; k++) {
      for(j=jstart; j<jend; j++) {
        for(i=istart; i<iend; i++) {
	      ilen = (i * lbdm.youter + j) * lbdm.zouter + k;
 	      if(lbphi[ilen] == 12 || lbphi[ilen] == 13) {
	        ipos[0] = 0.0;
            ipos[1] = 0.0;
            ipos[2] = 0.0;
          }
	      else {
            ipos[0] = fGetOneDirecSpeedSwiftSite(0, &lbf[ilen*lbsitelength]);
            ipos[1] = fGetOneDirecSpeedSwiftSite(1, &lbf[ilen*lbsitelength]);
            ipos[2] = fGetOneDirecSpeedSwiftSite(2, &lbf[ilen*lbsitelength]);
          }
	      file<<ipos[0]<<"  "<<ipos[1]<<"  "<<ipos[2]<<endl;
	    }
      }
    }
  }
  else if(!incompress) {
    for(k=kstart; k<kend; k++) {
      for(j=jstart; j<jend; j++) {
        for(i=istart; i<iend; i++) {
	      ilen = (i * lbdm.youter + j) * lbdm.zouter + k;
 	      if(lbphi[ilen] == 12 || lbphi[ilen] == 13) {
	        ipos[0] = 0.0;
            ipos[1] = 0.0;
            ipos[2] = 0.0;
          }
	      else {
            ipos[0] = fGetOneDirecSpeedSite(0, &lbf[ilen*lbsitelength]);
            ipos[1] = fGetOneDirecSpeedSite(1, &lbf[ilen*lbsitelength]);
            ipos[2] = fGetOneDirecSpeedSite(2, &lbf[ilen*lbsitelength]);
          }
	      file<<ipos[0]<<"  "<<ipos[1]<<"  "<<ipos[2]<<endl;
	    }
      }
    }
  }
  else {
    for(k=kstart; k<kend; k++) {
      for(j=jstart; j<jend; j++) {
        for(i=istart; i<iend; i++) {
	      ilen = (i * lbdm.youter + j) * lbdm.zouter + k;
 	      if(lbphi[ilen] == 12 || lbphi[ilen] == 13) {
	        ipos[0] = 0.0;
            ipos[1] = 0.0;
            ipos[2] = 0.0;
          }
	      else {
            ipos[0] = fGetOneDirecSpeedIncomSite(0, &lbf[ilen*lbsitelength]);
            ipos[1] = fGetOneDirecSpeedIncomSite(1, &lbf[ilen*lbsitelength]);
            ipos[2] = fGetOneDirecSpeedIncomSite(2, &lbf[ilen*lbsitelength]);
          }
	      file<<ipos[0]<<"  "<<ipos[1]<<"  "<<ipos[2]<<endl;
	    }
      }
    }
  }

  // write phase field/space property
  file<<endl;
  file<<"SCALARS phase_field int"<<endl;
  file<<"LOOKUP_TABLE default"<<endl;
  for(k=kstart; k<kend; k++)
    for(j=jstart; j<jend; j++)
      for(i=istart; i<iend; i++)
	    {
	      ilen = (i * lbdm.youter + j) * lbdm.zouter + k;
	      jpos=lbphi[ilen];
	      file<<jpos<<endl;
   	    }
  file.close();
  return 0;
}


int fOutputLegacyVTKT2D(const char* filename="lbout")
{

  // output .vtk file with scalar temperature and velocity

  int i, j, istart, iend, jstart, jend;
  float ipos[3];
  int jpos;
  int ilen=0, ilen1=0, ilen2=0;
  static int qVersion;
  char buf[80];
  if(lbdm.size>1)
    sprintf(buf, "%s%.6dat%.6d.vtk", filename, lbdm.rank, qVersion);
  else
    sprintf(buf, "%s%.6d.vtk", filename, qVersion);
  ofstream file(buf, ios::binary);

  file<<"# vtk DataFile Version 3.0"<<endl;
  file<<"DL_MESO_LBE"<<endl;
  file<<"BINARY"<<endl;
  file<<"DATASET STRUCTURED_GRID"<<endl;

  ilen1=lbdm.xouter;
  if(lbdm.xcor == 0)
    ilen1 -= lbdm.bwid;
  if(lbdm.xcor == lbdm.xdim-1)
    ilen1 -= lbdm.bwid;

  ilen2=lbdm.youter;
  if(lbdm.ycor == 0)
    ilen2 -= lbdm.bwid;
  if(lbdm.ycor == lbdm.ydim-1)
    ilen2 -= lbdm.bwid;

  file<<"DIMENSIONS  "<<ilen1<<"  "<<ilen2<<"  1"<<endl;
  file<<"POINTS  "<<(ilen1*ilen2)<<"  float"<<endl;

  // write grid points
  istart = 0; iend = lbdm.xouter; 
  if(lbdm.xcor == 0)
    istart = lbdm.bwid;
  if(lbdm.xcor == lbdm.xdim-1)
    iend = lbdm.xouter - lbdm.bwid;

  jstart = 0; jend = lbdm.youter; 
  if(lbdm.ycor == 0)
    jstart = lbdm.bwid;
  if(lbdm.ycor == lbdm.ydim-1)
    jend = lbdm.youter - lbdm.bwid;

  for(j=jstart; j<jend; j++)
    for(i=istart; i<iend; i++) {
      ipos[0]=(lbdm.xs + i - lbdm.bwid)*float(lbdx);
      ipos[1]=(lbdm.ys + j - lbdm.bwid)*float(lbdx);
      ipos[2]=0.0;
      if (!bigend) fByteSwap(ipos,sizeof(float),3);
      file.write((char*)&ipos, 3*sizeof(float));
    }

  file<<"POINT_DATA  "<<(ilen1*ilen2)<<endl;
  file<<"SCALARS temperature float"<<endl;
  file<<"LOOKUP_TABLE default"<<endl;

  // write temperature
  for(j=jstart; j<jend; j++)
    for(i=istart; i<iend; i++) {
      ilen = i* lbdm.youter + j;
      ipos[0] = float(fGetTemperatureSite(ilen));
      if (!bigend) fByteSwap(ipos,sizeof(float),1);
      file.write((char*)&ipos, sizeof(float));
    }

  file<<"VECTORS velocity float"<<endl;

  // write velocity
  if(interact==5) {
    for(j=jstart; j<jend; j++) {
      for(i=istart; i<iend; i++) {
        ilen = i* lbdm.youter + j;
        if(lbphi[ilen] == 12 || lbphi[ilen] == 13) {
	      ipos[0] = 0.0;
          ipos[1] = 0.0;
        }
        else {
          ipos[0] = fGetOneDirecSpeedSwiftSite(0, &lbf[ilen*lbsitelength]);
          ipos[1] = fGetOneDirecSpeedSwiftSite(1, &lbf[ilen*lbsitelength]);
        }
        ipos[2] = 0.0;
        if (!bigend) fByteSwap(ipos,sizeof(float),3);
        file.write((char*)&ipos, 3*sizeof(float));
      }
    }
  }
  else if(!incompress) {
    for(j=jstart; j<jend; j++) {
      for(i=istart; i<iend; i++) {
        ilen = i* lbdm.youter + j;
        if(lbphi[ilen] == 12 || lbphi[ilen] == 13) {
	      ipos[0] = 0.0;
          ipos[1] = 0.0;
        }
        else {
          ipos[0] = fGetOneDirecSpeedSite(0, &lbf[ilen*lbsitelength]);
          ipos[1] = fGetOneDirecSpeedSite(1, &lbf[ilen*lbsitelength]);
        }
        ipos[2] = 0.0;
        if (!bigend) fByteSwap(ipos,sizeof(float),3);
        file.write((char*)&ipos, 3*sizeof(float));
      }
    }
  }
  else {
    for(j=jstart; j<jend; j++) {
      for(i=istart; i<iend; i++) {
        ilen = i* lbdm.youter + j;
        if(lbphi[ilen] == 12 || lbphi[ilen] == 13) {
	      ipos[0] = 0.0;
          ipos[1] = 0.0;
        }
        else {
          ipos[0] = fGetOneDirecSpeedIncomSite(0, &lbf[ilen*lbsitelength]);
          ipos[1] = fGetOneDirecSpeedIncomSite(1, &lbf[ilen*lbsitelength]);
        }
        ipos[2] = 0.0;
        if (!bigend) fByteSwap(ipos,sizeof(float),3);
        file.write((char*)&ipos, 3*sizeof(float));
      }
    }
  }

  file<<"SCALARS phase_field int"<<endl;
  file<<"LOOKUP_TABLE default"<<endl;
  
  // write phase field/space property
  for(j=jstart; j<jend; j++)
    for(i=istart; i<iend; i++) {
      ilen=i*lbdm.youter +j;
      jpos=lbphi[ilen];
      if (!bigend) fByteSwap(&jpos,sizeof(int),1);
      file.write(reinterpret_cast<const char*>(&jpos), sizeof(int));
    }
	
  file.close();
  
  return 0;
}


int fsOutputLegacyVTKT2D(const char* filename="lbout")
{
  int i, j, istart, iend, jstart, jend;
  float ipos[3];
  int jpos;
  int ilen=0, ilen1=0, ilen2=0;
  static int qVersion;
  char buf[80];
  if(lbdm.size>1)
    sprintf(buf, "%s%.6dat%.6d.vtk", filename, lbdm.rank, qVersion);
  else
    sprintf(buf, "%s%.6d.vtk", filename, qVersion);
  ofstream file(buf);
  file<<"# vtk DataFile Version 3.0"<<endl;
  file<<"DL_MESO_LBE"<<endl;
  file<<"ASCII"<<endl;
  file<<"DATASET STRUCTURED_GRID"<<endl;

  ilen1=lbdm.xouter;
  if(lbdm.xcor == 0)
    ilen1 -= lbdm.bwid;
  if(lbdm.xcor == lbdm.xdim-1)
    ilen1 -= lbdm.bwid;

  ilen2=lbdm.youter;
  if(lbdm.ycor == 0)
    ilen2 -= lbdm.bwid;
  if(lbdm.ycor == lbdm.ydim-1)
    ilen2 -= lbdm.bwid;

  file<<"DIMENSIONS  "<<ilen1<<"  "<<ilen2<<"  1"<<endl;
  file<<"POINTS  "<<(ilen1*ilen2)<<"  float"<<endl;

  // write grid points
  istart = 0; iend = lbdm.xouter; 
  if(lbdm.xcor == 0)
    istart = lbdm.bwid;
  if(lbdm.xcor == lbdm.xdim-1)
    iend = lbdm.xouter - lbdm.bwid;

  jstart = 0; jend = lbdm.youter; 
  if(lbdm.ycor == 0)
    jstart = lbdm.bwid;
  if(lbdm.ycor == lbdm.ydim-1)
    jend = lbdm.youter - lbdm.bwid;

  for(j=jstart; j<jend; j++)
    for(i=istart; i<iend; i++)
      file<<(lbdm.xs+i-lbdm.bwid)*float(lbdx)<<"  "<<(lbdm.ys+j-lbdm.bwid)*float(lbdx)<<"  "<<0.0<<endl;
  file<<endl;
  file<<"POINT_DATA  "<<(ilen1*ilen2)<<endl;
  // write temperature
  file<<"SCALARS temperature float"<<endl;
  file<<"LOOKUP_TABLE default"<<endl;
  for(j=jstart; j<jend; j++)
    for(i=istart; i<iend; i++)
      {
	    ilen = i * lbdm.youter + j;
	    ipos[0] = float(fGetTemperatureSite(ilen));
	    file<<ipos[0]<<endl;
      }
  // write velocity
  file<<endl;
  file<<"VECTORS velocity float"<<endl;
  if(interact==5) {
    for(j=jstart; j<jend; j++) {
      for(i=istart; i<iend; i++) {
	    ilen = i * lbdm.youter + j;
 	    if(lbphi[ilen] == 12 || lbphi[ilen] == 13) {
	      ipos[0] = 0.0;
          ipos[1] = 0.0;
        }
	    else {
          ipos[0] = fGetOneDirecSpeedSwiftSite(0, &lbf[ilen*lbsitelength]);
          ipos[1] = fGetOneDirecSpeedSwiftSite(1, &lbf[ilen*lbsitelength]);
        }
	    file<<ipos[0]<<"  "<<ipos[1]<<"  "<<0.0<<endl;
      }
    }
  }
  else if(!incompress) {
    for(j=jstart; j<jend; j++) {
      for(i=istart; i<iend; i++) {
	    ilen = i * lbdm.youter + j;
 	    if(lbphi[ilen] == 12 || lbphi[ilen] == 13) {
	      ipos[0] = 0.0;
          ipos[1] = 0.0;
        }
	    else {
          ipos[0] = fGetOneDirecSpeedSite(0, &lbf[ilen*lbsitelength]);
          ipos[1] = fGetOneDirecSpeedSite(1, &lbf[ilen*lbsitelength]);
        }
	    file<<ipos[0]<<"  "<<ipos[1]<<"  "<<0.0<<endl;
      }
    }
  }
  else {
    for(j=jstart; j<jend; j++) {
      for(i=istart; i<iend; i++) {
	    ilen = i * lbdm.youter + j;
 	    if(lbphi[ilen] == 12 || lbphi[ilen] == 13) {
	      ipos[0] = 0.0;
          ipos[1] = 0.0;
        }
	    else {
          ipos[0] = fGetOneDirecSpeedIncomSite(0, &lbf[ilen*lbsitelength]);
          ipos[1] = fGetOneDirecSpeedIncomSite(1, &lbf[ilen*lbsitelength]);
        }
	    file<<ipos[0]<<"  "<<ipos[1]<<"  "<<0.0<<endl;
      }
    }
  }

  // write phase field/space property
  file<<endl;
  file<<"SCALARS phase_field float"<<endl;
  file<<"LOOKUP_TABLE default"<<endl;
  for(j=jstart; j<jend; j++)
    for(i=istart; i<iend; i++)
      {
	    ilen = i * lbdm.youter + j;
	    jpos=lbphi[ilen];
	    file<<jpos<<endl;
	  }
  file.close();
  return 0;
}

