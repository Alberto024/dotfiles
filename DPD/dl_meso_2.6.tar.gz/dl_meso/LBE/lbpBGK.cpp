/***********************************************
 *   DL_MESO       Version 2.6                 *
 *   Authors   :   R. S. Qin, M. A. Seaton     *
 *   Amended   :   L. Grinberg                 *
 *   Copyright :   STFC Daresbury Laboratory   *
 *             :   22/10/2015                  *
 ***********************************************/

// Standard fluid collisions

int fSiteFluidCollisionBGK(double* startpos, double *sitespeed, double* bodyforce)
{
  
  // calculate fluid collisions at grid point: uses BGK single relaxation time

  double speed[3], feq[lbsy.nq], rho[lbsy.nf];
  double invmassrelax, relax;
  double *pt2 = &startpos[0];
  double *pt3 = &bodyforce[0];
  int qdim = lbsy.nf+lbsy.nc+lbsy.nt;
    
  fGetAllMassSite(rho, pt2);

  for(int j=0; j<lbsy.nf; j++) {
    relax = 1.0 - lbtf[j];
    invmassrelax = fReciprocal(rho[j]*lbtf[j]);
    speed[0] = sitespeed[0] + pt3[3*j]   * invmassrelax;
    speed[1] = sitespeed[1] + pt3[3*j+1] * invmassrelax;
    speed[2] = sitespeed[2] + pt3[3*j+2] * invmassrelax;
    fGetEquilibriumF(&feq[0], speed, rho[j]);
    for(int i=0; i<lbsy.nq; i++){
      pt2[i*qdim+j] = relax * pt2[i*qdim+j] + feq[i]*lbtf[j];
    }
  }

  pt2 = NULL;
  pt3 = NULL;  
  return 0;
}

int fSiteFluidIncomCollisionBGK(double* startpos, double *sitespeed, double* bodyforce)
{
  
  // calculate fluid collisions at grid point: uses BGK single relaxation time
  // with incompressible fluids

  double speed[3], feq[lbsy.nq], rho[lbsy.nf];
  double density, invmassrelax, relax;
  double *pt2 = &startpos[0];
  double *pt3 = &bodyforce[0];
  int qdim = lbsy.nf+lbsy.nc+lbsy.nt;

  fGetAllMassSite(rho, pt2);
    
  for(int j=0; j<lbsy.nf; j++) {
    density = lbincp[j];
    relax = 1.0 - lbtf[j];
    invmassrelax = fReciprocal(density * lbtf[j]);
    speed[0] = sitespeed[0] + pt3[3*j]   * invmassrelax;
    speed[1] = sitespeed[1] + pt3[3*j+1] * invmassrelax;
    speed[2] = sitespeed[2] + pt3[3*j+2] * invmassrelax;
    fGetEquilibriumFIncom(&feq[0], speed, rho[j], density);
    for(int i=0; i<lbsy.nq; i++){
      pt2[i*qdim+j] = relax * pt2[i*qdim+j] + feq[i]*lbtf[j];
    }
  }

  pt2 = NULL;
  pt3 = NULL;  
  return 0;
}

int fSiteFluidCollisionBGKEDM(double* startpos, double *sitespeed, double* bodyforce)
{
  
  // calculate fluid collisions at grid point: uses BGK single relaxation time with
  // Exact Difference Method forcing term

  double dv[3], feq[lbsy.nq], rho[lbsy.nf];
  double invmass, relax, source;
  double modv,eixux,eiyuy,eizuz,eixdux,eiyduy,eizduz;
  double *pt2 = &startpos[0];
  double *pt3 = &bodyforce[0];
  int qdim = lbsy.nf+lbsy.nc+lbsy.nt;

  fGetAllMassSite(rho, pt2);

  for(int j=0; j<lbsy.nf; j++) {
    invmass = fReciprocal(rho[j]);
    dv[0] = pt3[3*j]   * invmass;
    dv[1] = pt3[3*j+1] * invmass;
    dv[2] = pt3[3*j+2] * invmass;
    fGetEquilibriumF(&feq[0], sitespeed, rho[j]);
    relax = 1.0 - lbtf[j];
    modv = dv[0]*(2.0*sitespeed[0]+dv[0]) + dv[1]*(2.0*sitespeed[1]+dv[1]) + dv[2]*(2.0*sitespeed[2]+dv[2]);
    for(int i=0; i<lbsy.nq; i++){
      eixux =  lbvx[i]*sitespeed[0];
      eiyuy =  lbvy[i]*sitespeed[1];
      eizuz =  lbvz[i]*sitespeed[2];
      eixdux = lbvx[i]*dv[0];
      eiyduy = lbvy[i]*dv[1];
      eizduz = lbvz[i]*dv[2];
      source = rho[j] * lbw[i] * (3.0 * (eixdux+eiyduy+eizduz) +
                                  4.5 * (eixdux*(eixdux+2.0*(eixux+eiyuy+eizuz+eiyduy+eizduz)) +
                                         eiyduy*(eiyduy+2.0*(eixux+eiyuy+eizuz+eizduz)) +
                                         eizduz*(eizduz+2.0*(eixux+eiyuy+eizuz))) -
                                  1.5 * modv);
      pt2[i*qdim+j] = relax * pt2[i*qdim+j] + source + feq[i]*lbtf[j];
    }
  }

  pt2 = NULL;
  pt3 = NULL;  
  return 0;
}

int fSiteFluidIncomCollisionBGKEDM(double* startpos, double *sitespeed, double* bodyforce)
{
  
  // calculate fluid collisions at grid point: uses BGK single relaxation time
  // with incompressible fluids and Exact Difference Method forcing term

  double dv[3], feq[lbsy.nq], rho[lbsy.nf];
  double density, invmass, relax, source;
  double modv,eixux,eiyuy,eizuz,eixdux,eiyduy,eizduz;
  double *pt2 = &startpos[0];
  double *pt3 = &bodyforce[0];
  int qdim = lbsy.nf+lbsy.nc+lbsy.nt;

  fGetAllMassSite(rho, pt2);

  for(int j=0; j<lbsy.nf; j++) {
    density = lbincp[j];
    invmass = fReciprocal(density);
    relax = 1.0 - lbtf[j];
    dv[0] = pt3[3*j]   * invmass;
    dv[1] = pt3[3*j+1] * invmass;
    dv[2] = pt3[3*j+2] * invmass;
    fGetEquilibriumFIncom(&feq[0], sitespeed, rho[j], density);
    modv = dv[0]*(2.0*sitespeed[0]+dv[0]) + dv[1]*(2.0*sitespeed[1]+dv[1]) + dv[2]*(2.0*sitespeed[2]+dv[2]);
    for(int i=0; i<lbsy.nq; i++){
      eixux =  lbvx[i]*sitespeed[0];
      eiyuy =  lbvy[i]*sitespeed[1];
      eizuz =  lbvz[i]*sitespeed[2];
      eixdux = lbvx[i]*dv[0];
      eiyduy = lbvy[i]*dv[1];
      eizduz = lbvz[i]*dv[2];
      source = density * lbw[i] * (3.0 * (eixdux+eiyduy+eizduz) +
                                   4.5 * (eixdux*(eixdux+2.0*(eixux+eiyuy+eizuz+eiyduy+eizduz)) +
                                          eiyduy*(eiyduy+2.0*(eixux+eiyuy+eizuz+eizduz)) +
                                          eizduz*(eizduz+2.0*(eixux+eiyuy+eizuz))) -
                                   1.5 * modv);
      pt2[i*qdim+j] = relax * pt2[i*qdim+j] + source + feq[i]*lbtf[j];
    }
  }

  pt2 = NULL;
  pt3 = NULL;  
  return 0;
}

int fSiteFluidCollisionBGKGuo(double* startpos, double *sitespeed, double* bodyforce)
{
  
  // calculate fluid collisions at grid point: uses BGK single relaxation time with
  // Guo forcing term

  double speed[3], force[3], feq[lbsy.nq], rho[lbsy.nf];
  double udot, source, invmass, relax, halfrelax, ex, ey, ez;
  double *pt2 = &startpos[0];
  double *pt3 = &bodyforce[0];
  int qdim = lbsy.nf+lbsy.nc+lbsy.nt;

  fGetAllMassSite(rho, pt2);

  for(int j=0; j<lbsy.nf; j++) {
    invmass = fReciprocal(rho[j]);
    force[0] = pt3[3*j];
    force[1] = pt3[3*j+1];
    force[2] = pt3[3*j+2];
    speed[0] = sitespeed[0] + 0.5 * force[0] * invmass;
    speed[1] = sitespeed[1] + 0.5 * force[1] * invmass;
    speed[2] = sitespeed[2] + 0.5 * force[2] * invmass;
    fGetEquilibriumF(&feq[0], speed, rho[j]);
    relax = 1.0 - lbtf[j];
    halfrelax = 1.0 - 0.5*lbtf[j];
    for(int i=0; i<lbsy.nq; i++){
      ex = lbvx[i];
      ey = lbvy[i];
      ez = lbvz[i];
      udot = ex * speed[0] + ey * speed[1] + ez * speed[2];
      source = (3.0*(ex-speed[0]) + 9.0*udot*ex) * force[0]
             + (3.0*(ey-speed[1]) + 9.0*udot*ey) * force[1]
             + (3.0*(ez-speed[2]) + 9.0*udot*ez) * force[2];
      pt2[i*qdim+j] = relax * pt2[i*qdim+j] + halfrelax * lbw[i] * source + feq[i]*lbtf[j];
    }
  }

  pt2 = NULL;
  pt3 = NULL;  
  return 0;
}

int fSiteFluidIncomCollisionBGKGuo(double* startpos, double *sitespeed, double* bodyforce)
{
  
  // calculate fluid collisions at grid point: uses BGK single relaxation time with
  // Guo forcing term for incompressible fluids

  double speed[3], force[3], feq[lbsy.nq], rho[lbsy.nf];
  double density, udot, source, invmass, relax, halfrelax, ex, ey, ez;
  double *pt2 = &startpos[0];
  double *pt3 = &bodyforce[0];
  int qdim = lbsy.nf+lbsy.nc+lbsy.nt;

  fGetAllMassSite(rho, pt2);

  for(int j=0; j<lbsy.nf; j++) {
    density = lbincp[j];
    invmass = fReciprocal(density);
    force[0] = pt3[3*j];
    force[1] = pt3[3*j+1];
    force[2] = pt3[3*j+2];
    speed[0] = sitespeed[0] + 0.5 * force[0] * invmass;
    speed[1] = sitespeed[1] + 0.5 * force[1] * invmass;
    speed[2] = sitespeed[2] + 0.5 * force[2] * invmass;
    fGetEquilibriumFIncom(&feq[0], speed, rho[j], density);
    relax = 1.0 - lbtf[j];
    halfrelax = 1.0 - 0.5*lbtf[j];
    for(int i=0; i<lbsy.nq; i++){
      ex = lbvx[i];
      ey = lbvy[i];
      ez = lbvz[i];
      udot = ex * speed[0] + ey * speed[1] + ez * speed[2];
      source = (3.0*(ex-speed[0]) + 9.0*udot*ex) * force[0]
             + (3.0*(ey-speed[1]) + 9.0*udot*ey) * force[1]
             + (3.0*(ez-speed[2]) + 9.0*udot*ez) * force[2];
      pt2[i*qdim+j] = relax * pt2[i*qdim+j] + halfrelax * lbw[i] * source + feq[i]*lbtf[j];
    }
  }

  pt2 = NULL;
  pt3 = NULL;  
  return 0;
}

// Achromatic fluid collisions with pre-calculated interfacial forces and phase segregation

int fSiteFluidCollisionBGKLishchuk(double* startpos, double *sitespeed, double* bodyforce, double* phaseindex)
{

  // BGK collision of achromatic fluid and D'Ortona segregration 
  // calculate collisions at grid point: uses BGK single relaxation time

  double speed[3], feq[lbsy.nq];
  double allmass, invallmass, omega, nx, ny, nz, segpiece, segcomp, invmassrelax, relax;
  double rho[lbsy.nf], seg[lbsy.nf*lbsy.nq], lbfac[lbsy.nq];
  double *pt2 = &startpos[0];
  double *pt3 = &bodyforce[0];
  double *pt4 = &phaseindex[0];
  int numpair = lbsy.nf*(lbsy.nf-1)/2;
  int qdim = lbsy.nf+lbsy.nc+lbsy.nt;

  // collision of achromatic fluid

  fGetAllMassSite(rho, pt2);
  allmass = 0.0;
  omega = 0.0;

  for(int j=0; j<lbsy.nf; j++) {
    allmass += rho[j];
    omega += lbtf[j] * rho[j];
  }

  invallmass = fReciprocal(allmass);
  omega *= invallmass;
      
  for(int i=0; i<lbsy.nq; i++) {
    lbfac[i] = 0.0;
    for(int j=0; j<lbsy.nf; j++) {
      lbfac[i] += pt2[i*qdim+j];
      seg[i*lbsy.nf+j] = 0.0;
    }
  }

  invmassrelax = invallmass * fReciprocal(omega);
  relax = 1.0 - omega;
  speed[0] = sitespeed[0] + pt3[0] * invmassrelax;
  speed[1] = sitespeed[1] + pt3[1] * invmassrelax;
  speed[2] = sitespeed[2] + pt3[2] * invmassrelax;
  fGetEquilibriumF(&feq[0], speed, allmass);
  for(int i=0; i<lbsy.nq; i++){
    lbfac[i] = relax * lbfac[i] + feq[i]*omega;
  }

  // segregation of fluids

  for(int k=0; k<numpair; k++) {
    int i = lbspair[2*k  ];
    int j = lbspair[2*k+1];
    nx = pt4[3*k  ];
    ny = pt4[3*k+1];
    nz = pt4[3*k+2];
    segpiece = lbseg[lbsy.nf*j+i] * rho[i] * rho[j] * invallmass * invallmass;
    for(int m=0; m<lbsy.nq; m++) {
      segcomp = segpiece * (lbvwx[m]*nx + lbvwy[m]*ny + lbvwz[m]*nz);
      seg[m*lbsy.nf+i] += segcomp;
      seg[m*lbsy.nf+j] -= segcomp;
    }
  }

  for(int m=0; m<lbsy.nq; m++) {
    for(int i=0; i<lbsy.nf; i++) {
      pt2[m*qdim+i] = rho[i] * lbfac[m] * invallmass + seg[m*lbsy.nf+i];
    }
  }

  pt2 = NULL;
  pt3 = NULL;  
  pt4 = NULL;  
  return 0;
}

int fSiteFluidIncomCollisionBGKLishchuk(double* startpos, double *sitespeed, double* bodyforce, double* phaseindex)
{

  // BGK collision of achromatic fluid and D'Ortona segregration 
  // calculate collisions at grid point: uses BGK single relaxation time with incompressible fluids

  double speed[3], feq[lbsy.nq];
  double onemass, allmass, invallmass, invmassrelax, relax, density, omega, nx, ny, nz, segcomp, segpiece;
  double rho[lbsy.nf], seg[lbsy.nf*lbsy.nq], lbfac[lbsy.nq];
  double *pt2 = &startpos[0];
  double *pt3 = &bodyforce[0];
  double *pt4 = &phaseindex[0];
  int numpair = lbsy.nf*(lbsy.nf-1)/2;
  int qdim = lbsy.nf+lbsy.nc+lbsy.nt;

  // collision of achromatic fluid

  fGetAllMassSite(rho, pt2);
  allmass = 0.0;
  omega = 0.0;
  density = 0.0;

  for(int j=0; j<lbsy.nf; j++) {
    omega += lbtf[j] * rho[j];
    density += lbincp[j] * rho[j];
    allmass += rho[j];
  }

  invallmass = fReciprocal(allmass);
  omega *= invallmass;
  density *= invallmass;

  for(int i=0; i<lbsy.nq; i++) {
    lbfac[i] = 0.0;
    for(int j=0; j<lbsy.nf; j++) {
      lbfac[i] += pt2[i*qdim+j];
      seg[i*lbsy.nf+j] = 0.0;
    }
  }

  invmassrelax = fReciprocal(omega*density);
  relax = 1.0 - omega;
  speed[0] = sitespeed[0] + pt3[0] * invmassrelax;
  speed[1] = sitespeed[1] + pt3[1] * invmassrelax;
  speed[2] = sitespeed[2] + pt3[2] * invmassrelax;
  fGetEquilibriumFIncom(&feq[0], speed, allmass, density);
  for(int i=0; i<lbsy.nq; i++){
    lbfac[i] = relax * lbfac[i] + feq[i]*omega;
  }

  // segregation of fluids

  for(int k=0; k<numpair; k++) {
    int i = lbspair[2*k  ];
    int j = lbspair[2*k+1];
    nx = pt4[3*k  ];
    ny = pt4[3*k+1];
    nz = pt4[3*k+2];
    segpiece = lbseg[lbsy.nf*j+i] * rho[i] * rho[j] * invallmass * invallmass;
    for(int m=0; m<lbsy.nq; m++) {
      segcomp = segpiece * (lbvwx[m]*nx + lbvwy[m]*ny + lbvwz[m]*nz);
      seg[m*lbsy.nf+i] += segcomp;
      seg[m*lbsy.nf+j] -= segcomp;
    }
  }

  for(int m=0; m<lbsy.nq; m++) {
    for(int i=0; i<lbsy.nf; i++) {
      pt2[m*qdim+i] = rho[i] * lbfac[m] * invallmass + seg[m*lbsy.nf+i];
    }
  }

  pt2 = NULL;
  pt3 = NULL;  
  pt4 = NULL;  
  return 0;
}

int fSiteFluidCollisionBGKEDMLishchuk(double* startpos, double *sitespeed, double* bodyforce, double* phaseindex)
{

  // BGK collision of achromatic fluid and D'Ortona segregration 
  // calculate collisions at grid point: uses BGK single relaxation time with
  // Exact Difference Method forcing term

  double dv[3], feq[lbsy.nq];
  double allmass, invallmass, omega, nx, ny, nz, segpiece, segcomp, relax, source;
  double modv,eixux,eiyuy,eizuz,eixdux,eiyduy,eizduz;
  double rho[lbsy.nf], seg[lbsy.nf*lbsy.nq], lbfac[lbsy.nq];
  double *pt2 = &startpos[0];
  double *pt3 = &bodyforce[0];
  double *pt4 = &phaseindex[0];
  int numpair = lbsy.nf*(lbsy.nf-1)/2;
  int qdim = lbsy.nf+lbsy.nc+lbsy.nt;

  // collision of achromatic fluid

  fGetAllMassSite(rho, pt2);
  allmass = 0.0;
  omega = 0.0;

  for(int j=0; j<lbsy.nf; j++) {
    allmass += rho[j];
    omega += lbtf[j] * rho[j];
  }

  invallmass = fReciprocal(allmass);
  omega *= invallmass;
      
  for(int i=0; i<lbsy.nq; i++) {
    lbfac[i] = 0.0;
    for(int j=0; j<lbsy.nf; j++) {
      lbfac[i] += pt2[i*qdim+j];
      seg[i*lbsy.nf+j] = 0.0;
    }
  }

  relax = 1.0 - omega;
  dv[0] = pt3[0] * invallmass;
  dv[1] = pt3[1] * invallmass;
  dv[2] = pt3[2] * invallmass;
  fGetEquilibriumF(&feq[0], sitespeed, allmass);
  modv = dv[0]*(2.0*sitespeed[0]+dv[0]) + dv[1]*(2.0*sitespeed[1]+dv[1]) + dv[2]*(2.0*sitespeed[2]+dv[2]);
  for(int i=0; i<lbsy.nq; i++){
    eixux =  lbvx[i]*sitespeed[0];
    eiyuy =  lbvy[i]*sitespeed[1];
    eizuz =  lbvz[i]*sitespeed[2];
    eixdux = lbvx[i]*dv[0];
    eiyduy = lbvy[i]*dv[1];
    eizduz = lbvz[i]*dv[2];
    source = allmass * lbw[i] * (3.0 * (eixdux+eiyduy+eizduz) +
                                 4.5 * (eixdux*(eixdux+2.0*(eixux+eiyuy+eizuz+eiyduy+eizduz)) +
                                        eiyduy*(eiyduy+2.0*(eixux+eiyuy+eizuz+eizduz)) +
                                        eizduz*(eizduz+2.0*(eixux+eiyuy+eizuz))) -
                                 1.5 * modv);
    lbfac[i] = relax * lbfac[i] + source + feq[i]*omega;
  }

  // segregation of fluids

  for(int k=0; k<numpair; k++) {
    int i = lbspair[2*k  ];
    int j = lbspair[2*k+1];
    nx = pt4[3*k  ];
    ny = pt4[3*k+1];
    nz = pt4[3*k+2];
    segpiece = lbseg[lbsy.nf*j+i] * rho[i] * rho[j] * invallmass * invallmass;
    for(int m=0; m<lbsy.nq; m++) {
      segcomp = segpiece * (lbvwx[m]*nx + lbvwy[m]*ny + lbvwz[m]*nz);
      seg[m*lbsy.nf+i] += segcomp;
      seg[m*lbsy.nf+j] -= segcomp;
    }
  }

  for(int m=0; m<lbsy.nq; m++) {
    for(int i=0; i<lbsy.nf; i++) {
      pt2[m*qdim+i] = rho[i] * lbfac[m] * invallmass + seg[m*lbsy.nf+i];
    }
  }

  pt2 = NULL;
  pt3 = NULL;  
  pt4 = NULL;  
  return 0;
}

int fSiteFluidIncomCollisionBGKEDMLishchuk(double* startpos, double *sitespeed, double* bodyforce, double* phaseindex)
{

  // BGK collision of achromatic fluid and D'Ortona segregration 
  // calculate collisions at grid point: uses BGK single relaxation time
  // with incompressible fluids and Exact Difference Method forcing term

  double dv[3], feq[lbsy.nq];
  double onemass, allmass, invallmass, invmass, relax, density, omega, nx, ny, nz, segcomp, segpiece, source;
  double modv,eixux,eiyuy,eizuz,eixdux,eiyduy,eizduz;
  double rho[lbsy.nf], seg[lbsy.nf*lbsy.nq], lbfac[lbsy.nq];
  double *pt2 = &startpos[0];
  double *pt3 = &bodyforce[0];
  double *pt4 = &phaseindex[0];
  int numpair = lbsy.nf*(lbsy.nf-1)/2;
  int qdim = lbsy.nf+lbsy.nc+lbsy.nt;

  // collision of achromatic fluid

  fGetAllMassSite(rho, pt2);
  allmass = 0.0;
  omega = 0.0;
  density = 0.0;

  for(int j=0; j<lbsy.nf; j++) {
    omega += lbtf[j] * rho[j];
    density += lbincp[j] * rho[j];
    allmass += rho[j];
  }

  invallmass = fReciprocal(allmass);
  omega *= invallmass;
  density *= invallmass;

  for(int i=0; i<lbsy.nq; i++) {
    lbfac[i] = 0.0;
    for(int j=0; j<lbsy.nf; j++) {
      lbfac[i] += pt2[i*qdim+j];
      seg[i*lbsy.nf+j] = 0.0;
    }
  }

  invmass = fReciprocal(density);
  relax = 1.0 - omega;
  dv[0] = pt3[0] * invmass;
  dv[1] = pt3[1] * invmass;
  dv[2] = pt3[2] * invmass;
  fGetEquilibriumFIncom(&feq[0], sitespeed, allmass, density);
  modv = dv[0]*(2.0*sitespeed[0]+dv[0]) + dv[1]*(2.0*sitespeed[1]+dv[1]) + dv[2]*(2.0*sitespeed[2]+dv[2]);
  for(int i=0; i<lbsy.nq; i++){
    eixux =  lbvx[i]*sitespeed[0];
    eiyuy =  lbvy[i]*sitespeed[1];
    eizuz =  lbvz[i]*sitespeed[2];
    eixdux = lbvx[i]*dv[0];
    eiyduy = lbvy[i]*dv[1];
    eizduz = lbvz[i]*dv[2];
    source = density * lbw[i] * (3.0 * (eixdux+eiyduy+eizduz) +
                                 4.5 * (eixdux*(eixdux+2.0*(eixux+eiyuy+eizuz+eiyduy+eizduz)) +
                                        eiyduy*(eiyduy+2.0*(eixux+eiyuy+eizuz+eizduz)) +
                                        eizduz*(eizduz+2.0*(eixux+eiyuy+eizuz))) -
                                 1.5 * modv);
    lbfac[i] = relax * lbfac[i] + source + feq[i]*omega;
  }

  // segregation of fluids

  for(int k=0; k<numpair; k++) {
    int i = lbspair[2*k  ];
    int j = lbspair[2*k+1];
    nx = pt4[3*k  ];
    ny = pt4[3*k+1];
    nz = pt4[3*k+2];
    segpiece = lbseg[lbsy.nf*j+i] * rho[i] * rho[j] * invallmass * invallmass;
    for(int m=0; m<lbsy.nq; m++) {
      segcomp = segpiece * (lbvwx[m]*nx + lbvwy[m]*ny + lbvwz[m]*nz);
      seg[m*lbsy.nf+i] += segcomp;
      seg[m*lbsy.nf+j] -= segcomp;
    }
  }

  for(int m=0; m<lbsy.nq; m++) {
    for(int i=0; i<lbsy.nf; i++) {
      pt2[m*qdim+i] = rho[i] * lbfac[m] * invallmass + seg[m*lbsy.nf+i];
    }
  }

  pt2 = NULL;
  pt3 = NULL;  
  pt4 = NULL;  
  return 0;
}

int fSiteFluidCollisionBGKGuoLishchuk(double* startpos, double *sitespeed, double* bodyforce, double* phaseindex)
{

  // BGK collision of achromatic fluid and D'Ortona segregration 
  // calculate collisions at grid point: uses BGK single relaxation time with Guo forcing term

  double speed[3], force[3], feq[lbsy.nq];
  double udot, source, allmass, invallmass, omega, nx, ny, nz;
  double ex, ey, ez, segcomp, segpiece, relax, halfrelax;
  double rho[lbsy.nf], seg[lbsy.nf*lbsy.nq], lbfac[lbsy.nq];
  double *pt2 = &startpos[0];
  double *pt3 = &bodyforce[0];
  double *pt4 = &phaseindex[0];
  int numpair = lbsy.nf*(lbsy.nf-1)/2;
  int qdim = lbsy.nf+lbsy.nc+lbsy.nt;

  // collision of achromatic fluid

  fGetAllMassSite(rho, pt2);
  allmass = 0.0;
  omega = 0.0;

  for(int j=0; j<lbsy.nf; j++) {
    allmass += rho[j];
    omega += lbtf[j] * rho[j];
  }

  invallmass = fReciprocal(allmass);
  omega *= invallmass;
      
  for(int i=0; i<lbsy.nq; i++) {
    lbfac[i] = 0.0;
    for(int j=0; j<lbsy.nf; j++) {
      lbfac[i] += pt2[i*qdim+j];
      seg[i*lbsy.nf+j] = 0.0;
    }
  }

  force[0] = pt3[0];
  force[1] = pt3[1];
  force[2] = pt3[2];
  speed[0] = sitespeed[0] + 0.5 * force[0] * invallmass;
  speed[1] = sitespeed[1] + 0.5 * force[1] * invallmass;
  speed[2] = sitespeed[2] + 0.5 * force[2] * invallmass;
  fGetEquilibriumF(&feq[0], speed, allmass);
  relax = 1.0 - omega;
  halfrelax = 1.0 - 0.5*omega;
  for(int i=0; i<lbsy.nq; i++){
    ex = lbvx[i];
    ey = lbvy[i];
    ez = lbvz[i];
    udot = ex * speed[0] + ey * speed[1] + ez * speed[2];
    source = (3.0*(ex-speed[0]) + 9.0*udot*ex) * force[0]
           + (3.0*(ey-speed[1]) + 9.0*udot*ey) * force[1]
           + (3.0*(ez-speed[2]) + 9.0*udot*ez) * force[2];
    lbfac[i] = relax * lbfac[i] + halfrelax * lbw[i] * source + feq[i]*omega;
  }

  // segregation of fluids

  for(int k=0; k<numpair; k++) {
    int i = lbspair[2*k  ];
    int j = lbspair[2*k+1];
    nx = pt4[3*k  ];
    ny = pt4[3*k+1];
    nz = pt4[3*k+2];
    segpiece = lbseg[lbsy.nf*j+i] * rho[i] * rho[j] * invallmass * invallmass;
    for(int m=0; m<lbsy.nq; m++) {
      segcomp = segpiece * (lbvwx[m]*nx + lbvwy[m]*ny + lbvwz[m]*nz);
      seg[m*lbsy.nf+i] += segcomp;
      seg[m*lbsy.nf+j] -= segcomp;
    }
  }

  for(int m=0; m<lbsy.nq; m++) {
    for(int i=0; i<lbsy.nf; i++) {
      pt2[m*qdim+i] = rho[i] * lbfac[m] * invallmass + seg[m*lbsy.nf+i];
    }
  }

  pt2 = NULL;
  pt3 = NULL;  
  pt4 = NULL;  
  return 0;
}

int fSiteFluidIncomCollisionBGKGuoLishchuk(double* startpos, double *sitespeed, double* bodyforce, double* phaseindex)
{

  // BGK collision of achromatic fluid and D'Ortona segregration 
  // calculate collisions at grid point: uses BGK single relaxation time
  // with Guo forcing term for incompressible fluids

  double speed[3], force[3], feq[lbsy.nq];
  double onemass, udot, source, allmass, invallmass, density, invdensity, omega, nx, ny, nz;
  double ex, ey, ez, segcomp, segpiece, relax, halfrelax;
  double rho[lbsy.nf], seg[lbsy.nf*lbsy.nq], lbfac[lbsy.nq];
  double *pt2 = &startpos[0];
  double *pt3 = &bodyforce[0];
  double *pt4 = &phaseindex[0];
  int numpair = lbsy.nf*(lbsy.nf-1)/2;
  int qdim = lbsy.nf+lbsy.nc+lbsy.nt;

  // collision of achromatic fluid

  fGetAllMassSite(rho, pt2);
  allmass = 0.0;
  omega = 0.0;
  density = 0.0;

  for(int j=0; j<lbsy.nf; j++) {
    omega += lbtf[j] * rho[j];
    density += lbincp[j] * rho[j];
    allmass += rho[j];
  }

  invallmass = fReciprocal(allmass);
  omega *= invallmass;
  density += invallmass;

  for(int i=0; i<lbsy.nq; i++) {
    lbfac[i] = 0.0;
    for(int j=0; j<lbsy.nf; j++) {
      lbfac[i] += pt2[i*qdim+j];
      seg[i*lbsy.nf+j] = 0.0;
    }
  }

  invdensity = fReciprocal(density);
  force[0] = pt3[0];
  force[1] = pt3[1];
  force[2] = pt3[2];
  speed[0] = sitespeed[0] + 0.5 * force[0] * invdensity;
  speed[1] = sitespeed[1] + 0.5 * force[1] * invdensity;
  speed[2] = sitespeed[2] + 0.5 * force[2] * invdensity;
  fGetEquilibriumFIncom(&feq[0], speed, allmass, density);
  relax = 1.0 - omega;
  halfrelax = 1.0 - 0.5*omega;
  for(int i=0; i<lbsy.nq; i++){
    ex = lbvx[i];
    ey = lbvy[i];
    ez = lbvz[i];
    udot = ex * speed[0] + ey * speed[1] + ez * speed[2];
    source = (3.0*(ex-speed[0]) + 9.0*udot*ex) * force[0]
           + (3.0*(ey-speed[1]) + 9.0*udot*ey) * force[1]
           + (3.0*(ez-speed[2]) + 9.0*udot*ez) * force[2];
    lbfac[i] = relax * lbfac[i] + halfrelax * lbw[i] * source + lbfeq[i]*omega;
  }

  // segregation of fluids

  for(int k=0; k<numpair; k++) {
    int i = lbspair[2*k  ];
    int j = lbspair[2*k+1];
    nx = pt4[3*k  ];
    ny = pt4[3*k+1];
    nz = pt4[3*k+2];
    segpiece = lbseg[lbsy.nf*j+i] * rho[i] * rho[j] * invallmass * invallmass;
    for(int m=0; m<lbsy.nq; m++) {
      segcomp = segpiece * (lbvwx[m]*nx + lbvwy[m]*ny + lbvwz[m]*nz);
      seg[m*lbsy.nf+i] += segcomp;
      seg[m*lbsy.nf+j] -= segcomp;
    }
  }

  for(int m=0; m<lbsy.nq; m++) {
    for(int i=0; i<lbsy.nf; i++) {
      pt2[m*qdim+i] = rho[i] * lbfac[m] * invallmass + seg[m*lbsy.nf+i];
    }
  }

  pt2 = NULL;
  pt3 = NULL;  
  pt4 = NULL;  
  return 0;
}

// Achromatic fluid collisions with local forcing terms and phase segregation

int fSiteFluidCollisionBGKLishchukLocal(double* startpos, double *sitespeed, double* bodyforce, double* phaseindex, int threed)
{

  // BGK collision of achromatic fluid and D'Ortona segregration 
  // calculate interfacial forcing terms and collisions at grid point:
  // uses BGK single relaxation time

  double speed[3], feq[lbsy.nq];
  double allmass, invallmass, omega, ex, ey, ez, nx, ny, nz;
  double forceconst, segpiece, segcomp, invmassrelax, relax;
  double rho[lbsy.nf], seg[lbsy.nf*lbsy.nq], lbfac[lbsy.nq], phaseforce[lbsy.nq];
  double *pt2 = &startpos[0];
  double *pt3 = &bodyforce[0];
  double *pt4 = &phaseindex[0];
  int numpair = lbsy.nf*(lbsy.nf-1)/2;
  int qdim = lbsy.nf+lbsy.nc+lbsy.nt;

  // collision of achromatic fluid

  fGetAllMassSite(rho, pt2);
  allmass = 0.0;
  omega = 0.0;

  for(int j=0; j<lbsy.nf; j++) {
    allmass += rho[j];
    omega += lbtf[j] * rho[j];
  }

  invallmass = fReciprocal(allmass);
  omega *= invallmass;
      
  for(int i=0; i<lbsy.nq; i++) {
    lbfac[i] = 0.0;
    phaseforce[i] = 0.0;
    for(int j=0; j<lbsy.nf; j++) {
      lbfac[i] += pt2[i*qdim+j];
      seg[i*lbsy.nf+j] = 0.0;
    }
  }

  // calculate local forcing terms

  for(int k=0; k<numpair; k++) {
    int i = lbspair[2*k  ];
    int j = lbspair[2*k+1];
    nx = pt4[3*k  ];
    ny = pt4[3*k+1];
    nz = pt4[3*k+2];
    forceconst = lbseg[lbsy.nf*j+i] * lbg[lbsy.nf*j+i] * rho[i] * rho[j];
    for(int m=0; m<lbsy.nq; m++) {
      ex = lbvx[m];
      ey = lbvy[m];
      ez = lbvz[m];
      phaseforce[m] += forceconst * ((nx*nx-1.0)*(ex*ex-lbcssq) + (ny*ny-1.0)*(ey*ey-lbcssq) + 2.0*nx*ny*ex*ey
                     + threed*((nz*nz-1.0)*(ez*ez-lbcssq) + 2.0*nz*ez*(nx*ex+ny*ey)));
    }
  }

  invmassrelax = invallmass / omega;
  relax = 1.0 - omega;
  forceconst = omega * invallmass * invallmass * invallmass * lbrcssq * lbrcssq;
  speed[0] = sitespeed[0] + pt3[0] * invmassrelax;
  speed[1] = sitespeed[1] + pt3[1] * invmassrelax;
  speed[2] = sitespeed[2] + pt3[2] * invmassrelax;
  fGetEquilibriumF(&feq[0], speed, allmass);
  for(int i=0; i<lbsy.nq; i++){
    lbfac[i] = relax * lbfac[i] + feq[i]*omega + lbw[i]*forceconst*phaseforce[i];
  }

  // segregation of fluids

  for(int k=0; k<numpair; k++) {
    int i = lbspair[2*k  ];
    int j = lbspair[2*k+1];
    nx = pt4[3*k  ];
    ny = pt4[3*k+1];
    nz = pt4[3*k+2];
    segpiece = lbseg[lbsy.nf*j+i] * rho[i] * rho[j] * invallmass * invallmass;
    for(int m=0; m<lbsy.nq; m++) {
      segcomp = segpiece * (lbvwx[m]*nx + lbvwy[m]*ny + lbvwz[m]*nz);
      seg[m*lbsy.nf+i] += segcomp;
      seg[m*lbsy.nf+j] -= segcomp;
    }
  }

  for(int m=0; m<lbsy.nq; m++) {
    for(int i=0; i<lbsy.nf; i++) {
      pt2[m*qdim+i] = rho[i] * lbfac[m] * invallmass + seg[m*lbsy.nf+i];
    }
  }

  pt2 = NULL;
  pt3 = NULL;  
  pt4 = NULL;  
  return 0;
}

int fSiteFluidIncomCollisionBGKLishchukLocal(double* startpos, double *sitespeed, double* bodyforce, double* phaseindex, int threed)
{

  // BGK collision of achromatic fluid and D'Ortona segregration 
  // calculate interfacial forcing terms and collisions at grid point:
  // uses BGK single relaxation time with incompressible fluids

  double speed[3], feq[lbsy.nq];
  double onemass, allmass, invallmass, invmassrelax, relax, density, omega;
  double forceconst, ex, ey, ez, nx, ny, nz, segcomp, segpiece;
  double rho[lbsy.nf], seg[lbsy.nf*lbsy.nq], lbfac[lbsy.nq], phaseforce[lbsy.nq];
  double *pt2 = &startpos[0];
  double *pt3 = &bodyforce[0];
  double *pt4 = &phaseindex[0];
  int numpair = lbsy.nf*(lbsy.nf-1)/2;
  int qdim = lbsy.nf+lbsy.nc+lbsy.nt;

  // collision of achromatic fluid

  fGetAllMassSite(rho, pt2);
  allmass = 0.0;
  omega = 0.0;
  density = 0.0;

  for(int j=0; j<lbsy.nf; j++) {
    omega += lbtf[j] * rho[j];
    density += lbincp[j] * rho[j];
    allmass += rho[j];
  }

  invallmass = fReciprocal(allmass);
  omega *= invallmass;
  density += invallmass;

  for(int i=0; i<lbsy.nq; i++) {
    lbfac[i] = 0.0;
    phaseforce[i] = 0.0;
    for(int j=0; j<lbsy.nf; j++) {
      lbfac[i] += pt2[i*qdim+j];
      seg[i*lbsy.nf+j] = 0.0;
    }
  }

  // calculate local forcing terms

  for(int k=0; k<numpair; k++) {
    int i = lbspair[2*k  ];
    int j = lbspair[2*k+1];
    nx = pt4[3*k  ];
    ny = pt4[3*k+1];
    nz = pt4[3*k+2];
    forceconst = lbseg[lbsy.nf*j+i] * lbg[lbsy.nf*j+i] * rho[i] * rho[j];
    for(int m=0; m<lbsy.nq; m++) {
      ex = lbvx[m];
      ey = lbvy[m];
      ez = lbvz[m];
      phaseforce[m] += forceconst * ((nx*nx-1.0)*(ex*ex-lbcssq) + (ny*ny-1.0)*(ey*ey-lbcssq) + 2.0*nx*ny*ex*ey
                     + threed*((nz*nz-1.0)*(ez*ez-lbcssq) + 2.0*nz*ez*(nx*ex+ny*ey)));
    }
  }

  invmassrelax = 1.0 / (omega * density);
  relax = 1.0 - omega;
  forceconst = omega * invallmass * invallmass * lbrcssq * lbrcssq * fReciprocal(density);
  speed[0] = sitespeed[0] + pt3[0] * invmassrelax;
  speed[1] = sitespeed[1] + pt3[1] * invmassrelax;
  speed[2] = sitespeed[2] + pt3[2] * invmassrelax;
  fGetEquilibriumFIncom(&feq[0], speed, allmass, density);
  for(int i=0; i<lbsy.nq; i++){
    lbfac[i] = relax * lbfac[i] + feq[i]*omega + lbw[i]*forceconst*phaseforce[i];
  }

  // segregation of fluids

  for(int k=0; k<numpair; k++) {
    int i = lbspair[2*k  ];
    int j = lbspair[2*k+1];
    nx = pt4[3*k  ];
    ny = pt4[3*k+1];
    nz = pt4[3*k+2];
    segpiece = lbseg[lbsy.nf*j+i] * rho[i] * rho[j] * invallmass * invallmass;
    for(int m=0; m<lbsy.nq; m++) {
      segcomp = segpiece * (lbvwx[m]*nx + lbvwy[m]*ny + lbvwz[m]*nz);
      seg[m*lbsy.nf+i] += segcomp;
      seg[m*lbsy.nf+j] -= segcomp;
    }
  }

  for(int m=0; m<lbsy.nq; m++) {
    for(int i=0; i<lbsy.nf; i++) {
      pt2[m*qdim+i] = rho[i] * lbfac[m] * invallmass + seg[m*lbsy.nf+i];
    }
  }

  pt2 = NULL;
  pt3 = NULL;  
  pt4 = NULL;  
  return 0;
}

int fSiteFluidCollisionBGKEDMLishchukLocal(double* startpos, double *sitespeed, double* bodyforce, double* phaseindex, int threed)
{

  // BGK collision of achromatic fluid and D'Ortona segregration 
  // calculate interfacial forcing terms and collisions at grid point:
  // uses BGK single relaxation time with Exact Difference Method forcing term

  double dv[3], feq[lbsy.nq];
  double allmass, invallmass, omega, forceconst, ex, ey, ez, nx, ny, nz, segpiece, segcomp, relax, source;
  double modv,eixux,eiyuy,eizuz,eixdux,eiyduy,eizduz;
  double rho[lbsy.nf], seg[lbsy.nf*lbsy.nq], lbfac[lbsy.nq], phaseforce[lbsy.nq];
  double *pt2 = &startpos[0];
  double *pt3 = &bodyforce[0];
  double *pt4 = &phaseindex[0];
  int numpair = lbsy.nf*(lbsy.nf-1)/2;
  int qdim = lbsy.nf+lbsy.nc+lbsy.nt;

  // collision of achromatic fluid

  fGetAllMassSite(rho, pt2);
  allmass = 0.0;
  omega = 0.0;

  for(int j=0; j<lbsy.nf; j++) {
    allmass += rho[j];
    omega += lbtf[j] * rho[j];
  }

  invallmass = fReciprocal(allmass);
  omega *= invallmass;
      
  for(int i=0; i<lbsy.nq; i++) {
    lbfac[i] = 0.0;
    phaseforce[i] = 0.0;
    for(int j=0; j<lbsy.nf; j++) {
      lbfac[i] += pt2[i*qdim+j];
      seg[i*lbsy.nf+j] = 0.0;
    }
  }

  // calculate local forcing terms

  for(int k=0; k<numpair; k++) {
    int i = lbspair[2*k  ];
    int j = lbspair[2*k+1];
    nx = pt4[3*k  ];
    ny = pt4[3*k+1];
    nz = pt4[3*k+2];
    forceconst = lbseg[lbsy.nf*j+i] * lbg[lbsy.nf*j+i] * rho[i] * rho[j];
    for(int m=0; m<lbsy.nq; m++) {
      ex = lbvx[m];
      ey = lbvy[m];
      ez = lbvz[m];
      phaseforce[m] += forceconst * ((nx*nx-1.0)*(ex*ex-lbcssq) + (ny*ny-1.0)*(ey*ey-lbcssq) + 2.0*nx*ny*ex*ey
                     + threed*((nz*nz-1.0)*(ez*ez-lbcssq) + 2.0*nz*ez*(nx*ex+ny*ey)));
    }
  }

  relax = 1.0 - omega;
  dv[0] = pt3[0] * invallmass;
  dv[1] = pt3[1] * invallmass;
  dv[2] = pt3[2] * invallmass;
  forceconst = omega * invallmass * invallmass * invallmass * lbrcssq * lbrcssq;
  fGetEquilibriumF(&feq[0], sitespeed, allmass);
  modv = dv[0]*(2.0*sitespeed[0]+dv[0]) + dv[1]*(2.0*sitespeed[1]+dv[1]) + dv[2]*(2.0*sitespeed[2]+dv[2]);
  for(int i=0; i<lbsy.nq; i++){
    eixux =  lbvx[i]*sitespeed[0];
    eiyuy =  lbvy[i]*sitespeed[1];
    eizuz =  lbvz[i]*sitespeed[2];
    eixdux = lbvx[i]*dv[0];
    eiyduy = lbvy[i]*dv[1];
    eizduz = lbvz[i]*dv[2];
    source = allmass * lbw[i] * (3.0 * (eixdux+eiyduy+eizduz) +
                                 4.5 * (eixdux*(eixdux+2.0*(eixux+eiyuy+eizuz+eiyduy+eizduz)) +
                                        eiyduy*(eiyduy+2.0*(eixux+eiyuy+eizuz+eizduz)) +
                                        eizduz*(eizduz+2.0*(eixux+eiyuy+eizuz))) -
                                 1.5 * modv);
    lbfac[i] = relax * lbfac[i] + source + feq[i]*omega + lbw[i]*forceconst*phaseforce[i];
  }

  // segregation of fluids

  for(int k=0; k<numpair; k++) {
    int i = lbspair[2*k  ];
    int j = lbspair[2*k+1];
    nx = pt4[3*k  ];
    ny = pt4[3*k+1];
    nz = pt4[3*k+2];
    segpiece = lbseg[lbsy.nf*j+i] * rho[i] * rho[j] * invallmass * invallmass;
    for(int m=0; m<lbsy.nq; m++) {
      segcomp = segpiece * (lbvwx[m]*nx + lbvwy[m]*ny + lbvwz[m]*nz);
      seg[m*lbsy.nf+i] += segcomp;
      seg[m*lbsy.nf+j] -= segcomp;
    }
  }

  for(int m=0; m<lbsy.nq; m++) {
    for(int i=0; i<lbsy.nf; i++) {
      pt2[m*qdim+i] = rho[i] * lbfac[m] * invallmass + seg[m*lbsy.nf+i];
    }
  }

  pt2 = NULL;
  pt3 = NULL;  
  pt4 = NULL;  
  return 0;
}

int fSiteFluidIncomCollisionBGKEDMLishchukLocal(double* startpos, double *sitespeed, double* bodyforce, double* phaseindex, int threed)
{

  // BGK collision of achromatic fluid and D'Ortona segregration 
  // calculate interfacial forcing terms and collisions at grid point:
  // uses BGK single relaxation time with incompressible fluids and
  // Exact Difference Method forcing term

  double dv[3], feq[lbsy.nq];
  double onemass, allmass, invallmass, invmass, relax, density, omega, source;
  double forceconst, ex, ey, ez, nx, ny, nz, segcomp, segpiece;
  double modv,eixux,eiyuy,eizuz,eixdux,eiyduy,eizduz;
  double rho[lbsy.nf], seg[lbsy.nf*lbsy.nq], lbfac[lbsy.nq], phaseforce[lbsy.nq];
  double *pt2 = &startpos[0];
  double *pt3 = &bodyforce[0];
  double *pt4 = &phaseindex[0];
  int numpair = lbsy.nf*(lbsy.nf-1)/2;
  int qdim = lbsy.nf+lbsy.nc+lbsy.nt;

  // collision of achromatic fluid

  fGetAllMassSite(rho, pt2);
  allmass = 0.0;
  omega = 0.0;
  density = 0.0;

  for(int j=0; j<lbsy.nf; j++) {
    omega += lbtf[j] * rho[j];
    density += lbincp[j] * rho[j];
    allmass += rho[j];
  }

  invallmass = fReciprocal(allmass);
  omega *= invallmass;
  density += invallmass;

  for(int i=0; i<lbsy.nq; i++) {
    lbfac[i] = 0.0;
    phaseforce[i] = 0.0;
    for(int j=0; j<lbsy.nf; j++) {
      lbfac[i] += pt2[i*qdim+j];
      seg[i*lbsy.nf+j] = 0.0;
    }
  }

  // calculate local forcing terms

  for(int k=0; k<numpair; k++) {
    int i = lbspair[2*k  ];
    int j = lbspair[2*k+1];
    nx = pt4[3*k  ];
    ny = pt4[3*k+1];
    nz = pt4[3*k+2];
    forceconst = lbseg[lbsy.nf*j+i] * lbg[lbsy.nf*j+i] * rho[i] * rho[j];
    for(int m=0; m<lbsy.nq; m++) {
      ex = lbvx[m];
      ey = lbvy[m];
      ez = lbvz[m];
      phaseforce[m] += forceconst * ((nx*nx-1.0)*(ex*ex-lbcssq) + (ny*ny-1.0)*(ey*ey-lbcssq) + 2.0*nx*ny*ex*ey
                     + threed*((nz*nz-1.0)*(ez*ez-lbcssq) + 2.0*nz*ez*(nx*ex+ny*ey)));
    }
  }

  invmass = fReciprocal(density);
  relax = 1.0 - omega;
  forceconst = omega * invallmass * invallmass * lbrcssq * lbrcssq * fReciprocal(density);
  dv[0] = pt3[0] * invmass;
  dv[1] = pt3[1] * invmass;
  dv[2] = pt3[2] * invmass;
  fGetEquilibriumFIncom(&feq[0], sitespeed, allmass, density);
  modv = dv[0]*(2.0*sitespeed[0]+dv[0]) + dv[1]*(2.0*sitespeed[1]+dv[1]) + dv[2]*(2.0*sitespeed[2]+dv[2]);
  for(int i=0; i<lbsy.nq; i++){
    eixux =  lbvx[i]*sitespeed[0];
    eiyuy =  lbvy[i]*sitespeed[1];
    eizuz =  lbvz[i]*sitespeed[2];
    eixdux = lbvx[i]*dv[0];
    eiyduy = lbvy[i]*dv[1];
    eizduz = lbvz[i]*dv[2];
    source = density * lbw[i] * (3.0 * (eixdux+eiyduy+eizduz) +
                                 4.5 * (eixdux*(eixdux+2.0*(eixux+eiyuy+eizuz+eiyduy+eizduz)) +
                                        eiyduy*(eiyduy+2.0*(eixux+eiyuy+eizuz+eizduz)) +
                                        eizduz*(eizduz+2.0*(eixux+eiyuy+eizuz))) -
                                 1.5 * modv);
    lbfac[i] = relax * lbfac[i] + source + feq[i]*omega + lbw[i]*forceconst*phaseforce[i];
  }

  // segregation of fluids

  for(int k=0; k<numpair; k++) {
    int i = lbspair[2*k  ];
    int j = lbspair[2*k+1];
    nx = pt4[3*k  ];
    ny = pt4[3*k+1];
    nz = pt4[3*k+2];
    segpiece = lbseg[lbsy.nf*j+i] * rho[i] * rho[j] * invallmass * invallmass;
    for(int m=0; m<lbsy.nq; m++) {
      segcomp = segpiece * (lbvwx[m]*nx + lbvwy[m]*ny + lbvwz[m]*nz);
      seg[m*lbsy.nf+i] += segcomp;
      seg[m*lbsy.nf+j] -= segcomp;
    }
  }

  for(int m=0; m<lbsy.nq; m++) {
    for(int i=0; i<lbsy.nf; i++) {
      pt2[m*qdim+i] = rho[i] * lbfac[m] * invallmass + seg[m*lbsy.nf+i];
    }
  }

  pt2 = NULL;
  pt3 = NULL;  
  pt4 = NULL;  
  return 0;
}

int fSiteFluidCollisionBGKGuoLishchukLocal(double* startpos, double *sitespeed, double* bodyforce, double* phaseindex, int threed)
{

  // BGK collision of achromatic fluid and D'Ortona segregration 
  // calculate interfacial forcing terms and collisions at grid point:
  // uses BGK single relaxation time with Guo forcing term

  double speed[3], force[3], feq[lbsy.nq];
  double onemass, udot, source, allmass, invallmass, omega, nx, ny, nz;
  double forceconst, ex, ey, ez, segcomp, segpiece, relax, halfrelax;
  double rho[lbsy.nf], seg[lbsy.nf*lbsy.nq], lbfac[lbsy.nq], phaseforce[lbsy.nq];
  double *pt2 = &startpos[0];
  double *pt3 = &bodyforce[0];
  double *pt4 = &phaseindex[0];
  int numpair = lbsy.nf*(lbsy.nf-1)/2;
  int qdim = lbsy.nf+lbsy.nc+lbsy.nt;

  // collision of achromatic fluid

  fGetAllMassSite(rho, pt2);
  allmass = 0.0;
  omega = 0.0;

  for(int j=0; j<lbsy.nf; j++) {
    allmass += rho[j];
    omega += lbtf[j] * rho[j];
  }

  invallmass = fReciprocal(allmass);
  omega *= invallmass;
      
  for(int i=0; i<lbsy.nq; i++) {
    lbfac[i] = 0.0;
    phaseforce[i] = 0.0;
    for(int j=0; j<lbsy.nf; j++) {
      lbfac[i] += pt2[i*qdim+j];
      seg[i*lbsy.nf+j] = 0.0;
    }
  }

  // calculate local forcing terms

  for(int k=0; k<numpair; k++) {
    int i = lbspair[2*k  ];
    int j = lbspair[2*k+1];
    nx = pt4[3*k  ];
    ny = pt4[3*k+1];
    nz = pt4[3*k+2];
    forceconst = lbseg[lbsy.nf*j+i] * lbg[lbsy.nf*j+i] * rho[i] * rho[j];
    for(int m=0; m<lbsy.nq; m++) {
      ex = lbvx[m];
      ey = lbvy[m];
      ez = lbvz[m];
      phaseforce[m] += forceconst * ((nx*nx-1.0)*(ex*ex-lbcssq) + (ny*ny-1.0)*(ey*ey-lbcssq) + 2.0*nx*ny*ex*ey
                     + threed*((nz*nz-1.0)*(ez*ez-lbcssq) + 2.0*nz*ez*(nx*ex+ny*ey)));
    }
  }

  force[0] = pt3[0];
  force[1] = pt3[1];
  force[2] = pt3[2];
  speed[0] = sitespeed[0] + 0.5 * force[0] * invallmass;
  speed[1] = sitespeed[1] + 0.5 * force[1] * invallmass;
  speed[2] = sitespeed[2] + 0.5 * force[2] * invallmass;
  fGetEquilibriumF(&feq[0], speed, allmass);
  relax = 1.0 - omega;
  halfrelax = 1.0 - 0.5*omega;
  forceconst = omega * invallmass * invallmass * invallmass * lbrcssq * lbrcssq;
  for(int i=0; i<lbsy.nq; i++){
    ex = lbvx[i];
    ey = lbvy[i];
    ez = lbvz[i];
    udot = ex * speed[0] + ey * speed[1] + ez * speed[2];
    source = (3.0*(ex-speed[0]) + 9.0*udot*ex) * force[0]
           + (3.0*(ey-speed[1]) + 9.0*udot*ey) * force[1]
           + (3.0*(ez-speed[2]) + 9.0*udot*ez) * force[2];
    lbfac[i] = relax * lbfac[i] + halfrelax * lbw[i] * source + feq[i]*omega + lbw[i]*forceconst*phaseforce[i];
  }

  // segregation of fluids

  for(int k=0; k<numpair; k++) {
    int i = lbspair[2*k  ];
    int j = lbspair[2*k+1];
    nx = pt4[3*k  ];
    ny = pt4[3*k+1];
    nz = pt4[3*k+2];
    segpiece = lbseg[lbsy.nf*j+i] * rho[i] * rho[j] * invallmass * invallmass;
    for(int m=0; m<lbsy.nq; m++) {
      segcomp = segpiece * (lbvwx[m]*nx + lbvwy[m]*ny + lbvwz[m]*nz);
      seg[m*lbsy.nf+i] += segcomp;
      seg[m*lbsy.nf+j] -= segcomp;
    }
  }

  for(int m=0; m<lbsy.nq; m++) {
    for(int i=0; i<lbsy.nf; i++) {
      pt2[m*qdim+i] = rho[i] * lbfac[m] * invallmass + seg[m*lbsy.nf+i];
    }
  }

  pt2 = NULL;
  pt3 = NULL;  
  pt4 = NULL;  
  return 0;
}

int fSiteFluidIncomCollisionBGKGuoLishchukLocal(double* startpos, double *sitespeed, double* bodyforce, double* phaseindex, int threed)
{

  // BGK collision of achromatic fluid and D'Ortona segregration 
  // calculate interfacial forcing terms and collisions at grid point:
  // uses BGK single relaxation time with Guo forcing term for incompressible fluids

  double speed[3], force[3], feq[lbsy.nq];
  double onemass, udot, source, allmass, invallmass, density, invdensity, omega, nx, ny, nz;
  double forceconst, ex, ey, ez, segcomp, segpiece, relax, halfrelax;
  double rho[lbsy.nf], seg[lbsy.nf*lbsy.nq], lbfac[lbsy.nq], phaseforce[lbsy.nq];
  double *pt2 = &startpos[0];
  double *pt3 = &bodyforce[0];
  double *pt4 = &phaseindex[0];
  int numpair = lbsy.nf*(lbsy.nf-1)/2;
  int qdim = lbsy.nf+lbsy.nc+lbsy.nt;

  // collision of achromatic fluid

  fGetAllMassSite(rho, pt2);
  allmass = 0.0;
  omega = 0.0;
  density = 0.0;

  for(int j=0; j<lbsy.nf; j++) {
    omega += lbtf[j] * rho[j];
    density += lbincp[j] * rho[j];
    allmass += rho[j];
  }

  invallmass = fReciprocal(allmass);
  omega *= invallmass;
  density += invallmass;

  for(int i=0; i<lbsy.nq; i++) {
    lbfac[i] = 0.0;
    phaseforce[i] = 0.0;
    for(int j=0; j<lbsy.nf; j++) {
      lbfac[i] += pt2[i*qdim+j];
      seg[i*lbsy.nf+j] = 0.0;
    }
  }

  // calculate local forcing terms

  for(int k=0; k<numpair; k++) {
    int i = lbspair[2*k  ];
    int j = lbspair[2*k+1];
    nx = pt4[3*k  ];
    ny = pt4[3*k+1];
    nz = pt4[3*k+2];
    forceconst = lbseg[lbsy.nf*j+i] * lbg[lbsy.nf*j+i] * rho[i] * rho[j];
    for(int m=0; m<lbsy.nq; m++) {
      ex = lbvx[m];
      ey = lbvy[m];
      ez = lbvz[m];
      phaseforce[m] += forceconst * ((nx*nx-1.0)*(ex*ex-lbcssq) + (ny*ny-1.0)*(ey*ey-lbcssq) + 2.0*nx*ny*ex*ey
                     + threed*((nz*nz-1.0)*(ez*ez-lbcssq) + 2.0*nz*ez*(nx*ex+ny*ey)));
    }
  }

  invdensity = fReciprocal(density);
  force[0] = pt3[0];
  force[1] = pt3[1];
  force[2] = pt3[2];
  speed[0] = sitespeed[0] + 0.5 * force[0] * invdensity;
  speed[1] = sitespeed[1] + 0.5 * force[1] * invdensity;
  speed[2] = sitespeed[2] + 0.5 * force[2] * invdensity;
  fGetEquilibriumFIncom(&feq[0], speed, allmass, density);
  relax = 1.0 - omega;
  halfrelax = 1.0 - 0.5*omega;
  forceconst = omega * invallmass * invallmass * lbrcssq * lbrcssq * invdensity;
  for(int i=0; i<lbsy.nq; i++){
    ex = lbvx[i];
    ey = lbvy[i];
    ez = lbvz[i];
    udot = ex * speed[0] + ey * speed[1] + ez * speed[2];
    source = (3.0*(ex-speed[0]) + 9.0*udot*ex) * force[0]
           + (3.0*(ey-speed[1]) + 9.0*udot*ey) * force[1]
           + (3.0*(ez-speed[2]) + 9.0*udot*ez) * force[2];
    lbfac[i] = relax * lbfac[i] + halfrelax * lbw[i] * source + lbfeq[i]*omega + lbw[i]*forceconst*phaseforce[i];
  }

  // segregation of fluids

  for(int k=0; k<numpair; k++) {
    int i = lbspair[2*k  ];
    int j = lbspair[2*k+1];
    nx = pt4[3*k  ];
    ny = pt4[3*k+1];
    nz = pt4[3*k+2];
    segpiece = lbseg[lbsy.nf*j+i] * rho[i] * rho[j] * invallmass * invallmass;
    for(int m=0; m<lbsy.nq; m++) {
      segcomp = segpiece * (lbvwx[m]*nx + lbvwy[m]*ny + lbvwz[m]*nz);
      seg[m*lbsy.nf+i] += segcomp;
      seg[m*lbsy.nf+j] -= segcomp;
    }
  }

  for(int m=0; m<lbsy.nq; m++) {
    for(int i=0; i<lbsy.nf; i++) {
      pt2[m*qdim+i] = rho[i] * lbfac[m] * invallmass + seg[m*lbsy.nf+i];
    }
  }

  pt2 = NULL;
  pt3 = NULL;  
  pt4 = NULL;  
  return 0;
}


// Swift free-energy fluid collisions

int fSiteFluidCollisionBGKSwiftOneFluid(double* startpos, double *sitespeed, double* gradient, double* bodyforce, double T)
{
  
  // calculate fluid collisions at grid point: uses BGK single relaxation time
  // and Swift free-energy interactions for one fluid

  double speed[3], feq[lbsy.nq], rho[lbsy.nf];
  double invmassrelax, relax, pb, lambda;
  double *pt2 = &startpos[0];
  double *pt3 = &gradient[0];
  double *pt4 = &bodyforce[0];
  int qdim = lbsy.nf+lbsy.nc+lbsy.nt;
    
  fGetAllMassSite(rho, pt2);
  pb = fGetBulkPressureSwift(rho[0], 0.0, T);
  lambda = fGetLambdaSwift(rho[0], lbtf[0], T);
  relax = 1.0 - lbtf[0];
  invmassrelax = fReciprocal(rho[0]*lbtf[0]);
  speed[0] = sitespeed[0] + pt4[0] * invmassrelax;
  speed[1] = sitespeed[1] + pt4[1] * invmassrelax;
  speed[2] = sitespeed[2] + pt4[2] * invmassrelax;
  fGetEquilibriumFSwiftOneFluid(feq, speed, rho[0], pb, lambda, pt3);
  for(int i=0; i<lbsy.nq; i++){
    pt2[i*qdim] = relax * pt2[i*qdim] + feq[i]*lbtf[0];
  }

  pt2 = NULL;
  pt3 = NULL;
  pt4 = NULL;
  return 0;
}

int fSiteFluidCollisionBGKSwiftTwoFluid(double* startpos, double *sitespeed, double* gradient, double* bodyforce, double T)
{
  
  // calculate fluid collisions at grid point: uses BGK single relaxation time
  // and Swift free-energy interactions for one fluids

  double speed[3], feq[2*lbsy.nq], rho[lbsy.nf];
  double omega, invmassrelax, relax, relaxphi, pb, mu, lambda;
  double *pt2 = &startpos[0];
  double *pt3 = &gradient[0];
  double *pt4 = &bodyforce[0];
  int qdim = lbsy.nf+lbsy.nc+lbsy.nt;
    
  fGetAllMassSite(rho, pt2);
  omega = 2.0*lbtf[0]*lbtf[1]/(2.0*lbtf[0]+(1.0+rho[1])*(lbtf[1]-lbtf[0]));
  pb = fGetBulkPressureSwift(rho[0], rho[1], T);
  lambda = fGetLambdaSwift(rho[0], omega, T);
  mu = fGetPotentialSwift(rho[1], pt3[7]);
  relax = 1.0 - omega;
  relaxphi = 1.0 - lbtmob;
  invmassrelax = fReciprocal(rho[0]*omega);
  speed[0] = sitespeed[0] + pt4[0] * invmassrelax;
  speed[1] = sitespeed[1] + pt4[1] * invmassrelax;
  speed[2] = sitespeed[2] + pt4[2] * invmassrelax;
  fGetEquilibriumFSwiftTwoFluid(feq, speed, rho[0], rho[1], pb, mu, lambda, pt3);
  for(int i=0; i<lbsy.nq; i++){
    pt2[i*qdim  ] = relax    * pt2[i*qdim  ] + feq[2*i  ]*omega;
    pt2[i*qdim+1] = relaxphi * pt2[i*qdim+1] + feq[2*i+1]*lbtmob;
  }

  pt2 = NULL;
  pt3 = NULL;
  pt4 = NULL;
  return 0;
}

int fSiteFluidCollisionBGKEDMSwiftOneFluid(double* startpos, double *sitespeed, double* gradient, double* bodyforce, double T)
{
  
  // calculate fluid collisions at grid point: uses BGK single relaxation time with
  // Exact Difference Method forcing term and Swift free-energy interactions for one fluid

  double dv[3], feq[lbsy.nq], rho[lbsy.nf];
  double invmass, relax, pb, lambda, source;
  double modv,eixux,eiyuy,eizuz,eixdux,eiyduy,eizduz;
  double *pt2 = &startpos[0];
  double *pt3 = &gradient[0];
  double *pt4 = &bodyforce[0];
  int qdim = lbsy.nf+lbsy.nc+lbsy.nt;

  fGetAllMassSite(rho, pt2);
  pb = fGetBulkPressureSwift(rho[0], 0.0, T);
  lambda = fGetLambdaSwift(rho[0], lbtf[0], T);
  invmass = fReciprocal(rho[0]);
  dv[0] = pt4[0] * invmass;
  dv[1] = pt4[1] * invmass;
  dv[2] = pt4[2] * invmass;
  fGetEquilibriumFSwiftOneFluid(feq, sitespeed, rho[0], pb, lambda, pt3);
  relax = 1.0 - lbtf[0];
  modv = dv[0]*(2.0*sitespeed[0]+dv[0]) + dv[1]*(2.0*sitespeed[1]+dv[1]) + dv[2]*(2.0*sitespeed[2]+dv[2]);
  for(int i=0; i<lbsy.nq; i++){
    eixux =  lbvx[i]*sitespeed[0];
    eiyuy =  lbvy[i]*sitespeed[1];
    eizuz =  lbvz[i]*sitespeed[2];
    eixdux = lbvx[i]*dv[0];
    eiyduy = lbvy[i]*dv[1];
    eizduz = lbvz[i]*dv[2];
    source = rho[0] * lbw[i] * (3.0 * (eixdux+eiyduy+eizduz) +
                                4.5 * (eixdux*(eixdux+2.0*(eixux+eiyuy+eizuz+eiyduy+eizduz)) +
                                       eiyduy*(eiyduy+2.0*(eixux+eiyuy+eizuz+eizduz)) +
                                       eizduz*(eizduz+2.0*(eixux+eiyuy+eizuz))) -
                                1.5 * modv);
    pt2[i*qdim] = relax * pt2[i*qdim] + source + feq[i]*lbtf[0];
  }

  pt2 = NULL;
  pt3 = NULL;
  pt4 = NULL;
  return 0;
}

int fSiteFluidCollisionBGKEDMSwiftTwoFluid(double* startpos, double *sitespeed, double* gradient, double* bodyforce, double T)
{
  
  // calculate fluid collisions at grid point: uses BGK single relaxation time with
  // Exact Difference Method forcing term and Swift free-energy interactions for two fluids

  double dv[3], feq[2*lbsy.nq], rho[lbsy.nf];
  double omega, invmass, relax, relaxphi, pb, mu, lambda, source;
  double modv,eixux,eiyuy,eizuz,eixdux,eiyduy,eizduz;
  double *pt2 = &startpos[0];
  double *pt3 = &gradient[0];
  double *pt4 = &bodyforce[0];
  int qdim = lbsy.nf+lbsy.nc+lbsy.nt;

  fGetAllMassSite(rho, pt2);
  omega = 2.0*lbtf[0]*lbtf[1]/(2.0*lbtf[0]+(1.0+rho[1])*(lbtf[1]-lbtf[0]));
  pb = fGetBulkPressureSwift(rho[0], rho[1], T);
  lambda = fGetLambdaSwift(rho[0], omega, T);
  mu = fGetPotentialSwift(rho[1], pt3[7]);
  relax = 1.0 - omega;
  relaxphi = 1.0 - lbtmob;
  invmass = fReciprocal(rho[0]);
  dv[0] = pt4[0] * invmass;
  dv[1] = pt4[1] * invmass;
  dv[2] = pt4[2] * invmass;
  fGetEquilibriumFSwiftTwoFluid(feq, sitespeed, rho[0], rho[1], pb, mu, lambda, pt3);
  modv = dv[0]*(2.0*sitespeed[0]+dv[0]) + dv[1]*(2.0*sitespeed[1]+dv[1]) + dv[2]*(2.0*sitespeed[2]+dv[2]);
  for(int i=0; i<lbsy.nq; i++){
    eixux =  lbvx[i]*sitespeed[0];
    eiyuy =  lbvy[i]*sitespeed[1];
    eizuz =  lbvz[i]*sitespeed[2];
    eixdux = lbvx[i]*dv[0];
    eiyduy = lbvy[i]*dv[1];
    eizduz = lbvz[i]*dv[2];
    source = rho[0] * lbw[i] * (3.0 * (eixdux+eiyduy+eizduz) +
                                4.5 * (eixdux*(eixdux+2.0*(eixux+eiyuy+eizuz+eiyduy+eizduz)) +
                                       eiyduy*(eiyduy+2.0*(eixux+eiyuy+eizuz+eizduz)) +
                                       eizduz*(eizduz+2.0*(eixux+eiyuy+eizuz))) -
                                1.5 * modv);
    pt2[i*qdim  ] = relax    * pt2[i*qdim  ] + feq[2*i  ]*omega + source;
    pt2[i*qdim+1] = relaxphi * pt2[i*qdim+1] + feq[2*i+1]*lbtmob;
  }

  pt2 = NULL;
  pt3 = NULL;
  pt4 = NULL;
  return 0;
}

int fSiteFluidCollisionBGKGuoSwiftOneFluid(double* startpos, double *sitespeed, double* gradient, double* bodyforce, double T)
{
  
  // calculate fluid collisions at grid point: uses BGK single relaxation time with
  // Guo forcing term and Swift free-energy interactions for one fluid

  double speed[3], force[3], feq[lbsy.nq], rho[lbsy.nf];
  double udot, source, invmass, relax, halfrelax, ex, ey, ez, pb, lambda;
  double *pt2 = &startpos[0];
  double *pt3 = &gradient[0];
  double *pt4 = &bodyforce[0];
  int qdim = lbsy.nf+lbsy.nc+lbsy.nt;

  fGetAllMassSite(rho, pt2);
  pb = fGetBulkPressureSwift(rho[0], 0.0, T);
  lambda = fGetLambdaSwift(rho[0], lbtf[0], T);
  invmass = fReciprocal(rho[0]);
  force[0] = pt4[0];
  force[1] = pt4[1];
  force[2] = pt4[2];
  speed[0] = sitespeed[0] + 0.5 * force[0] * invmass;
  speed[1] = sitespeed[1] + 0.5 * force[1] * invmass;
  speed[2] = sitespeed[2] + 0.5 * force[2] * invmass;
  fGetEquilibriumFSwiftOneFluid(feq, speed, rho[0], pb, lambda, pt3);
  relax = 1.0 - lbtf[0];
  halfrelax = 1.0 - 0.5*lbtf[0];
  for(int i=0; i<lbsy.nq; i++){
    ex = lbvx[i];
    ey = lbvy[i];
    ez = lbvz[i];
    udot = ex * speed[0] + ey * speed[1] + ez * speed[2];
    source = (3.0*(ex-speed[0]) + 9.0*udot*ex) * force[0]
           + (3.0*(ey-speed[1]) + 9.0*udot*ey) * force[1]
           + (3.0*(ez-speed[2]) + 9.0*udot*ez) * force[2];
    pt2[i*qdim] = relax * pt2[i*qdim] + halfrelax * lbw[i] * source + feq[i]*lbtf[0];
  }

  pt2 = NULL;
  pt3 = NULL;
  pt4 = NULL;
  return 0;
}

int fSiteFluidCollisionBGKGuoSwiftTwoFluid(double* startpos, double *sitespeed, double* gradient, double* bodyforce, double T)
{
  
  // calculate fluid collisions at grid point: uses BGK single relaxation time with
  // Guo forcing term and Swift free-energy interactions for two fluids

  double speed[3], force[3], feq[2*lbsy.nq], rho[lbsy.nf];
  double omega, udot, source, invmass, relax, relaxphi, halfrelax, ex, ey, ez, pb, mu, lambda;
  double *pt2 = &startpos[0];
  double *pt3 = &gradient[0];
  double *pt4 = &bodyforce[0];
  int qdim = lbsy.nf+lbsy.nc+lbsy.nt;

  fGetAllMassSite(rho, pt2);
  omega = 2.0*lbtf[0]*lbtf[1]/(2.0*lbtf[0]+(1.0+rho[1])*(lbtf[1]-lbtf[0]));
  pb = fGetBulkPressureSwift(rho[0], rho[1], T);
  lambda = fGetLambdaSwift(rho[0], omega, T);
  mu = fGetPotentialSwift(rho[1], pt3[7]);
  invmass = fReciprocal(rho[0]);
  force[0] = pt4[0];
  force[1] = pt4[1];
  force[2] = pt4[2];
  speed[0] = sitespeed[0] + 0.5 * force[0] * invmass;
  speed[1] = sitespeed[1] + 0.5 * force[1] * invmass;
  speed[2] = sitespeed[2] + 0.5 * force[2] * invmass;
  fGetEquilibriumFSwiftTwoFluid(feq, speed, rho[0], rho[1], pb, mu, lambda, pt3);
  relax = 1.0 - omega;
  relaxphi = 1.0 - lbtmob;
  halfrelax = 1.0 - 0.5*omega;
  for(int i=0; i<lbsy.nq; i++){
    ex = lbvx[i];
    ey = lbvy[i];
    ez = lbvz[i];
    udot = ex * speed[0] + ey * speed[1] + ez * speed[2];
    source = (3.0*(ex-speed[0]) + 9.0*udot*ex) * force[0]
           + (3.0*(ey-speed[1]) + 9.0*udot*ey) * force[1]
           + (3.0*(ez-speed[2]) + 9.0*udot*ez) * force[2];
    pt2[i*qdim  ] = relax    * pt2[i*qdim  ] + feq[2*i]*omega    + halfrelax * lbw[i] * source;
    pt2[i*qdim+1] = relaxphi * pt2[i*qdim+1] + feq[2*i+1]*lbtmob;
  }

  pt2 = NULL;
  pt3 = NULL;
  pt4 = NULL;
  return 0;
}


// Solute collisions

int fSiteSoluteCollisionBGK(double* startpos, double *sitespeed)
{
  
  // calculate solute collisions at grid point: uses BGK single relaxation time

  double relax;
  double feq[lbsy.nq], rho[lbsy.nc];
  double *pt2 = &startpos[0];
  int qdim = lbsy.nf+lbsy.nc+lbsy.nt;

  fGetAllConcSite(rho, pt2);
    
  for(int j=0; j<lbsy.nc; j++) {
    fGetEquilibriumC(&feq[0], sitespeed, rho[j]);
    relax = 1.0 - lbtc[j];
    for(int i=0; i<lbsy.nq; i++) {
      pt2[i*qdim+j] = relax * pt2[i*qdim+j] + feq[i]*lbtc[j];
    }
  }

  pt2 = NULL;
  return 0;
}

// Thermal collisions

int fSiteThermalCollisionBGK(double* startpos, double *sitespeed)
{
  
  // calculate thermal collisions at grid point: uses BGK single relaxation time

  double onemass, relax;
  double feq[lbsy.nq];
  double *pt2 = &startpos[0];
  int qdim = lbsy.nf+lbsy.nc+lbsy.nt;

  if(lbsy.nt == 1) {
    onemass = fGetOneMassSite(pt2);    
    fGetEquilibriumT(&feq[0], sitespeed, onemass);
    relax = 1.0 - lbtt[0];
    for(int i=0; i<lbsy.nq; i++) {
      pt2[i*qdim] = relax * pt2[i*qdim] + feq[i]*lbtt[0];
    }
  }

  pt2 = NULL;
  return 0;
}

// Collision loops over all grid points

int fCollisionBGK()
{

  long il;
  long Tmax = lbdm.touter;

  if(!incompress) {

   #pragma omp parallel
   {
      double interforce_local_t[3*lbsy.nf], sitespeed_local_t[3];
      double *interforce = &interforce_local_t[0];
      double *sitespeed = &sitespeed_local_t[0];

      #pragma omp for
      for(il=0; il<Tmax; il++) {
        fGetSpeedSite(sitespeed, &lbf[il*lbsitelength]);
        if(lbphi[il] != 11) {
          for(int ll=0; ll<3*lbsy.nf; ll++)
	        interforce [ll] = lbinterforce[il*3*lbsy.nf+ll] + postequil*lbbdforce[ll];
          if(lbphi[il] != 12 && lbphi[il] != 13)
            fSiteFluidCollisionBGK(&lbf[il*lbsitelength], sitespeed, interforce);
          fSiteSoluteCollisionBGK(&lbf[il*lbsitelength + lbsy.nf], sitespeed);
          fSiteThermalCollisionBGK(&lbf[il*lbsitelength + lbsy.nf+lbsy.nc], sitespeed);
        }
      }
    }
  }
  else {
      
   #pragma omp parallel
   {
      double interforce_local_t[3*lbsy.nf], sitespeed_local_t[3];
      double *interforce = &interforce_local_t[0];
      double *sitespeed = &sitespeed_local_t[0];

      #pragma omp for
      for(il=0; il<Tmax; il++) {
        fGetSpeedIncomSite(sitespeed, &lbf[il*lbsitelength]);
        if(lbphi[il] != 11) {
          for(int ll=0; ll<3*lbsy.nf; ll++)
            interforce[ll] = lbinterforce[il*3*lbsy.nf+ll] + postequil*lbbdforce[ll];
          if(lbphi[il] != 12 && lbphi[il] != 13)
            fSiteFluidIncomCollisionBGK(&lbf[il*lbsitelength], sitespeed, interforce);
          fSiteSoluteCollisionBGK(&lbf[il*lbsitelength + lbsy.nf], sitespeed);
          fSiteThermalCollisionBGK(&lbf[il*lbsitelength + lbsy.nf+lbsy.nc], sitespeed);
        }
      }
    }
  }
  return 0;
}

int fCollisionBGKEDM()
{
  long il;
  long Tmax = lbdm.touter;

  if(!incompress) {

    #pragma omp parallel
    {
      double interforce_t[3*lbsy.nf], sitespeed_t[3];
      double *interforce = &interforce_t[0];
      double *sitespeed = &sitespeed_t[0];
                                     
      #pragma omp for
      for(il=0; il<Tmax; il++) {
        fGetSpeedSite(sitespeed, &lbf[il*lbsitelength]);
        if(lbphi[il] != 11) {
          for(int ll=0; ll<3*lbsy.nf; ll++)
            interforce[ll] = lbinterforce[il*3*lbsy.nf+ll] + postequil*lbbdforce[ll];
          if(lbphi[il] != 12 && lbphi[il] != 13)
            fSiteFluidCollisionBGKEDM(&lbf[il*lbsitelength], sitespeed, interforce);
          fSiteSoluteCollisionBGK(&lbf[il*lbsitelength + lbsy.nf], sitespeed);
          fSiteThermalCollisionBGK(&lbf[il*lbsitelength + lbsy.nf+lbsy.nc], sitespeed);
        }
      }
    }
  }
  else {

    #pragma omp parallel
    {
      double interforce_t[3*lbsy.nf], sitespeed_t[3];
      double *interforce = &interforce_t[0];
      double *sitespeed = &sitespeed_t[0];
                                     
      #pragma omp for
      for(il=0; il<Tmax; il++) {
        fGetSpeedIncomSite(sitespeed, &lbf[il*lbsitelength]);
        if(lbphi[il] != 11) {
          for(int ll=0; ll<3*lbsy.nf; ll++)
            interforce[ll] = lbinterforce[il*3*lbsy.nf+ll] + postequil*lbbdforce[ll];
          if(lbphi[il] != 12 && lbphi[il] != 13)
            fSiteFluidIncomCollisionBGKEDM(&lbf[il*lbsitelength], sitespeed, interforce);
          fSiteSoluteCollisionBGK(&lbf[il*lbsitelength + lbsy.nf], sitespeed);
          fSiteThermalCollisionBGK(&lbf[il*lbsitelength + lbsy.nf+lbsy.nc], sitespeed);
        }
      }
    }
  }
  return 0;
}

int fCollisionBGKGuo()
{
  long il;
  int Tmax = lbdm.touter;

  if(!incompress) {

    #pragma omp parallel
    {
      double interforce_t[3*lbsy.nf], sitespeed_t[3];
      double *interforce = &interforce_t[0];
      double *sitespeed = &sitespeed_t[0];
                                     
      #pragma omp for
      for(il=0; il<Tmax; il++) {
        fGetSpeedSite(sitespeed, &lbf[il*lbsitelength]);
        if(lbphi[il] != 11) {
          for(int ll=0; ll<3*lbsy.nf; ll++)
            interforce[ll] = lbinterforce[il*3*lbsy.nf+ll] + postequil*lbbdforce[ll];
          if(lbphi[il] != 12 && lbphi[il] != 13)
            fSiteFluidCollisionBGKGuo(&lbf[il*lbsitelength], sitespeed, interforce);
          fSiteSoluteCollisionBGK(&lbf[il*lbsitelength + lbsy.nf], sitespeed);
          fSiteThermalCollisionBGK(&lbf[il*lbsitelength + lbsy.nf+lbsy.nc], sitespeed);
        }
      }
    }
  }
  else {

    #pragma omp parallel
    {
      double interforce_t[3*lbsy.nf], sitespeed_t[3];
      double *interforce = &interforce_t[0];
      double *sitespeed = &sitespeed_t[0];
                                     
      #pragma omp for
      for(il=0; il<Tmax; il++) {
        fGetSpeedIncomSite(sitespeed, &lbf[il*lbsitelength]);
        if(lbphi[il] != 11) {
          for(int ll=0; ll<3*lbsy.nf; ll++)
            interforce[ll] = lbinterforce[il*3*lbsy.nf+ll] + postequil*lbbdforce[ll];
          if(lbphi[il] != 12 && lbphi[il] != 13)
            fSiteFluidIncomCollisionBGKGuo(&lbf[il*lbsitelength], sitespeed, interforce);
          fSiteSoluteCollisionBGK(&lbf[il*lbsitelength + lbsy.nf], sitespeed);
          fSiteThermalCollisionBGK(&lbf[il*lbsitelength + lbsy.nf+lbsy.nc], sitespeed);
        }
      }
    }
  }
  return 0;
}


int fCollisionBGKShanChen()
{

  long il;
  long Tmax = lbdm.touter;

  if(!incompress) {

   #pragma omp parallel
   {
      double interforce_local_t[3*lbsy.nf], sitespeed_local_t[3];
      double *interforce = &interforce_local_t[0];
      double *sitespeed = &sitespeed_local_t[0];

      #pragma omp for
      for(il=0; il<Tmax; il++) {
        fGetSpeedShanChenSite(sitespeed, &lbf[il*lbsitelength]);
        if(lbphi[il] != 11) {
          for(int ll=0; ll<3*lbsy.nf; ll++)
	        interforce [ll] = lbinterforce[il*3*lbsy.nf+ll] + postequil*lbbdforce[ll];
          if(lbphi[il] != 12 && lbphi[il] != 13)
            fSiteFluidCollisionBGK(&lbf[il*lbsitelength], sitespeed, interforce);
          fSiteSoluteCollisionBGK(&lbf[il*lbsitelength + lbsy.nf], sitespeed);
          fSiteThermalCollisionBGK(&lbf[il*lbsitelength + lbsy.nf+lbsy.nc], sitespeed);
        }
      }
    }
  }
  else {
      
   #pragma omp parallel
   {
      double interforce_local_t[3*lbsy.nf], sitespeed_local_t[3];
      double *interforce = &interforce_local_t[0];
      double *sitespeed = &sitespeed_local_t[0];

      #pragma omp for
      for(il=0; il<Tmax; il++) {
        fGetSpeedShanChenIncomSite(sitespeed, &lbf[il*lbsitelength]);
        if(lbphi[il] != 11) {
          for(int ll=0; ll<3*lbsy.nf; ll++)
            interforce[ll] = lbinterforce[il*3*lbsy.nf+ll] + postequil*lbbdforce[ll];
          if(lbphi[il] != 12 && lbphi[il] != 13)
            fSiteFluidIncomCollisionBGK(&lbf[il*lbsitelength], sitespeed, interforce);
          fSiteSoluteCollisionBGK(&lbf[il*lbsitelength + lbsy.nf], sitespeed);
          fSiteThermalCollisionBGK(&lbf[il*lbsitelength + lbsy.nf+lbsy.nc], sitespeed);
        }
      }
    }
  }
  return 0;
}

int fCollisionBGKEDMShanChen()
{
  long il;
  long Tmax = lbdm.touter;

  if(!incompress) {

    #pragma omp parallel
    {
      double interforce_t[3*lbsy.nf], sitespeed_t[3];
      double *interforce = &interforce_t[0];
      double *sitespeed = &sitespeed_t[0];
                                     
      #pragma omp for
      for(il=0; il<Tmax; il++) {
        fGetSpeedShanChenSite(sitespeed, &lbf[il*lbsitelength]);
        if(lbphi[il] != 11) {
          for(int ll=0; ll<3*lbsy.nf; ll++)
            interforce[ll] = lbinterforce[il*3*lbsy.nf+ll] + postequil*lbbdforce[ll];
          if(lbphi[il] != 12 && lbphi[il] != 13)
            fSiteFluidCollisionBGKEDM(&lbf[il*lbsitelength], sitespeed, interforce);
          fSiteSoluteCollisionBGK(&lbf[il*lbsitelength + lbsy.nf], sitespeed);
          fSiteThermalCollisionBGK(&lbf[il*lbsitelength + lbsy.nf+lbsy.nc], sitespeed);
        }
      }
    }
  }
  else {

    #pragma omp parallel
    {
      double interforce_t[3*lbsy.nf], sitespeed_t[3];
      double *interforce = &interforce_t[0];
      double *sitespeed = &sitespeed_t[0];
                                     
      #pragma omp for
      for(il=0; il<Tmax; il++) {
        fGetSpeedShanChenIncomSite(sitespeed, &lbf[il*lbsitelength]);
        if(lbphi[il] != 11) {
          for(int ll=0; ll<3*lbsy.nf; ll++)
            interforce[ll] = lbinterforce[il*3*lbsy.nf+ll] + postequil*lbbdforce[ll];
          if(lbphi[il] != 12 && lbphi[il] != 13)
            fSiteFluidIncomCollisionBGKEDM(&lbf[il*lbsitelength], sitespeed, interforce);
          fSiteSoluteCollisionBGK(&lbf[il*lbsitelength + lbsy.nf], sitespeed);
          fSiteThermalCollisionBGK(&lbf[il*lbsitelength + lbsy.nf+lbsy.nc], sitespeed);
        }
      }
    }
  }
  return 0;
}

int fCollisionBGKGuoShanChen()
{
  long il;
  int Tmax = lbdm.touter;

  if(!incompress) {

    #pragma omp parallel
    {
      double interforce_t[3*lbsy.nf], sitespeed_t[3];
      double *interforce = &interforce_t[0];
      double *sitespeed = &sitespeed_t[0];
                                     
      #pragma omp for
      for(il=0; il<Tmax; il++) {
        fGetSpeedShanChenSite(sitespeed, &lbf[il*lbsitelength]);
        if(lbphi[il] != 11) {
          for(int ll=0; ll<3*lbsy.nf; ll++)
            interforce[ll] = lbinterforce[il*3*lbsy.nf+ll] + postequil*lbbdforce[ll];
          if(lbphi[il] != 12 && lbphi[il] != 13)
            fSiteFluidCollisionBGKGuo(&lbf[il*lbsitelength], sitespeed, interforce);
          fSiteSoluteCollisionBGK(&lbf[il*lbsitelength + lbsy.nf], sitespeed);
          fSiteThermalCollisionBGK(&lbf[il*lbsitelength + lbsy.nf+lbsy.nc], sitespeed);
        }
      }
    }
  }
  else {

    #pragma omp parallel
    {
      double interforce_t[3*lbsy.nf], sitespeed_t[3];
      double *interforce = &interforce_t[0];
      double *sitespeed = &sitespeed_t[0];
                                     
      #pragma omp for
      for(il=0; il<Tmax; il++) {
        fGetSpeedShanChenIncomSite(sitespeed, &lbf[il*lbsitelength]);
        if(lbphi[il] != 11) {
          for(int ll=0; ll<3*lbsy.nf; ll++)
            interforce[ll] = lbinterforce[il*3*lbsy.nf+ll] + postequil*lbbdforce[ll];
          if(lbphi[il] != 12 && lbphi[il] != 13)
            fSiteFluidIncomCollisionBGKGuo(&lbf[il*lbsitelength], sitespeed, interforce);
          fSiteSoluteCollisionBGK(&lbf[il*lbsitelength + lbsy.nf], sitespeed);
          fSiteThermalCollisionBGK(&lbf[il*lbsitelength + lbsy.nf+lbsy.nc], sitespeed);
        }
      }
    }
  }
  return 0;
}


int fCollisionBGKLishchuk()
{
  long il;
  double frac,invallmass;
  int numpair = 3 * lbsy.nf * (lbsy.nf-1) / 2;
  long Tmax = lbdm.touter;

  if(!incompress) {
      
    #pragma omp parallel private(frac,invallmass)
    {
      double interforce_t[3], sitespeed_t[3];
      double *interforce = &interforce_t[0];
      double *sitespeed = &sitespeed_t[0];

      #pragma omp for
      for(il=0; il<Tmax; il++) {
        fGetSpeedSite(sitespeed, &lbf[il*lbsitelength]);
        if(lbphi[il] != 11) {
          invallmass = fReciprocal(fGetTotMassSite(&lbf[il*lbsitelength]));
          interforce[0] = 0.0; interforce[1] = 0.0; interforce[2] = 0.0;
          for(int ll=0; ll<lbsy.nf; ll++) {
            frac = fGetOneMassSite(ll, il) * invallmass;
	        interforce[0] += lbinterforce[il*3*lbsy.nf+3*ll  ]+postequil*frac*lbbdforce[3*ll  ];
            interforce[1] += lbinterforce[il*3*lbsy.nf+3*ll+1]+postequil*frac*lbbdforce[3*ll+1];
	        interforce[2] += lbinterforce[il*3*lbsy.nf+3*ll+2]+postequil*frac*lbbdforce[3*ll+2];
          }
          if(lbphi[il] != 12 && lbphi[il] != 13)
	        fSiteFluidCollisionBGKLishchuk(&lbf[il*lbsitelength], sitespeed, interforce, &lbft[il*numpair]);
          fSiteSoluteCollisionBGK(&lbf[il*lbsitelength + lbsy.nf], sitespeed);
          fSiteThermalCollisionBGK(&lbf[il*lbsitelength + lbsy.nf+lbsy.nc], sitespeed);
        }
      }
    }
  }
  else {
      
    #pragma omp parallel private(frac,invallmass)
    {
      double interforce_t[3], sitespeed_t[3];
      double *interforce = &interforce_t[0];
      double *sitespeed = &sitespeed_t[0];

      #pragma omp for
      for(il=0; il<Tmax; il++) {
        fGetSpeedIncomSite(sitespeed, &lbf[il*lbsitelength]);
        if(lbphi[il] != 11) {
          invallmass = fReciprocal(fGetTotMassSite(&lbf[il*lbsitelength]));
          interforce[0] = 0.0; interforce[1] = 0.0; interforce[2] = 0.0;
          for(int ll=0; ll<lbsy.nf; ll++) {
            frac = fGetOneMassSite(ll, il) * invallmass;
            interforce[0] += lbinterforce[il*3*lbsy.nf+3*ll  ]+postequil*frac*lbbdforce[3*ll  ];
            interforce[1] += lbinterforce[il*3*lbsy.nf+3*ll+1]+postequil*frac*lbbdforce[3*ll+1];
            interforce[2] += lbinterforce[il*3*lbsy.nf+3*ll+2]+postequil*frac*lbbdforce[3*ll+2];
          }
          if(lbphi[il] != 12 && lbphi[il] != 13)
            fSiteFluidIncomCollisionBGKLishchuk(&lbf[il*lbsitelength], sitespeed, interforce, &lbft[il*numpair]);
          fSiteSoluteCollisionBGK(&lbf[il*lbsitelength + lbsy.nf], sitespeed);
          fSiteThermalCollisionBGK(&lbf[il*lbsitelength + lbsy.nf+lbsy.nc], sitespeed);
        }
      }
    }
  }
  return 0;
}

int fCollisionBGKEDMLishchuk()
{
  long il;
  double frac,invallmass;
  int numpair = 3 * lbsy.nf * (lbsy.nf-1) / 2;
  long Tmax = lbdm.touter;

  if(!incompress) {

    #pragma omp parallel private(frac,invallmass)
    {
      double interforce_t[3], sitespeed_t[3];
      double *interforce = &interforce_t[0];
      double *sitespeed = &sitespeed_t[0];

      #pragma omp for
      for(il=0; il<Tmax; il++) {
        fGetSpeedSite(sitespeed, &lbf[il*lbsitelength]);
        if(lbphi[il] != 11) {
          invallmass = fReciprocal(fGetTotMassSite(&lbf[il*lbsitelength]));
          interforce[0] = 0.0; interforce[1] = 0.0; interforce[2] = 0.0;
          for(int ll=0; ll<lbsy.nf; ll++) {
            frac = fGetOneMassSite(ll, il) * invallmass;
            interforce[0] += lbinterforce[il*3*lbsy.nf+3*ll  ]+postequil*frac*lbbdforce[3*ll  ];
            interforce[1] += lbinterforce[il*3*lbsy.nf+3*ll+1]+postequil*frac*lbbdforce[3*ll+1];
            interforce[2] += lbinterforce[il*3*lbsy.nf+3*ll+2]+postequil*frac*lbbdforce[3*ll+2];
          }
          if(lbphi[il] != 12 && lbphi[il] != 13)
            fSiteFluidCollisionBGKEDMLishchuk(&lbf[il*lbsitelength], sitespeed, interforce, &lbft[il*numpair]);
          fSiteSoluteCollisionBGK(&lbf[il*lbsitelength + lbsy.nf], sitespeed);
          fSiteThermalCollisionBGK(&lbf[il*lbsitelength + lbsy.nf+lbsy.nc], sitespeed);
        }
      }
    }
  }
  else {

    #pragma omp parallel private(frac,invallmass)
    {
      double interforce_t[3], sitespeed_t[3];
      double *interforce = &interforce_t[0];
      double *sitespeed = &sitespeed_t[0];

      #pragma omp for
      for(il=0; il<Tmax; il++) {
        fGetSpeedIncomSite(sitespeed, &lbf[il*lbsitelength]);
        if(lbphi[il] != 11) {
          invallmass = fReciprocal(fGetTotMassSite(&lbf[il*lbsitelength]));
          interforce[0] = 0.0; interforce[1] = 0.0; interforce[2] = 0.0;
          for(int ll=0; ll<lbsy.nf; ll++) {
            frac = fGetOneMassSite(ll, il) * invallmass;
            interforce[0] += lbinterforce[il*3*lbsy.nf+3*ll  ]+postequil*frac*lbbdforce[3*ll  ];
            interforce[1] += lbinterforce[il*3*lbsy.nf+3*ll+1]+postequil*frac*lbbdforce[3*ll+1];
            interforce[2] += lbinterforce[il*3*lbsy.nf+3*ll+2]+postequil*frac*lbbdforce[3*ll+2];
          }
          if(lbphi[il] != 12 && lbphi[il] != 13)
            fSiteFluidIncomCollisionBGKEDMLishchuk(&lbf[il*lbsitelength], sitespeed, interforce, &lbft[il*numpair]);
          fSiteSoluteCollisionBGK(&lbf[il*lbsitelength + lbsy.nf], sitespeed);
          fSiteThermalCollisionBGK(&lbf[il*lbsitelength + lbsy.nf+lbsy.nc], sitespeed);
        }
      }
    }
  }
  return 0;
}

int fCollisionBGKGuoLishchuk()
{
  long il;
  double frac,invallmass;
  int numpair = 3 * lbsy.nf * (lbsy.nf-1) / 2;
  long Tmax = lbdm.touter;

  if(!incompress) {

    #pragma omp parallel private(frac,invallmass)
    {
      double interforce_t[3], sitespeed_t[3];
      double *interforce = &interforce_t[0];
      double *sitespeed = &sitespeed_t[0];

      #pragma omp for
      for(il=0; il<Tmax; il++) {
        fGetSpeedSite(sitespeed, &lbf[il*lbsitelength]);
        if(lbphi[il] != 11) {
          invallmass = fReciprocal(fGetTotMassSite(&lbf[il*lbsitelength]));
          interforce[0] = 0.0; interforce[1] = 0.0; interforce[2] = 0.0;
          for(int ll=0; ll<lbsy.nf; ll++) {
            frac = fGetOneMassSite(ll, il) * invallmass;
	        interforce[0] += lbinterforce[il*3*lbsy.nf+3*ll  ]+postequil*frac*lbbdforce[3*ll  ];
            interforce[1] += lbinterforce[il*3*lbsy.nf+3*ll+1]+postequil*frac*lbbdforce[3*ll+1];
            interforce[2] += lbinterforce[il*3*lbsy.nf+3*ll+2]+postequil*frac*lbbdforce[3*ll+2];
          }
          if(lbphi[il] != 12 && lbphi[il] != 13)
            fSiteFluidCollisionBGKGuoLishchuk(&lbf[il*lbsitelength], sitespeed, interforce, &lbft[il*numpair]);
          fSiteSoluteCollisionBGK(&lbf[il*lbsitelength + lbsy.nf], sitespeed);
          fSiteThermalCollisionBGK(&lbf[il*lbsitelength + lbsy.nf+lbsy.nc], sitespeed);
        }
      }
    }
  }
  else {

    #pragma omp parallel private(frac,invallmass)
    {
      double interforce_t[3], sitespeed_t[3];
      double *interforce = &interforce_t[0];
      double *sitespeed = &sitespeed_t[0];

      #pragma omp for
      for(il=0; il<Tmax; il++) {
        fGetSpeedIncomSite(sitespeed, &lbf[il*lbsitelength]);
        if(lbphi[il] != 11) {
          invallmass = fReciprocal(fGetTotMassSite(&lbf[il*lbsitelength]));
          interforce[0] = 0.0; interforce[1] = 0.0; interforce[2] = 0.0;
          for(int ll=0; ll<lbsy.nf; ll++) {
            frac = fGetOneMassSite(ll, il) * invallmass;
            interforce[0] += lbinterforce[il*3*lbsy.nf+3*ll  ]+postequil*frac*lbbdforce[3*ll  ];
            interforce[1] += lbinterforce[il*3*lbsy.nf+3*ll+1]+postequil*frac*lbbdforce[3*ll+1];
            interforce[2] += lbinterforce[il*3*lbsy.nf+3*ll+2]+postequil*frac*lbbdforce[3*ll+2];
          }
          if(lbphi[il] != 12 && lbphi[il] != 13)
            fSiteFluidIncomCollisionBGKGuoLishchuk(&lbf[il*lbsitelength], sitespeed, interforce, &lbft[il*numpair]);
          fSiteSoluteCollisionBGK(&lbf[il*lbsitelength + lbsy.nf], sitespeed);
          fSiteThermalCollisionBGK(&lbf[il*lbsitelength + lbsy.nf+lbsy.nc], sitespeed);
        }
      }
    }
  }
  return 0;
}


int fCollisionBGKLishchukLocal()
{
  long il;
  double frac,invallmass;
  int numpair = 3 * lbsy.nf * (lbsy.nf-1) / 2;
  int threed = (lbsy.nd>2);
  long Tmax = lbdm.touter;

  if(!incompress) {
      
    #pragma omp parallel private(frac,invallmass)
    {
      double interforce_t[3], sitespeed_t[3];
      double *interforce = &interforce_t[0];
      double *sitespeed = &sitespeed_t[0];

      #pragma omp for
      for(il=0; il<Tmax; il++) {
        fGetSpeedSite(sitespeed, &lbf[il*lbsitelength]);
        if(lbphi[il] != 11) {
          invallmass = fReciprocal(fGetTotMassSite(&lbf[il*lbsitelength]));
          interforce[0] = 0.0; interforce[1] = 0.0; interforce[2] = 0.0;
          for(int ll=0; ll<lbsy.nf; ll++) {
            frac = fGetOneMassSite(ll, il) * invallmass;
	        interforce[0] += lbinterforce[il*3*lbsy.nf+3*ll  ]+postequil*frac*lbbdforce[3*ll  ];
            interforce[1] += lbinterforce[il*3*lbsy.nf+3*ll+1]+postequil*frac*lbbdforce[3*ll+1];
	        interforce[2] += lbinterforce[il*3*lbsy.nf+3*ll+2]+postequil*frac*lbbdforce[3*ll+2];
          }
          if(lbphi[il] != 12 && lbphi[il] != 13)
	        fSiteFluidCollisionBGKLishchukLocal(&lbf[il*lbsitelength], sitespeed, interforce, &lbft[il*numpair], threed);
          fSiteSoluteCollisionBGK(&lbf[il*lbsitelength + lbsy.nf], sitespeed);
          fSiteThermalCollisionBGK(&lbf[il*lbsitelength + lbsy.nf+lbsy.nc], sitespeed);
        }
      }
    }
  }
  else {
      
    #pragma omp parallel private(frac,invallmass)
    {
      double interforce_t[3], sitespeed_t[3];
      double *interforce = &interforce_t[0];
      double *sitespeed = &sitespeed_t[0];

      #pragma omp for
      for(il=0; il<Tmax; il++) {
        fGetSpeedIncomSite(sitespeed, &lbf[il*lbsitelength]);
        if(lbphi[il] != 11) {
          invallmass = fReciprocal(fGetTotMassSite(&lbf[il*lbsitelength]));
          interforce[0] = 0.0; interforce[1] = 0.0; interforce[2] = 0.0;
          for(int ll=0; ll<lbsy.nf; ll++) {
            frac = fGetOneMassSite(ll, il) * invallmass;
            interforce[0] += lbinterforce[il*3*lbsy.nf+3*ll  ]+postequil*frac*lbbdforce[3*ll  ];
            interforce[1] += lbinterforce[il*3*lbsy.nf+3*ll+1]+postequil*frac*lbbdforce[3*ll+1];
            interforce[2] += lbinterforce[il*3*lbsy.nf+3*ll+2]+postequil*frac*lbbdforce[3*ll+2];
          }
          if(lbphi[il] != 12 && lbphi[il] != 13)
            fSiteFluidIncomCollisionBGKLishchukLocal(&lbf[il*lbsitelength], sitespeed, interforce, &lbft[il*numpair], threed);
          fSiteSoluteCollisionBGK(&lbf[il*lbsitelength + lbsy.nf], sitespeed);
          fSiteThermalCollisionBGK(&lbf[il*lbsitelength + lbsy.nf+lbsy.nc], sitespeed);
        }
      }
    }
  }
  return 0;
}

int fCollisionBGKEDMLishchukLocal()
{
  long il;
  double frac,invallmass;
  int numpair = 3 * lbsy.nf * (lbsy.nf-1) / 2;
  int threed = (lbsy.nd>2);
  long Tmax = lbdm.touter;

  if(!incompress) {

    #pragma omp parallel private(frac,invallmass)
    {
      double interforce_t[3], sitespeed_t[3];
      double *interforce = &interforce_t[0];
      double *sitespeed = &sitespeed_t[0];

      #pragma omp for
      for(il=0; il<Tmax; il++) {
        fGetSpeedSite(sitespeed, &lbf[il*lbsitelength]);
        if(lbphi[il] != 11) {
          invallmass = fReciprocal(fGetTotMassSite(&lbf[il*lbsitelength]));
          interforce[0] = 0.0; interforce[1] = 0.0; interforce[2] = 0.0;
          for(int ll=0; ll<lbsy.nf; ll++) {
            frac = fGetOneMassSite(ll, il) * invallmass;
            interforce[0] += lbinterforce[il*3*lbsy.nf+3*ll  ]+postequil*frac*lbbdforce[3*ll  ];
            interforce[1] += lbinterforce[il*3*lbsy.nf+3*ll+1]+postequil*frac*lbbdforce[3*ll+1];
            interforce[2] += lbinterforce[il*3*lbsy.nf+3*ll+2]+postequil*frac*lbbdforce[3*ll+2];
          }
          if(lbphi[il] != 12 && lbphi[il] != 13)
            fSiteFluidCollisionBGKEDMLishchukLocal(&lbf[il*lbsitelength], sitespeed, interforce, &lbft[il*numpair], threed);
          fSiteSoluteCollisionBGK(&lbf[il*lbsitelength + lbsy.nf], sitespeed);
          fSiteThermalCollisionBGK(&lbf[il*lbsitelength + lbsy.nf+lbsy.nc], sitespeed);
        }
      }
    }
  }
  else {

    #pragma omp parallel private(frac,invallmass)
    {
      double interforce_t[3], sitespeed_t[3];
      double *interforce = &interforce_t[0];
      double *sitespeed = &sitespeed_t[0];

      #pragma omp for
      for(il=0; il<Tmax; il++) {
        fGetSpeedIncomSite(sitespeed, &lbf[il*lbsitelength]);
        if(lbphi[il] != 11) {
          invallmass = fReciprocal(fGetTotMassSite(&lbf[il*lbsitelength]));
          interforce[0] = 0.0; interforce[1] = 0.0; interforce[2] = 0.0;
          for(int ll=0; ll<lbsy.nf; ll++) {
            frac = fGetOneMassSite(ll, il) * invallmass;
            interforce[0] += lbinterforce[il*3*lbsy.nf+3*ll  ]+postequil*frac*lbbdforce[3*ll  ];
            interforce[1] += lbinterforce[il*3*lbsy.nf+3*ll+1]+postequil*frac*lbbdforce[3*ll+1];
            interforce[2] += lbinterforce[il*3*lbsy.nf+3*ll+2]+postequil*frac*lbbdforce[3*ll+2];
          }
          if(lbphi[il] != 12 && lbphi[il] != 13)
            fSiteFluidIncomCollisionBGKEDMLishchukLocal(&lbf[il*lbsitelength], sitespeed, interforce, &lbft[il*numpair], threed);
          fSiteSoluteCollisionBGK(&lbf[il*lbsitelength + lbsy.nf], sitespeed);
          fSiteThermalCollisionBGK(&lbf[il*lbsitelength + lbsy.nf+lbsy.nc], sitespeed);
        }
      }
    }
  }
  return 0;
}

int fCollisionBGKGuoLishchukLocal()
{
  long il;
  double frac,invallmass;
  int numpair = 3 * lbsy.nf * (lbsy.nf-1) / 2;
  int threed = (lbsy.nd>2);
  long Tmax = lbdm.touter;

  if(!incompress) {

    #pragma omp parallel private(frac,invallmass)
    {
      double interforce_t[3], sitespeed_t[3];
      double *interforce = &interforce_t[0];
      double *sitespeed = &sitespeed_t[0];

      #pragma omp for
      for(il=0; il<Tmax; il++) {
        fGetSpeedSite(sitespeed, &lbf[il*lbsitelength]);
        if(lbphi[il] != 11) {
          invallmass = fReciprocal(fGetTotMassSite(&lbf[il*lbsitelength]));
          interforce[0] = 0.0; interforce[1] = 0.0; interforce[2] = 0.0;
          for(int ll=0; ll<lbsy.nf; ll++) {
            frac = fGetOneMassSite(ll, il) * invallmass;
	        interforce[0] += lbinterforce[il*3*lbsy.nf+3*ll  ]+postequil*frac*lbbdforce[3*ll  ];
            interforce[1] += lbinterforce[il*3*lbsy.nf+3*ll+1]+postequil*frac*lbbdforce[3*ll+1];
            interforce[2] += lbinterforce[il*3*lbsy.nf+3*ll+2]+postequil*frac*lbbdforce[3*ll+2];
          }
          if(lbphi[il] != 12 && lbphi[il] != 13)
            fSiteFluidCollisionBGKGuoLishchukLocal(&lbf[il*lbsitelength], sitespeed, interforce, &lbft[il*numpair], threed);
          fSiteSoluteCollisionBGK(&lbf[il*lbsitelength + lbsy.nf], sitespeed);
          fSiteThermalCollisionBGK(&lbf[il*lbsitelength + lbsy.nf+lbsy.nc], sitespeed);
        }
      }
    }
  }
  else {

    #pragma omp parallel private(frac,invallmass)
    {
      double interforce_t[3], sitespeed_t[3];
      double *interforce = &interforce_t[0];
      double *sitespeed = &sitespeed_t[0];

      #pragma omp for
      for(il=0; il<Tmax; il++) {
        fGetSpeedIncomSite(sitespeed, &lbf[il*lbsitelength]);
        if(lbphi[il] != 11) {
          invallmass = fReciprocal(fGetTotMassSite(&lbf[il*lbsitelength]));
          interforce[0] = 0.0; interforce[1] = 0.0; interforce[2] = 0.0;
          for(int ll=0; ll<lbsy.nf; ll++) {
            frac = fGetOneMassSite(ll, il) * invallmass;
            interforce[0] += lbinterforce[il*3*lbsy.nf+3*ll  ]+postequil*frac*lbbdforce[3*ll  ];
            interforce[1] += lbinterforce[il*3*lbsy.nf+3*ll+1]+postequil*frac*lbbdforce[3*ll+1];
            interforce[2] += lbinterforce[il*3*lbsy.nf+3*ll+2]+postequil*frac*lbbdforce[3*ll+2];
          }
          if(lbphi[il] != 12 && lbphi[il] != 13)
            fSiteFluidIncomCollisionBGKGuoLishchukLocal(&lbf[il*lbsitelength], sitespeed, interforce, &lbft[il*numpair], threed);
          fSiteSoluteCollisionBGK(&lbf[il*lbsitelength + lbsy.nf], sitespeed);
          fSiteThermalCollisionBGK(&lbf[il*lbsitelength + lbsy.nf+lbsy.nc], sitespeed);
        }
      }
    }
  }
  return 0;
}


int fCollisionBGKSwift()
{

  long il;
  long Tmax = lbdm.touter;

  if(lbsy.nf>1) {

   #pragma omp parallel
   {
      double interforce_local_t[3], sitespeed_local_t[3];
      double *interforce = &interforce_local_t[0];
      double *sitespeed = &sitespeed_local_t[0];

      #pragma omp for
      for(il=0; il<Tmax; il++) {
        fGetOneSpeedSite(sitespeed, &lbf[il*lbsitelength]);
        double T = (lbsy.nt>0)?fGetTemperatureSite(il):lbsyst;
        double frac = fGetFracSwiftSite(0, &lbf[il*lbsitelength]);
        if(lbneigh[il]>0 && lbphi[il]==0) {
          sitespeed[0] = 0.0; sitespeed[1] = 0.0; sitespeed[2] = 0.0;
        }
        if(lbphi[il] != 11) {
          for(int ll=0; ll<3; ll++)
            interforce [ll] = frac*(lbinterforce[il*3*lbsy.nf+ll] + postequil*lbbdforce[ll]) + (1.0-frac)*(lbinterforce[il*3*lbsy.nf+3+ll] + postequil*lbbdforce[3+ll]);
          if(lbphi[il] != 12 && lbphi[il] != 13)
            fSiteFluidCollisionBGKSwiftTwoFluid(&lbf[il*lbsitelength], sitespeed, &lbft[8*il], interforce, T);
          fSiteSoluteCollisionBGK(&lbf[il*lbsitelength + lbsy.nf], sitespeed);
          fSiteThermalCollisionBGK(&lbf[il*lbsitelength + lbsy.nf+lbsy.nc], sitespeed);
        }
      }
    }
  }
  else {
      
   #pragma omp parallel
   {
      double interforce_local_t[3], sitespeed_local_t[3];
      double *interforce = &interforce_local_t[0];
      double *sitespeed = &sitespeed_local_t[0];

      #pragma omp for
      for(il=0; il<Tmax; il++) {
        fGetOneSpeedSite(sitespeed, &lbf[il*lbsitelength]);
        double T = (lbsy.nt>0)?fGetTemperatureSite(il):lbsyst;
        if(lbneigh[il]>0 && lbphi[il]==0) {
          sitespeed[0] = 0.0; sitespeed[1] = 0.0; sitespeed[2] = 0.0;
        }
        if(lbphi[il] != 11) {
          for(int ll=0; ll<3; ll++)
            interforce [ll] = lbinterforce[il*3*lbsy.nf+ll] + postequil*lbbdforce[ll];
          if(lbphi[il] != 12 && lbphi[il] != 13)
            fSiteFluidCollisionBGKSwiftOneFluid(&lbf[il*lbsitelength], sitespeed, &lbft[4*il], interforce, T);
          fSiteSoluteCollisionBGK(&lbf[il*lbsitelength + lbsy.nf], sitespeed);
          fSiteThermalCollisionBGK(&lbf[il*lbsitelength + lbsy.nf+lbsy.nc], sitespeed);
        }
      }
    }
  }
  return 0;
}

int fCollisionBGKEDMSwift()
{
  long il;
  long Tmax = lbdm.touter;

  if(lbsy.nf>1) {

   #pragma omp parallel
   {
      double interforce_local_t[3], sitespeed_local_t[3];
      double *interforce = &interforce_local_t[0];
      double *sitespeed = &sitespeed_local_t[0];

      #pragma omp for
      for(il=0; il<Tmax; il++) {
        fGetOneSpeedSite(sitespeed, &lbf[il*lbsitelength]);
        double T = (lbsy.nt>0)?fGetTemperatureSite(il):lbsyst;
        double frac = fGetFracSwiftSite(0, &lbf[il*lbsitelength]);
        if(lbneigh[il]>0 && lbphi[il]==0) {
          sitespeed[0] = 0.0; sitespeed[1] = 0.0; sitespeed[2] = 0.0;
        }
        if(lbphi[il] != 11) {
          for(int ll=0; ll<3; ll++)
            interforce [ll] = frac*(lbinterforce[il*3*lbsy.nf+ll] + postequil*lbbdforce[ll]) + (1.0-frac)*(lbinterforce[il*3*lbsy.nf+3+ll] + postequil*lbbdforce[3+ll]);
          if(lbphi[il] != 12 && lbphi[il] != 13)
            fSiteFluidCollisionBGKEDMSwiftTwoFluid(&lbf[il*lbsitelength], sitespeed, &lbft[8*il], interforce, T);
          fSiteSoluteCollisionBGK(&lbf[il*lbsitelength + lbsy.nf], sitespeed);
          fSiteThermalCollisionBGK(&lbf[il*lbsitelength + lbsy.nf+lbsy.nc], sitespeed);
        }
      }
    }
  }
  else {
      
   #pragma omp parallel
   {
      double interforce_local_t[3], sitespeed_local_t[3];
      double *interforce = &interforce_local_t[0];
      double *sitespeed = &sitespeed_local_t[0];

      #pragma omp for
      for(il=0; il<Tmax; il++) {
        fGetOneSpeedSite(sitespeed, &lbf[il*lbsitelength]);
        double T = (lbsy.nt>0)?fGetTemperatureSite(il):lbsyst;
        if(lbneigh[il]>0 && lbphi[il]==0) {
          sitespeed[0] = 0.0; sitespeed[1] = 0.0; sitespeed[2] = 0.0;
        }
        if(lbphi[il] != 11) {
          for(int ll=0; ll<3; ll++)
            interforce [ll] = lbinterforce[il*3*lbsy.nf+ll] + postequil*lbbdforce[ll];
          if(lbphi[il] != 12 && lbphi[il] != 13)
            fSiteFluidCollisionBGKEDMSwiftOneFluid(&lbf[il*lbsitelength], sitespeed, &lbft[4*il], interforce, T);
          fSiteSoluteCollisionBGK(&lbf[il*lbsitelength + lbsy.nf], sitespeed);
          fSiteThermalCollisionBGK(&lbf[il*lbsitelength + lbsy.nf+lbsy.nc], sitespeed);
        }
      }
    }
  }
  return 0;
}

int fCollisionBGKGuoSwift()
{
  long il;
  int Tmax = lbdm.touter;

  if(lbsy.nf>1) {

   #pragma omp parallel
   {
      double interforce_local_t[3], sitespeed_local_t[3];
      double *interforce = &interforce_local_t[0];
      double *sitespeed = &sitespeed_local_t[0];

      #pragma omp for
      for(il=0; il<Tmax; il++) {
        fGetOneSpeedSite(sitespeed, &lbf[il*lbsitelength]);
        double T = (lbsy.nt>0)?fGetTemperatureSite(il):lbsyst;
        double frac = fGetFracSwiftSite(0, &lbf[il*lbsitelength]);
        if(lbneigh[il]>0 && lbphi[il]==0) {
          sitespeed[0] = 0.0; sitespeed[1] = 0.0; sitespeed[2] = 0.0;
        }
        if(lbphi[il] != 11) {
          for(int ll=0; ll<3; ll++)
            interforce [ll] = frac*(lbinterforce[il*3*lbsy.nf+ll] + postequil*lbbdforce[ll]) + (1.0-frac)*(lbinterforce[il*3*lbsy.nf+3+ll] + postequil*lbbdforce[3+ll]);
          if(lbphi[il] != 12 && lbphi[il] != 13)
            fSiteFluidCollisionBGKGuoSwiftTwoFluid(&lbf[il*lbsitelength], sitespeed, &lbft[8*il], interforce, T);
          fSiteSoluteCollisionBGK(&lbf[il*lbsitelength + lbsy.nf], sitespeed);
          fSiteThermalCollisionBGK(&lbf[il*lbsitelength + lbsy.nf+lbsy.nc], sitespeed);
        }
      }
    }
  }
  else {
      
   #pragma omp parallel
   {
      double interforce_local_t[3], sitespeed_local_t[3];
      double *interforce = &interforce_local_t[0];
      double *sitespeed = &sitespeed_local_t[0];

      #pragma omp for
      for(il=0; il<Tmax; il++) {
        fGetOneSpeedSite(sitespeed, &lbf[il*lbsitelength]);
        double T = (lbsy.nt>0)?fGetTemperatureSite(il):lbsyst;
        if(lbneigh[il]>0 && lbphi[il]==0) {
          sitespeed[0] = 0.0; sitespeed[1] = 0.0; sitespeed[2] = 0.0;
        }
        if(lbphi[il] != 11) {
          for(int ll=0; ll<3; ll++)
            interforce [ll] = lbinterforce[il*3*lbsy.nf+ll] + postequil*lbbdforce[ll];
          if(lbphi[il] != 12 && lbphi[il] != 13)
            fSiteFluidCollisionBGKGuoSwiftOneFluid(&lbf[il*lbsitelength], sitespeed, &lbft[4*il], interforce, T);
          fSiteSoluteCollisionBGK(&lbf[il*lbsitelength + lbsy.nf], sitespeed);
          fSiteThermalCollisionBGK(&lbf[il*lbsitelength + lbsy.nf+lbsy.nc], sitespeed);
        }
      }
    }
  }
  return 0;
}


