/***********************************************
 *   DL_MESO       Version 2.6                 *
 *   Authors   :   R. S. Qin, M. A. Seaton     *
 *   Amended   :   L. Grinberg                 *
 *   Copyright :   STFC Daresbury Laboratory   *
 *             :   22/10/2015                  *
 ***********************************************/

inline void fWeakMemory() 
{ 
  cout << "error: cannot allocate more memory" << endl;
  exit(1);
  return;
}

int fMemoryAllocation()
{

  // allocate memory for lattice Boltzmann calculation

  unsigned long dim = lbsitelength * lbdm.touter;
  unsigned long dim1 = lbsy.nf + lbsy.nc + lbsy.nt;
  unsigned long dim2 = 3 * lbsy.nf * (lbsy.nf-1) / 2;
  unsigned long dim3 = 4 * lbsy.nf;

  long i;
  unsigned long dimmax, j;
  int ii,jj,kk;

  if(dim != 0) {
    lbf = new double[dim];  
    if(lbf == NULL) fWeakMemory();
    for(j=0; j<dim; j++)
      lbf[j] = 0.0;
  }

  dimmax = dim1;
  if (interact==3 || interact==4)
    dimmax = fCppMax (dim1, dim2);
  if (interact==5)
    dimmax = fCppMax (dim1, dim3);

  if(lbdm.touter * dimmax != 0) {
    lbft = new double[lbdm.touter * dimmax];
    if(lbft == NULL) fWeakMemory();
    for(i=0; i< lbdm.touter * dimmax; i++)
      lbft[i] = 0.0;
  }

  if(lbsy.nq != 0) {
    lbfeq = new double[lbsy.nf*lbsy.nq];
    if(lbfeq == NULL) fWeakMemory();
    for(i=0; i< lbsy.nf*lbsy.nq; i++)
      lbfeq[i] = 0.0;
  }

  if(lbdm.touter != 0) {
    lbphi = new int[lbdm.touter];
    if(lbphi == NULL) fWeakMemory();
    for(i=0; i< lbdm.touter; i++)
      lbphi[i] = 0;
  }

  if(lbdm.touter != 0) {
    lbneigh = new int[lbdm.touter];
    if(lbneigh == NULL) fWeakMemory();
    for(i=0; i< lbdm.touter; i++)
      lbneigh[i] = 0;
  }

  if(lbsy.nq != 0) {
    lbw = new double[lbsy.nq];
    if(lbw == NULL) fWeakMemory();
    for(i=0; i< lbsy.nq; i++)
      lbw[i] = 0;
    lbwi = new double[lbsy.nq];
    if(lbwi == NULL) fWeakMemory();
    for(i=0; i< lbsy.nq; i++)
      lbwi[i] = 0;
    lbw0 = new double[lbsy.nq];
    if(lbw0 == NULL) fWeakMemory();
    for(i=0; i< lbsy.nq; i++)
      lbw0[i] = 0;
    lbwpt = new double[lbsy.nq];
    if(lbwpt == NULL) fWeakMemory();
    for(i=0; i< lbsy.nq; i++)
      lbwpt[i] = 0;
    lbwxx = new double[lbsy.nq];
    if(lbwxx == NULL) fWeakMemory();
    for(i=0; i< lbsy.nq; i++)
      lbwxx[i] = 0;
    lbwyy = new double[lbsy.nq];
    if(lbwyy == NULL) fWeakMemory();
    for(i=0; i< lbsy.nq; i++)
      lbwyy[i] = 0;
    lbwzz = new double[lbsy.nq];
    if(lbwzz == NULL) fWeakMemory();
    for(i=0; i< lbsy.nq; i++)
      lbwzz[i] = 0;
    lbwxy = new double[lbsy.nq];
    if(lbwxy == NULL) fWeakMemory();
    for(i=0; i< lbsy.nq; i++)
      lbwxy[i] = 0;
    lbwxz = new double[lbsy.nq];
    if(lbwxz == NULL) fWeakMemory();
    for(i=0; i< lbsy.nq; i++)
      lbwxz[i] = 0;
    lbwyz = new double[lbsy.nq];
    if(lbwyz == NULL) fWeakMemory();
    for(i=0; i< lbsy.nq; i++)
      lbwyz[i] = 0;
    lbwgam = new double[lbsy.nq];
    if(lbwgam == NULL) fWeakMemory();
    for(i=0; i< lbsy.nq; i++)
      lbwgam[i] = 0;
    lbwdel = new double[lbsy.nq];
    if(lbwdel == NULL) fWeakMemory();
    for(i=0; i< lbsy.nq; i++)
      lbwdel[i] = 0;
    lbvx = new int[lbsy.nq];
    lbvy = new int[lbsy.nq];
    lbvz = new int[lbsy.nq];
    if(lbvx == NULL) fWeakMemory();
    if(lbvy == NULL) fWeakMemory();
    if(lbvz == NULL) fWeakMemory();
    for(i=0; i<lbsy.nq; i++) {
      lbvx[i] = 0; lbvy[i] = 0; lbvz[i] = 0;
    }
    lbvwx = new double[lbsy.nq];
    lbvwy = new double[lbsy.nq];
    lbvwz = new double[lbsy.nq];
    if(lbvwx == NULL) fWeakMemory();
    if(lbvwy == NULL) fWeakMemory();
    if(lbvwz == NULL) fWeakMemory();
    for(i=0; i< lbsy.nq; i++) {
      lbvwx[i] = 0; lbvwy[i] = 0; lbvwz[i] = 0;
    }
  }

  if(lbsy.nq != 0) {
    lbopv = new int[lbsy.nq];
    if(lbopv == NULL) fWeakMemory();
    for(i=0; i< lbsy.nq; i++)
      lbopv[i] = 0;
  }

  if(lbsy.nq != 0) {
    lbtr = new double[lbsy.nq*lbsy.nq];
    if(lbtr == NULL) fWeakMemory();
    for(i=0; i<lbsy.nq*lbsy.nq; i++)
      lbtr[i] = 0;
  }

  if(lbsy.nq != 0) {
    lbtrinv = new double[lbsy.nq*lbsy.nq];
    if(lbtrinv == NULL) fWeakMemory();
    for(i=0; i<lbsy.nf*lbsy.nq; i++)
      lbtrinv[i] = 0;
  }

  if(lbsy.nf != 0) {
    lbtf = new double[lbsy.nf];
    if(lbtf == NULL) fWeakMemory();
    for(i=0; i< lbsy.nf; i++)
      lbtf[i] = 0;
  }

  if(lbsy.nf != 0) {
    lbtfbulk = new double[lbsy.nf];
    if(lbtfbulk == NULL) fWeakMemory();
    for(i=0; i< lbsy.nf; i++)
      lbtfbulk[i] = 0;
  }

  if(lbsy.nf != 0) {
    lbbdforce = new double[3 * lbsy.nf];
    if(lbbdforce == NULL) fWeakMemory();
    for(i=0; i< 3 * lbsy.nf; i++)
      lbbdforce[i] = 0;
  }

  if(lbsy.nf != 0) {
    lbbousforce = new double[3 * lbsy.nf];
    if(lbbousforce == NULL) fWeakMemory();
    for(i=0; i< 3 * lbsy.nf; i++)
      lbbousforce[i] = 0;
  }

  if(lbsy.nf != 0) {
    lbinterforce = new double[3 * lbsy.nf * lbdm.touter];
    if( lbinterforce== NULL) fWeakMemory();
    for(i=0; i< 3 * lbsy.nf * lbdm.touter; i++)
      lbinterforce[i] = 0;
  }


  if(lbsy.nc != 0) {
    lbtc = new double[lbsy.nc];
    if(lbtc == NULL) fWeakMemory();
    for(i=0; i< lbsy.nc; i++)
      lbtc[i] = 0;
  }

  if(lbsy.nt != 0) {
    lbtt = new double[lbsy.nt];
    if(lbtt == NULL) fWeakMemory();
    for(i=0; i< lbsy.nt; i++)
      lbtt[i] = 0;
  }

  if(lbsy.nf != 0) {
    lbscpot = new int[lbsy.nf];
    if(lbscpot == NULL)  fWeakMemory();
    for(i=0; i< lbsy.nf; i++)
      lbscpot[i] = 0;
  }

  if(lbsy.nf != 0) {
    lbwet = new int[lbsy.nf];
    if(lbwet == NULL)  fWeakMemory();
    for(i=0; i< lbsy.nf; i++)
      lbwet[i] = 0;
  }

  if(lbsy.nf != 0) {
    lbg = new double[lbsy.nf * lbsy.nf];
    if(lbg == NULL)  fWeakMemory();
    for(i=0; i< lbsy.nf * lbsy.nf; i++)
      lbg[i] = 0;
  }

  if(lbsy.nf != 0) {
    lbgwall = new double[lbsy.nf];
    if(lbgwall == NULL)  fWeakMemory();
    for(i=0; i< lbsy.nf; i++)
      lbgwall[i] = 0;
  }

  if(lbsy.nf != 0) {
    lbseg = new double[lbsy.nf * lbsy.nf];
    if(lbseg == NULL)  fWeakMemory();
    for(i=0; i< lbsy.nf * lbsy.nf; i++)
      lbseg[i] = 0;
  }

  if(lbsy.nf != 0) {
    lbpsi0 = new double[lbsy.nf];
    if(lbpsi0 == NULL)  fWeakMemory();
    for(i=0; i< lbsy.nf; i++)
      lbpsi0[i] = 0;
  }

  if(lbsy.nf != 0) {
    lbcritt = new double[lbsy.nf];
    if(lbcritt == NULL)  fWeakMemory();
    for(i=0; i< lbsy.nf; i++)
      lbcritt[i] = 0;
  }

  if(lbsy.nf != 0) {
    lbcritp = new double[lbsy.nf];
    if(lbcritp == NULL)  fWeakMemory();
    for(i=0; i< lbsy.nf; i++)
      lbcritp[i] = 0;
  }

  if(lbsy.nf != 0) {
    lbeosa = new double[lbsy.nf];
    if(lbeosa == NULL)  fWeakMemory();
    for(i=0; i< lbsy.nf; i++)
      lbeosa[i] = 0;
  }
    
  if(lbsy.nf != 0) {
    lbeosb = new double[lbsy.nf];
    if(lbeosb == NULL)  fWeakMemory();
    for(i=0; i< lbsy.nf; i++)
      lbeosb[i] = 0;
  }
    
  if(lbsy.nf != 0) {
    lbacentric = new double[lbsy.nf];
    if(lbacentric == NULL)  fWeakMemory();
    for(i=0; i< lbsy.nf; i++)
      lbacentric[i] = 0;
  }
    
  if(lbsy.nf != 0) {
    lbscquad= new double[lbsy.nf*lbsy.nf];
    if(lbscquad == NULL)  fWeakMemory();
    for(i=0; i< lbsy.nf*lbsy.nf; i++)
      lbscquad[i] = 1.0;
  }
    
/*
  if(lbsy.nf != 0) {
    lbemradius = new double[lbsy.nf];
    if(lbemradius == NULL) fWeakMemory();
    for(i=0; i< lbsy.nf; i++)
      lbemradius[i] = 0;
  }

  if(lbsy.nf != 0) {
    lbemnumber = new int[lbsy.nf];
    if(lbemnumber == NULL)  fWeakMemory();
    for(i=0; i< lbsy.nf; i++)
      lbemnumber[i] = 0;
  }
*/

  if(lbsy.nf != 0) {
    lbincp = new double[lbsy.nf];
    if(lbincp == NULL)  fWeakMemory();
    for(i=0; i< lbsy.nf; i++)
      lbincp[i] = 0;
  }

  if(lbsy.nf != 0) {
    lbinip = new double[lbsy.nf];
    if(lbinip == NULL)  fWeakMemory();
    for(i=0; i< lbsy.nf; i++)
      lbinip[i] = 0;
  }

  if(lbsy.nf != 0) {
    lbtopp = new double[lbsy.nf];
    if(lbtopp == NULL) fWeakMemory();
    for(i=0; i< lbsy.nf; i++)
      lbtopp[i] = 0;
  }

  if(lbsy.nf != 0) {
    lbbotp = new double[lbsy.nf];
    if(lbbotp == NULL) fWeakMemory();
    for(i=0; i< lbsy.nf; i++)
      lbbotp[i] = 0;
  }

  if(lbsy.nf != 0) {
    lbfrop = new double[lbsy.nf];
    if(lbfrop == NULL) fWeakMemory();
    for(i=0; i< lbsy.nf; i++)
      lbfrop[i] = 0;
  }

  if(lbsy.nf != 0) {
    lbbacp = new double[lbsy.nf];
    if(lbbacp == NULL) fWeakMemory();
    for(i=0; i< lbsy.nf; i++)
      lbbacp[i] = 0;
  }

  if(lbsy.nf != 0) {
    lblefp = new double[lbsy.nf];
    if(lblefp == NULL) fWeakMemory();
    for(i=0; i< lbsy.nf; i++)
      lblefp[i] = 0;
  }

  if(lbsy.nf != 0) {
    lbrigp = new double[lbsy.nf];
    if(lbrigp == NULL) fWeakMemory();
    for(i=0; i< lbsy.nf; i++)
      lbrigp[i] = 0;
  }

/*
  if((lbsy.nf-1) != 0) {
    lbanifold = new int[(lbsy.nf * (lbsy.nf-1)) / 2];
    if(lbanifold == NULL) fWeakMemory();
    for(i=0; i< (lbsy.nf * (lbsy.nf-1)) / 2; i++)
      lbanifold[i] = 0;
  }

  if((lbsy.nf-1) != 0) {
    lbanitens = new double[(lbsy.nf * (lbsy.nf-1)) / 2];
    if(lbanitens == NULL) fWeakMemory();
    for(i=0; i< (lbsy.nf * (lbsy.nf-1)) / 2; i++)
      lbanitens[i] = 0;
  }
*/

  if(lbsy.nc != 0) {
    lbinic = new double[lbsy.nc];
    if(lbinic == NULL) fWeakMemory();
    for(i=0; i< lbsy.nc; i++)
      lbinic[i] = 0;
  }

  if(lbsy.nc != 0) {
    lbtopc = new double[lbsy.nc];
    if(lbtopc == NULL) fWeakMemory();
    for(i=0; i< lbsy.nc; i++)
      lbtopc[i] = 0;
  }

  if(lbsy.nc != 0) {
    lbbotc = new double[lbsy.nc];
    if(lbbotc == NULL) fWeakMemory();
    for(i=0; i< lbsy.nc; i++)
      lbbotc[i] = 0;
  }

  if(lbsy.nc != 0) {
    lbfroc = new double[lbsy.nc];
    if(lbfroc == NULL) fWeakMemory();
    for(i=0; i< lbsy.nc; i++)
      lbfroc[i] = 0;
  }

  if(lbsy.nc != 0) {
    lbbacc = new double[lbsy.nc];
    if(lbbacc == NULL) fWeakMemory();
    for(i=0; i< lbsy.nc; i++)
      lbbacc[i] = 0;
  }

  if(lbsy.nc != 0) {
    lblefc = new double[lbsy.nc];
    if(lblefc == NULL) fWeakMemory();
    for(i=0; i< lbsy.nc; i++)
      lblefc[i] = 0;
  }

  if(lbsy.nc != 0) {
    lbrigc = new double[lbsy.nc];
    if(lbrigc == NULL) fWeakMemory();
    for(i=0; i< lbsy.nc; i++)
      lbrigc[i] = 0;
  }

  // zero velocity arrays

  for(i=0; i<3; i++) {
    lbiniv[i] = 0;
    lbtopv[i] = 0;
    lbbotv[i] = 0;
    lbfrov[i] = 0;
    lbbacv[i] = 0;
    lblefv[i] = 0;
    lbrigv[i] = 0;
  }

  // zero free-energy template and wetting parameter arrays

    for(i=0; i<19; i++) {
      lbfevx[i] = 0;
      lbfevy[i] = 0;
      lbfevz[i] = 0;
    }
    for(i=0; i<4; i++) {
      lbfewet[i] = 0;
    }

  // set species pairs for Lishchuk interactions
    
  if(interact==3 || interact==4) {
    lbspair = new int[lbsy.nf*(lbsy.nf-1)];
    if(lbspair == NULL) fWeakMemory();
    kk = -1;
    for(ii=0;ii<lbsy.nf-1;ii++) {
      for(jj=ii+1;jj<lbsy.nf;jj++) {
        kk++;
        lbspair[2*kk  ] = ii;
        lbspair[2*kk+1] = jj;
      }
    }
  }

  return 0;

}


int fFreeMemory()
{
  
  // free all allocated memory
  
  delete [] lbf;  
  delete [] lbft;
  delete [] lbphi;
  delete [] lbw;
  delete [] lbwi;
  delete [] lbw0;
  delete [] lbwpt;
  delete [] lbwxx;
  delete [] lbwyy;
  delete [] lbwzz;
  delete [] lbwxy;
  delete [] lbwxz;
  delete [] lbwyz;
  delete [] lbwgam;
  delete [] lbwdel;
  delete [] lbtf;
  delete [] lbtfbulk;
  delete [] lbtc;
  delete [] lbg;
  delete [] lbgwall;
  delete [] lbvx;
  delete [] lbvy;
  delete [] lbvz;
  delete [] lbvwx;
  delete [] lbvwy;
  delete [] lbvwz;
  delete [] lbopv;
  delete [] lbtr;
  delete [] lbtrinv;
  delete [] lbfeq;
//  delete [] lbemnumber;
//  delete [] lbemradius;
//  delete [] lbanitens;
//  delete [] lbanifold;
  delete [] lbinic;
  delete [] lbtopc;
  delete [] lbbotc;
  delete [] lbfroc;
  delete [] lbbacc;
  delete [] lblefc;
  delete [] lbrigc;
  delete [] lbincp;
  delete [] lbinip;
  delete [] lbtopp;
  delete [] lbbotp;
  delete [] lbfrop;
  delete [] lbbacp;
  delete [] lblefp;
  delete [] lbrigp;
  delete [] lbbdforce;
  delete [] lbbousforce;
  delete [] lbouter;

  return 0;
  
}

int fSetSerialDomain()
{
  int ii,jj,kk;
  lbdm.rank = 0;
  lbdm.size = 0;
  lbdm.xs = 0;
  lbdm.ys = 0;
  lbdm.xe = lbsy.nx;
  lbdm.ye = lbsy.ny;
  lbdm.zs = 0;
  lbdm.ze = lbsy.nz;
  lbdm.xinner = lbsy.nx;
  lbdm.yinner = lbsy.ny;
  lbdm.zinner = lbsy.nz;
  lbdm.xouter = lbsy.nx;
  lbdm.youter = lbsy.ny;
  lbdm.zouter = lbsy.nz;
  lbdm.xcor=0;
  lbdm.ycor=0;
  lbdm.zcor=0;
  lbdm.xdim=1;
  lbdm.ydim=1;
  lbdm.zdim=1;
  lbdm.touter = lbdm.xouter * lbdm.youter * lbdm.zouter;
  lbdm.owidx = lbdm.bwid;
  lbdm.owidy = lbdm.bwid;
  lbdm.owidz = lbdm.bwid;
  if (lbdm.owidx<1)
    lbdm.owidx = 1;
  if (lbdm.owidy<1)
    lbdm.owidy = 1;
  if (lbdm.owidz<1)
    lbdm.owidz = 1;
  lbdm.bwid = 0;
  if(lbsy.nd == 2) {
    lbdm.zs = 0;
    lbdm.ze = 1;
    lbdm.zinner = 1;
    lbdm.zouter = 1;
    lbdm.touter = lbdm.xouter * lbdm.youter;
    lbdm.owidz = 0;
  }
  // set grid boundary regions
  lboutersize = 0;
  ii = 2*lbdm.xouter*lbdm.youter*lbdm.owidz +
       2*lbdm.xouter*(lbdm.zouter-2*lbdm.owidz)*lbdm.owidy +
       2*(lbdm.youter-2*lbdm.owidy)*(lbdm.zouter-2*lbdm.owidz)*lbdm.owidx;
  lbouter = new unsigned long[4*ii];
  for(ii=0; ii<lbdm.xouter; ii++) {
    for(jj=0; jj<lbdm.youter; jj++) {
      for(kk=0; kk<lbdm.zouter; kk++) {
        if ((ii<lbdm.owidx) || (jj<lbdm.owidy) || (kk<lbdm.owidz) || (ii>=(lbdm.xouter-lbdm.owidx)) ||
            (jj>=(lbdm.youter-lbdm.owidy)) || (kk>=(lbdm.zouter-lbdm.owidz))) {
          lbouter[4*lboutersize  ] = (unsigned long) ((ii*lbdm.youter+jj)*lbdm.zouter+kk);
          lbouter[4*lboutersize+1] = (unsigned long) ii;
          lbouter[4*lboutersize+2] = (unsigned long) jj;
          lbouter[4*lboutersize+3] = (unsigned long) kk;
          lboutersize++;
        }
      }
    }
  }
  return 0;
}

int fSetSerialDomainBuffer()
{
  int ii,jj,kk;
  lbdm.rank = 0;
  lbdm.size = 0;
  lbdm.xs = 0;
  lbdm.ys = 0;
  lbdm.xe = lbsy.nx;
  lbdm.ye = lbsy.ny;
  lbdm.zs = 0;
  lbdm.ze = lbsy.nz;
  lbdm.xinner = lbsy.nx;
  lbdm.yinner = lbsy.ny;
  lbdm.zinner = lbsy.nz;
  lbdm.xouter = lbsy.nx + 2*lbdm.bwid;
  lbdm.youter = lbsy.ny + 2*lbdm.bwid;
  lbdm.zouter = lbsy.nz + 2*lbdm.bwid;
  lbdm.xcor=0;
  lbdm.ycor=0;
  lbdm.zcor=0;
  lbdm.xdim=1;
  lbdm.ydim=1;
  lbdm.zdim=1;
  lbdm.touter = lbdm.xouter * lbdm.youter * lbdm.zouter;
  lbdm.owidx = lbdm.bwid;
  lbdm.owidy = lbdm.bwid;
  lbdm.owidz = lbdm.bwid;
  if (lbdm.owidx<1)
    lbdm.owidx = 1;
  if (lbdm.owidy<1)
    lbdm.owidy = 1;
  if (lbdm.owidz<1)
    lbdm.owidz = 1;
  if(lbsy.nd == 2) {
    lbdm.zs = 0;
    lbdm.ze = 1;
    lbdm.zinner = 1;
    lbdm.zouter = 1;
    lbdm.touter = lbdm.xouter * lbdm.youter;
    lbdm.owidz = 0;
  }
  // set grid boundary regions
  lboutersize = 0;
  ii = 2*lbdm.xouter*lbdm.youter*lbdm.owidz +
       2*lbdm.xouter*(lbdm.zouter-2*lbdm.owidz)*lbdm.owidy +
       2*(lbdm.youter-2*lbdm.owidy)*(lbdm.zouter-2*lbdm.owidz)*lbdm.owidx;
  lbouter = new unsigned long[4*ii];
  for(ii=0; ii<lbdm.xouter; ii++) {
    for(jj=0; jj<lbdm.youter; jj++) {
      for(kk=0; kk<lbdm.zouter; kk++) {
        if ((ii<lbdm.owidx) || (jj<lbdm.owidy) || (kk<lbdm.owidz) || (ii>=(lbdm.xouter-lbdm.owidx)) ||
            (jj>=(lbdm.youter-lbdm.owidy)) || (kk>=(lbdm.zouter-lbdm.owidz))) {
          lbouter[4*lboutersize  ] = (unsigned long) ((ii*lbdm.youter+jj)*lbdm.zouter+kk);
          lbouter[4*lboutersize+1] = (unsigned long) ii;
          lbouter[4*lboutersize+2] = (unsigned long) jj;
          lbouter[4*lboutersize+3] = (unsigned long) kk;
          lboutersize++;
        }
      }
    }
  }
  return 0;
}

int fStartDLMESO()
{
  
  if(lbdm.rank == 0) {
    cout << endl;
    cout << "Welcome to DL_MESO_LBE" << endl << endl;
    cout << "STFC/CCP5 Program Library Package" << endl;
    cout << "STFC Daresbury Laboratory Lattice Boltzmann Equation program" << endl << endl;
    cout << "DL_MESO version 2.6, November 2015" << endl;
    cout << "Authors: R. S. Qin & M. A. Seaton" << endl;
    cout << "Copyright (c) 2015 STFC Daresbury Laboratory, United Kingdom" << endl << endl;
    cout << "Any comments or queries, please contact Dr. M. A. Seaton at:" << endl;
    cout << "   Email: michael.seaton@stfc.ac.uk" << endl;
    cout << "   Tel:   +44 (0)1925 603317" << endl << endl;
    time_t starttime;
    struct tm * timeinfo;
    time ( &starttime);
    timeinfo = localtime ( &starttime );
    cout << "Program started at: " << asctime (timeinfo) << endl;
  }
  
  return 0;
}


int fFinishDLMESO()
{
  time_t endtime;
  struct tm * timeinfo;
  time ( &endtime);
  timeinfo = localtime ( &endtime );
  if(lbdm.rank == 0) {
    cout << "Calculation time elapsed: " << timetotal << " seconds" << endl;
    cout << "Efficiency measure: " << (0.000001*lbtotstep*(lbsy.nf+lbsy.nc+lbsy.nt)*lbsy.nx*lbsy.ny*lbsy.nz/timetotal) 
         << " MLUPS" << endl;
    cout << "Program finished at: " << asctime (timeinfo) << endl << endl;
    cout << "Many thanks for using DL_MESO_LBE in your work. Please acknowledge" << endl;
    cout << "our efforts by including one of the following references when"<<endl;
    cout << "publishing data obtained using DL_MESO_LBE:" << endl << endl;
    cout << "   M. A. Seaton, R. L. Anderson, S. Metz and W. Smith, \"DL_MESO:" << endl;
    cout << "   highly scalable mesoscale simulations\", Mol. Sim. 39 (10), 796-821" << endl;
    cout << "   (2013), doi:10.1080/08927022.2013.772297" << endl << endl;
    cout << "   M. A. Seaton, \"The DL_MESO Mesoscale Simulation Package\", STFC" << endl;
    cout << "   Scientific Computing Department (2012), www.ccp5.ac.uk/DL_MESO" << endl << endl << endl;
  }

  return 0;

}


int fsPrintDomainInfo()
{

  // print domain information (serial version: prints number of threads if using OpenMP)

  int nthreads=1;

#ifdef _OPENMP
  #pragma omp parallel
  {
    #pragma omp single
    {
      nthreads = omp_get_num_threads();
      cout << "Running with " << nthreads << " threads" << endl;
    }
  }
#endif

  return 0;
}


int fGetModel()
{

  // initialize vectors (lbvx, lbvy, lbvz), weights (lbw), conjugate links (lbopv) etc.

  if(lbsy.nq == 9) 
    D2Q9();

  else if(lbsy.nq == 15)
    D3Q15();

  else if(lbsy.nq == 19)
    D3Q19(); 

  else if(lbsy.nq == 27)
    D3Q27();

  else 
    {
      if(lbdm.rank == 0) {
        cout << "error: the requested model is not available" << endl;
        }
      exit(1);
    }
    
  lbdx = lbsoundv * lbdt / lbcs;
  
  return 0;
  
}


int fMarkBoundArea3D()
{

  // denotes boundary areas for message passing:
  // only used with non-zero boundary layers (e.g. parallel calculations)

  long spos;
  for(int i=0; i<lbdm.bwid; i++)
    for(int j=0; j<lbdm.youter; j++)
      for(int k=0; k<lbdm.zouter; k++) {
	    spos = (i * lbdm.youter + j) * lbdm.zouter + k;
	    if(lbphi[spos] == 0)
	      lbphi[spos] = 10;
      }

  for(int i=lbdm.xouter-lbdm.bwid; i<lbdm.xouter; i++)
    for(int j=0; j<lbdm.youter; j++)
      for(int k=0; k<lbdm.zouter; k++) {
	    spos = (i * lbdm.youter + j) * lbdm.zouter + k;
	    if(lbphi[spos] == 0)
	      lbphi[spos] = 10;
      }

  for(int i=lbdm.bwid; i<lbdm.xouter-lbdm.bwid; i++)
    for(int j=0; j<lbdm.bwid; j++)
      for(int k=0; k<lbdm.zouter; k++){
	    spos = (i * lbdm.youter + j) * lbdm.zouter + k;
	    if(lbphi[spos] == 0)
	      lbphi[spos] = 10;
      }
    
  for(int i=lbdm.bwid; i<lbdm.xouter-lbdm.bwid; i++)
    for(int j=lbdm.youter-lbdm.bwid; j<lbdm.youter; j++)
      for(int k=0; k<lbdm.zouter; k++){
	    spos = (i * lbdm.youter + j) * lbdm.zouter + k;
	    if(lbphi[spos] == 0)
	      lbphi[spos] = 10;
      }

  for(int i=lbdm.bwid; i<lbdm.xouter-lbdm.bwid; i++)
    for(int j=lbdm.bwid; j<lbdm.youter-lbdm.bwid; j++)
      for(int k=0; k<lbdm.bwid; k++){
	    spos = (i * lbdm.youter + j) * lbdm.zouter + k;
	    if(lbphi[spos] == 0)
	      lbphi[spos] = 10;
      }

  for(int i=lbdm.bwid; i<lbdm.xouter-lbdm.bwid; i++)
    for(int j=lbdm.bwid; j<lbdm.youter-lbdm.bwid; j++)
      for(int k=lbdm.zouter-lbdm.bwid; k<lbdm.zouter; k++){
	    spos = (i * lbdm.youter + j) * lbdm.zouter + k;
	    if(lbphi[spos] == 0)
	      lbphi[spos] = 10;
      }
    
  return 0;	
}


int fMarkBoundArea2D()
{

  // denotes boundary areas for message passing:
  // only used with non-zero boundary layers (e.g. parallel calculations)

  long spos;
  for(int i=0; i<lbdm.bwid; i++)
    for(int j=0; j<lbdm.youter; j++) {
      spos = i * lbdm.youter + j;  
      if(lbphi[spos] == 0)
	    lbphi[spos] = 10;
      }

  for(int i=lbdm.xouter-lbdm.bwid; i<lbdm.xouter; i++)
    for(int j=0; j<lbdm.youter; j++) {
      spos = i * lbdm.youter + j;
      if(lbphi[spos] == 0)
	    lbphi[spos] = 10;
      }

  for(int i=lbdm.bwid; i<lbdm.xouter-lbdm.bwid; i++)
    for(int j=0; j<lbdm.bwid; j++) {
      spos = i * lbdm.youter + j;
      if(lbphi[spos] == 0)
	    lbphi[spos] = 10;
      }

  for(int i=lbdm.bwid; i<lbdm.xouter-lbdm.bwid; i++)
    for(int j=lbdm.youter-lbdm.bwid; j<lbdm.youter; j++) {
      spos = i * lbdm.youter + j;
      if(lbphi[spos] == 0)
	    lbphi[spos] = 10;
      }
    
  return 0;	
}


int fMarkBoundArea()
{

  if(lbsy.nd == 2)
    fMarkBoundArea2D();
  else
    fMarkBoundArea3D();
  return 0;
}


int fGetEquilibriumF(double *feq, double *v, double rho)
{

  // calculate equilibrium distribution function for compressible fluid:
  // only suitable for square lattices, not suitable for incompressible fluid

  double modv = v[0]*v[0] + v[1]*v[1] + v[2]*v[2];
  double uv;

  for(int i=0; i<lbsy.nq; i++)
    {
      uv = lbvx[i] * v[0] + lbvy[i] * v[1] + lbvz[i] * v[2];
      feq[i] = rho * lbw[i] * (1 + 3.0 * uv + 4.5 * uv * uv - 1.5 * modv);
    }
  
  return 0;
}


int fGetEquilibriumFIncom(double *feq, double *v, double rho, double rho0)
{

  // calculate equilibrium distribution function for incompressible fluid:
  // only suitable for square lattices

  double modv = v[0]*v[0] + v[1]*v[1] + v[2]*v[2];
  double uv;
  
  for(int i=0; i<lbsy.nq; i++)
    {
      uv = lbvx[i] * v[0] + lbvy[i] * v[1] + lbvz[i] * v[2];
      feq[i] = lbw[i] * (rho + rho0 * (3.0 * uv + 4.5 * uv * uv - 1.5 * modv));
    }
  
  return 0;
}


int fGetEquilibriumFSwiftOneFluid(double *feq, double *v, double rho, double p0, double lambda, double *delta)
{

  // calculate equilibrium distribution function for one compressible fluid
  // using Swift Free Energy approach: only suitable for square lattices,
  // not suitable for incompressible fluid

  double modv = v[0]*v[0] + v[1]*v[1] + v[2]*v[2];
  double uv,udr,edr,ee;
  double drdx = delta[0];
  double drdy = delta[1];
  double drdz = delta[2];
  double nabr = delta[3];

  for(int i=0; i<lbsy.nq; i++)
    {
      uv = lbvx[i] * v[0] + lbvy[i] * v[1] + lbvz[i] * v[2];
      edr = lbvx[i] * drdx + lbvy[i] * drdy + lbvz[i] * drdz;
      udr = drdx * v[0] + drdy * v[1] + drdz * v[2];
      ee = lbvx[i] * lbvx[i] + lbvy[i] * lbvy[i] + lbvz[i] * lbvz[i];
      feq[i] = rho * lbw0[i] + lbwi[i] * (rho * (uv + 1.5 * uv * uv - 0.5 * modv) + lambda * (3.0 * uv * edr + (lbwgam[i] * ee + lbwdel[i]) * udr))
             + lbwpt[i] * (p0 - lbkappa * rho * nabr)
             + lbkappa * (lbwxx[i]*drdx*drdx + lbwyy[i]*drdy*drdy + lbwzz[i]*drdz*drdz + lbwxy[i]*drdx*drdy + lbwxz[i]*drdx*drdz + lbwyz[i]*drdy*drdz);
    }
  
  return 0;
}


int fGetEquilibriumFSwiftTwoFluid(double *feq, double *v, double rho, double phi, double p0, double pot, double lambda, double *delta)
{

  // calculate equilibrium distribution function for two compressible fluids
  // using Swift Free Energy approach: only suitable for square lattices,
  // not suitable for incompressible fluids

  double modv = v[0]*v[0] + v[1]*v[1] + v[2]*v[2];
  double uv,udr,edr,ee;
  double drdx = (lbfeeos>0)?delta[0]:0.0;
  double drdy = (lbfeeos>0)?delta[1]:0.0;
  double drdz = (lbfeeos>0)?delta[2]:0.0;
  double nabr = (lbfeeos>0)?delta[3]:0.0;
  double dfdx = delta[4];
  double dfdy = delta[5];
  double dfdz = delta[6];
  double nabf = delta[7];

  for(int i=0; i<lbsy.nq; i++)
    {
      uv = lbvx[i] * v[0] + lbvy[i] * v[1] + lbvz[i] * v[2];
      edr = lbvx[i] * drdx + lbvy[i] * drdy + lbvz[i] * drdz;
      udr = drdx * v[0] + drdy * v[1] + drdz * v[2];
      ee = lbvx[i] * lbvx[i] + lbvy[i] * lbvy[i] + lbvz[i] * lbvz[i];
      feq[2*i  ] = rho * lbw0[i] + lbwi[i] * (rho * (uv + 1.5 * uv * uv - 0.5 * modv) + lambda * (3.0 * uv * edr + (lbwgam[i] * ee + lbwdel[i]) * udr))
                 + lbwpt[i] * (p0 - lbkappa * (rho * nabr + phi * nabf))
                 + lbkappa * (lbwxx[i]*(drdx*drdx+dfdx*dfdx) + lbwyy[i]*(drdy*drdy+dfdy*dfdy) + lbwzz[i]*(drdz*drdz+dfdz*dfdz)
                            + lbwxy[i]*(drdx*drdy+dfdx*dfdy) + lbwxz[i]*(drdx*drdz+dfdx*dfdz) + lbwyz[i]*(drdy*drdz+dfdy*dfdz));
      feq[2*i+1] = lbfemob * pot * lbwpt[i] + phi * (lbw0[i] + lbwi[i] * (uv + 1.5 * uv * uv - 0.5 * modv));
    }
  
  return 0;
}

double fGetBulkPressureSwift(double rho, double phi, double T)
{
  // calculate bulk pressure term for Swift free-energy fluids
  // (equation of state)

  double p0;
  double R = lbgasconst;
  double Tr, m, pstar, rho0, psi0, a, b, p;
  
  p0 = 0.0;
  switch(lbfeeos) {
    case 0:
      // Ideal lattice gas: P = rho*c_s^2
      p0 = rho*lbcssq;
      break;
    case 1:
      // Shan-Chen model (1993)
      rho0 = lbincp[0];
      a = lbeosa[0]*lbcssq*rho0*rho0;
      psi0 = 1.0 - exp(-rho*fReciprocal(rho0));
      p0 = rho*lbcssq + 0.5*a*psi0*psi0;
      break;
    case 2:
      // Shan-Chen model (1994)
      rho0 = lbincp[0];
      psi0 = lbeosb[0]*exp(-rho0*fReciprocal(rho));
      p0 = rho*lbcssq + 0.5*lbeosa[0]*lbcssq*psi0*psi0;
      break;
    case 3:
      // Quadratic equation of state (psi = rho)
      a = lbeosa[0]*lbcssq;
      p0 = rho*(lbcssq + 0.5*a*rho);
      break;
    case 4:
      // Ideal gas: P = rho*RT
      p0 = rho*R*T;
      break;
    case 5:
      // van der Waals (1873): P = rho*RT/(1-b*rho) - a*rho*rho
      a = lbeosa[0];
      b = lbeosb[0];
      p0 = rho*R*T*fReciprocal(1.0-b*rho)-a*rho*rho;
      break;
    case 6:
      // Carnahan-Starling-van der Waals (1972): P = rho*RT*(1+phi+phi^2-phi^3)/((1-phi)^3) - a*rho*rho
      a = lbeosa[0];
      p = 0.25*rho*lbeosb[0];
      psi0 = fReciprocal(1.0-p);
      p0 = rho*R*T*(1.0+p*(1.0+p*(1.0-p)))*psi0*psi0*psi0-a*rho*rho;
      break;
    case 7:
      // Redlich-Kwong (1949): P = rho*RT/(1-b*rho) - a*rho*rho/(sqrt(T)*(1+b*rho)) (constant system temperature)
      a = lbeosa[0];
      b = lbeosb[0];
      p0 = rho*R*T*fReciprocal(1.0-b*rho)-a*rho*rho*fReciprocal(1.0+b*rho);
      break;
    case 8:
      // Redlich-Kwong (1949): P = rho*RT/(1-b*rho) - a*rho*rho/(sqrt(T)*(1+b*rho)) (variable system temperature)
      a = lbeosa[0]*fReciprocal(sqrt(T));
      b = lbeosb[0];
      p0 = rho*R*T*fReciprocal(1.0-b*rho)-a*rho*rho*fReciprocal(1.0+b*rho);
      break;
    case 9:
      // Soave-Redlich-Kwong (1972): P = rho*RT/(1-b*rho) - a*alpha*rho*rho/(1+b*rho) (constant system temperature)
      a = lbeosa[0];
      b = lbeosb[0];
      p0 = rho*R*T*fReciprocal(1.0-b*rho)-a*rho*rho*fReciprocal(1.0+b*rho);
      break;
    case 10:
      // Soave-Redlich-Kwong (1972): P = rho*RT/(1-b*rho) - a*alpha*rho*rho/(1+b*rho) (variable system temperature)
      Tr = T * fReciprocal(lbcritt[0]);
      m = (1.0 + (0.480 + lbacentric[0] * (1.574  - 0.176 * lbacentric[0])) * (1.0 - sqrt(Tr)));
      a = lbeosa[0]*m*m;
      b = lbeosb[0];
      p0 = rho*R*T*fReciprocal(1.0-b*rho)-a*rho*rho*fReciprocal(1.0+b*rho);
      break;
    case 11:
      // Peng-Robinson (1976): P = rho*RT/(1-b*rho) - a*alpha*rho*rho/(1+2*b*rho-b*b*rho*rho) (constant system temperature)
      a = lbeosa[0];
      b = lbeosb[0];
      p0 = rho*R*T*fReciprocal(1.0-b*rho)-a*rho*rho*fReciprocal(1.0+b*rho*(2.0-b*rho));
      break;
    case 12:
      // Peng-Robinson (1976): P = rho*RT/(1-b*rho) - a*alpha*rho*rho/(1+2*b*rho-b*b*rho*rho) (variable system temperature)
      Tr = T * fReciprocal(lbcritt[0]);
      m = (1.0 + (0.37464 + lbacentric[0] * (1.54226  - 0.26992 * lbacentric[0])) * (1.0 - sqrt(Tr)));
      a = lbeosa[0]*m*m;
      b = lbeosb[0];
      p0 = rho*R*T*fReciprocal(1.0-b*rho)-a*rho*rho*fReciprocal(1.0+b*rho*(2.0-b*rho));
      break;
    case 13:
     // Carnahan-Starling-Redlich-Kwong (1972): P = rho*RT*(1+phi+phi^2-phi^3)/((1-phi)^3) - a*rho*rho/(sqrt(T)*(1+b*rho)) (constant system temperature)
      a = lbeosa[0];
      b = lbeosb[0];
      p = 0.25*rho*b;
      psi0 = fReciprocal(1.0-p);
      p0 = rho*R*T*(1.0+p*(1.0+p*(1.0-p)))*psi0*psi0*psi0-a*rho*rho*fReciprocal(1.0+b*rho);
      break;
    case 14:
     // Carnahan-Starling-Redlich-Kwong (1972): P = rho*RT*(1+phi+phi^2-phi^3)/((1-phi)^3) - a*rho*rho/(sqrt(T)*(1+b*rho)) (variable system temperature)
      a = lbeosa[0]*fReciprocal(sqrt(T));
      b = lbeosb[0];
      p = 0.25*rho*b;
      psi0 = fReciprocal(1.0-p);
      p0 = rho*R*T*(1.0+p*(1.0+p*(1.0-p)))*psi0*psi0*psi0-a*rho*rho*fReciprocal(1.0+b*rho);
      break;
  }
  switch(lbfepot) {
    case 0:
      // No concentration terms
      break;
    case 1:
      // Quartic terms: P_mix = a*(-0.5*phi^2+0.75*phi^4)
      a = lbeosa[1];
      p0 += a*phi*phi*(-0.5+0.75*phi*phi);
      break;
  }
  return p0;
}

double fGetPotentialSwift(double phi, double d2phi)
{
  double pot;
  double a,b;
  pot = 0.0;
  switch(lbfepot) {
    case 0:
      // No concentration terms
      break;
    case 1:
      // Quartic terms: mu = a*phi+b*phi^3
      a = lbeosa[1];
      pot = a*phi*(-1.0+phi*phi);
      break;
  }
  return (pot-lbkappa*d2phi);
}

double fGetLambdaSwift(double rho, double omega, double T)
{
  // calculate Galilean invariance correction factor for fluid
  // (depends on equation of state)

  double lambda;
  double R = lbgasconst;
  double Tr, m, pstar, rho0, psi0, a, b, phi;

  lambda = 0.0;
  switch(lbfeeos) {
    case 0:
      // Ideal lattice gas: P = rho*c_s^2
      lambda = 0.0;
      break;
    case 1:
      // Shan-Chen model (1993)
      rho0 = lbincp[0];
      a = lbeosa[0]*lbcssq*rho0;
      psi0 = exp(-rho*fReciprocal(rho0));
      lambda = -(1.0/omega-0.5)*a*psi0*(1.0-psi0);
      break;
    case 2:
      // Shan-Chen model (1994)
      rho0 = lbincp[0];
      psi0 = lbeosb[0];
      a = lbeosa[0]*lbcssq*psi0*psi0;
      lambda = (1.0/omega-0.5)*a*rho0*fReciprocal(rho)*exp(-2.0*rho0*fReciprocal(rho));
      break;
    case 3:
      // Quadratic equation of state (psi = rho)
      a = lbeosa[0]*lbcssq;
      lambda = -(1.0/omega-0.5) * a*rho;
      break;
    case 4:
      // Ideal gas: P = rho*RT
      lambda = (1.0/omega-0.5) * (lbrcssq - R*T);
      break;
    case 5:
      // van der Waals (1873): P = rho*RT/(1-b*rho) - a*rho*rho
      a = lbeosa[0];
      b = lbeosb[0];
      lambda = (1.0/omega-0.5) * (lbrcssq - R*T*fReciprocal((1.0-b*rho)*(1.0-b*rho)) + 2.0*a*rho);
      break;
    case 6:
      // Carnahan-Starling-van der Waals (1972): P = rho*RT*(1+phi+phi^2-phi^3)/((1-phi)^3) - a*rho*rho
      a = lbeosa[0];
      phi = 0.25*rho*lbeosb[0];
      psi0 = fReciprocal((1.0-phi)*(1.0-phi));
      lambda = (1.0/omega-0.5) * (lbrcssq - R*T*(1.0+phi*(4.0+phi*(4.0+phi*(-4.0+phi))))*psi0*psi0 + 2.0*a*rho);
      break;
    case 7:
      // Redlich-Kwong (1949): P = rho*RT/(1-b*rho) - a*rho*rho/(sqrt(T)*(1+b*rho)) (constant system temperature)
      a = lbeosa[0];
      b = lbeosb[0];
      lambda = (1.0/omega-0.5) * (lbrcssq - R*T*fReciprocal(1.0+b*rho*(b*rho-2.0)) + a*rho*(2.0+b*rho)*fReciprocal(1.0+b*rho*(2.0+b*rho)));
      break;
    case 8:
      // Redlich-Kwong (1949): P = rho*RT/(1-b*rho) - a*rho*rho/(sqrt(T)*(1+b*rho)) (variable system temperature)
      a = lbeosa[0]*fReciprocal(sqrt(T));
      b = lbeosb[0];
      lambda = (1.0/omega-0.5) * (lbrcssq - R*T*fReciprocal(1.0+b*rho*(b*rho-2.0)) + a*rho*(2.0+b*rho)*fReciprocal(1.0+b*rho*(2.0+b*rho)));
      break;
    case 9:
      // Soave-Redlich-Kwong (1972): P = rho*RT/(1-b*rho) - a*alpha*rho*rho/(1+b*rho) (constant system temperature)
      a = lbeosa[0];
      b = lbeosb[0];
      lambda = (1.0/omega-0.5) * (lbrcssq - R*T*fReciprocal(1.0+b*rho*(b*rho-2.0)) + a*rho*(2.0+b*rho)*fReciprocal(1.0+b*rho*(2.0+b*rho)));
      break;
    case 10:
      // Soave-Redlich-Kwong (1972): P = rho*RT/(1-b*rho) - a*alpha*rho*rho/(1+b*rho) (variable system temperature)
      Tr = T * fReciprocal(lbcritt[0]);
      m = (1.0 + (0.480 + lbacentric[0] * (1.574  - 0.176 * lbacentric[0])) * (1.0 - sqrt(Tr)));
      a = lbeosa[0]*m*m;
      b = lbeosb[0];
      lambda = (1.0/omega-0.5) * (lbrcssq - R*T*fReciprocal(1.0+b*rho*(b*rho-2.0)) + a*rho*(2.0+b*rho)*fReciprocal(1.0+b*rho*(2.0+b*rho)));
      break;
    case 11:
      // Peng-Robinson (1976): P = rho*RT/(1-b*rho) - a*alpha*rho*rho/(1+2*b*rho-b*b*rho*rho) (constant system temperature)
      a = lbeosa[0];
      b = lbeosb[0];
      lambda = (1.0/omega-0.5) * (lbrcssq - R*T*fReciprocal(1.0+b*rho*(b*rho-2.0)) + 2.0*a*rho*fReciprocal((1.0+b*rho*(2.0-b*rho))*(1.0+b*rho*(2.0-b*rho))));
      break;
    case 12:
      // Peng-Robinson (1976): P = rho*RT/(1-b*rho) - a*alpha*rho*rho/(1+2*b*rho-b*b*rho*rho) (variable system temperature)
      Tr = T * fReciprocal(lbcritt[0]);
      m = (1.0 + (0.37464 + lbacentric[0] * (1.54226  - 0.26992 * lbacentric[0])) * (1.0 - sqrt(Tr)));
      a = lbeosa[0]*m*m;
      b = lbeosb[0];
      lambda = (1.0/omega-0.5) * (lbrcssq - R*T*fReciprocal(1.0+b*rho*(b*rho-2.0)) + 2.0*a*rho*fReciprocal((1.0+b*rho*(2.0-b*rho))*(1.0+b*rho*(2.0-b*rho))));
      break;
    case 13:
     // Carnahan-Starling-Redlich-Kwong (1972): P = rho*RT*(1+phi+phi^2-phi^3)/((1-phi)^3) - a*rho*rho/(sqrt(T)*(1+b*rho)) (constant system temperature)
      a = lbeosa[0];
      b = lbeosb[0];
      phi = 0.25*rho*b;
      psi0 = fReciprocal((1.0-phi)*(1.0-phi));
      lambda = (1.0/omega-0.5) * (lbrcssq - R*T*(1.0+phi*(4.0+phi*(4.0+phi*(-4.0+phi))))*psi0*psi0 + a*rho*(2.0+b*rho)*fReciprocal(1.0+b*rho*(2.0+b*rho)));
      break;
    case 14:
     // Carnahan-Starling-Redlich-Kwong (1972): P = rho*RT*(1+phi+phi^2-phi^3)/((1-phi)^3) - a*rho*rho/(sqrt(T)*(1+b*rho)) (variable system temperature)
      a = lbeosa[0]*fReciprocal(sqrt(T));
      b = lbeosb[0];
      phi = 0.25*rho*b;
      psi0 = fReciprocal((1.0-phi)*(1.0-phi));
      lambda = (1.0/omega-0.5) * (lbrcssq - R*T*(1.0+phi*(4.0+phi*(4.0+phi*(-4.0+phi))))*psi0*psi0 + a*rho*(2.0+b*rho)*fReciprocal(1.0+b*rho*(2.0+b*rho)));
      break;
  }
  return lambda;
}

int fGetEquilibriumC(double *feq, double *v, double rho)
{

  // calculate equilibrium distribution function for solute:
  // only suitable for square lattices

  double uv;
  
  for(int i=0; i<lbsy.nq; i++)
    {
      uv = lbvx[i] * v[0] + lbvy[i] * v[1] + lbvz[i] * v[2];
      feq[i] = rho * lbw[i] * (1.0 + 3.0 * uv);
    }
  
  return 0;
}


int fGetEquilibriumT(double *feq, double *v, double rho)
{

  // calculate equilibrium distribution function for temperature:
  // only suitable for square lattices

  double uv;
  
  for(int i=0; i<lbsy.nq; i++)
    {
      uv = lbvx[i] * v[0] + lbvy[i] * v[1] + lbvz[i] * v[2];
      feq[i] = rho * lbw[i] * (1.0 + 3.0 * uv);
    }
  
  return 0;
}


int fInitializeSystem()
{

  // initialize system

  double ttodo, rho, phi, pb, mu, lambda, omega;
  double T = (lbsy.nt>0)?lbinit:lbsyst;
  double *pt2=&lbf[0];
  int *pt3=&lbphi[0];
  int qdim = lbsy.nf+lbsy.nc+lbsy.nt;
  double delta[4*lbsy.nf], tdone[lbsy.nf];
    
  for(int l=0; l<4*lbsy.nf; l++)
    delta[l] = 0.0;
    
  for(long i=0; i<lbdm.touter; i++) {
    if(lbphi[i] == 10 || lbphi[i] == 11 || lbphi[i] == 12 || lbphi[i] == 13) { 
      for(int l=0; l<lbsitelength; l++){
	    pt2[i*lbsitelength+l] = 0;
      }
    }
    else {
      ttodo =0.0;
      for(int l=0; l<lbsy.nf; l++)
	    ttodo += lbinip[l];
      if(lbsy.nf==1) {
        tdone[0] = lbinip[0]*(1.0+lbnoise*fRandom());
        if(interact==5) {
          pb = fGetBulkPressureSwift(tdone[0], 0.0, T);
          lambda = fGetLambdaSwift(tdone[0], lbtf[0], T);
          fGetEquilibriumFSwiftOneFluid(lbfeq, lbiniv, tdone[0], pb, lambda, delta);
        }
        else if(!incompress) {
	      fGetEquilibriumF(lbfeq, lbiniv, tdone[0]);
        }
        else {
          fGetEquilibriumFIncom(lbfeq, lbiniv, tdone[0], lbincp[0]);
        }
        for(int m=0; m<lbsy.nq; m++) {
          pt2[i*lbsitelength+m*qdim] = lbfeq[m];
        }
      }
      else {
        for(int l=0; l<lbsy.nf-1; l++) {
          tdone[l] = lbinip[l]*(1.0+lbnoise*fRandom());
          ttodo -= tdone[l];
        }
        tdone[lbsy.nf-1] = ttodo;
        if(interact==5) {
          rho = tdone[0]+tdone[1];
          phi = (tdone[0]-tdone[1])*fReciprocal(rho);
          omega = 2.0*lbtf[0]*lbtf[1]/(2.0*lbtf[0]+(1.0+phi)*(lbtf[1]-lbtf[0]));
          pb = fGetBulkPressureSwift(rho, phi, T);
          lambda = fGetLambdaSwift(rho, omega, T);
          mu = fGetPotentialSwift(phi, 0.0);
          fGetEquilibriumFSwiftTwoFluid(lbfeq, lbiniv, rho, phi, pb, mu, lambda, delta);
          for(int m=0; m<lbsy.nq; m++) {
            pt2[i*lbsitelength+m*qdim  ] = lbfeq[2*m  ];
            pt2[i*lbsitelength+m*qdim+1] = lbfeq[2*m+1];
          }
        }
        else if(!incompress) {
          for(int l=0; l<lbsy.nf; l++) {
            fGetEquilibriumF(lbfeq, lbiniv, tdone[l]);
            for(int m=0; m<lbsy.nq; m++) {
              pt2[i*lbsitelength+m*qdim+l] = lbfeq[m];
            }
          }
        }
        else {
          for(int l=0; l<lbsy.nf; l++) {
            fGetEquilibriumFIncom(lbfeq, lbiniv, tdone[l], lbincp[l]);
            for(int m=0; m<lbsy.nq; m++) {
              pt2[i*lbsitelength+m*qdim+l] = lbfeq[m];
            }
          }
        }
      }
      ttodo =0.0;
      for(int l=0; l<lbsy.nc; l++)
	    ttodo += lbinic[l];
      for(int l=1; l<lbsy.nc; l++) {
	    tdone[0] = lbinic[l-1]*(1+lbnoise*fRandom());
	    ttodo -= tdone[0];
	    fGetEquilibriumC(lbfeq, lbiniv, tdone[0]);
	    for(int m=0; m<lbsy.nq; m++) {
	      pt2[i*lbsitelength+m*qdim+lbsy.nf+(l-1)] = lbfeq[m];
	    }
      }
      if(lbsy.nc > 1) {
	    fGetEquilibriumC(lbfeq, lbiniv, ttodo);
	    for(int m=0; m<lbsy.nq; m++) {
	      pt2[i*lbsitelength+m*qdim+lbsy.nf+lbsy.nc-1] = lbfeq[m];
	    }
      }
      else if(lbsy.nc == 1) {
	    fGetEquilibriumC(lbfeq, lbiniv, lbinic[0]*(1+lbnoise*fRandom()));
	    for(int m=0; m<lbsy.nq; m++) {
	      pt2[i*lbsitelength+m*qdim+lbsy.nf] = lbfeq[m];
	    }
      }
      if(lbsy.nt ==1) {
	    fGetEquilibriumT(lbfeq, lbiniv, lbinit);
	    for(int m=0; m<lbsy.nq; m++) {
	      pt2[i*lbsitelength+m*qdim+lbsy.nf+lbsy.nc] = lbfeq[m];
	    }
      }
      if(lbsy.pf ==1) {
	    pt2[i*lbsitelength+qdim*lbsy.nq] = 0;
      }
    }
  }
  pt2=NULL;
  pt3=NULL;
  return 0;
}


int fPropagationTwoLattice()
{
  
  // move particles to neighbouring grid points using two-lattice algorithm
  
  int tdim = (lbsy.nf + lbsy.nc + lbsy.nt) * lbsy.nq;
  int qdim = lbsy.nf+lbsy.nc+lbsy.nt;
  long dxy = lbdm.youter * lbdm.zouter;
  int q;
  long xps, xpos, yps, ypos, zps, zpos;
  
  for(int m=0; m<tdim; m++) {
    q = m / qdim;
    if(q != 0) {
      for(int i=0; i<lbdm.xouter; i++) {
        xps = i * dxy;
        xpos = fCppMod(i+lbvx[q], lbdm.xouter) * dxy;
        for(int j=0; j<lbdm.youter; j++) {
          yps = j * lbdm.zouter + xps;
          ypos = fCppMod(j+lbvy[q], lbdm.youter) * lbdm.zouter + xpos;
          for(int k=0; k<lbdm.zouter; k++) {
            zps = k + yps; 
            zpos = fCppMod(k+lbvz[q], lbdm.zouter) + ypos;
            lbft[zpos] = lbf[zps * lbsitelength + m];
          }
        }
      }
      for(long i = 0; i<lbdm.touter; i++)
        lbf[i * lbsitelength + m] = lbft[i];
    }
  }
  return 0;    
}

int fPropagationSwap()
{
  
  // move particles to neighbouring grid points using swap algorithm
  // separate loops for two swaps: suitable for lbdm.bwid >= 0
                                     
#pragma omp parallel
  {
    long il, ilnext;
    int qdim = (lbsy.nf + lbsy.nc + lbsy.nt);
    int half = (lbsy.nq - 1) / 2;
    int nextx, nexty, nextz;
    int Xmax = lbdm.xouter;
    int Ymax = lbdm.youter;
    int Zmax = lbdm.zouter;

    #pragma omp for
    for (il=0; il<lbdm.touter; il++)
      for (int m=1; m<=half; m++)
        for (int l=0; l<qdim; l++)
          fSwapPair (lbf[il*lbsitelength + l + m*qdim], lbf[il*lbsitelength + l + (m+half)*qdim]);

    #pragma omp for collapse(3) private(il,ilnext)
    for(int i=0; i<Xmax; i++)
      for(int j=0; j<Ymax; j++)
        for(int k=0; k<Zmax; k++) {
          il = (i * Ymax + j) * Zmax + k;
          for (int m=1; m<=half; m++) {
            nextx = fCppMod(i + lbvx[m], Xmax);
            nexty = fCppMod(j + lbvy[m], Ymax);
            nextz = fCppMod(k + lbvz[m], Zmax);
            ilnext = (nextx * Ymax + nexty) * Zmax + nextz;
            for (int l=0; l<qdim; l++) {
              fSwapPair (lbf[il*lbsitelength + l + (m+half)*qdim], lbf[ilnext*lbsitelength + l + m*qdim]);
            }
          }
        }
                                     
  }
  return 0;    
}

int fPropagationCombinedSwap()
{
  // move particles to neighbouring grid points using swap algorithm
  // single loop for both swaps: only suitable when lbdm.bwid>0
  // (calculations in parallel and serial with non-zero boundary layers)
  
  long il, ilnext;
  int qdim = (lbsy.nf + lbsy.nc + lbsy.nt);
  int half = (lbsy.nq - 1) / 2;
  int i, j, k, nextx, nexty, nextz;
  
  for (il=0; il<lbdm.touter; il++) {
    fGetCoord(il, i, j, k);
    for (int m=1; m<=half; m++) {
      nextx = i + lbvx[m];
      nexty = j + lbvy[m];
      nextz = k + lbvz[m];
      for (int l=0; l<qdim; l++) {
        fSwapPair (lbf[il*lbsitelength + l + m*qdim], lbf[il*lbsitelength + l + (m+half)*qdim]);
        if (nextx>=0 && nexty>=0 && nextz>=0 && nextx<lbdm.xouter
                     && nexty<lbdm.youter && nextz<lbdm.zouter) {
          ilnext = (nextx * lbdm.youter + nexty) * lbdm.zouter + nextz;
          fSwapPair (lbf[il*lbsitelength + l + (m+half)*qdim], lbf[ilnext*lbsitelength + l + m*qdim]);
        }
      }
    }
  }
  return 0;
}


