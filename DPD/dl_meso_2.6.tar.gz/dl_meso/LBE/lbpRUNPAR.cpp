/***********************************************
 *   DL_MESO       Version 2.6                 *
 *   Authors   :   R. S. Qin, M. A. Seaton     *
 *   Ammended  :   L. Grinberg                 *
 *   Copyright :   STFC Daresbury Laboratory   *
 *             :   22/10/2015                  *
 ***********************************************/

// No mesoscopic interactions

// option 0: BGK with standard forcing

int fBGK()
{
  do { 
    fNonBlockCommunication();
    if(lbcurstep%lbsave == 0 || lbcurstep==lbequstep) {
      if(lbequstep>0 && lbcurstep==lbequstep) {
        fPrintEndEquilibration();
        postequil = 1;
        fReadSpaceParameter();
        fBoundNonBlockCommunication();
        fNeighbourBoundary();
        fMarkBoundArea();
      }
      if(lbcurstep>=lbequstep)
        fOutput();
      if(lbdm.rank == 0)
	    cout << left << setw(12) << lbcurstep << " ";
      fPrintSystemMass();
      double timeelapsed = fCheckTimeMPI();
      if(lbdm.rank == 0)
	    cout << left << setw(12) << timeelapsed << " ";
      fPrintSystemMomentum();
    }
    if(lbsy.nt==1) {
      fInteractionForceZero();
      fConvectionForceBoussinesq(lbbousth, lbboustl);
    }
    fCollisionBGK();
    fPostCollBoundary();
#ifdef _OPENMP
    fPropagationSwap();
#else
    fPropagationCombinedSwap();
#endif
    fPostPropBoundary();
    lbcurstep++;
  }
  while(lbcurstep<=lbtotstep);
  return 0;
}

// option 1: BGK with EDM forcing

int fBGKEDM()
{
  do { 
    fNonBlockCommunication();
    if(lbcurstep%lbsave == 0 || lbcurstep==lbequstep) {
      if(lbequstep>0 && lbcurstep==lbequstep) {
        fPrintEndEquilibration();
        postequil = 1;
        fReadSpaceParameter();
        fBoundNonBlockCommunication();
        fNeighbourBoundary();
        fMarkBoundArea();
      }
      if(lbcurstep>=lbequstep)
        fOutput();
      if(lbdm.rank == 0)
	    cout << left << setw(12) << lbcurstep << " ";
      fPrintSystemMass();
      double timeelapsed = fCheckTimeMPI();
      if(lbdm.rank == 0)
	    cout << left << setw(12) << timeelapsed << " ";
      fPrintSystemMomentum();
    }
    if(lbsy.nt==1) {
      fInteractionForceZero();
      fConvectionForceBoussinesq(lbbousth, lbboustl);
    }
    fCollisionBGKEDM();
    fPostCollBoundary();
#ifdef _OPENMP
    fPropagationSwap();
#else
    fPropagationCombinedSwap();
#endif
    fPostPropBoundary();
    lbcurstep++;
  }
  while(lbcurstep<=lbtotstep);
  return 0;
}

// option 2: BGK with Guo forcing

int fBGKGuo()
{
  do { 
    fNonBlockCommunication();
    if(lbcurstep%lbsave == 0 || lbcurstep==lbequstep) {
      if(lbequstep>0 && lbcurstep==lbequstep) {
        fPrintEndEquilibration();
        postequil = 1;
        fReadSpaceParameter();
        fBoundNonBlockCommunication();
        fNeighbourBoundary();
        fMarkBoundArea();
      }
      if(lbcurstep>=lbequstep)
        fOutput();
      if(lbdm.rank == 0)
	    cout << left << setw(12) << lbcurstep << " ";
      fPrintSystemMass();
      double timeelapsed = fCheckTimeMPI();
      if(lbdm.rank == 0)
	    cout << left << setw(12) << timeelapsed << " ";
      fPrintSystemMomentum();
    }
    if(lbsy.nt==1) {
      fInteractionForceZero();
      fConvectionForceBoussinesq(lbbousth, lbboustl);
    }
    fCollisionBGKGuo();
    fPostCollBoundary();
#ifdef _OPENMP
    fPropagationSwap();
#else
    fPropagationCombinedSwap();
#endif
    fPostPropBoundary();
    lbcurstep++;
  }
  while(lbcurstep<=lbtotstep);
  return 0;
}

// option 3: TRT with standard forcing

int fTRT()
{
  do { 
    fNonBlockCommunication();
    if(lbcurstep%lbsave == 0 || lbcurstep==lbequstep) {
      if(lbequstep>0 && lbcurstep==lbequstep) {
        fPrintEndEquilibration();
        postequil = 1;
        fReadSpaceParameter();
        fBoundNonBlockCommunication();
        fNeighbourBoundary();
        fMarkBoundArea();
      }
      if(lbcurstep>=lbequstep)
        fOutput();
      if(lbdm.rank == 0)
	    cout << left << setw(12) << lbcurstep << " ";
      fPrintSystemMass();
      double timeelapsed = fCheckTimeMPI();
      if(lbdm.rank == 0)
	    cout << left << setw(12) << timeelapsed << " ";
      fPrintSystemMomentum();
    }
    if(lbsy.nt==1) {
      fInteractionForceZero();
      fConvectionForceBoussinesq(lbbousth, lbboustl);
    }
    fCollisionTRT();
    fPostCollBoundary();
#ifdef _OPENMP
    fPropagationSwap();
#else
    fPropagationCombinedSwap();
#endif
    fPostPropBoundary();
    lbcurstep++;
  }
  while(lbcurstep<=lbtotstep);
  return 0;
}

// option 4: TRT with EDM forcing

int fTRTEDM()
{
  do { 
    fNonBlockCommunication();
    if(lbcurstep%lbsave == 0 || lbcurstep==lbequstep) {
      if(lbequstep>0 && lbcurstep==lbequstep) {
        fPrintEndEquilibration();
        postequil = 1;
        fReadSpaceParameter();
        fBoundNonBlockCommunication();
        fNeighbourBoundary();
        fMarkBoundArea();
      }
      if(lbcurstep>=lbequstep)
        fOutput();
      if(lbdm.rank == 0)
	    cout << left << setw(12) << lbcurstep << " ";
      fPrintSystemMass();
      double timeelapsed = fCheckTimeMPI();
      if(lbdm.rank == 0)
	    cout << left << setw(12) << timeelapsed << " ";
      fPrintSystemMomentum();
    }
    if(lbsy.nt==1) {
      fInteractionForceZero();
      fConvectionForceBoussinesq(lbbousth, lbboustl);
    }
    fCollisionTRTEDM();
    fPostCollBoundary();
#ifdef _OPENMP
    fPropagationSwap();
#else
    fPropagationCombinedSwap();
#endif
    fPostPropBoundary();
    lbcurstep++;
  }
  while(lbcurstep<=lbtotstep);
  return 0;
}

// option 5: TRT with Guo forcing

int fTRTGuo()
{
  do { 
    fNonBlockCommunication();
    if(lbcurstep%lbsave == 0 || lbcurstep==lbequstep) {
      if(lbequstep>0 && lbcurstep==lbequstep) {
        fPrintEndEquilibration();
        postequil = 1;
        fReadSpaceParameter();
        fBoundNonBlockCommunication();
        fNeighbourBoundary();
        fMarkBoundArea();
      }
      if(lbcurstep>=lbequstep)
        fOutput();
      if(lbdm.rank == 0)
	    cout << left << setw(12) << lbcurstep << " ";
      fPrintSystemMass();
      double timeelapsed = fCheckTimeMPI();
      if(lbdm.rank == 0)
	    cout << left << setw(12) << timeelapsed << " ";
      fPrintSystemMomentum();
    }
    if(lbsy.nt==1) {
      fInteractionForceZero();
      fConvectionForceBoussinesq(lbbousth, lbboustl);
    }
    fCollisionTRTGuo();
    fPostCollBoundary();
#ifdef _OPENMP
    fPropagationSwap();
#else
    fPropagationCombinedSwap();
#endif
    fPostPropBoundary();
    lbcurstep++;
  }
  while(lbcurstep<=lbtotstep);
  return 0;
}

// option 6: MRT with standard forcing

int fMRT()
{
  do { 
    fNonBlockCommunication();
    if(lbcurstep%lbsave == 0 || lbcurstep==lbequstep) {
      if(lbequstep>0 && lbcurstep==lbequstep) {
        fPrintEndEquilibration();
        postequil = 1;
        fReadSpaceParameter();
        fBoundNonBlockCommunication();
        fNeighbourBoundary();
        fMarkBoundArea();
      }
      if(lbcurstep>=lbequstep)
        fOutput();
      if(lbdm.rank == 0)
	    cout << left << setw(12) << lbcurstep << " ";
      fPrintSystemMass();
      double timeelapsed = fCheckTimeMPI();
      if(lbdm.rank == 0)
	    cout << left << setw(12) << timeelapsed << " ";
      fPrintSystemMomentum();
    }
    if(lbsy.nt==1) {
      fInteractionForceZero();
      fConvectionForceBoussinesq(lbbousth, lbboustl);
    }
    fCollisionMRT();
    fPostCollBoundary();
#ifdef _OPENMP
    fPropagationSwap();
#else
    fPropagationCombinedSwap();
#endif
    fPostPropBoundary();
    lbcurstep++;
  }
  while(lbcurstep<=lbtotstep);
  return 0;
}

// option 7: MRT with EDM forcing

int fMRTEDM()
{
  do { 
    fNonBlockCommunication();
    if(lbcurstep%lbsave == 0 || lbcurstep==lbequstep) {
      if(lbequstep>0 && lbcurstep==lbequstep) {
        fPrintEndEquilibration();
        postequil = 1;
        fReadSpaceParameter();
        fBoundNonBlockCommunication();
        fNeighbourBoundary();
        fMarkBoundArea();
      }
      if(lbcurstep>=lbequstep)
        fOutput();
      if(lbdm.rank == 0)
	    cout << left << setw(12) << lbcurstep << " ";
      fPrintSystemMass();
      double timeelapsed = fCheckTimeMPI();
      if(lbdm.rank == 0)
	    cout << left << setw(12) << timeelapsed << " ";
      fPrintSystemMomentum();
    }
    if(lbsy.nt==1) {
      fInteractionForceZero();
      fConvectionForceBoussinesq(lbbousth, lbboustl);
    }
    fCollisionMRTEDM();
    fPostCollBoundary();
#ifdef _OPENMP
    fPropagationSwap();
#else
    fPropagationCombinedSwap();
#endif
    fPostPropBoundary();
    lbcurstep++;
  }
  while(lbcurstep<=lbtotstep);
  return 0;
}

// option 8: MRT with Guo-like forcing

int fMRTGuo()
{
  do { 
    fNonBlockCommunication();
    if(lbcurstep%lbsave == 0 || lbcurstep==lbequstep) {
      if(lbequstep>0 && lbcurstep==lbequstep) {
        fPrintEndEquilibration();
        postequil = 1;
        fReadSpaceParameter();
        fBoundNonBlockCommunication();
        fNeighbourBoundary();
        fMarkBoundArea();
      }
      if(lbcurstep>=lbequstep)
        fOutput();
      if(lbdm.rank == 0)
	    cout << left << setw(12) << lbcurstep << " ";
      fPrintSystemMass();
      double timeelapsed = fCheckTimeMPI();
      if(lbdm.rank == 0)
	    cout << left << setw(12) << timeelapsed << " ";
      fPrintSystemMomentum();
    }
    if(lbsy.nt==1) {
      fInteractionForceZero();
      fConvectionForceBoussinesq(lbbousth, lbboustl);
    }
    fCollisionMRTGuo();
    fPostCollBoundary();
#ifdef _OPENMP
    fPropagationSwap();
#else
    fPropagationCombinedSwap();
#endif
    fPostPropBoundary();
    lbcurstep++;
  }
  while(lbcurstep<=lbtotstep);
  return 0;
}

// Shan-Chen pseudopotential interactions

// option 0: BGK with standard forcing

int fBGKShanChen()
{
  do { 
    fNonBlockCommunication();
    if(lbcurstep%lbsave == 0 || lbcurstep==lbequstep) {
      if(lbequstep>0 && lbcurstep==lbequstep) {
        fPrintEndEquilibration();
        postequil = 1;
        fReadSpaceParameter();
        fBoundNonBlockCommunication();
        fNeighbourBoundary();
        fMarkBoundArea();
      }
      if(lbcurstep>=lbequstep)
        fOutput();
      if(lbdm.rank == 0)
	    cout << left << setw(12) << lbcurstep << " ";
      fPrintSystemMass();
      double timeelapsed = fCheckTimeMPI();
      if(lbdm.rank == 0)
	    cout << left << setw(12) << timeelapsed << " ";
      fPrintSystemMomentum();
    }
    fInteractionForceZero();
    fConvectionForceBoussinesq(lbbousth, lbboustl);
    fCalcPotential_ShanChen();
    fInteractionForceShanChen();
    fForceNonBlockCommunication();
    fCollisionBGKShanChen();
    fPostCollBoundary();
#ifdef _OPENMP
    fPropagationSwap();
#else
    fPropagationCombinedSwap();
#endif
    fPostPropBoundary();
    lbcurstep++;
  }
  while(lbcurstep<=lbtotstep);
  return 0;
}

// option 1: BGK with EDM forcing

int fBGKEDMShanChen()
{
  do { 
    fNonBlockCommunication();
    if(lbcurstep%lbsave == 0 || lbcurstep==lbequstep) {
      if(lbequstep>0 && lbcurstep==lbequstep) {
        fPrintEndEquilibration();
        postequil = 1;
        fReadSpaceParameter();
        fBoundNonBlockCommunication();
        fNeighbourBoundary();
        fMarkBoundArea();
      }
      if(lbcurstep>=lbequstep)
        fOutput();
      if(lbdm.rank == 0)
	    cout << left << setw(12) << lbcurstep << " ";
      fPrintSystemMass();
      double timeelapsed = fCheckTimeMPI();
      if(lbdm.rank == 0)
	    cout << left << setw(12) << timeelapsed << " ";
      fPrintSystemMomentum();
    }
    fInteractionForceZero();
    fConvectionForceBoussinesq(lbbousth, lbboustl);
    fCalcPotential_ShanChen();
    fInteractionForceShanChen();
    fForceNonBlockCommunication();
    fCollisionBGKEDMShanChen();
    fPostCollBoundary();
#ifdef _OPENMP
    fPropagationSwap();
#else
    fPropagationCombinedSwap();
#endif
    fPostPropBoundary();
    lbcurstep++;
  }
  while(lbcurstep<=lbtotstep);
  return 0;
}

// option 2: BGK with Guo forcing

int fBGKGuoShanChen()
{
  do { 
    fNonBlockCommunication();
    if(lbcurstep%lbsave == 0 || lbcurstep==lbequstep) {
      if(lbequstep>0 && lbcurstep==lbequstep) {
        fPrintEndEquilibration();
        postequil = 1;
        fReadSpaceParameter();
        fBoundNonBlockCommunication();
        fNeighbourBoundary();
        fMarkBoundArea();
      }
      if(lbcurstep>=lbequstep)
        fOutput();
      if(lbdm.rank == 0)
	    cout << left << setw(12) << lbcurstep << " ";
      fPrintSystemMass();
      double timeelapsed = fCheckTimeMPI();
      if(lbdm.rank == 0)
	    cout << left << setw(12) << timeelapsed << " ";
      fPrintSystemMomentum();
    }
    fInteractionForceZero();
    fConvectionForceBoussinesq(lbbousth, lbboustl);
    fCalcPotential_ShanChen();
    fInteractionForceShanChen();
    fForceNonBlockCommunication();
    fCollisionBGKGuoShanChen();
    fPostCollBoundary();
#ifdef _OPENMP
    fPropagationSwap();
#else
    fPropagationCombinedSwap();
#endif
    fPostPropBoundary();
    lbcurstep++;
  }
  while(lbcurstep<=lbtotstep);
  return 0;
}

// option 3: TRT with standard forcing

int fTRTShanChen()
{
  do { 
    fNonBlockCommunication();
    if(lbcurstep%lbsave == 0 || lbcurstep==lbequstep) {
      if(lbequstep>0 && lbcurstep==lbequstep) {
        fPrintEndEquilibration();
        postequil = 1;
        fReadSpaceParameter();
        fBoundNonBlockCommunication();
        fNeighbourBoundary();
        fMarkBoundArea();
      }
      if(lbcurstep>=lbequstep)
        fOutput();
      if(lbdm.rank == 0)
	    cout << left << setw(12) << lbcurstep << " ";
      fPrintSystemMass();
      double timeelapsed = fCheckTimeMPI();
      if(lbdm.rank == 0)
	    cout << left << setw(12) << timeelapsed << " ";
      fPrintSystemMomentum();
    }
    fInteractionForceZero();
    fConvectionForceBoussinesq(lbbousth, lbboustl);
    fCalcPotential_ShanChen();
    fInteractionForceShanChen();
    fForceNonBlockCommunication();
    fCollisionTRTShanChen();
    fPostCollBoundary();
#ifdef _OPENMP
    fPropagationSwap();
#else
    fPropagationCombinedSwap();
#endif
    fPostPropBoundary();
    lbcurstep++;
  }
  while(lbcurstep<=lbtotstep);
  return 0;
}

// option 4: TRT with EDM forcing

int fTRTEDMShanChen()
{
  do { 
    fNonBlockCommunication();
    if(lbcurstep%lbsave == 0 || lbcurstep==lbequstep) {
      if(lbequstep>0 && lbcurstep==lbequstep) {
        fPrintEndEquilibration();
        postequil = 1;
        fReadSpaceParameter();
        fBoundNonBlockCommunication();
        fNeighbourBoundary();
        fMarkBoundArea();
      }
      if(lbcurstep>=lbequstep)
        fOutput();
      if(lbdm.rank == 0)
	    cout << left << setw(12) << lbcurstep << " ";
      fPrintSystemMass();
      double timeelapsed = fCheckTimeMPI();
      if(lbdm.rank == 0)
	    cout << left << setw(12) << timeelapsed << " ";
      fPrintSystemMomentum();
    }
    fInteractionForceZero();
    fConvectionForceBoussinesq(lbbousth, lbboustl);
    fCalcPotential_ShanChen();
    fInteractionForceShanChen();
    fForceNonBlockCommunication();
    fCollisionTRTEDMShanChen();
    fPostCollBoundary();
#ifdef _OPENMP
    fPropagationSwap();
#else
    fPropagationCombinedSwap();
#endif
    fPostPropBoundary();
    lbcurstep++;
  }
  while(lbcurstep<=lbtotstep);
  return 0;
}

// option 5: TRT with Guo forcing

int fTRTGuoShanChen()
{
  do { 
    fNonBlockCommunication();
    if(lbcurstep%lbsave == 0 || lbcurstep==lbequstep) {
      if(lbequstep>0 && lbcurstep==lbequstep) {
        fPrintEndEquilibration();
        postequil = 1;
        fReadSpaceParameter();
        fBoundNonBlockCommunication();
        fNeighbourBoundary();
        fMarkBoundArea();
      }
      if(lbcurstep>=lbequstep)
        fOutput();
      if(lbdm.rank == 0)
	    cout << left << setw(12) << lbcurstep << " ";
      fPrintSystemMass();
      double timeelapsed = fCheckTimeMPI();
      if(lbdm.rank == 0)
	    cout << left << setw(12) << timeelapsed << " ";
      fPrintSystemMomentum();
    }
    fInteractionForceZero();
    fConvectionForceBoussinesq(lbbousth, lbboustl);
    fCalcPotential_ShanChen();
    fInteractionForceShanChen();
    fForceNonBlockCommunication();
    fCollisionTRTGuoShanChen();
    fPostCollBoundary();
#ifdef _OPENMP
    fPropagationSwap();
#else
    fPropagationCombinedSwap();
#endif
    fPostPropBoundary();
    lbcurstep++;
  }
  while(lbcurstep<=lbtotstep);
  return 0;
}

// option 6: MRT with standard forcing

int fMRTShanChen()
{
  do { 
    fNonBlockCommunication();
    if(lbcurstep%lbsave == 0 || lbcurstep==lbequstep) {
      if(lbequstep>0 && lbcurstep==lbequstep) {
        fPrintEndEquilibration();
        postequil = 1;
        fReadSpaceParameter();
        fBoundNonBlockCommunication();
        fNeighbourBoundary();
        fMarkBoundArea();
      }
      if(lbcurstep>=lbequstep)
        fOutput();
      if(lbdm.rank == 0)
	    cout << left << setw(12) << lbcurstep << " ";
      fPrintSystemMass();
      double timeelapsed = fCheckTimeMPI();
      if(lbdm.rank == 0)
	    cout << left << setw(12) << timeelapsed << " ";
      fPrintSystemMomentum();
    }
    fInteractionForceZero();
    fConvectionForceBoussinesq(lbbousth, lbboustl);
    fCalcPotential_ShanChen();
    fInteractionForceShanChen();
    fForceNonBlockCommunication();
    fCollisionMRTShanChen();
    fPostCollBoundary();
#ifdef _OPENMP
    fPropagationSwap();
#else
    fPropagationCombinedSwap();
#endif
    fPostPropBoundary();
    lbcurstep++;
  }
  while(lbcurstep<=lbtotstep);
  return 0;
}

// option 7: MRT with EDM forcing

int fMRTEDMShanChen()
{
  do { 
    fNonBlockCommunication();
    if(lbcurstep%lbsave == 0 || lbcurstep==lbequstep) {
      if(lbequstep>0 && lbcurstep==lbequstep) {
        fPrintEndEquilibration();
        postequil = 1;
        fReadSpaceParameter();
        fBoundNonBlockCommunication();
        fNeighbourBoundary();
        fMarkBoundArea();
      }
      if(lbcurstep>=lbequstep)
        fOutput();
      if(lbdm.rank == 0)
	    cout << left << setw(12) << lbcurstep << " ";
      fPrintSystemMass();
      double timeelapsed = fCheckTimeMPI();
      if(lbdm.rank == 0)
	    cout << left << setw(12) << timeelapsed << " ";
      fPrintSystemMomentum();
    }
    fInteractionForceZero();
    fConvectionForceBoussinesq(lbbousth, lbboustl);
    fCalcPotential_ShanChen();
    fInteractionForceShanChen();
    fForceNonBlockCommunication();
    fCollisionMRTEDMShanChen();
    fPostCollBoundary();
#ifdef _OPENMP
    fPropagationSwap();
#else
    fPropagationCombinedSwap();
#endif
    fPostPropBoundary();
    lbcurstep++;
  }
  while(lbcurstep<=lbtotstep);
  return 0;
}

// option 8: MRT with Guo-like forcing

int fMRTGuoShanChen()
{
  do { 
    fNonBlockCommunication();
    if(lbcurstep%lbsave == 0 || lbcurstep==lbequstep) {
      if(lbequstep>0 && lbcurstep==lbequstep) {
        fPrintEndEquilibration();
        postequil = 1;
        fReadSpaceParameter();
        fBoundNonBlockCommunication();
        fNeighbourBoundary();
        fMarkBoundArea();
      }
      if(lbcurstep>=lbequstep)
        fOutput();
      if(lbdm.rank == 0)
	    cout << left << setw(12) << lbcurstep << " ";
      fPrintSystemMass();
      double timeelapsed = fCheckTimeMPI();
      if(lbdm.rank == 0)
	    cout << left << setw(12) << timeelapsed << " ";
      fPrintSystemMomentum();
    }
    fInteractionForceZero();
    fConvectionForceBoussinesq(lbbousth, lbboustl);
    fCalcPotential_ShanChen();
    fInteractionForceShanChen();
    fForceNonBlockCommunication();
    fCollisionMRTGuoShanChen();
    fPostCollBoundary();
#ifdef _OPENMP
    fPropagationSwap();
#else
    fPropagationCombinedSwap();
#endif
    fPostPropBoundary();
    lbcurstep++;
  }
  while(lbcurstep<=lbtotstep);
  return 0;
}

// Shan/Chen pseudopotential interactions with quadratic pseudopotential term

// option 0: BGK with standard forcing

int fBGKShanChenQuadratic()
{
  do { 
    fNonBlockCommunication();
    if(lbcurstep%lbsave == 0 || lbcurstep==lbequstep) {
      if(lbequstep>0 && lbcurstep==lbequstep) {
        fPrintEndEquilibration();
        postequil = 1;
        fReadSpaceParameter();
        fBoundNonBlockCommunication();
        fNeighbourBoundary();
        fMarkBoundArea();
      }
      if(lbcurstep>=lbequstep)
        fOutput();
      if(lbdm.rank == 0)
	    cout << left << setw(12) << lbcurstep << " ";
      fPrintSystemMass();
      double timeelapsed = fCheckTimeMPI();
      if(lbdm.rank == 0)
	    cout << left << setw(12) << timeelapsed << " ";
      fPrintSystemMomentum();
    }
    fInteractionForceZero();
    fConvectionForceBoussinesq(lbbousth, lbboustl);
    fCalcPotential_ShanChen();
    fInteractionForceShanChenQuadratic();
    fForceNonBlockCommunication();
    fCollisionBGKShanChen();
    fPostCollBoundary();
#ifdef _OPENMP
    fPropagationSwap();
#else
    fPropagationCombinedSwap();
#endif
    fPostPropBoundary();
    lbcurstep++;
  }
  while(lbcurstep<=lbtotstep);
  return 0;
}

// option 1: BGK with EDM forcing

int fBGKEDMShanChenQuadratic()
{
  do { 
    fNonBlockCommunication();
    if(lbcurstep%lbsave == 0 || lbcurstep==lbequstep) {
      if(lbequstep>0 && lbcurstep==lbequstep) {
        fPrintEndEquilibration();
        postequil = 1;
        fReadSpaceParameter();
        fBoundNonBlockCommunication();
        fNeighbourBoundary();
        fMarkBoundArea();
      }
      if(lbcurstep>=lbequstep)
        fOutput();
      if(lbdm.rank == 0)
	    cout << left << setw(12) << lbcurstep << " ";
      fPrintSystemMass();
      double timeelapsed = fCheckTimeMPI();
      if(lbdm.rank == 0)
	    cout << left << setw(12) << timeelapsed << " ";
      fPrintSystemMomentum();
    }
    fInteractionForceZero();
    fConvectionForceBoussinesq(lbbousth, lbboustl);
    fCalcPotential_ShanChen();
    fInteractionForceShanChenQuadratic();
    fForceNonBlockCommunication();
    fCollisionBGKEDMShanChen();
    fPostCollBoundary();
#ifdef _OPENMP
    fPropagationSwap();
#else
    fPropagationCombinedSwap();
#endif
    fPostPropBoundary();
    lbcurstep++;
  }
  while(lbcurstep<=lbtotstep);
  return 0;
}

// option 2: BGK with Guo forcing

int fBGKGuoShanChenQuadratic()
{
  do { 
    fNonBlockCommunication();
    if(lbcurstep%lbsave == 0 || lbcurstep==lbequstep) {
      if(lbequstep>0 && lbcurstep==lbequstep) {
        fPrintEndEquilibration();
        postequil = 1;
        fReadSpaceParameter();
        fBoundNonBlockCommunication();
        fNeighbourBoundary();
        fMarkBoundArea();
      }
      if(lbcurstep>=lbequstep)
        fOutput();
      if(lbdm.rank == 0)
	    cout << left << setw(12) << lbcurstep << " ";
      fPrintSystemMass();
      double timeelapsed = fCheckTimeMPI();
      if(lbdm.rank == 0)
	    cout << left << setw(12) << timeelapsed << " ";
      fPrintSystemMomentum();
    }
    fInteractionForceZero();
    fConvectionForceBoussinesq(lbbousth, lbboustl);
    fCalcPotential_ShanChen();
    fInteractionForceShanChenQuadratic();
    fForceNonBlockCommunication();
    fCollisionBGKGuoShanChen();
    fPostCollBoundary();
#ifdef _OPENMP
    fPropagationSwap();
#else
    fPropagationCombinedSwap();
#endif
    fPostPropBoundary();
    lbcurstep++;
  }
  while(lbcurstep<=lbtotstep);
  return 0;
}

// option 3: TRT with standard forcing

int fTRTShanChenQuadratic()
{
  do { 
    fNonBlockCommunication();
    if(lbcurstep%lbsave == 0 || lbcurstep==lbequstep) {
      if(lbequstep>0 && lbcurstep==lbequstep) {
        fPrintEndEquilibration();
        postequil = 1;
        fReadSpaceParameter();
        fBoundNonBlockCommunication();
        fNeighbourBoundary();
        fMarkBoundArea();
      }
      if(lbcurstep>=lbequstep)
        fOutput();
      if(lbdm.rank == 0)
	    cout << left << setw(12) << lbcurstep << " ";
      fPrintSystemMass();
      double timeelapsed = fCheckTimeMPI();
      if(lbdm.rank == 0)
	    cout << left << setw(12) << timeelapsed << " ";
      fPrintSystemMomentum();
    }
    fInteractionForceZero();
    fConvectionForceBoussinesq(lbbousth, lbboustl);
    fCalcPotential_ShanChen();
    fInteractionForceShanChenQuadratic();
    fForceNonBlockCommunication();
    fCollisionTRTShanChen();
    fPostCollBoundary();
#ifdef _OPENMP
    fPropagationSwap();
#else
    fPropagationCombinedSwap();
#endif
    fPostPropBoundary();
    lbcurstep++;
  }
  while(lbcurstep<=lbtotstep);
  return 0;
}

// option 4: TRT with EDM forcing

int fTRTEDMShanChenQuadratic()
{
  do { 
    fNonBlockCommunication();
    if(lbcurstep%lbsave == 0 || lbcurstep==lbequstep) {
      if(lbequstep>0 && lbcurstep==lbequstep) {
        fPrintEndEquilibration();
        postequil = 1;
        fReadSpaceParameter();
        fBoundNonBlockCommunication();
        fNeighbourBoundary();
        fMarkBoundArea();
      }
      if(lbcurstep>=lbequstep)
        fOutput();
      if(lbdm.rank == 0)
	    cout << left << setw(12) << lbcurstep << " ";
      fPrintSystemMass();
      double timeelapsed = fCheckTimeMPI();
      if(lbdm.rank == 0)
	    cout << left << setw(12) << timeelapsed << " ";
      fPrintSystemMomentum();
    }
    fInteractionForceZero();
    fConvectionForceBoussinesq(lbbousth, lbboustl);
    fCalcPotential_ShanChen();
    fInteractionForceShanChenQuadratic();
    fForceNonBlockCommunication();
    fCollisionTRTEDMShanChen();
    fPostCollBoundary();
#ifdef _OPENMP
    fPropagationSwap();
#else
    fPropagationCombinedSwap();
#endif
    fPostPropBoundary();
    lbcurstep++;
  }
  while(lbcurstep<=lbtotstep);
  return 0;
}

// option 5: TRT with Guo forcing

int fTRTGuoShanChenQuadratic()
{
  do { 
    fNonBlockCommunication();
    if(lbcurstep%lbsave == 0 || lbcurstep==lbequstep) {
      if(lbequstep>0 && lbcurstep==lbequstep) {
        fPrintEndEquilibration();
        postequil = 1;
        fReadSpaceParameter();
        fBoundNonBlockCommunication();
        fNeighbourBoundary();
        fMarkBoundArea();
      }
      if(lbcurstep>=lbequstep)
        fOutput();
      if(lbdm.rank == 0)
	    cout << left << setw(12) << lbcurstep << " ";
      fPrintSystemMass();
      double timeelapsed = fCheckTimeMPI();
      if(lbdm.rank == 0)
	    cout << left << setw(12) << timeelapsed << " ";
      fPrintSystemMomentum();
    }
    fInteractionForceZero();
    fConvectionForceBoussinesq(lbbousth, lbboustl);
    fCalcPotential_ShanChen();
    fInteractionForceShanChenQuadratic();
    fForceNonBlockCommunication();
    fCollisionTRTGuoShanChen();
    fPostCollBoundary();
#ifdef _OPENMP
    fPropagationSwap();
#else
    fPropagationCombinedSwap();
#endif
    fPostPropBoundary();
    lbcurstep++;
  }
  while(lbcurstep<=lbtotstep);
  return 0;
}

// option 6: MRT with standard forcing

int fMRTShanChenQuadratic()
{
  do { 
    fNonBlockCommunication();
    if(lbcurstep%lbsave == 0 || lbcurstep==lbequstep) {
      if(lbequstep>0 && lbcurstep==lbequstep) {
        fPrintEndEquilibration();
        postequil = 1;
        fReadSpaceParameter();
        fBoundNonBlockCommunication();
        fNeighbourBoundary();
        fMarkBoundArea();
      }
      if(lbcurstep>=lbequstep)
        fOutput();
      if(lbdm.rank == 0)
	    cout << left << setw(12) << lbcurstep << " ";
      fPrintSystemMass();
      double timeelapsed = fCheckTimeMPI();
      if(lbdm.rank == 0)
	    cout << left << setw(12) << timeelapsed << " ";
      fPrintSystemMomentum();
    }
    fInteractionForceZero();
    fConvectionForceBoussinesq(lbbousth, lbboustl);
    fCalcPotential_ShanChen();
    fInteractionForceShanChenQuadratic();
    fForceNonBlockCommunication();
    fCollisionMRTShanChen();
    fPostCollBoundary();
#ifdef _OPENMP
    fPropagationSwap();
#else
    fPropagationCombinedSwap();
#endif
    fPostPropBoundary();
    lbcurstep++;
  }
  while(lbcurstep<=lbtotstep);
  return 0;
}

// option 7: MRT with EDM forcing

int fMRTEDMShanChenQuadratic()
{
  do { 
    fNonBlockCommunication();
    if(lbcurstep%lbsave == 0 || lbcurstep==lbequstep) {
      if(lbequstep>0 && lbcurstep==lbequstep) {
        fPrintEndEquilibration();
        postequil = 1;
        fReadSpaceParameter();
        fBoundNonBlockCommunication();
        fNeighbourBoundary();
        fMarkBoundArea();
      }
      if(lbcurstep>=lbequstep)
        fOutput();
      if(lbdm.rank == 0)
	    cout << left << setw(12) << lbcurstep << " ";
      fPrintSystemMass();
      double timeelapsed = fCheckTimeMPI();
      if(lbdm.rank == 0)
	    cout << left << setw(12) << timeelapsed << " ";
      fPrintSystemMomentum();
    }
    fInteractionForceZero();
    fConvectionForceBoussinesq(lbbousth, lbboustl);
    fCalcPotential_ShanChen();
    fInteractionForceShanChenQuadratic();
    fForceNonBlockCommunication();
    fCollisionMRTEDMShanChen();
    fPostCollBoundary();
#ifdef _OPENMP
    fPropagationSwap();
#else
    fPropagationCombinedSwap();
#endif
    fPostPropBoundary();
    lbcurstep++;
  }
  while(lbcurstep<=lbtotstep);
  return 0;
}

// option 8: MRT with Guo-like forcing

int fMRTGuoShanChenQuadratic()
{
  do { 
    fNonBlockCommunication();
    if(lbcurstep%lbsave == 0 || lbcurstep==lbequstep) {
      if(lbequstep>0 && lbcurstep==lbequstep) {
        fPrintEndEquilibration();
        postequil = 1;
        fReadSpaceParameter();
        fBoundNonBlockCommunication();
        fNeighbourBoundary();
        fMarkBoundArea();
      }
      if(lbcurstep>=lbequstep)
        fOutput();
      if(lbdm.rank == 0)
	    cout << left << setw(12) << lbcurstep << " ";
      fPrintSystemMass();
      double timeelapsed = fCheckTimeMPI();
      if(lbdm.rank == 0)
	    cout << left << setw(12) << timeelapsed << " ";
      fPrintSystemMomentum();
    }
    fInteractionForceZero();
    fConvectionForceBoussinesq(lbbousth, lbboustl);
    fCalcPotential_ShanChen();
    fInteractionForceShanChenQuadratic();
    fForceNonBlockCommunication();
    fCollisionMRTGuoShanChen();
    fPostCollBoundary();
#ifdef _OPENMP
    fPropagationSwap();
#else
    fPropagationCombinedSwap();
#endif
    fPostPropBoundary();
    lbcurstep++;
  }
  while(lbcurstep<=lbtotstep);
  return 0;
}

// Lishchuk continuum-based interactions (with interfacial normals calculated non-locally)

// option 0: BGK with standard forcing

int fBGKLishchuk()
{
  do { 
    fNonBlockCommunication();
    if(lbcurstep%lbsave == 0 || lbcurstep==lbequstep) {
      if(lbequstep>0 && lbcurstep==lbequstep) {
        fPrintEndEquilibration();
        postequil = 1;
        fReadSpaceParameter();
        fBoundNonBlockCommunication();
        fNeighbourBoundary();
        fMarkBoundArea();
      }
      if(lbcurstep>=lbequstep)
        fOutput();
      if(lbdm.rank == 0)
	    cout << left << setw(12) << lbcurstep << " ";
      fPrintSystemMass();
      double timeelapsed = fCheckTimeMPI();
      if(lbdm.rank == 0)
	    cout << left << setw(12) << timeelapsed << " ";
      fPrintSystemMomentum();
    }
    fInteractionForceZero();
    fConvectionForceBoussinesq(lbbousth, lbboustl);
    fCalcPhaseIndex_Lishchuk();
    fIndexNonBlockCommunication();
    fInteractionForceLishchuk();
    fForceNonBlockCommunication();
    fCollisionBGKLishchuk();
    fPostCollBoundary();
#ifdef _OPENMP
    fPropagationSwap();
#else
    fPropagationCombinedSwap();
#endif
    fPostPropBoundary();
    lbcurstep++;
  }
  while(lbcurstep<=lbtotstep);
  return 0;
}

// option 1: BGK with EDM forcing

int fBGKEDMLishchuk()
{
  do { 
    fNonBlockCommunication();
    if(lbcurstep%lbsave == 0 || lbcurstep==lbequstep) {
      if(lbequstep>0 && lbcurstep==lbequstep) {
        fPrintEndEquilibration();
        postequil = 1;
        fReadSpaceParameter();
        fBoundNonBlockCommunication();
        fNeighbourBoundary();
        fMarkBoundArea();
      }
      if(lbcurstep>=lbequstep)
        fOutput();
      if(lbdm.rank == 0)
	    cout << left << setw(12) << lbcurstep << " ";
      fPrintSystemMass();
      double timeelapsed = fCheckTimeMPI();
      if(lbdm.rank == 0)
	    cout << left << setw(12) << timeelapsed << " ";
      fPrintSystemMomentum();
    }
    fInteractionForceZero();
    fConvectionForceBoussinesq(lbbousth, lbboustl);
    fCalcPhaseIndex_Lishchuk();
    fIndexNonBlockCommunication();
    fInteractionForceLishchuk();
    fForceNonBlockCommunication();
    fCollisionBGKEDMLishchuk();
    fPostCollBoundary();
#ifdef _OPENMP
    fPropagationSwap();
#else
    fPropagationCombinedSwap();
#endif
    fPostPropBoundary();
    lbcurstep++;
  }
  while(lbcurstep<=lbtotstep);
  return 0;
}

// option 2: BGK with Guo forcing

int fBGKGuoLishchuk()
{
  do { 
    fNonBlockCommunication();
    if(lbcurstep%lbsave == 0 || lbcurstep==lbequstep) {
      if(lbequstep>0 && lbcurstep==lbequstep) {
        fPrintEndEquilibration();
        postequil = 1;
        fReadSpaceParameter();
        fBoundNonBlockCommunication();
        fNeighbourBoundary();
        fMarkBoundArea();
      }
      if(lbcurstep>=lbequstep)
        fOutput();
      if(lbdm.rank == 0)
	    cout << left << setw(12) << lbcurstep << " ";
      fPrintSystemMass();
      double timeelapsed = fCheckTimeMPI();
      if(lbdm.rank == 0)
	    cout << left << setw(12) << timeelapsed << " ";
      fPrintSystemMomentum();
    }
    fInteractionForceZero();
    fConvectionForceBoussinesq(lbbousth, lbboustl);
    fCalcPhaseIndex_Lishchuk();
    fIndexNonBlockCommunication();
    fInteractionForceLishchuk();
    fForceNonBlockCommunication();
    fCollisionBGKGuoLishchuk();
    fPostCollBoundary();
#ifdef _OPENMP
    fPropagationSwap();
#else
    fPropagationCombinedSwap();
#endif
    fPostPropBoundary();
    lbcurstep++;
  }
  while(lbcurstep<=lbtotstep);
  return 0;
}

// option 3: TRT with standard forcing

int fTRTLishchuk()
{
  do { 
    fNonBlockCommunication();
    if(lbcurstep%lbsave == 0 || lbcurstep==lbequstep) {
      if(lbequstep>0 && lbcurstep==lbequstep) {
        fPrintEndEquilibration();
        postequil = 1;
        fReadSpaceParameter();
        fBoundNonBlockCommunication();
        fNeighbourBoundary();
        fMarkBoundArea();
      }
      if(lbcurstep>=lbequstep)
        fOutput();
      if(lbdm.rank == 0)
	    cout << left << setw(12) << lbcurstep << " ";
      fPrintSystemMass();
      double timeelapsed = fCheckTimeMPI();
      if(lbdm.rank == 0)
	    cout << left << setw(12) << timeelapsed << " ";
      fPrintSystemMomentum();
    }
    fInteractionForceZero();
    fConvectionForceBoussinesq(lbbousth, lbboustl);
    fCalcPhaseIndex_Lishchuk();
    fIndexNonBlockCommunication();
    fInteractionForceLishchuk();
    fForceNonBlockCommunication();
    fCollisionTRTLishchuk();
    fPostCollBoundary();
#ifdef _OPENMP
    fPropagationSwap();
#else
    fPropagationCombinedSwap();
#endif
    fPostPropBoundary();
    lbcurstep++;
  }
  while(lbcurstep<=lbtotstep);
  return 0;
}

// option 4: TRT with EDM forcing

int fTRTEDMLishchuk()
{
  do { 
    fNonBlockCommunication();
    if(lbcurstep%lbsave == 0 || lbcurstep==lbequstep) {
      if(lbequstep>0 && lbcurstep==lbequstep) {
        fPrintEndEquilibration();
        postequil = 1;
        fReadSpaceParameter();
        fBoundNonBlockCommunication();
        fNeighbourBoundary();
        fMarkBoundArea();
      }
      if(lbcurstep>=lbequstep)
        fOutput();
      if(lbdm.rank == 0)
	    cout << left << setw(12) << lbcurstep << " ";
      fPrintSystemMass();
      double timeelapsed = fCheckTimeMPI();
      if(lbdm.rank == 0)
	    cout << left << setw(12) << timeelapsed << " ";
      fPrintSystemMomentum();
    }
    fInteractionForceZero();
    fConvectionForceBoussinesq(lbbousth, lbboustl);
    fCalcPhaseIndex_Lishchuk();
    fIndexNonBlockCommunication();
    fInteractionForceLishchuk();
    fForceNonBlockCommunication();
    fCollisionTRTEDMLishchuk();
    fPostCollBoundary();
#ifdef _OPENMP
    fPropagationSwap();
#else
    fPropagationCombinedSwap();
#endif
    fPostPropBoundary();
    lbcurstep++;
  }
  while(lbcurstep<=lbtotstep);
  return 0;
}

// option 5: TRT with Guo forcing

int fTRTGuoLishchuk()
{
  do { 
    fNonBlockCommunication();
    if(lbcurstep%lbsave == 0 || lbcurstep==lbequstep) {
      if(lbequstep>0 && lbcurstep==lbequstep) {
        fPrintEndEquilibration();
        postequil = 1;
        fReadSpaceParameter();
        fBoundNonBlockCommunication();
        fNeighbourBoundary();
        fMarkBoundArea();
      }
      if(lbcurstep>=lbequstep)
        fOutput();
      if(lbdm.rank == 0)
	    cout << left << setw(12) << lbcurstep << " ";
      fPrintSystemMass();
      double timeelapsed = fCheckTimeMPI();
      if(lbdm.rank == 0)
	    cout << left << setw(12) << timeelapsed << " ";
      fPrintSystemMomentum();
    }
    fInteractionForceZero();
    fConvectionForceBoussinesq(lbbousth, lbboustl);
    fCalcPhaseIndex_Lishchuk();
    fIndexNonBlockCommunication();
    fInteractionForceLishchuk();
    fForceNonBlockCommunication();
    fCollisionTRTGuoLishchuk();
    fPostCollBoundary();
#ifdef _OPENMP
    fPropagationSwap();
#else
    fPropagationCombinedSwap();
#endif
    fPostPropBoundary();
    lbcurstep++;
  }
  while(lbcurstep<=lbtotstep);
  return 0;
}

// option 6: MRT with standard forcing

int fMRTLishchuk()
{
  do { 
    fNonBlockCommunication();
    if(lbcurstep%lbsave == 0 || lbcurstep==lbequstep) {
      if(lbequstep>0 && lbcurstep==lbequstep) {
        fPrintEndEquilibration();
        postequil = 1;
        fReadSpaceParameter();
        fBoundNonBlockCommunication();
        fNeighbourBoundary();
        fMarkBoundArea();
      }
      if(lbcurstep>=lbequstep)
        fOutput();
      if(lbdm.rank == 0)
	    cout << left << setw(12) << lbcurstep << " ";
      fPrintSystemMass();
      double timeelapsed = fCheckTimeMPI();
      if(lbdm.rank == 0)
	    cout << left << setw(12) << timeelapsed << " ";
      fPrintSystemMomentum();
    }
    fInteractionForceZero();
    fConvectionForceBoussinesq(lbbousth, lbboustl);
    fCalcPhaseIndex_Lishchuk();
    fIndexNonBlockCommunication();
    fInteractionForceLishchuk();
    fForceNonBlockCommunication();
    fCollisionMRTLishchuk();
    fPostCollBoundary();
#ifdef _OPENMP
    fPropagationSwap();
#else
    fPropagationCombinedSwap();
#endif
    fPostPropBoundary();
    lbcurstep++;
  }
  while(lbcurstep<=lbtotstep);
  return 0;
}

// option 7: MRT with EDM forcing

int fMRTEDMLishchuk()
{
  do { 
    fNonBlockCommunication();
    if(lbcurstep%lbsave == 0 || lbcurstep==lbequstep) {
      if(lbequstep>0 && lbcurstep==lbequstep) {
        fPrintEndEquilibration();
        postequil = 1;
        fReadSpaceParameter();
        fBoundNonBlockCommunication();
        fNeighbourBoundary();
        fMarkBoundArea();
      }
      if(lbcurstep>=lbequstep)
        fOutput();
      if(lbdm.rank == 0)
	    cout << left << setw(12) << lbcurstep << " ";
      fPrintSystemMass();
      double timeelapsed = fCheckTimeMPI();
      if(lbdm.rank == 0)
	    cout << left << setw(12) << timeelapsed << " ";
      fPrintSystemMomentum();
    }
    fInteractionForceZero();
    fConvectionForceBoussinesq(lbbousth, lbboustl);
    fCalcPhaseIndex_Lishchuk();
    fIndexNonBlockCommunication();
    fInteractionForceLishchuk();
    fForceNonBlockCommunication();
    fCollisionMRTEDMLishchuk();
    fPostCollBoundary();
#ifdef _OPENMP
    fPropagationSwap();
#else
    fPropagationCombinedSwap();
#endif
    fPostPropBoundary();
    lbcurstep++;
  }
  while(lbcurstep<=lbtotstep);
  return 0;
}

// option 8: MRT with Guo-like forcing

int fMRTGuoLishchuk()
{
  do { 
    fNonBlockCommunication();
    if(lbcurstep%lbsave == 0 || lbcurstep==lbequstep) {
      if(lbequstep>0 && lbcurstep==lbequstep) {
        fPrintEndEquilibration();
        postequil = 1;
        fReadSpaceParameter();
        fBoundNonBlockCommunication();
        fNeighbourBoundary();
        fMarkBoundArea();
      }
      if(lbcurstep>=lbequstep)
        fOutput();
      if(lbdm.rank == 0)
	    cout << left << setw(12) << lbcurstep << " ";
      fPrintSystemMass();
      double timeelapsed = fCheckTimeMPI();
      if(lbdm.rank == 0)
	    cout << left << setw(12) << timeelapsed << " ";
      fPrintSystemMomentum();
    }
    fInteractionForceZero();
    fConvectionForceBoussinesq(lbbousth, lbboustl);
    fCalcPhaseIndex_Lishchuk();
    fIndexNonBlockCommunication();
    fInteractionForceLishchuk();
    fForceNonBlockCommunication();
    fCollisionMRTGuoLishchuk();
    fPostCollBoundary();
#ifdef _OPENMP
    fPropagationSwap();
#else
    fPropagationCombinedSwap();
#endif
    fPostPropBoundary();
    lbcurstep++;
  }
  while(lbcurstep<=lbtotstep);
  return 0;
}

// Lishchuk continuum-based interactions (with interfacial normals calculated locally)

// option 0: BGK with standard forcing

int fBGKLishchukLocal()
{
  do { 
    fNonBlockCommunication();
    if(lbcurstep%lbsave == 0 || lbcurstep==lbequstep) {
      if(lbequstep>0 && lbcurstep==lbequstep) {
        fPrintEndEquilibration();
        postequil = 1;
        fReadSpaceParameter();
        fBoundNonBlockCommunication();
        fNeighbourBoundary();
        fMarkBoundArea();
      }
      if(lbcurstep>=lbequstep)
        fOutput();
      if(lbdm.rank == 0)
	    cout << left << setw(12) << lbcurstep << " ";
      fPrintSystemMass();
      double timeelapsed = fCheckTimeMPI();
      if(lbdm.rank == 0)
	    cout << left << setw(12) << timeelapsed << " ";
      fPrintSystemMomentum();
    }
    fInteractionForceZero();
    fConvectionForceBoussinesq(lbbousth, lbboustl);
    fCalcPhaseIndex_LishchukLocal();
    fCollisionBGKLishchukLocal();
    fPostCollBoundary();
#ifdef _OPENMP
    fPropagationSwap();
#else
    fPropagationCombinedSwap();
#endif
    fPostPropBoundary();
    lbcurstep++;
  }
  while(lbcurstep<=lbtotstep);
  return 0;
}

// option 1: BGK with EDM forcing

int fBGKEDMLishchukLocal()
{
  do { 
    fNonBlockCommunication();
    if(lbcurstep%lbsave == 0 || lbcurstep==lbequstep) {
      if(lbequstep>0 && lbcurstep==lbequstep) {
        fPrintEndEquilibration();
        postequil = 1;
        fReadSpaceParameter();
        fBoundNonBlockCommunication();
        fNeighbourBoundary();
        fMarkBoundArea();
      }
      if(lbcurstep>=lbequstep)
        fOutput();
      if(lbdm.rank == 0)
	    cout << left << setw(12) << lbcurstep << " ";
      fPrintSystemMass();
      double timeelapsed = fCheckTimeMPI();
      if(lbdm.rank == 0)
	    cout << left << setw(12) << timeelapsed << " ";
      fPrintSystemMomentum();
    }
    fInteractionForceZero();
    fConvectionForceBoussinesq(lbbousth, lbboustl);
    fCalcPhaseIndex_LishchukLocal();
    fCollisionBGKEDMLishchukLocal();
    fPostCollBoundary();
#ifdef _OPENMP
    fPropagationSwap();
#else
    fPropagationCombinedSwap();
#endif
    fPostPropBoundary();
    lbcurstep++;
  }
  while(lbcurstep<=lbtotstep);
  return 0;
}

// option 2: BGK with Guo forcing

int fBGKGuoLishchukLocal()
{
  do { 
    fNonBlockCommunication();
    if(lbcurstep%lbsave == 0 || lbcurstep==lbequstep) {
      if(lbequstep>0 && lbcurstep==lbequstep) {
        fPrintEndEquilibration();
        postequil = 1;
        fReadSpaceParameter();
        fBoundNonBlockCommunication();
        fNeighbourBoundary();
        fMarkBoundArea();
      }
      if(lbcurstep>=lbequstep)
        fOutput();
      if(lbdm.rank == 0)
	    cout << left << setw(12) << lbcurstep << " ";
      fPrintSystemMass();
      double timeelapsed = fCheckTimeMPI();
      if(lbdm.rank == 0)
	    cout << left << setw(12) << timeelapsed << " ";
      fPrintSystemMomentum();
    }
    fInteractionForceZero();
    fConvectionForceBoussinesq(lbbousth, lbboustl);
    fCalcPhaseIndex_LishchukLocal();
    fCollisionBGKGuoLishchukLocal();
    fPostCollBoundary();
#ifdef _OPENMP
    fPropagationSwap();
#else
    fPropagationCombinedSwap();
#endif
    fPostPropBoundary();
    lbcurstep++;
  }
  while(lbcurstep<=lbtotstep);
  return 0;
}

// option 3: TRT with standard forcing

int fTRTLishchukLocal()
{
  do { 
    fNonBlockCommunication();
    if(lbcurstep%lbsave == 0 || lbcurstep==lbequstep) {
      if(lbequstep>0 && lbcurstep==lbequstep) {
        fPrintEndEquilibration();
        postequil = 1;
        fReadSpaceParameter();
        fBoundNonBlockCommunication();
        fNeighbourBoundary();
        fMarkBoundArea();
      }
      if(lbcurstep>=lbequstep)
        fOutput();
      if(lbdm.rank == 0)
	    cout << left << setw(12) << lbcurstep << " ";
      fPrintSystemMass();
      double timeelapsed = fCheckTimeMPI();
      if(lbdm.rank == 0)
	    cout << left << setw(12) << timeelapsed << " ";
      fPrintSystemMomentum();
    }
    fInteractionForceZero();
    fConvectionForceBoussinesq(lbbousth, lbboustl);
    fCalcPhaseIndex_LishchukLocal();
    fCollisionTRTLishchukLocal();
    fPostCollBoundary();
#ifdef _OPENMP
    fPropagationSwap();
#else
    fPropagationCombinedSwap();
#endif
    fPostPropBoundary();
    lbcurstep++;
  }
  while(lbcurstep<=lbtotstep);
  return 0;
}

// option 4: TRT with EDM forcing

int fTRTEDMLishchukLocal()
{
  do { 
    fNonBlockCommunication();
    if(lbcurstep%lbsave == 0 || lbcurstep==lbequstep) {
      if(lbequstep>0 && lbcurstep==lbequstep) {
        fPrintEndEquilibration();
        postequil = 1;
        fReadSpaceParameter();
        fBoundNonBlockCommunication();
        fNeighbourBoundary();
        fMarkBoundArea();
      }
      if(lbcurstep>=lbequstep)
        fOutput();
      if(lbdm.rank == 0)
	    cout << left << setw(12) << lbcurstep << " ";
      fPrintSystemMass();
      double timeelapsed = fCheckTimeMPI();
      if(lbdm.rank == 0)
	    cout << left << setw(12) << timeelapsed << " ";
      fPrintSystemMomentum();
    }
    fInteractionForceZero();
    fConvectionForceBoussinesq(lbbousth, lbboustl);
    fCalcPhaseIndex_LishchukLocal();
    fCollisionTRTEDMLishchukLocal();
    fPostCollBoundary();
#ifdef _OPENMP
    fPropagationSwap();
#else
    fPropagationCombinedSwap();
#endif
    fPostPropBoundary();
    lbcurstep++;
  }
  while(lbcurstep<=lbtotstep);
  return 0;
}

// option 5: TRT with Guo forcing

int fTRTGuoLishchukLocal()
{
  do { 
    fNonBlockCommunication();
    if(lbcurstep%lbsave == 0 || lbcurstep==lbequstep) {
      if(lbequstep>0 && lbcurstep==lbequstep) {
        fPrintEndEquilibration();
        postequil = 1;
        fReadSpaceParameter();
        fBoundNonBlockCommunication();
        fNeighbourBoundary();
        fMarkBoundArea();
      }
      if(lbcurstep>=lbequstep)
        fOutput();
      if(lbdm.rank == 0)
	    cout << left << setw(12) << lbcurstep << " ";
      fPrintSystemMass();
      double timeelapsed = fCheckTimeMPI();
      if(lbdm.rank == 0)
	    cout << left << setw(12) << timeelapsed << " ";
      fPrintSystemMomentum();
    }
    fInteractionForceZero();
    fConvectionForceBoussinesq(lbbousth, lbboustl);
    fCalcPhaseIndex_LishchukLocal();
    fCollisionTRTGuoLishchukLocal();
    fPostCollBoundary();
#ifdef _OPENMP
    fPropagationSwap();
#else
    fPropagationCombinedSwap();
#endif
    fPostPropBoundary();
    lbcurstep++;
  }
  while(lbcurstep<=lbtotstep);
  return 0;
}

// option 6: MRT with standard forcing

int fMRTLishchukLocal()
{
  do { 
    fNonBlockCommunication();
    if(lbcurstep%lbsave == 0 || lbcurstep==lbequstep) {
      if(lbequstep>0 && lbcurstep==lbequstep) {
        fPrintEndEquilibration();
        postequil = 1;
        fReadSpaceParameter();
        fBoundNonBlockCommunication();
        fNeighbourBoundary();
        fMarkBoundArea();
      }
      if(lbcurstep>=lbequstep)
        fOutput();
      if(lbdm.rank == 0)
	    cout << left << setw(12) << lbcurstep << " ";
      fPrintSystemMass();
      double timeelapsed = fCheckTimeMPI();
      if(lbdm.rank == 0)
	    cout << left << setw(12) << timeelapsed << " ";
      fPrintSystemMomentum();
    }
    fInteractionForceZero();
    fConvectionForceBoussinesq(lbbousth, lbboustl);
    fCalcPhaseIndex_LishchukLocal();
    fCollisionMRTLishchukLocal();
    fPostCollBoundary();
#ifdef _OPENMP
    fPropagationSwap();
#else
    fPropagationCombinedSwap();
#endif
    fPostPropBoundary();
    lbcurstep++;
  }
  while(lbcurstep<=lbtotstep);
  return 0;
}

// option 7: MRT with EDM forcing

int fMRTEDMLishchukLocal()
{
  do { 
    fNonBlockCommunication();
    if(lbcurstep%lbsave == 0 || lbcurstep==lbequstep) {
      if(lbequstep>0 && lbcurstep==lbequstep) {
        fPrintEndEquilibration();
        postequil = 1;
        fReadSpaceParameter();
        fBoundNonBlockCommunication();
        fNeighbourBoundary();
        fMarkBoundArea();
      }
      if(lbcurstep>=lbequstep)
        fOutput();
      if(lbdm.rank == 0)
	    cout << left << setw(12) << lbcurstep << " ";
      fPrintSystemMass();
      double timeelapsed = fCheckTimeMPI();
      if(lbdm.rank == 0)
	    cout << left << setw(12) << timeelapsed << " ";
      fPrintSystemMomentum();
    }
    fInteractionForceZero();
    fConvectionForceBoussinesq(lbbousth, lbboustl);
    fCalcPhaseIndex_LishchukLocal();
    fCollisionMRTEDMLishchukLocal();
    fPostCollBoundary();
#ifdef _OPENMP
    fPropagationSwap();
#else
    fPropagationCombinedSwap();
#endif
    fPostPropBoundary();
    lbcurstep++;
  }
  while(lbcurstep<=lbtotstep);
  return 0;
}

// option 8: MRT with Guo-like forcing

int fMRTGuoLishchukLocal()
{
  do { 
    fNonBlockCommunication();
    if(lbcurstep%lbsave == 0 || lbcurstep==lbequstep) {
      if(lbequstep>0 && lbcurstep==lbequstep) {
        fPrintEndEquilibration();
        postequil = 1;
        fReadSpaceParameter();
        fBoundNonBlockCommunication();
        fNeighbourBoundary();
        fMarkBoundArea();
      }
      if(lbcurstep>=lbequstep)
        fOutput();
      if(lbdm.rank == 0)
	    cout << left << setw(12) << lbcurstep << " ";
      fPrintSystemMass();
      double timeelapsed = fCheckTimeMPI();
      if(lbdm.rank == 0)
	    cout << left << setw(12) << timeelapsed << " ";
      fPrintSystemMomentum();
    }
    fInteractionForceZero();
    fConvectionForceBoussinesq(lbbousth, lbboustl);
    fCalcPhaseIndex_LishchukLocal();
    fCollisionMRTGuoLishchukLocal();
    fPostCollBoundary();
#ifdef _OPENMP
    fPropagationSwap();
#else
    fPropagationCombinedSwap();
#endif
    fPostPropBoundary();
    lbcurstep++;
  }
  while(lbcurstep<=lbtotstep);
  return 0;
}

// Swift free-energy interactions

// option 0: BGK with standard forcing

int fBGKSwift()
{
  do { 
    fNonBlockCommunication();
    if(lbcurstep%lbsave == 0 || lbcurstep==lbequstep) {
      if(lbequstep>0 && lbcurstep==lbequstep) {
        fPrintEndEquilibration();
        postequil = 1;
        fReadSpaceParameter();
        fBoundNonBlockCommunication();
        fNeighbourBoundary();
        fMarkBoundArea();
      }
      if(lbcurstep>=lbequstep)
        fOutput();
      if(lbdm.rank == 0)
	    cout << left << setw(12) << lbcurstep << " ";
      fPrintSystemMass();
      double timeelapsed = fCheckTimeMPI();
      if(lbdm.rank == 0)
	    cout << left << setw(12) << timeelapsed << " ";
      fPrintSystemMomentum();
    }
    fInteractionForceZero();
    fConvectionForceBoussinesq(lbbousth, lbboustl);
    fCalcGradient_Swift();
    fIndexNonBlockCommunication();
    fCollisionBGKSwift();
    fPostCollBoundary();
#ifdef _OPENMP
    fPropagationSwap();
#else
    fPropagationCombinedSwap();
#endif
    fPostPropBoundary();
    lbcurstep++;
  }
  while(lbcurstep<=lbtotstep);
  return 0;
}

// option 1: BGK with EDM forcing

int fBGKEDMSwift()
{
  do { 
    fNonBlockCommunication();
    if(lbcurstep%lbsave == 0 || lbcurstep==lbequstep) {
      if(lbequstep>0 && lbcurstep==lbequstep) {
        fPrintEndEquilibration();
        postequil = 1;
        fReadSpaceParameter();
        fBoundNonBlockCommunication();
        fNeighbourBoundary();
        fMarkBoundArea();
      }
      if(lbcurstep>=lbequstep)
        fOutput();
      if(lbdm.rank == 0)
	    cout << left << setw(12) << lbcurstep << " ";
      fPrintSystemMass();
      double timeelapsed = fCheckTimeMPI();
      if(lbdm.rank == 0)
	    cout << left << setw(12) << timeelapsed << " ";
      fPrintSystemMomentum();
    }
    fInteractionForceZero();
    fConvectionForceBoussinesq(lbbousth, lbboustl);
    fCalcGradient_Swift();
    fIndexNonBlockCommunication();
    fCollisionBGKEDMSwift();
    fPostCollBoundary();
#ifdef _OPENMP
    fPropagationSwap();
#else
    fPropagationCombinedSwap();
#endif
    fPostPropBoundary();
    lbcurstep++;
  }
  while(lbcurstep<=lbtotstep);
  return 0;
}

// option 2: BGK with Guo forcing

int fBGKGuoSwift()
{
  do { 
    fNonBlockCommunication();
    if(lbcurstep%lbsave == 0 || lbcurstep==lbequstep) {
      if(lbequstep>0 && lbcurstep==lbequstep) {
        fPrintEndEquilibration();
        postequil = 1;
        fReadSpaceParameter();
        fBoundNonBlockCommunication();
        fNeighbourBoundary();
        fMarkBoundArea();
      }
      if(lbcurstep>=lbequstep)
        fOutput();
      if(lbdm.rank == 0)
	    cout << left << setw(12) << lbcurstep << " ";
      fPrintSystemMass();
      double timeelapsed = fCheckTimeMPI();
      if(lbdm.rank == 0)
	    cout << left << setw(12) << timeelapsed << " ";
      fPrintSystemMomentum();
    }
    fInteractionForceZero();
    fConvectionForceBoussinesq(lbbousth, lbboustl);
    fCalcGradient_Swift();
    fIndexNonBlockCommunication();
    fCollisionBGKGuoLishchuk();
    fPostCollBoundary();
#ifdef _OPENMP
    fPropagationSwap();
#else
    fPropagationCombinedSwap();
#endif
    fPostPropBoundary();
    lbcurstep++;
  }
  while(lbcurstep<=lbtotstep);
  return 0;
}

// option 3: TRT with standard forcing

int fTRTSwift()
{
  do { 
    fNonBlockCommunication();
    if(lbcurstep%lbsave == 0 || lbcurstep==lbequstep) {
      if(lbequstep>0 && lbcurstep==lbequstep) {
        fPrintEndEquilibration();
        postequil = 1;
        fReadSpaceParameter();
        fBoundNonBlockCommunication();
        fNeighbourBoundary();
        fMarkBoundArea();
      }
      if(lbcurstep>=lbequstep)
        fOutput();
      if(lbdm.rank == 0)
	    cout << left << setw(12) << lbcurstep << " ";
      fPrintSystemMass();
      double timeelapsed = fCheckTimeMPI();
      if(lbdm.rank == 0)
	    cout << left << setw(12) << timeelapsed << " ";
      fPrintSystemMomentum();
    }
    fInteractionForceZero();
    fConvectionForceBoussinesq(lbbousth, lbboustl);
    fCalcGradient_Swift();
    fIndexNonBlockCommunication();
    fCollisionTRTSwift();
    fPostCollBoundary();
#ifdef _OPENMP
    fPropagationSwap();
#else
    fPropagationCombinedSwap();
#endif
    fPostPropBoundary();
    lbcurstep++;
  }
  while(lbcurstep<=lbtotstep);
  return 0;
}

// option 4: TRT with EDM forcing

int fTRTEDMSwift()
{
  do { 
    fNonBlockCommunication();
    if(lbcurstep%lbsave == 0 || lbcurstep==lbequstep) {
      if(lbequstep>0 && lbcurstep==lbequstep) {
        fPrintEndEquilibration();
        postequil = 1;
        fReadSpaceParameter();
        fBoundNonBlockCommunication();
        fNeighbourBoundary();
        fMarkBoundArea();
      }
      if(lbcurstep>=lbequstep)
        fOutput();
      if(lbdm.rank == 0)
	    cout << left << setw(12) << lbcurstep << " ";
      fPrintSystemMass();
      double timeelapsed = fCheckTimeMPI();
      if(lbdm.rank == 0)
	    cout << left << setw(12) << timeelapsed << " ";
      fPrintSystemMomentum();
    }
    fInteractionForceZero();
    fConvectionForceBoussinesq(lbbousth, lbboustl);
    fCalcGradient_Swift();
    fIndexNonBlockCommunication();
    fCollisionTRTEDMSwift();
    fPostCollBoundary();
#ifdef _OPENMP
    fPropagationSwap();
#else
    fPropagationCombinedSwap();
#endif
    fPostPropBoundary();
    lbcurstep++;
  }
  while(lbcurstep<=lbtotstep);
  return 0;
}

// option 5: TRT with Guo forcing

int fTRTGuoSwift()
{
  do { 
    fNonBlockCommunication();
    if(lbcurstep%lbsave == 0 || lbcurstep==lbequstep) {
      if(lbequstep>0 && lbcurstep==lbequstep) {
        fPrintEndEquilibration();
        postequil = 1;
        fReadSpaceParameter();
        fBoundNonBlockCommunication();
        fNeighbourBoundary();
        fMarkBoundArea();
      }
      if(lbcurstep>=lbequstep)
        fOutput();
      if(lbdm.rank == 0)
	    cout << left << setw(12) << lbcurstep << " ";
      fPrintSystemMass();
      double timeelapsed = fCheckTimeMPI();
      if(lbdm.rank == 0)
	    cout << left << setw(12) << timeelapsed << " ";
      fPrintSystemMomentum();
    }
    fInteractionForceZero();
    fConvectionForceBoussinesq(lbbousth, lbboustl);
    fCalcGradient_Swift();
    fIndexNonBlockCommunication();
    fCollisionTRTGuoSwift();
    fPostCollBoundary();
#ifdef _OPENMP
    fPropagationSwap();
#else
    fPropagationCombinedSwap();
#endif
    fPostPropBoundary();
    lbcurstep++;
  }
  while(lbcurstep<=lbtotstep);
  return 0;
}

// option 6: MRT with standard forcing

int fMRTSwift()
{
  do { 
    fNonBlockCommunication();
    if(lbcurstep%lbsave == 0 || lbcurstep==lbequstep) {
      if(lbequstep>0 && lbcurstep==lbequstep) {
        fPrintEndEquilibration();
        postequil = 1;
        fReadSpaceParameter();
        fBoundNonBlockCommunication();
        fNeighbourBoundary();
        fMarkBoundArea();
      }
      if(lbcurstep>=lbequstep)
        fOutput();
      if(lbdm.rank == 0)
	    cout << left << setw(12) << lbcurstep << " ";
      fPrintSystemMass();
      double timeelapsed = fCheckTimeMPI();
      if(lbdm.rank == 0)
	    cout << left << setw(12) << timeelapsed << " ";
      fPrintSystemMomentum();
    }
    fInteractionForceZero();
    fConvectionForceBoussinesq(lbbousth, lbboustl);
    fCalcGradient_Swift();
    fIndexNonBlockCommunication();
    fCollisionMRTSwift();
    fPostCollBoundary();
#ifdef _OPENMP
    fPropagationSwap();
#else
    fPropagationCombinedSwap();
#endif
    fPostPropBoundary();
    lbcurstep++;
  }
  while(lbcurstep<=lbtotstep);
  return 0;
}

// option 7: MRT with EDM forcing

int fMRTEDMSwift()
{
  do { 
    fNonBlockCommunication();
    if(lbcurstep%lbsave == 0 || lbcurstep==lbequstep) {
      if(lbequstep>0 && lbcurstep==lbequstep) {
        fPrintEndEquilibration();
        postequil = 1;
        fReadSpaceParameter();
        fBoundNonBlockCommunication();
        fNeighbourBoundary();
        fMarkBoundArea();
      }
      if(lbcurstep>=lbequstep)
        fOutput();
      if(lbdm.rank == 0)
	    cout << left << setw(12) << lbcurstep << " ";
      fPrintSystemMass();
      double timeelapsed = fCheckTimeMPI();
      if(lbdm.rank == 0)
	    cout << left << setw(12) << timeelapsed << " ";
      fPrintSystemMomentum();
    }
    fInteractionForceZero();
    fConvectionForceBoussinesq(lbbousth, lbboustl);
    fCalcGradient_Swift();
    fIndexNonBlockCommunication();
    fCollisionMRTEDMSwift();
    fPostCollBoundary();
#ifdef _OPENMP
    fPropagationSwap();
#else
    fPropagationCombinedSwap();
#endif
    fPostPropBoundary();
    lbcurstep++;
  }
  while(lbcurstep<=lbtotstep);
  return 0;
}

// option 8: MRT with Guo-like forcing

int fMRTGuoSwift()
{
  do { 
    fNonBlockCommunication();
    if(lbcurstep%lbsave == 0 || lbcurstep==lbequstep) {
      if(lbequstep>0 && lbcurstep==lbequstep) {
        fPrintEndEquilibration();
        postequil = 1;
        fReadSpaceParameter();
        fBoundNonBlockCommunication();
        fNeighbourBoundary();
        fMarkBoundArea();
      }
      if(lbcurstep>=lbequstep)
        fOutput();
      if(lbdm.rank == 0)
	    cout << left << setw(12) << lbcurstep << " ";
      fPrintSystemMass();
      double timeelapsed = fCheckTimeMPI();
      if(lbdm.rank == 0)
	    cout << left << setw(12) << timeelapsed << " ";
      fPrintSystemMomentum();
    }
    fInteractionForceZero();
    fConvectionForceBoussinesq(lbbousth, lbboustl);
    fCalcGradient_Swift();
    fIndexNonBlockCommunication();
    fCollisionMRTGuoSwift();
    fPostCollBoundary();
#ifdef _OPENMP
    fPropagationSwap();
#else
    fPropagationCombinedSwap();
#endif
    fPostPropBoundary();
    lbcurstep++;
  }
  while(lbcurstep<=lbtotstep);
  return 0;
}

