#include <iostream>
#include <iomanip>
#include <fstream>
#include <string>
#include <cstring>
#include <cstdlib>
#include <stdio.h>
#include <sys/stat.h>
using namespace std;
int outtype,numfluid,numsolute,numtemp;

/***********************************************
 *   DL_MESO       Version 1.4                 *
 *   Authors   :   R. S. Qin, M. A. Seaton     *
 *   Copyright :   STFC Daresbury Laboratory   *
 *             :   27/08/2015                  *
 ***********************************************/

class cGatherData
{

  // creates parallel VTK files (lbtout%.4d.pvts) to link files created by
  // individual processes (lbout*.vts), where %.4d is the saved time step

  // the data structure follows the VTK XML standard for structured grids
  
public:

  cGatherData()
    {

      getsize();
      gatherallVTK();

    }

  ~cGatherData()
    {

    }

  int getsize();

  int gatherallVTK();
  
protected:

  int sizeofint;

  int sizeofsys;

  int sizeofver;

  int ntx, nty, ntz;

  int *xs, *xe, *ys, *ye, *zs, *ze;

};


int cGatherData::getsize()
{

  // this procedure is required to avoid mismatches caused by different 
  // machines

  char buf[80];
  char issue[22];
  double value;
  int x1, x2, y1, y2, z1, z2;
  int j=0;

  if (outtype<0 || outtype>4) 
    {
      cout<<"Which output type was produced?"<<endl;
      cout<<"(0 = all, 1 = density, 2 = mass fraction, 3 = solute concentration, 4 = temperature)"<<endl;
      while (outtype<0 || outtype>4)
        {
          cin >> outtype;
        }
    }

  ifstream myfile("lbout.info");

  if(!myfile)
    {
      cout<<"error opening "<<"lbout.info"<<" file\n"; 
      exit(1);
    }

  while (!myfile.eof() && j<5)
    {

      myfile >> issue >> x1;

      if(!strcmp(issue, "sizeofSystem")) {
        sizeofsys = int(x1);
        j++;
      }
      else if(!strcmp(issue, "sizeofInteger")) {
        sizeofint = int(x1);
        j++;
      }
      else if(!strcmp(issue, "numberofFluids")) {
        numfluid = int(x1);
        j++;
      }
      else if(!strcmp(issue, "numberofSolutes")) {
        numsolute = int(x1);
        j++;
      }
      else if(!strcmp(issue, "numberofTemperatures")) {
        numtemp = int(x1);
        j++;
      }
    }

  myfile.close();

  xs=new int[sizeofsys];
  xe=new int[sizeofsys];
  ys=new int[sizeofsys];
  ye=new int[sizeofsys];
  zs=new int[sizeofsys];
  ze=new int[sizeofsys];

  //  this procedure can deal with unequal numbers of grid points among
  //  processes

  struct stat results;

  for(int i=0; i<sizeofsys; i++)
    {
      sprintf(buf, "lbout%.6dat000000.vts", i);

      if(stat(buf, &results) != 0) {
        cout<<"error opening "<<buf<<" file\n";
        exit(1);
      }

    }

  //  work out the number of VTK-files available

  int i=0;
  
  while(1)
    {

      sprintf(buf, "lbout000000at%.6d.vts", i);

      ifstream myfile(buf);

      if(!myfile)
        {
          sizeofver = i;
          break;
        }
      
      i++;
      
    }

  //  determine sizes of extents for pieces and entire system

  ifstream myfile1("lbout.ext");

  if(!myfile1)
    {
      cout<<"error opening "<<"lbout.ext"<<" file\n"; 
      exit(1);
    }

  ntx = 0;
  nty = 0;
  ntz = 0;

  while (!myfile1.eof())
    {
      myfile1 >> issue >> x1 >> x2 >> y1 >> y2 >> z1 >> z2;
      for(int i=0; i<sizeofsys; i++) {
        sprintf(buf, "extent_%.6d", i);
        if(!strcmp(issue, buf)) {
          xs[i] = x1;
          xe[i] = x2;
          ys[i] = y1;
          ye[i] = y2;
          zs[i] = z1;
          ze[i] = z2;
          if(x2>ntx)
            ntx = x2;
          if(y2>nty)
            nty = y2;
          if(z2>ntz)
            ntz = z2;
        } 

      }
      
    }

  myfile1.close();

  return 0;
  
}


int cGatherData::gatherallVTK()
{

  // write .pvts file for each timestep

  char namebuf[80];

  for(int k=0; k<sizeofver; k++) {

    sprintf(namebuf, "lbtout%.6d.pvts", k);

    ofstream ofile(namebuf);

    ofile<<"<?xml version=\"1.0\"?>"<<endl;
    ofile<<"<VTKFile type=\"PStructuredGrid\" version=\"0.1\" byte_order=\"BigEndian\">"<<endl;
    ofile<<"<PStructuredGrid WholeExtent=\"0 "<<ntx<<" 0 "<<nty<<" 0 "<<ntz<<"\" GhostLevel=\"1\">"<<endl;
    ofile<<"<PPointData Scalars=\"phase_field\" Vectors=\"velocity\">"<<endl;

    if (outtype==0) {
      for(int iprop=0; iprop<numfluid; iprop++)
        ofile<<"<PDataArray Name=\"density_"<<iprop<<"\" type=\"Float32\"/>"<<endl;
      for(int iprop=0; iprop<numfluid; iprop++)
        ofile<<"<PDataArray Name=\"fraction_"<<iprop<<"\" type=\"Float32\"/>"<<endl;
      for(int iprop=0; iprop<numsolute; iprop++)
        ofile<<"<PDataArray Name=\"concentration_"<<iprop<<"\" type=\"Float32\"/>"<<endl;
      if(numtemp==1)
        ofile<<"<PDataArray Name=\"temperature\" type=\"Float32\"/>"<<endl;
    }
    else if (outtype==1)
      ofile<<"<PDataArray Name=\"density\" type=\"Float32\"/>"<<endl;
    else if (outtype==2)
      ofile<<"<PDataArray Name=\"fraction\" type=\"Float32\"/>"<<endl;
    else if (outtype==3)
      ofile<<"<PDataArray Name=\"concentration\" type=\"Float32\"/>"<<endl;
    else
      ofile<<"<PDataArray Name=\"temperature\" type=\"Float32\"/>"<<endl;

    ofile<<"<PDataArray Name=\"velocity\" type=\"Float32\" NumberOfComponents=\"3\"/>"<<endl;
    ofile<<"<PDataArray Name=\"phase_field\" type=\"Int32\"/>"<<endl;
    ofile<<"</PPointData>"<<endl;
    ofile<<"<PPoints>"<<endl;
    ofile<<"<PDataArray type=\"Float32\" NumberOfComponents=\"3\"/>"<<endl;
    ofile<<"</PPoints>"<<endl;

    for(int i=0; i<sizeofsys; i++) {
      ofile<<"<Piece Extent=\""<<xs[i]<<" "<<xe[i]<<" "<<ys[i]<<" "<<ye[i]<<" "<<zs[i]<<" "<<ze[i]
           <<"\" Source=\"lbout"<<setw(6)<<setfill('0')<<i<<"at"<<setw(6)<<setfill('0')<<k<<".vts\"/>"<<endl;
    }

    ofile<<"</PStructuredGrid>"<<endl;
    ofile<<"</VTKFile>"<<endl;
    ofile.close();

  }

  return 0;
}


int main(int argc, char* argv[])
{
  outtype=-1;
  if (argc>1)
    outtype = atoi(argv[1]);

  cGatherData aa;

  return 0;
}
