#include <iostream>
#include <fstream>
#include <string>
#include <cstring>
#include <cstdlib>
#include <stdio.h>
#include <sys/stat.h>

using namespace std;
int fCppMod(int, int);
template <class T> void fSwapPair ( T&, T& );

/***********************************************
 *   DL_MESO       Version 2.6                 *
 *   Authors   :   R. S. Qin, M. A. Seaton     *
 *   Copyright :   STFC Daresbury Laboratory   *
 *             :   03/12/2012                  *
 *   Utility to add fluid drops, solute and    *
 *   temperature sources to LBE simulations    *
 *   in lbin.init files                        *
 ***********************************************/
int main(int argc, char* argv[])
{

  char issue[30];
  char value[30];
  char str1[30];

  int nd,nf,nc,nt,pf,nx,ny,nz;
  long int ngrid;
 
  double lbiniv[3];
  double* lbincp;
  double* lbinip;

  double* lbinic;

  double lbinit;

  double* rho;
  double* conc;
  double* temp;
  double* vx;
  double* vy;
  double* vz;
  int* change;

  int contfluid;
  int deffluid;
  int numdrop;
  int fluiddrop;
  int xs,xe,ys,ye,zs,ze,dx,dy,dz;
  long int pos;
  double radius,det,rho0;
  double x0,y0,z0;

  // read lbin.sys file for system parameters

  ifstream myfile;
  myfile.open("lbin.sys", ios::in);

  if(!myfile)
    {
      printf("error opening system file\n");
      exit(1);
    }

  while (!myfile.eof())
    {

      myfile >> issue >> value;

      if(!strcmp(issue, "space_dimension")) 
	nd = atoi(value);
      else if(!strcmp(issue, "number_of_fluid")) 
	nf = atoi(value);
      else if(!strcmp(issue, "number_of_solute"))
	nc = atoi(value);
      else if(!strcmp(issue, "temperature_scalar"))
	nt = atoi(value);
      else if(!strcmp(issue, "phase_field"))
	pf = atoi(value);
      else if(!strcmp(issue, "grid_number_x"))
	nx = atoi(value);
      else if(!strcmp(issue, "grid_number_y"))
	ny = atoi(value);
      else if(!strcmp(issue, "grid_number_z"))
	nz = atoi(value);

    }

  if((nd == 2) && (nz != 1))
    nz = 1;  

  // allocate arrays for fluid densities and solute concentrations

  if(nf != 0) {
    lbincp = new double[nf];
    lbinip = new double[nf];
    for(int i=0; i< nf; i++) {
      lbincp[i] = 0;
      lbinip[i] = 0;
    }
  }

  if(nc != 0) {
    lbinic = new double[nc];
    for(int i=0; i< nc; i++) {
      lbinic[i] = 0;
    }
  }

  for(int i=0; i<3; i++)
    lbiniv[i] = 0;
  
  // re-read lbin.sys file for initial for fluid densities,
  // solute concentrations and temperature

  myfile.clear();
  myfile.seekg(0, ios::beg);

  while (!myfile.eof())
    {
      myfile >> issue>> value;
      if(!strcmp(issue, "temperature_ini"))
	lbinit = atof(value);
      
      else {

	for(int i=0; i<3; i++) {
	  sprintf(str1, "speed_ini_%d", i);
	  if(!strcmp(issue, str1)) {
	    lbiniv[i] = atof(value); goto Found;}
 
	}

	for(int i=0; i<nf; i++) {

	  sprintf(str1, "density_inc_%d", i);
	  if(!strcmp(issue, str1)){
	    lbincp[i] = atof(value);  goto Found;} 
	  
	  sprintf(str1, "density_ini_%d", i);
	  if(!strcmp(issue, str1)){
	    lbinip[i] = atof(value);  
            if(lbincp[i]==0.0)
              lbincp[i] = atof(value);
            goto Found;}
	  
	}

	for(int i=0; i<nc; i++) {
	  sprintf(str1, "solute_ini_%d", i);
	  if(!strcmp(issue, str1)) {
	    lbinic[i] = atof(value); goto Found;}
	  
	}
      }
    Found: ;
    }

  myfile.close();

  // Allocate arrays for modifications to default values

  ngrid = nx*ny*nz;

  if(ngrid!=0) {
    rho = new double[ngrid*nf];
    conc = new double[ngrid*nc];
    temp = new double[ngrid*nt];
    vx = new double[ngrid];
    vy = new double[ngrid];
    vz = new double[ngrid];
    change = new int[ngrid];
    for(long int i=0; i<ngrid; i++) {
      change[i] = 0;
      vx[i] = lbiniv[0];
      vy[i] = lbiniv[1];
      vz[i] = lbiniv[2];
      for(int j=0; j<nf; j++)
        rho[i*nf+j] = 0.0;
      for(int j=0; j<nc; j++)
        conc[i*nc+j] = 0.0;
      for(int j=0; j<nt; j++)
        temp[i*nt+j] = 0.0;
    }
  }

  cout << "Size of system: x = " << nx << ", y = " << ny;
  if(nd>2)
    cout << ", z = " << nz;
  cout << endl;

  contfluid = 0;
  cout << "Default system density: ";
  for(int i=0; i<nf; i++) {
    cout << "Fluid "<<i<<" = " <<lbinip[i] << endl;
    if(lbinip[i]!=0.0) {
      contfluid++;
      deffluid = i;
    }
    if(i<nf-1)
      cout << "                        ";
  }

  cout << "Constant fluid density: ";  
  for(int i=0; i<nf; i++) {
    cout << "Fluid "<<i<<" = " <<lbincp[i] << endl;
    if(i<nf-1)
      cout << "                        ";
  }

  if(nc>0) {
    cout << "Default system concentration: ";
    for(int i=0; i<nf; i++) {
      cout << "Solute "<<i<<" = " <<lbincp[i] << endl;
      if(i<nf-1)
        cout << "                              ";
    }
  }

  if(nt>0)
    cout << "Default system temperature = " << lbinit << endl;

  cout << "Default system velocity: x = " << lbiniv[0] << ", y = " << lbiniv[1];
  if(nd>2)
    cout << ", z = " << lbiniv[2];
  cout << endl << endl;

  // add fluid drops to system

  if(nf==1 && lbinip[0]!=lbincp[0]) {
    cout << "Number of drops to be added to system: ";
    cin >> numdrop;
    for(int id=0; id<numdrop; id++) {
      cout << "Radius for drop "<<(id+1)<<": ";
      cin >> radius;
      if(nd==2) {
        cout << "Centre of drop (x,y): ";
        while(1) {
          cin >> x0 >> y0;
          if(x0<0 || y0<0 || x0>=nx || y0>=ny)
            cout << "Out of range!" << endl;
          else
            break;
        }
        xs = x0-radius-1; xe = x0+radius+1;
        ys = y0-radius-1; ye = y0+radius+1;
        cout << "Density of drop (default = "<<lbincp[0]<<"): ";
        while(1) {
          cin >> rho0;
          if(rho0<0)
            cout << "Out of range!" << endl;
          else if (rho0==0) {
            rho0 = lbincp[0];
            break;
          }
          else
            break;
        }
        for(int i=xs; i<=xe; i++) {
          for(int j=ys; j<=ye; j++) {
            det = (i-x0)*(i-x0) + (j-y0)*(j-y0) - radius*radius;
            if(det<0.0) {
              pos = fCppMod(i, nx) * ny + fCppMod(j, ny);
              change[pos] = 1;
              vx[pos] = 0.0;
              vy[pos] = 0.0;
              vz[pos] = 0.0;
              rho[pos] = rho0;
            }
          }
        }
      }
      else {
        cout << "Centre of drop (x,y,z): ";
        while(1) {
          cin >> x0 >> y0 >> z0;
          if(x0<0 || y0<0 || x0>=nx || y0>=ny || z0<0 || z0>=nz)
            cout << "Out of range!" << endl;
          else
            break;
        }
        xs = x0-radius-1; xe = x0+radius+1;
        ys = y0-radius-1; ye = y0+radius+1;
        zs = z0-radius-1; ze = z0+radius+1;
        cout << "Density of drop (default = "<<lbincp[0]<<"): ";
        while(1) {
          cin >> rho0;
          if(rho0<0)
            cout << "Out of range!" << endl;
          else if (rho0==0) {
            rho0 = lbincp[0];
            break;
          }
          else
            break;
        }
        for(int i=xs; i<=xe; i++) {
          for(int j=ys; j<=ye; j++) {
            for(int k=zs; k<=ze; k++) {
              det = (i-x0)*(i-x0) + (j-y0)*(j-y0) + (k-z0)*(k-z0) - radius*radius;
              if(det<0.0) {
                pos = (fCppMod(i, nx) * ny + fCppMod(j, ny)) * nz + fCppMod(k, nz);
                change[pos] = 1;
                vx[pos] = 0.0;
                vy[pos] = 0.0;
                vz[pos] = 0.0;
                rho[pos] = rho0;
              }
            }
          }
        }
      }
    }
  }
  else if(nf>1) {
    cout << "Continuous (bulk) fluid for system:";
    for(int i=0; i<nf; i++) {
      if(lbinip[i]!=0) {
        cout << " " << i;
      }
    }
    cout << endl;
    if(contfluid==0) {
      cout << "No fluid found for system!" << endl;
      exit(1);
    }
    else if(deffluid>1) {
      cout << "No single continuous fluid found - please enter number for continuous fluid:" << endl;
      while (1) {
        cin >> deffluid;
        if(deffluid<0 || deffluid>=nf)
          cout << "Invalid fluid number!" << endl;
        else if(lbinip[deffluid]==0.0)
          cout << "Selected fluid not continuous!" << endl;
        else
          break;
      }
    }
    cout << "Number of drops to be added to system: ";
    cin >> numdrop;
    for(int id=0; id<numdrop; id++) {
      cout << "Fluid species for drop "<<(id+1)<<": ";
      while(1) {
        cin >> fluiddrop;
        if(fluiddrop<0 || fluiddrop>=nf)
          cout << "Invalid fluid number!" << endl;
        else if(fluiddrop==deffluid)
          cout << "Selected fluid is continuous!" << endl;
        else
          break;
      }
      cout << "Radius for drop "<<(id+1)<<": ";
      cin >> radius;
      if(nd==2) {
        cout << "Centre of drop (x,y): ";
        while(1) {
          cin >> x0 >> y0;
          if(x0<0 || y0<0 || x0>=nx || y0>=ny)
            cout << "Out of range!" << endl;
          else 
            break;
        }
        xs = x0-radius-1; xe = x0+radius+1;
        ys = y0-radius-1; ye = y0+radius+1;
        cout << "Density of drop (default = "<<lbincp[fluiddrop]<<"): ";
        while(1) {
          cin >> rho0;
          if(rho0<0)
            cout << "Out of range!" << endl;
          else if (rho0==0) {
            rho0 = lbincp[fluiddrop];
            break;
          }
          else
            break;
        }
        for(int i=xs; i<=xe; i++) {
          for(int j=ys; j<=ye; j++) {
            det = (i-x0)*(i-x0) + (j-y0)*(j-y0) - radius*radius;
            if(det<0.0) {
              pos = fCppMod(i, nx) * ny + fCppMod(j, ny);
              change[pos] = 1;
              vx[pos] = 0.0;
              vy[pos] = 0.0;
              vz[pos] = 0.0;
              rho[nf*pos+deffluid] = 0.0;
              rho[nf*pos+fluiddrop] = rho0;
            }
          }
        }
      }
      else {
        cout << "Centre of drop (x,y,z): ";
        while(1) {
          cin >> x0 >> y0 >> z0;
          if(x0<0 || y0<0 || x0>=nx || y0>=ny || z0<0 || z0>=nz)
            cout << "Out of range!" << endl;
          else 
            break;
        }
        xs = x0-radius-1; xe = x0+radius+1;
        ys = y0-radius-1; ye = y0+radius+1;
        zs = z0-radius-1; ze = z0+radius+1;
        cout << "Density of drop (default = "<<lbincp[fluiddrop]<<"): ";
        while(1) {
          cin >> rho0;
          if(rho0<0)
            cout << "Out of range!" << endl;
          else if (rho0==0) {
            rho0 = lbincp[fluiddrop];
            break;
          }
          else
            break;
        }
        for(int i=xs; i<=xe; i++) {
          for(int j=ys; j<=ye; j++) {
            for(int k=zs; k<=ze; k++) {
              det = (i-x0)*(i-x0) + (j-y0)*(j-y0) + (k-z0)*(k-z0) - radius*radius;
              if(det<0.0) {
                pos = (fCppMod(i, nx) * ny + fCppMod(j, ny)) * nz + fCppMod(k, nz);
                change[pos] = 1;
                vx[pos] = 0.0;
                vy[pos] = 0.0;
                vz[pos] = 0.0;
                rho[nf*pos+deffluid] = 0.0;
                rho[nf*pos+fluiddrop] = lbincp[fluiddrop];
              }
            }
          }
        }
      }
    }
  }

  // add sources of solute to system

  if(nc>0) {
    cout << "Number of solute sources to add to system: ";
    cin >> numdrop;
    for(int id=0; id<numdrop; id++) {
      cout << "Solute for source "<<(id+1)<<": ";
      while(1) {
        cin >> fluiddrop;
        if(fluiddrop<0 || fluiddrop>=nc)
          cout << "Invalid solute number!" << endl;
        else
          break;
      }
      cout << "Concentration of solute " << fluiddrop << " for source "<<(id+1)<<": ";
      cin >> rho0;
      if(nd==2) {
        cout << "Corner of source (x,y): ";
        while(1) {
          cin >> xs >> ys;
          if(xs<0 || ys<0 || xs>=nx || ys>=ny)
            cout << "Out of range!" << endl;
          else 
            break;
        }
        cout << "Extent of source (dx,dy): ";
        cin >> dx >> dy;
        xe = xs + dx; ye = ys + dy;
        if(xe<xs) fSwapPair (xs, xe);
        if(ye<ys) fSwapPair (ys, ye);
        for(int i=xs; i<=xe; i++) {
          for(int j=ys; j<=ye; j++) {
            pos = fCppMod(i, nx) * ny + fCppMod(j, ny);
            change[pos] = 1;
            conc[nc*pos+fluiddrop] = rho0;
          }
        }
      }
      else {
        cout << "Corner of source (x,y,z): ";
        while(1) {
          cin >> xs >> ys >> zs;
          if(xs<0 || ys<0 || xs>=nx || ys>=ny || zs<0 || zs>=nz)
            cout << "Out of range!" << endl;
          else 
            break;
        }
        cout << "Extent of source (dx,dy,dz): ";
        cin >> dx >> dy >> dz;
        xe = xs + dx; ye = ys + dy; ze = zs + dz;
        if(xe<xs) fSwapPair (xs, xe);
        if(ye<ys) fSwapPair (ys, ye);
        if(ze<zs) fSwapPair (zs, ze);
        for(int i=xs; i<=xe; i++) {
          for(int j=ys; j<=ye; j++) {
            for(int k=zs; k<=ze; k++) {
              pos = (fCppMod(i, nx) * ny + fCppMod(j, ny)) * nz + fCppMod(k, nz);
              change[pos] = 1;
              conc[nc*pos+fluiddrop] = rho0;
            }
          }
        }
      }
    }
  }

  // add temperature sources to system

  if(nt>0) {
    cout << "Number of temperatures sources to add to system: ";
    cin >> numdrop;
    for(int id=0; id<numdrop; id++) {
      cout << "Temperature for source "<<(id+1)<<": ";
      cin >> rho0;
      if(nd==2) {
        cout << "Corner of source (x,y): ";
        while(1) {
          cin >> xs >> ys;
          if(xs<0 || ys<0 || xs>=nx || ys>=ny)
            cout << "Out of range!" << endl;
          else 
            break;
        }
        cout << "Extent of source (dx,dy): ";
        cin >> dx >> dy;
        xe = xs + dx; ye = ys + dy;
        if(xe<xs) fSwapPair (xs, xe);
        if(ye<ys) fSwapPair (ys, ye);
        for(int i=xs; i<=xe; i++) {
          for(int j=ys; j<=ye; j++) {
            pos = fCppMod(i, nx) * ny + fCppMod(j, ny);
            change[pos] = 1;
            temp[pos] = rho0;
          }
        }
      }
      else {
        cout << "Corner of source (x,y,z): ";
        while(1) {
          cin >> xs >> ys >> zs;
          if(xs<0 || ys<0 || xs>=nx || ys>=ny || zs<0 || zs>=nz)
            cout << "Out of range!" << endl;
          else 
            break;
        }
        cout << "Extent of source (dx,dy,dz): ";
        cin >> dx >> dy >> dz;
        xe = xs + dx; ye = ys + dy; ze = zs + dz;
        if(xe<xs) fSwapPair (xs, xe);
        if(ye<ys) fSwapPair (ys, ye);
        if(ze<zs) fSwapPair (zs, ze);
        for(int i=xs; i<=xe; i++) {
          for(int j=ys; j<=ye; j++) {
            for(int k=zs; k<=ze; k++) {
              pos = (fCppMod(i, nx) * ny + fCppMod(j, ny)) * nz + fCppMod(k, nz);
              change[pos] = 1;
              temp[pos] = rho0;
            }
          }
        }
      }
    }
  }

  // write lbin.init file

  ofstream init;
  init.open("lbin.init");

  for(int i=0; i<nx; i++) {
    for(int j=0; j<ny; j++) {
      for(int k=0; k<nz; k++) {
        pos = (i * ny + j) * nz + k;
        if(change[pos]) {
          init << i << " " << j << " " << k << " " << vx[pos] << " " << vy[pos] << " " << vz[pos];
          for(int l=0; l<nf; l++) {
            init << " " << rho[nf*pos+l];
          }
          for(int l=0; l<nc; l++) {
            init << " " << conc[nc*pos+l];
          }
          if(nt>0) {
            init << " " << temp[pos];
          }
          init << endl;
        }
      }
    }
  }

  init.close();

}

int fCppMod(int a, int b)
{

  // ensure integer number a is in a range between 0 and b-1

  if( a < 0 )
    return (a+b);

  else if(a >= b)
    return (a-b);

  else
    return a;
}

template <class T> void fSwapPair ( T& a, T& b)
{
  T c(a); a=b; b=c;
}

