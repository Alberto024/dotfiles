/***********************************************
 *   DL_MESO       Version 2.6                 *
 *   Authors   :   R. S. Qin, M. A. Seaton     *
 *   Copyright :   STFC Daresbury Laboratory   *
 *             :   22/10/2015                  *
 ***********************************************/

// XML VTK (structured grid) format output

int fOutputVTK(const char* filename="lbout")
{
  if(lbsy.nd ==3)
    fOutputVTK3D(filename);
  else
    fOutputVTK2D(filename);
  return 0;
}


int fsOutputVTK(const char* filename="lbout")
{
  if(lbsy.nd ==3)
    fsOutputVTK3D(filename);
  else
    fsOutputVTK2D(filename);
  return 0;
}


int fOutputVTKP(const char* filename="lbout", int iprop=0)
{
  if(lbsy.nd ==3)
    fOutputVTKP3D(filename, iprop);
  else
    fOutputVTKP2D(filename, iprop);
  return 0;
}


int fsOutputVTKP(const char* filename="lbout", int iprop=0)
{
  if(lbsy.nd ==3)
    fsOutputVTKP3D(filename, iprop);
  else
    fsOutputVTKP2D(filename, iprop);
  return 0;
}


int fOutputVTKCA(const char* filename="lbout", int iprop=0)
{
  if(lbsy.nd ==3)
    fOutputVTKCA3D(filename, iprop);
  else
    fOutputVTKCA2D(filename, iprop);
  return 0;
}


int fsOutputVTKCA(const char* filename="lbout", int iprop=0)
{
  if(lbsy.nd ==3)
    fsOutputVTKCA3D(filename, iprop);
  else
    fsOutputVTKCA2D(filename, iprop);
  return 0;
}


int fOutputVTKCB(const char* filename="lbout", int iprop=0)
{
  if(lbsy.nd ==3)
    fOutputVTKCB3D(filename, iprop);
  else
    fOutputVTKCB2D(filename, iprop);
  return 0;
}


int fsOutputVTKCB(const char* filename="lbout", int iprop=0)
{
  if(lbsy.nd ==3)
    fsOutputVTKCB3D(filename, iprop);
  else
    fsOutputVTKCB2D(filename, iprop);
  return 0;
}


int fOutputVTKT(const char* filename="lbout")
{
  if(lbsy.nd ==3)
    fOutputVTKT3D(filename);
  else
    fOutputVTKT2D(filename);
  return 0;
}


int fsOutputVTKT(const char* filename="lbout")
{
  if(lbsy.nd ==3)
    fsOutputVTKT3D(filename);
  else
    fsOutputVTKT2D(filename);
  return 0;
}

int fOutputVTK3D(const char* filename="lbout")
{

  // output .vts file with properties for all fluids

  int i, j, k, iprop, istart, iend, jstart, jend, kstart, kend, offset;
  double rho, frac;
  float ipos[3];
  int jpos;
  long kpos;
  int ilen=0, ilen1=0, ilen2=0, ilen3=0;
  char buf[80];
  if(lbdm.size>1)
    sprintf(buf, "%s%.6dat%.6d.vts", filename, lbdm.rank, qVersion);
  else
    sprintf(buf, "%s%.6d.vts", filename, qVersion);
    
  ofstream file(buf, ios::binary);

  file<<"<?xml version=\"1.0\"?>"<<endl;
  file<<"<VTKFile type=\"StructuredGrid\" version=\"0.1\" byte_order=\"BigEndian\">"<<endl;

  // determine extent of piece
  istart = 0; iend = lbdm.xouter; 
  if(lbdm.xcor == 0)
    istart = lbdm.bwid;
  if(lbdm.xcor == lbdm.xdim-1)
    iend = lbdm.xouter - lbdm.bwid;

  jstart = 0; jend = lbdm.youter; 
  if(lbdm.ycor == 0)
    jstart = lbdm.bwid;
  if(lbdm.ycor == lbdm.ydim-1)
    jend = lbdm.youter - lbdm.bwid;

  kstart = 0; kend = lbdm.zouter; 
  if(lbdm.zcor == 0)
    kstart = lbdm.bwid;
  if(lbdm.zcor == lbdm.zdim-1)
    kend = lbdm.zouter - lbdm.bwid;

  file<<"<StructuredGrid WholeExtent=\"";
  file<<(lbdm.xs+istart-lbdm.bwid)<<" "<<(lbdm.xs+iend-lbdm.bwid-1)
      <<" "<<(lbdm.ys+jstart-lbdm.bwid)<<" "<<(lbdm.ys+jend-lbdm.bwid-1)
      <<" "<<(lbdm.zs+kstart-lbdm.bwid)<<" "<<(lbdm.zs+kend-lbdm.bwid-1)<<"\">"<<endl;
  file<<"<Piece Extent=\""<<(lbdm.xs+istart-lbdm.bwid)<<" "<<(lbdm.xs+iend-lbdm.bwid-1)
      <<" "<<(lbdm.ys+jstart-lbdm.bwid)<<" "<<(lbdm.ys+jend-lbdm.bwid-1)
      <<" "<<(lbdm.zs+kstart-lbdm.bwid)<<" "<<(lbdm.zs+kend-lbdm.bwid-1)<<"\">"<<endl;

  file<<"<PointData Scalars=\"phase_field\" Vectors=\"velocity\">"<<endl;

  // determine number of data points
  ilen1=lbdm.xouter;
  if(lbdm.xcor == 0)
    ilen1 -= lbdm.bwid;
  if(lbdm.xcor == lbdm.xdim-1)
    ilen1 -= lbdm.bwid;

  ilen2=lbdm.youter;
  if(lbdm.ycor == 0)
    ilen2 -= lbdm.bwid;
  if(lbdm.ycor == lbdm.ydim-1)
    ilen2 -= lbdm.bwid;

  ilen3=lbdm.zouter;
  if(lbdm.zcor == 0)
    ilen3 -= lbdm.bwid;
  if(lbdm.zcor == lbdm.zdim-1)
    ilen3 -= lbdm.bwid;

  offset = 0;
  for(iprop=0; iprop<lbsy.nf; iprop++) {
    file<<"<DataArray Name=\"density_"<<iprop<<"\" type=\"Float32\" format=\"appended\" offset=\""<<offset<<"\">"<<endl;
    offset += sizeof(float)*ilen1*ilen2*ilen3 + sizeof(unsigned int);
    file<<"</DataArray>"<<endl;
  }
  for(iprop=0; iprop<lbsy.nf; iprop++) {
    file<<"<DataArray Name=\"fraction_"<<iprop<<"\" type=\"Float32\" format=\"appended\" offset=\""<<offset<<"\">"<<endl;
    offset += sizeof(float)*ilen1*ilen2*ilen3 + sizeof(unsigned int);
    file<<"</DataArray>"<<endl;
  }
  for(iprop=0; iprop<lbsy.nc; iprop++) {
    file<<"<DataArray Name=\"concentration_"<<iprop<<"\" type=\"Float32\" format=\"appended\" offset=\""<<offset<<"\">"<<endl;
    offset += sizeof(float)*ilen1*ilen2*ilen3 + sizeof(unsigned int);
    file<<"</DataArray>"<<endl;
  }
  if(lbsy.nt==1) {
    file<<"<DataArray Name=\"temperature\" type=\"Float32\" format=\"appended\" offset=\""<<offset<<"\">"<<endl;
    offset += sizeof(float)*ilen1*ilen2*ilen3 + sizeof(unsigned int);
    file<<"</DataArray>"<<endl;
  }
  file<<"<DataArray Name=\"velocity\" type=\"Float32\" NumberOfComponents=\"3\" format=\"appended\" offset=\""<<offset<<"\">"<<endl;
  offset += 3*sizeof(float)*ilen1*ilen2*ilen3 + sizeof(unsigned int);
  file<<"</DataArray>"<<endl;

  file<<"<DataArray Name=\"phase_field\" type=\"Int32\" format=\"appended\" offset=\""<<offset<<"\">"<<endl;
  offset += sizeof(int)*ilen1*ilen2*ilen3 + sizeof(unsigned int);
  file<<"</DataArray>"<<endl;
  file<<"</PointData>"<<endl;
  file<<"<Points>"<<endl;
  file<<"<DataArray type=\"Float32\" NumberOfComponents=\"3\" format=\"appended\" offset=\""<<offset<<"\">"<<endl;
  file<<"</DataArray>"<<endl;
  file<<"</Points>"<<endl;
  file<<"</Piece>"<<endl;
  file<<"</StructuredGrid>"<<endl;

  file<<"<AppendedData encoding=\"raw\">"<<endl;
  file<<"_";  

  // write densities and mass fractions
  if(interact==5 && lbsy.nf>1) {
    for(iprop=0; iprop<lbsy.nf; iprop++) {
      kpos=sizeof(float)*ilen1*ilen2*ilen3;
      if (!bigend) fByteSwap(&kpos,sizeof(unsigned int),1);
      file.write(reinterpret_cast<const char*>(&kpos), sizeof(unsigned int));
      for(k=kstart; k<kend; k++) {
        for(j=jstart; j<jend; j++) {
          for(i=istart; i<iend; i++) {
  	        ilen = (i * lbdm.youter + j) * lbdm.zouter + k;
            rho = fGetOneMassSite(&lbf[ilen*lbsitelength]);
            frac = fGetFracSwiftSite(iprop, &lbf[ilen*lbsitelength]);
    	    ipos[0] = float(rho*frac);
            if (!bigend) fByteSwap(ipos,sizeof(float),1);
	        file.write((char*)&ipos[0], sizeof(float));
          }
        }
      }
    }
    for(iprop=0; iprop<lbsy.nf; iprop++) {
      kpos=sizeof(float)*ilen1*ilen2*ilen3;
      if (!bigend) fByteSwap(&kpos,sizeof(unsigned int),1);
      file.write(reinterpret_cast<const char*>(&kpos), sizeof(unsigned int));
      for(k=kstart; k<kend; k++) {
        for(j=jstart; j<jend; j++) {
          for(i=istart; i<iend; i++) {
  	        ilen = (i * lbdm.youter + j) * lbdm.zouter + k;
    	    ipos[0] = float(fGetFracSwiftSite(iprop, &lbf[ilen*lbsitelength]));
            if (!bigend) fByteSwap(ipos,sizeof(float),1);
	        file.write((char*)&ipos[0], sizeof(float));
          }
        }
      }
    }
  }
  else {
    for(iprop=0; iprop<lbsy.nf; iprop++) {
      kpos=sizeof(float)*ilen1*ilen2*ilen3;
      if (!bigend) fByteSwap(&kpos,sizeof(unsigned int),1);
      file.write(reinterpret_cast<const char*>(&kpos), sizeof(unsigned int));
      for(k=kstart; k<kend; k++) {
        for(j=jstart; j<jend; j++) {
          for(i=istart; i<iend; i++) {
  	        ilen = (i * lbdm.youter + j) * lbdm.zouter + k;
    	    ipos[0] = float(fGetOneMassSite(&lbf[ilen*lbsitelength+iprop]));
            if (!bigend) fByteSwap(ipos,sizeof(float),1);
	        file.write((char*)&ipos[0], sizeof(float));
          }
        }
      }
    }
    for(iprop=0; iprop<lbsy.nf; iprop++) {
      kpos=sizeof(float)*ilen1*ilen2*ilen3;
      if (!bigend) fByteSwap(&kpos,sizeof(unsigned int),1);
      file.write(reinterpret_cast<const char*>(&kpos), sizeof(unsigned int));
      for(k=kstart; k<kend; k++) {
        for(j=jstart; j<jend; j++) {
          for(i=istart; i<iend; i++) {
	        ilen = (i * lbdm.youter + j) * lbdm.zouter + k;
            ipos[0] = float(fGetFracSite(iprop, &lbf[ilen*lbsitelength]));
            if (!bigend) fByteSwap(ipos,sizeof(float),1);
	        file.write((char*)&ipos[0], sizeof(float));
          }
        }
      }
    }
  }

  // write solute concentrations
  for(iprop=0; iprop<lbsy.nc; iprop++) {
    kpos=sizeof(float)*ilen1*ilen2*ilen3;
    if (!bigend) fByteSwap(&kpos,sizeof(unsigned int),1);
    file.write(reinterpret_cast<const char*>(&kpos), sizeof(unsigned int));
    for(k=kstart; k<kend; k++) {
      for(j=jstart; j<jend; j++) {
        for(i=istart; i<iend; i++) {
	      ilen = (i * lbdm.youter + j) * lbdm.zouter + k;
 	      ipos[0] = float(fGetOneConcSite(iprop, ilen));
          if (!bigend) fByteSwap(ipos,sizeof(float),1);
	      file.write((char*)&ipos[0], sizeof(float));
        }
      }
    }
  }

  // write temperatures
  if(lbsy.nt==1) {
    kpos=sizeof(float)*ilen1*ilen2*ilen3;
    if (!bigend) fByteSwap(&kpos,sizeof(unsigned int),1);
    file.write(reinterpret_cast<const char*>(&kpos), sizeof(unsigned int));
    for(k=kstart; k<kend; k++) {
      for(j=jstart; j<jend; j++) {
        for(i=istart; i<iend; i++) {
	      ilen = (i * lbdm.youter + j) * lbdm.zouter + k;
 	      ipos[0] = float(fGetTemperatureSite(ilen));
          if (!bigend) fByteSwap(ipos,sizeof(float),1);
	      file.write((char*)&ipos[0], sizeof(float));
        }
      }
    }
  }

  // write velocity
  kpos=3*sizeof(float)*ilen1*ilen2*ilen3;
  if (!bigend) fByteSwap(&kpos,sizeof(unsigned int),1);
  file.write(reinterpret_cast<const char*>(&kpos), sizeof(unsigned int));
  if(interact==5) {
    for(k=kstart; k<kend; k++) {
      for(j=jstart; j<jend; j++) {
        for(i=istart; i<iend; i++) {
	      ilen = (i * lbdm.youter + j) * lbdm.zouter + k;
  	      if(lbphi[ilen] == 12 || lbphi[ilen] == 13) {
	        ipos[0] = 0.0;
            ipos[1] = 0.0;
            ipos[2] = 0.0;
          }
	      else {
            ipos[0] = fGetOneDirecSpeedSwiftSite(0, &lbf[ilen*lbsitelength]);
            ipos[1] = fGetOneDirecSpeedSwiftSite(1, &lbf[ilen*lbsitelength]);
            ipos[2] = fGetOneDirecSpeedSwiftSite(2, &lbf[ilen*lbsitelength]);
          }
          if (!bigend) fByteSwap(ipos,sizeof(float),3);
	      file.write((char*)&ipos, 3*sizeof(float));
        }
      }
    }
  }
  else if(!incompress) {
    for(k=kstart; k<kend; k++) {
      for(j=jstart; j<jend; j++) {
        for(i=istart; i<iend; i++) {
	      ilen = (i * lbdm.youter + j) * lbdm.zouter + k;
  	      if(lbphi[ilen] == 12 || lbphi[ilen] == 13) {
	        ipos[0] = 0.0;
            ipos[1] = 0.0;
            ipos[2] = 0.0;
          }
	      else {
            ipos[0] = fGetOneDirecSpeedSite(0, &lbf[ilen*lbsitelength]);
            ipos[1] = fGetOneDirecSpeedSite(1, &lbf[ilen*lbsitelength]);
            ipos[2] = fGetOneDirecSpeedSite(2, &lbf[ilen*lbsitelength]);
          }
          if (!bigend) fByteSwap(ipos,sizeof(float),3);
	      file.write((char*)&ipos, 3*sizeof(float));
        }
      }
    }
  }
  else {
    for(k=kstart; k<kend; k++) {
      for(j=jstart; j<jend; j++) {
        for(i=istart; i<iend; i++) {
	      ilen = (i * lbdm.youter + j) * lbdm.zouter + k;
  	      if(lbphi[ilen] == 12 || lbphi[ilen] == 13) {
	        ipos[0] = 0.0;
            ipos[1] = 0.0;
            ipos[2] = 0.0;
          }
	      else {
            ipos[0] = fGetOneDirecSpeedIncomSite(0, &lbf[ilen*lbsitelength]);
            ipos[1] = fGetOneDirecSpeedIncomSite(1, &lbf[ilen*lbsitelength]);
            ipos[2] = fGetOneDirecSpeedIncomSite(2, &lbf[ilen*lbsitelength]);
          }
          if (!bigend) fByteSwap(ipos,sizeof(float),3);
	      file.write((char*)&ipos, 3*sizeof(float));
        }
      }
    }
  }
  // write phase field/space property
  kpos=sizeof(int)*ilen1*ilen2*ilen3;
  if (!bigend) fByteSwap(&kpos,sizeof(unsigned int),1);
  file.write(reinterpret_cast<const char*>(&kpos), sizeof(unsigned int));
  for(k=kstart; k<kend; k++)
    for(j=jstart; j<jend; j++) {
      for(i=istart; i<iend; i++) {
	    ilen=(i * lbdm.youter + j) * lbdm.zouter + k;
	    jpos=lbphi[ilen];
        if (!bigend) fByteSwap(&jpos,sizeof(int),1);
	    file.write(reinterpret_cast<const char*>(&jpos), sizeof(int));
      }
    }	

  // write grid points
  kpos=3*sizeof(float)*ilen1*ilen2*ilen3;
  if (!bigend) fByteSwap(&kpos,sizeof(unsigned int),1);
  file.write(reinterpret_cast<const char*>(&kpos), sizeof(unsigned int));
  for(k=kstart; k<kend; k++)
    for(j=jstart; j<jend; j++) {
      for(i=istart; i<iend; i++) {
	    ipos[0]=(lbdm.xs + i - lbdm.bwid)*float(lbdx);
	    ipos[1]=(lbdm.ys + j - lbdm.bwid)*float(lbdx);
	    ipos[2]=(lbdm.zs + k - lbdm.bwid)*float(lbdx);
        if (!bigend) fByteSwap(ipos,sizeof(float),3);
	    file.write((char*)&ipos, 3*sizeof(float));
      }
    }

  file<<"</AppendedData>"<<endl;
  file<<"</VTKFile>"<<endl;
  
  file.close();
  
  return 0;
}


int fsOutputVTK3D(const char* filename="lbout")
{
  int i, j, k, istart, iend, jstart, jend, kstart, kend, iprop;
  float ipos[3];
  int jpos;
  long ilen=0;
  char buf[80];
  double rho, frac;
    
  if(lbdm.size>1)
    sprintf(buf, "%s%.6dat%.6d.vts", filename, lbdm.rank, qVersion);
  else
    sprintf(buf, "%s%.6d.vts", filename, qVersion);
  ofstream file(buf);
  file<<"<?xml version=\"1.0\"?>"<<endl;
  file<<"<VTKFile type=\"StructuredGrid\" version=\"0.1\" byte_order=\"BigEndian\">"<<endl;
    
  // determine extent of piece
  istart = 0; iend = lbdm.xouter; 
  if(lbdm.xcor == 0)
    istart = lbdm.bwid;
  if(lbdm.xcor == lbdm.xdim-1)
    iend = lbdm.xouter - lbdm.bwid;

  jstart = 0; jend = lbdm.youter; 
  if(lbdm.ycor == 0)
    jstart = lbdm.bwid;
  if(lbdm.ycor == lbdm.ydim-1)
    jend = lbdm.youter - lbdm.bwid;

  kstart = 0; kend = lbdm.zouter; 
  if(lbdm.zcor == 0)
    kstart = lbdm.bwid;
  if(lbdm.zcor == lbdm.zdim-1)
    kend = lbdm.zouter - lbdm.bwid;

  file<<"<StructuredGrid WholeExtent=\"";
  file<<(lbdm.xs+istart-lbdm.bwid)<<" "<<(lbdm.xs+iend-lbdm.bwid-1)
      <<" "<<(lbdm.ys+jstart-lbdm.bwid)<<" "<<(lbdm.ys+jend-lbdm.bwid-1)
      <<" "<<(lbdm.zs+kstart-lbdm.bwid)<<" "<<(lbdm.zs+kend-lbdm.bwid-1)<<"\">"<<endl;
  file<<"<Piece Extent=\""<<(lbdm.xs+istart-lbdm.bwid)<<" "<<(lbdm.xs+iend-lbdm.bwid-1)
      <<" "<<(lbdm.ys+jstart-lbdm.bwid)<<" "<<(lbdm.ys+jend-lbdm.bwid-1)
      <<" "<<(lbdm.zs+kstart-lbdm.bwid)<<" "<<(lbdm.zs+kend-lbdm.bwid-1)<<"\">"<<endl;
  // write grid points
  file<<"<Points>"<<endl;
  file<<"<DataArray type=\"Float32\" NumberOfComponents=\"3\" format=\"ascii\">"<<endl;
  for(k=kstart; k<kend; k++)
    for(j=jstart; j<jend; j++)
      for(i=istart; i<iend; i++)
	    file<<(lbdm.xs+i-lbdm.bwid)*float(lbdx)<<" "<<(lbdm.ys+j-lbdm.bwid)*float(lbdx)<<" "<<(lbdm.zs+k-lbdm.bwid)*float(lbdx)<<" ";
  file<<endl;
  file<<"</DataArray>"<<endl;
  file<<"</Points>"<<endl;
  file<<"<PointData Scalars=\"density\" Vectors=\"velocity\">"<<endl;
  // write densities and mass fractions
  if(interact==5 && lbsy.nf>1) {
    for(iprop=0; iprop<lbsy.nf; iprop++) {
      file<<"<DataArray Name=\"density_"<<iprop<<"\" type=\"Float32\" format=\"ascii\">"<<endl;
      for(k=kstart; k<kend; k++) {
        for(j=jstart; j<jend; j++) {
          for(i=istart; i<iend; i++) {
	        ilen = (i * lbdm.youter + j) * lbdm.zouter + k;
            rho = fGetOneMassSite(&lbf[ilen*lbsitelength]);
            frac = fGetFracSwiftSite(iprop, &lbf[ilen*lbsitelength]);
	        ipos[0] = float(rho*frac);
	        file<<ipos[0]<<" ";
	      }
        }
      }
      file<<endl;
      file<<"</DataArray>"<<endl;
    }
    for(iprop=0; iprop<lbsy.nf; iprop++) {
      file<<"<DataArray Name=\"fraction_"<<iprop<<"\" type=\"Float32\" format=\"ascii\">"<<endl;
      for(k=kstart; k<kend; k++) {
        for(j=jstart; j<jend; j++) {
          for(i=istart; i<iend; i++) {
  	        ilen = (i * lbdm.youter + j) * lbdm.zouter + k;
	        ipos[0] = float(fGetFracSwiftSite(iprop, &lbf[ilen*lbsitelength]));
	        file<<ipos[0]<<" ";
	      }
        }
      }
      file<<endl;
      file<<"</DataArray>"<<endl;
    }
  }
  else {
    for(iprop=0; iprop<lbsy.nf; iprop++) {
      file<<"<DataArray Name=\"density_"<<iprop<<"\" type=\"Float32\" format=\"ascii\">"<<endl;
      for(k=kstart; k<kend; k++) {
        for(j=jstart; j<jend; j++) {
          for(i=istart; i<iend; i++) {
	        ilen = (i * lbdm.youter + j) * lbdm.zouter + k;
	        ipos[0] = float(fGetOneMassSite(&lbf[ilen*lbsitelength+iprop]));
	        file<<ipos[0]<<" ";
	      }
        }
      }
      file<<endl;
      file<<"</DataArray>"<<endl;
    }
    for(iprop=0; iprop<lbsy.nf; iprop++) {
      file<<"<DataArray Name=\"fraction_"<<iprop<<"\" type=\"Float32\" format=\"ascii\">"<<endl;
      for(k=kstart; k<kend; k++) {
        for(j=jstart; j<jend; j++) {
          for(i=istart; i<iend; i++) {
	        ilen = (i * lbdm.youter + j) * lbdm.zouter + k;
	        ipos[0] = float(fGetFracSite(iprop, &lbf[ilen*lbsitelength]));
	        file<<ipos[0]<<" ";
	      }
        }
      }
      file<<endl;
      file<<"</DataArray>"<<endl;
    }
  }
  // write solute concentrations
  for(iprop=0; iprop<lbsy.nc; iprop++) {
    file<<"<DataArray Name=\"concentration_"<<iprop<<"\" type=\"Float32\" format=\"ascii\">"<<endl;
    for(k=kstart; k<kend; k++) {
      for(j=jstart; j<jend; j++) {
        for(i=istart; i<iend; i++) {
	      ilen = (i * lbdm.youter + j) * lbdm.zouter + k;
	      ipos[0] = float(fGetOneConcSite(iprop, ilen));
	      file<<ipos[0]<<" ";
        }
      }
    }
    file<<endl;
    file<<"</DataArray>"<<endl;
  }
  // write temperatures
  if(lbsy.nt==1) {
    file<<"<DataArray Name=\"temperature\" type=\"Float32\" format=\"ascii\">"<<endl;
    for(k=kstart; k<kend; k++) {
      for(j=jstart; j<jend; j++) {
        for(i=istart; i<iend; i++) {
	      ilen = (i * lbdm.youter + j) * lbdm.zouter + k;
	      ipos[0] = float(fGetTemperatureSite(ilen));
	      file<<ipos[0]<<" ";
	    }
      }
    }
    file<<endl;
    file<<"</DataArray>"<<endl;
  }

  // write velocity
  file<<"<DataArray Name=\"velocity\" type=\"Float32\" NumberOfComponents=\"3\" format=\"ascii\">"<<endl;
  if(interact==5) {
    for(k=kstart; k<kend; k++) {
      for(j=jstart; j<jend; j++) {
        for(i=istart; i<iend; i++) {
	      ilen = (i * lbdm.youter + j) * lbdm.zouter + k;
  	      if(lbphi[ilen] == 12 || lbphi[ilen] == 13) {
	        ipos[0] = 0.0;
            ipos[1] = 0.0;
            ipos[2] = 0.0;
          }
	      else {
            ipos[0] = fGetOneDirecSpeedSwiftSite(0, &lbf[ilen*lbsitelength]);
            ipos[1] = fGetOneDirecSpeedSwiftSite(1, &lbf[ilen*lbsitelength]);
            ipos[2] = fGetOneDirecSpeedSwiftSite(2, &lbf[ilen*lbsitelength]);
          }
  	      file<<ipos[0]<<" "<<ipos[1]<<" "<<ipos[2]<<" ";
	    }
      }
    }
  }
  else if(!incompress) {
    for(k=kstart; k<kend; k++) {
      for(j=jstart; j<jend; j++) {
        for(i=istart; i<iend; i++) {
	      ilen = (i * lbdm.youter + j) * lbdm.zouter + k;
  	      if(lbphi[ilen] == 12 || lbphi[ilen] == 13) {
	        ipos[0] = 0.0;
            ipos[1] = 0.0;
            ipos[2] = 0.0;
          }
	      else {
            ipos[0] = fGetOneDirecSpeedSite(0, &lbf[ilen*lbsitelength]);
            ipos[1] = fGetOneDirecSpeedSite(1, &lbf[ilen*lbsitelength]);
            ipos[2] = fGetOneDirecSpeedSite(2, &lbf[ilen*lbsitelength]);
          }
  	      file<<ipos[0]<<" "<<ipos[1]<<" "<<ipos[2]<<" ";
	    }
      }
    }
  }
  else {
    for(k=kstart; k<kend; k++) {
      for(j=jstart; j<jend; j++) {
        for(i=istart; i<iend; i++) {
	      ilen = (i * lbdm.youter + j) * lbdm.zouter + k;
  	      if(lbphi[ilen] == 12 || lbphi[ilen] == 13) {
	        ipos[0] = 0.0;
            ipos[1] = 0.0;
            ipos[2] = 0.0;
          }
	      else {
            ipos[0] = fGetOneDirecSpeedIncomSite(0, &lbf[ilen*lbsitelength]);
            ipos[1] = fGetOneDirecSpeedIncomSite(1, &lbf[ilen*lbsitelength]);
            ipos[2] = fGetOneDirecSpeedIncomSite(2, &lbf[ilen*lbsitelength]);
          }
	      file<<ipos[0]<<" "<<ipos[1]<<" "<<ipos[2]<<" ";
	    }
      }
    }
  }
  file<<endl;
  file<<"</DataArray>"<<endl;
  // write phase field/space property
  file<<"<DataArray Name=\"phase_field\" type=\"Int32\" format=\"ascii\">"<<endl;
  for(k=kstart; k<kend; k++)
    for(j=jstart; j<jend; j++)
      for(i=istart; i<iend; i++)
	    {
	      ilen = (i * lbdm.youter + j) * lbdm.zouter + k;
	      jpos=lbphi[ilen];
	      file<<jpos<<" ";
	    }

  file<<endl;
  file<<"</DataArray>"<<endl;
  file<<"</PointData>"<<endl;
  file<<"</Piece>"<<endl;
  file<<"</StructuredGrid>"<<endl;
  file<<"</VTKFile>"<<endl;
  file.close();
  return 0;
}


int fOutputVTK2D(const char* filename="lbout")
{

  // output .vts file with properties for all fluids

  int i, j, iprop, istart, iend, jstart, jend, offset;
  float ipos[3];
  int jpos;
  long kpos;
  int ilen=0, ilen1=0, ilen2=0;
  char buf[80];
  double rho, frac;
    
  if(lbdm.size>1)
    sprintf(buf, "%s%.6dat%.6d.vts", filename, lbdm.rank, qVersion);
  else
    sprintf(buf, "%s%.6d.vts", filename, qVersion);
  ofstream file(buf, ios::binary);

  file<<"<?xml version=\"1.0\"?>"<<endl;
  file<<"<VTKFile type=\"StructuredGrid\" version=\"0.1\" byte_order=\"BigEndian\">"<<endl;

  // determine extent of piece
  istart = 0; iend = lbdm.xouter; 
  if(lbdm.xcor == 0)
    istart = lbdm.bwid;
  if(lbdm.xcor == lbdm.xdim-1)
    iend = lbdm.xouter - lbdm.bwid;

  jstart = 0; jend = lbdm.youter; 
  if(lbdm.ycor == 0)
    jstart = lbdm.bwid;
  if(lbdm.ycor == lbdm.ydim-1)
    jend = lbdm.youter - lbdm.bwid;

  file<<"<StructuredGrid WholeExtent=\"";
  file<<(lbdm.xs+istart-lbdm.bwid)<<" "<<(lbdm.xs+iend-lbdm.bwid-1)
      <<" "<<(lbdm.ys+jstart-lbdm.bwid)<<" "<<(lbdm.ys+jend-lbdm.bwid-1)<<" 0 0\">"<<endl;
  file<<"<Piece Extent=\""<<(lbdm.xs+istart-lbdm.bwid)<<" "<<(lbdm.xs+iend-lbdm.bwid-1)
      <<" "<<(lbdm.ys+jstart-lbdm.bwid)<<" "<<(lbdm.ys+jend-lbdm.bwid-1)<<" 0 0\">"<<endl;

  file<<"<PointData Scalars=\"phase_field\" Vectors=\"velocity\">"<<endl;

  // determine number of data points
  ilen1=lbdm.xouter;
  if(lbdm.xcor == 0)
    ilen1 -= lbdm.bwid;
  if(lbdm.xcor == lbdm.xdim-1)
    ilen1 -= lbdm.bwid;

  ilen2=lbdm.youter;
  if(lbdm.ycor == 0)
    ilen2 -= lbdm.bwid;
  if(lbdm.ycor == lbdm.ydim-1)
    ilen2 -= lbdm.bwid;

  offset = 0;
  for(iprop=0; iprop<lbsy.nf; iprop++) {
    file<<"<DataArray Name=\"density_"<<iprop<<"\" type=\"Float32\" format=\"appended\" offset=\""<<offset<<"\">"<<endl;
    offset += sizeof(float)*ilen1*ilen2 + sizeof(unsigned int);
    file<<"</DataArray>"<<endl;
  }
  for(iprop=0; iprop<lbsy.nf; iprop++) {
    file<<"<DataArray Name=\"fraction_"<<iprop<<"\" type=\"Float32\" format=\"appended\" offset=\""<<offset<<"\">"<<endl;
    offset += sizeof(float)*ilen1*ilen2 + sizeof(unsigned int);
    file<<"</DataArray>"<<endl;
  }
  for(iprop=0; iprop<lbsy.nc; iprop++) {
    file<<"<DataArray Name=\"concentration_"<<iprop<<"\" type=\"Float32\" format=\"appended\" offset=\""<<offset<<"\">"<<endl;
    offset += sizeof(float)*ilen1*ilen2 + sizeof(unsigned int);
    file<<"</DataArray>"<<endl;
  }
  if(lbsy.nt==1) {
    file<<"<DataArray Name=\"temperature\" type=\"Float32\" format=\"appended\" offset=\""<<offset<<"\">"<<endl;
    offset += sizeof(float)*ilen1*ilen2 + sizeof(unsigned int);
    file<<"</DataArray>"<<endl;
  }
  file<<"<DataArray Name=\"velocity\" type=\"Float32\" NumberOfComponents=\"3\" format=\"appended\" offset=\""<<offset<<"\">"<<endl;
  offset += 3*sizeof(float)*ilen1*ilen2 + sizeof(unsigned int);
  file<<"</DataArray>"<<endl;

  file<<"<DataArray Name=\"phase_field\" type=\"Int32\" format=\"appended\" offset=\""<<offset<<"\">"<<endl;
  offset += sizeof(int)*ilen1*ilen2 + sizeof(unsigned int);
  file<<"</DataArray>"<<endl;
  file<<"</PointData>"<<endl;
  file<<"<Points>"<<endl;
  file<<"<DataArray type=\"Float32\" NumberOfComponents=\"3\" format=\"appended\" offset=\""<<offset<<"\">"<<endl;
  file<<"</DataArray>"<<endl;
  file<<"</Points>"<<endl;
  file<<"</Piece>"<<endl;
  file<<"</StructuredGrid>"<<endl;

  file<<"<AppendedData encoding=\"raw\">"<<endl;
  file<<"_";  

  // write densities and mass fractions
  if(interact==5 && lbsy.nf>1) {
    for(iprop=0; iprop<lbsy.nf; iprop++) {
      kpos=sizeof(float)*ilen1*ilen2;
      if (!bigend) fByteSwap(&kpos,sizeof(unsigned int),1);
      file.write(reinterpret_cast<const char*>(&kpos), sizeof(unsigned int));
      for(j=jstart; j<jend; j++) {
        for(i=istart; i<iend; i++) {
          ilen = i * lbdm.youter + j;
          rho = fGetOneMassSite(&lbf[ilen*lbsitelength]);
          frac = fGetFracSwiftSite(iprop, &lbf[ilen*lbsitelength]);
  	      ipos[0] = float(rho*frac);
          if (!bigend) fByteSwap(ipos,sizeof(float),1);
	      file.write((char*)&ipos[0], sizeof(float));
        }
      }
    }
    for(iprop=0; iprop<lbsy.nf; iprop++) {
      kpos=sizeof(float)*ilen1*ilen2;
      if (!bigend) fByteSwap(&kpos,sizeof(unsigned int),1);
      file.write(reinterpret_cast<const char*>(&kpos), sizeof(unsigned int));
      for(j=jstart; j<jend; j++) {
        for(i=istart; i<iend; i++) {
          ilen = i * lbdm.youter + j;
  	      ipos[0] = float(fGetFracSite(iprop, &lbf[ilen*lbsitelength]));
          if (!bigend) fByteSwap(ipos,sizeof(float),1);
	      file.write((char*)&ipos[0], sizeof(float));
        }
      }
    }
      
  }
  else {
    for(iprop=0; iprop<lbsy.nf; iprop++) {
      kpos=sizeof(float)*ilen1*ilen2;
      if (!bigend) fByteSwap(&kpos,sizeof(unsigned int),1);
      file.write(reinterpret_cast<const char*>(&kpos), sizeof(unsigned int));
      for(j=jstart; j<jend; j++) {
        for(i=istart; i<iend; i++) {
          ilen = i * lbdm.youter + j;
  	      ipos[0] = float(fGetOneMassSite(&lbf[ilen*lbsitelength+iprop]));
          if (!bigend) fByteSwap(ipos,sizeof(float),1);
	      file.write((char*)&ipos[0], sizeof(float));
        }
      }
    }
    for(iprop=0; iprop<lbsy.nf; iprop++) {
      kpos=sizeof(float)*ilen1*ilen2;
      if (!bigend) fByteSwap(&kpos,sizeof(unsigned int),1);
      file.write(reinterpret_cast<const char*>(&kpos), sizeof(unsigned int));
      for(j=jstart; j<jend; j++) {
        for(i=istart; i<iend; i++) {
          ilen = i * lbdm.youter + j;
          ipos[0] = float(fGetFracSite(iprop, &lbf[ilen*lbsitelength]));
          if (!bigend) fByteSwap(ipos,sizeof(float),1);
	      file.write((char*)&ipos[0], sizeof(float));
        }
      }
    }
  }

  // write solute concentrations
  for(iprop=0; iprop<lbsy.nc; iprop++) {
    kpos=sizeof(float)*ilen1*ilen2;
    if (!bigend) fByteSwap(&kpos,sizeof(unsigned int),1);
    file.write(reinterpret_cast<const char*>(&kpos), sizeof(unsigned int));
    for(j=jstart; j<jend; j++) {
      for(i=istart; i<iend; i++) {
	    ilen = i * lbdm.youter + j;
 	    ipos[0] = float(fGetOneConcSite(iprop, ilen));
        if (!bigend) fByteSwap(ipos,sizeof(float),1);
	    file.write((char*)&ipos[0], sizeof(float));
      }
    }
  }

  // write temperatures
  if(lbsy.nt==1) {
    kpos=sizeof(float)*ilen1*ilen2;
    if (!bigend) fByteSwap(&kpos,sizeof(unsigned int),1);
    file.write(reinterpret_cast<const char*>(&kpos), sizeof(unsigned int));
    for(j=jstart; j<jend; j++) {
      for(i=istart; i<iend; i++) {
	    ilen = i * lbdm.youter + j;
 	    ipos[0] = float(fGetTemperatureSite(ilen));
        if (!bigend) fByteSwap(ipos,sizeof(float),1);
	    file.write((char*)&ipos[0], sizeof(float));
      }
    }
  }

  // write velocity
  kpos=3*sizeof(float)*ilen1*ilen2;
  if (!bigend) fByteSwap(&kpos,sizeof(unsigned int),1);
  file.write(reinterpret_cast<const char*>(&kpos), sizeof(unsigned int));
  if(interact==5) {
    for(j=jstart; j<jend; j++) {
      for(i=istart; i<iend; i++) {
        ilen = i * lbdm.youter + j;
        if(lbphi[ilen] == 12 || lbphi[ilen] == 13) {
	      ipos[0] = 0.0;
          ipos[1] = 0.0;
        }
        else {
          ipos[0] = fGetOneDirecSpeedSwiftSite(0, &lbf[ilen*lbsitelength]);
          ipos[1] = fGetOneDirecSpeedSwiftSite(1, &lbf[ilen*lbsitelength]);
        }
        ipos[2] = 0.0;
        if (!bigend) fByteSwap(ipos,sizeof(float),3);
        file.write((char*)&ipos, 3*sizeof(float));
      }
    }
  }
  else if (!incompress) {
    for(j=jstart; j<jend; j++) {
      for(i=istart; i<iend; i++) {
        ilen = i * lbdm.youter + j;
        if(lbphi[ilen] == 12 || lbphi[ilen] == 13) {
	      ipos[0] = 0.0;
          ipos[1] = 0.0;
        }
        else {
          ipos[0] = fGetOneDirecSpeedSite(0, &lbf[ilen*lbsitelength]);
          ipos[1] = fGetOneDirecSpeedSite(1, &lbf[ilen*lbsitelength]);
        }
        ipos[2] = 0.0;
        if (!bigend) fByteSwap(ipos,sizeof(float),3);
        file.write((char*)&ipos, 3*sizeof(float));
      }
    }
  }
  else {
    for(j=jstart; j<jend; j++) {
      for(i=istart; i<iend; i++) {
        ilen = i * lbdm.youter + j;
        if(lbphi[ilen] == 12 || lbphi[ilen] == 13) {
	      ipos[0] = 0.0;
          ipos[1] = 0.0;
        }
        else {
          ipos[0] = fGetOneDirecSpeedIncomSite(0, &lbf[ilen*lbsitelength]);
          ipos[1] = fGetOneDirecSpeedIncomSite(1, &lbf[ilen*lbsitelength]);
        }
        ipos[2] = 0.0;
        if (!bigend) fByteSwap(ipos,sizeof(float),3);
        file.write((char*)&ipos, 3*sizeof(float));
      }
    }
  }

  // write phase field/space property
  kpos=sizeof(int)*ilen1*ilen2;
  if (!bigend) fByteSwap(&kpos,sizeof(unsigned int),1);
  file.write(reinterpret_cast<const char*>(&kpos), sizeof(unsigned int));
  for(j=jstart; j<jend; j++)
    for(i=istart; i<iend; i++) {
      ilen=i * lbdm.youter + j;
      jpos=lbphi[ilen];
      if (!bigend) fByteSwap(&jpos,sizeof(int),1);
      file.write(reinterpret_cast<const char*>(&jpos), sizeof(int));
    }

  // write grid points
  kpos=3*sizeof(float)*ilen1*ilen2;
  if (!bigend) fByteSwap(&kpos,sizeof(unsigned int),1);
  file.write(reinterpret_cast<const char*>(&kpos), sizeof(unsigned int));
  for(j=jstart; j<jend; j++)
    for(i=istart; i<iend; i++) {
      ipos[0]=(lbdm.xs + i - lbdm.bwid)*float(lbdx);
      ipos[1]=(lbdm.ys + j - lbdm.bwid)*float(lbdx);
      ipos[2]=0.0;
      if (!bigend) fByteSwap(ipos,sizeof(float),3);
      file.write((char*)&ipos, 3*sizeof(float));
    }

  file<<"</AppendedData>"<<endl;
  file<<"</VTKFile>"<<endl;
  
  file.close();
  
  return 0;
}


int fsOutputVTK2D(const char* filename="lbout")
{
  int i, j, istart, iend, jstart, jend, iprop;
  float ipos[3];
  int jpos;
  long ilen=0;
  char buf[80];
  double rho, frac;
    
  if(lbdm.size>1)
    sprintf(buf, "%s%.6dat%.6d.vts", filename, lbdm.rank, qVersion);
  else
    sprintf(buf, "%s%.6d.vts", filename, qVersion);
  ofstream file(buf);
  file<<"<?xml version=\"1.0\"?>"<<endl;
  file<<"<VTKFile type=\"StructuredGrid\" version=\"0.1\" byte_order=\"BigEndian\">"<<endl;
    
  istart = 0; iend = lbdm.xouter; 
  if(lbdm.xcor == 0)
    istart = lbdm.bwid;
  if(lbdm.xcor == lbdm.xdim-1)
    iend = lbdm.xouter - lbdm.bwid;

  jstart = 0; jend = lbdm.youter; 
  if(lbdm.ycor == 0)
    jstart = lbdm.bwid;
  if(lbdm.ycor == lbdm.ydim-1)
    jend = lbdm.youter - lbdm.bwid;

  file<<"<StructuredGrid WholeExtent=\"";
  file<<(lbdm.xs+istart-lbdm.bwid)<<" "<<(lbdm.xs+iend-lbdm.bwid-1)
      <<" "<<(lbdm.ys+jstart-lbdm.bwid)<<" "<<(lbdm.ys+jend-lbdm.bwid-1)<<" 0 0\">"<<endl;
  file<<"<Piece Extent=\""<<(lbdm.xs+istart-lbdm.bwid)<<" "<<(lbdm.xs+iend-lbdm.bwid-1)
      <<" "<<(lbdm.ys+jstart-lbdm.bwid)<<" "<<(lbdm.ys+jend-lbdm.bwid-1)<<" 0 0\">"<<endl;
  // write grid points
  file<<"<Points>"<<endl;
  file<<"<DataArray type=\"Float32\" NumberOfComponents=\"3\" format=\"ascii\">"<<endl;
  for(j=jstart; j<jend; j++)
    for(i=istart; i<iend; i++)
      file<<(lbdm.xs+i-lbdm.bwid)*float(lbdx)<<" "<<(lbdm.ys+j-lbdm.bwid)*float(lbdx)<<" "<<0.0<<" ";
  file<<endl;
  file<<"</DataArray>"<<endl;
  file<<"</Points>"<<endl;
  file<<"<PointData Scalars=\"density\" Vectors=\"velocity\">"<<endl;
  // write densities and mass fractions
  if(interact==5 && lbsy.nf>1) {
    for(iprop=0; iprop<lbsy.nf; iprop++) {
      file<<"<DataArray Name=\"density_"<<iprop<<"\" type=\"Float32\" format=\"ascii\">"<<endl;
      for(j=jstart; j<jend; j++) {
        for(i=istart; i<iend; i++) {
  	      ilen = i * lbdm.youter + j;
          rho = fGetOneMassSite(&lbf[ilen*lbsitelength]);
          frac = fGetFracSwiftSite(iprop, &lbf[ilen*lbsitelength]);
	      ipos[0] = float(rho*frac);
	      file<<ipos[0]<<" ";
        }
      }
      file<<endl;
      file<<"</DataArray>"<<endl;
    }
    for(iprop=0; iprop<lbsy.nf; iprop++) {
      file<<"<DataArray Name=\"fraction_"<<iprop<<"\" type=\"Float32\" format=\"ascii\">"<<endl;
      for(j=jstart; j<jend; j++) {
        for(i=istart; i<iend; i++) {
	      ilen = i * lbdm.youter + j;
	      ipos[0] = float(fGetFracSwiftSite(iprop, &lbf[ilen*lbsitelength]));
	      file<<ipos[0]<<" ";
        }
      }
      file<<endl;
      file<<"</DataArray>"<<endl;
    }
  }
  else {
    for(iprop=0; iprop<lbsy.nf; iprop++) {
      file<<"<DataArray Name=\"density_"<<iprop<<"\" type=\"Float32\" format=\"ascii\">"<<endl;
      for(j=jstart; j<jend; j++) {
        for(i=istart; i<iend; i++) {
	      ilen = i * lbdm.youter + j;
	      ipos[0] = float(fGetOneMassSite(&lbf[ilen*lbsitelength+iprop]));
	      file<<ipos[0]<<" ";
        }
      }
      file<<endl;
      file<<"</DataArray>"<<endl;
    }
    for(iprop=0; iprop<lbsy.nf; iprop++) {
      file<<"<DataArray Name=\"fraction_"<<iprop<<"\" type=\"Float32\" format=\"ascii\">"<<endl;
      for(j=jstart; j<jend; j++) {
        for(i=istart; i<iend; i++) {
	      ilen = i * lbdm.youter + j;
  	      ipos[0] = float(fGetFracSite(iprop, &lbf[ilen*lbsitelength]));
	      file<<ipos[0]<<" ";
        }
      }
      file<<endl;
      file<<"</DataArray>"<<endl;
    }
  }
  // write solute concentrations
  for(iprop=0; iprop<lbsy.nc; iprop++) {
    file<<"<DataArray Name=\"concentration_"<<iprop<<"\" type=\"Float32\" format=\"ascii\">"<<endl;
    for(j=jstart; j<jend; j++) {
      for(i=istart; i<iend; i++) {
	    ilen = i * lbdm.youter + j;
	    ipos[0] = float(fGetOneConcSite(iprop, ilen));
	    file<<ipos[0]<<" ";
      }
    }
    file<<endl;
    file<<"</DataArray>"<<endl;
  }
  // write temperatures
  if(lbsy.nt==1) {
    file<<"<DataArray Name=\"temperature\" type=\"Float32\" format=\"ascii\">"<<endl;
    for(j=jstart; j<jend; j++) {
      for(i=istart; i<iend; i++) {
	    ilen = i * lbdm.youter + j;
	    ipos[0] = float(fGetTemperatureSite(ilen));
	    file<<ipos[0]<<" ";
      }
    }
    file<<endl;
    file<<"</DataArray>"<<endl;
  }

  // write velocity
  file<<"<DataArray Name=\"velocity\" type=\"Float32\" NumberOfComponents=\"3\" format=\"ascii\">"<<endl;
  if (interact==5) {
    for(j=jstart; j<jend; j++) {
      for(i=istart; i<iend; i++) {
	    ilen = i * lbdm.youter + j;
        if(lbphi[ilen] == 12 || lbphi[ilen] == 13) {
	      ipos[0] = 0.0;
          ipos[1] = 0.0;
        }
	    else {
          ipos[0] = fGetOneDirecSpeedSwiftSite(0, &lbf[ilen*lbsitelength]);
          ipos[1] = fGetOneDirecSpeedSwiftSite(1, &lbf[ilen*lbsitelength]);
        }
	    file<<ipos[0]<<" "<<ipos[1]<<" "<<0.0<<" ";
      }
    }
  }
  else if (!incompress) {
    for(j=jstart; j<jend; j++) {
      for(i=istart; i<iend; i++) {
	    ilen = i * lbdm.youter + j;
        if(lbphi[ilen] == 12 || lbphi[ilen] == 13) {
	      ipos[0] = 0.0;
          ipos[1] = 0.0;
        }
	    else {
          ipos[0] = fGetOneDirecSpeedSite(0, &lbf[ilen*lbsitelength]);
          ipos[1] = fGetOneDirecSpeedSite(1, &lbf[ilen*lbsitelength]);
        }
	    file<<ipos[0]<<" "<<ipos[1]<<" "<<0.0<<" ";
      }
    }
  }
  else {
    for(j=jstart; j<jend; j++) {
      for(i=istart; i<iend; i++) {
	    ilen = i * lbdm.youter + j;
        if(lbphi[ilen] == 12 || lbphi[ilen] == 13) {
          ipos[0] = 0.0;
          ipos[1] = 0.0;
        }
	    else {
          ipos[0] = fGetOneDirecSpeedIncomSite(0, &lbf[ilen*lbsitelength]);
          ipos[1] = fGetOneDirecSpeedIncomSite(1, &lbf[ilen*lbsitelength]);
        }
	    file<<ipos[0]<<" "<<ipos[1]<<" "<<0.0<<" ";
      }
    }
  }

  file<<endl;
  file<<"</DataArray>"<<endl;
  // write phase field/space property
  file<<"<DataArray Name=\"phase_field\" type=\"Int32\" format=\"ascii\">"<<endl;
  for(j=jstart; j<jend; j++)
    for(i=istart; i<iend; i++)
      {
	    ilen = i * lbdm.youter + j;
	    jpos=lbphi[ilen];
	    file<<jpos<<" ";
      }
  file<<endl;
  file<<"</DataArray>"<<endl;
  file<<"</PointData>"<<endl;
  file<<"</Piece>"<<endl;
  file<<"</StructuredGrid>"<<endl;
  file<<"</VTKFile>"<<endl;
  file.close();
  return 0;
}


int fOutputVTKP3D(const char* filename="lbout", int iprop=0)
{

  // output .vts file with macroscopic mass density and velocity for fluid iprop

  int i, j, k, istart, iend, jstart, jend, kstart, kend, offset;
  float ipos[3];
  int jpos;
  long kpos;
  int ilen=0, ilen1=0, ilen2=0, ilen3=0;
  char buf[80];
  double rho, frac;
    
  if(lbdm.size>1)
    sprintf(buf, "%s%.6dat%.6d.vts", filename, lbdm.rank, qVersion);
  else
    sprintf(buf, "%s%.6d.vts", filename, qVersion);
  ofstream file(buf, ios::binary);

  file<<"<?xml version=\"1.0\"?>"<<endl;
  file<<"<VTKFile type=\"StructuredGrid\" version=\"0.1\" byte_order=\"BigEndian\">"<<endl;

  // determine extent of piece
  istart = 0; iend = lbdm.xouter; 
  if(lbdm.xcor == 0)
    istart = lbdm.bwid;
  if(lbdm.xcor == lbdm.xdim-1)
    iend = lbdm.xouter - lbdm.bwid;

  jstart = 0; jend = lbdm.youter; 
  if(lbdm.ycor == 0)
    jstart = lbdm.bwid;
  if(lbdm.ycor == lbdm.ydim-1)
    jend = lbdm.youter - lbdm.bwid;

  kstart = 0; kend = lbdm.zouter; 
  if(lbdm.zcor == 0)
    kstart = lbdm.bwid;
  if(lbdm.zcor == lbdm.zdim-1)
    kend = lbdm.zouter - lbdm.bwid;

  file<<"<StructuredGrid WholeExtent=\"";
  file<<(lbdm.xs+istart-lbdm.bwid)<<" "<<(lbdm.xs+iend-lbdm.bwid-1)
      <<" "<<(lbdm.ys+jstart-lbdm.bwid)<<" "<<(lbdm.ys+jend-lbdm.bwid-1)
      <<" "<<(lbdm.zs+kstart-lbdm.bwid)<<" "<<(lbdm.zs+kend-lbdm.bwid-1)<<"\">"<<endl;
  file<<"<Piece Extent=\""<<(lbdm.xs+istart-lbdm.bwid)<<" "<<(lbdm.xs+iend-lbdm.bwid-1)
      <<" "<<(lbdm.ys+jstart-lbdm.bwid)<<" "<<(lbdm.ys+jend-lbdm.bwid-1)
      <<" "<<(lbdm.zs+kstart-lbdm.bwid)<<" "<<(lbdm.zs+kend-lbdm.bwid-1)<<"\">"<<endl;

  file<<"<PointData Scalars=\"phase_field\" Vectors=\"velocity\">"<<endl;

  // determine number of data points
  ilen1=lbdm.xouter;
  if(lbdm.xcor == 0)
    ilen1 -= lbdm.bwid;
  if(lbdm.xcor == lbdm.xdim-1)
    ilen1 -= lbdm.bwid;

  ilen2=lbdm.youter;
  if(lbdm.ycor == 0)
    ilen2 -= lbdm.bwid;
  if(lbdm.ycor == lbdm.ydim-1)
    ilen2 -= lbdm.bwid;

  ilen3=lbdm.zouter;
  if(lbdm.zcor == 0)
    ilen3 -= lbdm.bwid;
  if(lbdm.zcor == lbdm.zdim-1)
    ilen3 -= lbdm.bwid;

  offset = 0;
  file<<"<DataArray Name=\"density\" type=\"Float32\" format=\"appended\" offset=\""<<offset<<"\">"<<endl;
  offset += sizeof(float)*ilen1*ilen2*ilen3 + sizeof(unsigned int);
  file<<"</DataArray>"<<endl;
  file<<"<DataArray Name=\"velocity\" type=\"Float32\" NumberOfComponents=\"3\" format=\"appended\" offset=\""<<offset<<"\">"<<endl;
  offset += 3*sizeof(float)*ilen1*ilen2*ilen3 + sizeof(unsigned int);
  file<<"</DataArray>"<<endl;
  file<<"<DataArray Name=\"phase_field\" type=\"Int32\" format=\"appended\" offset=\""<<offset<<"\">"<<endl;
  offset += sizeof(int)*ilen1*ilen2*ilen3 + sizeof(unsigned int);
  file<<"</DataArray>"<<endl;
  file<<"</PointData>"<<endl;
  file<<"<Points>"<<endl;
  file<<"<DataArray type=\"Float32\" NumberOfComponents=\"3\" format=\"appended\" offset=\""<<offset<<"\">"<<endl;
  file<<"</DataArray>"<<endl;
  file<<"</Points>"<<endl;
  file<<"</Piece>"<<endl;
  file<<"</StructuredGrid>"<<endl;

  file<<"<AppendedData encoding=\"raw\">"<<endl;
  file<<"_";  

  // write density
  if(interact==5 && lbsy.nf>1) {
    kpos=sizeof(float)*ilen1*ilen2*ilen3;
    if (!bigend) fByteSwap(&kpos,sizeof(unsigned int),1);
    file.write(reinterpret_cast<const char*>(&kpos), sizeof(unsigned int));
    for(k=kstart; k<kend; k++) {
      for(j=jstart; j<jend; j++) {
        for(i=istart; i<iend; i++) {
	      ilen = (i * lbdm.youter + j) * lbdm.zouter + k;
          rho = fGetOneMassSite(&lbf[ilen*lbsitelength]);
          frac = fGetFracSwiftSite(iprop, &lbf[ilen*lbsitelength]);
  	      ipos[0] = float(rho*frac);
          if (!bigend) fByteSwap(ipos,sizeof(float),1);
	      file.write((char*)&ipos[0], sizeof(float));
        }
      }
    }
  }
  else {
    kpos=sizeof(float)*ilen1*ilen2*ilen3;
    if (!bigend) fByteSwap(&kpos,sizeof(unsigned int),1);
    file.write(reinterpret_cast<const char*>(&kpos), sizeof(unsigned int));
    for(k=kstart; k<kend; k++) {
      for(j=jstart; j<jend; j++) {
        for(i=istart; i<iend; i++) {
	      ilen = (i * lbdm.youter + j) * lbdm.zouter + k;
	      ipos[0] = float(fGetOneMassSite(&lbf[ilen*lbsitelength+iprop]));
          if (!bigend) fByteSwap(ipos,sizeof(float),1);
	      file.write((char*)&ipos[0], sizeof(float));
        }
      }
    }
  }
    
  // write velocity
  kpos=3*sizeof(float)*ilen1*ilen2*ilen3;
  if (!bigend) fByteSwap(&kpos,sizeof(unsigned int),1);
  file.write(reinterpret_cast<const char*>(&kpos), sizeof(unsigned int));
  if(interact==5) {
    for(k=kstart; k<kend; k++) {
      for(j=jstart; j<jend; j++) {
        for(i=istart; i<iend; i++) {
	      ilen = (i * lbdm.youter + j) * lbdm.zouter + k;
  	      if(lbphi[ilen] == 12 || lbphi[ilen] == 13) {
	        ipos[0] = 0.0;
            ipos[1] = 0.0;
            ipos[2] = 0.0;
          }
	      else {
            ipos[0] = fGetOneDirecSpeedSwiftSite(0, &lbf[ilen*lbsitelength]);
            ipos[1] = fGetOneDirecSpeedSwiftSite(1, &lbf[ilen*lbsitelength]);
            ipos[2] = fGetOneDirecSpeedSwiftSite(2, &lbf[ilen*lbsitelength]);
          }
          if (!bigend) fByteSwap(ipos,sizeof(float),3);
	      file.write((char*)&ipos, 3*sizeof(float));
        }
      }
    }
  }
  if(!incompress) {
    for(k=kstart; k<kend; k++) {
      for(j=jstart; j<jend; j++) {
        for(i=istart; i<iend; i++) {
	      ilen = (i * lbdm.youter + j) * lbdm.zouter + k;
  	      if(lbphi[ilen] == 12 || lbphi[ilen] == 13) {
	        ipos[0] = 0.0;
            ipos[1] = 0.0;
            ipos[2] = 0.0;
          }
	      else {
            ipos[0] = fGetOneDirecSpeedSite(0, &lbf[ilen*lbsitelength]);
            ipos[1] = fGetOneDirecSpeedSite(1, &lbf[ilen*lbsitelength]);
            ipos[2] = fGetOneDirecSpeedSite(2, &lbf[ilen*lbsitelength]);
          }
          if (!bigend) fByteSwap(ipos,sizeof(float),3);
	      file.write((char*)&ipos, 3*sizeof(float));
        }
      }
    }
  }
  else {
    for(k=kstart; k<kend; k++) {
      for(j=jstart; j<jend; j++) {
        for(i=istart; i<iend; i++) {
	      ilen = (i * lbdm.youter + j) * lbdm.zouter + k;
  	      if(lbphi[ilen] == 12 || lbphi[ilen] == 13) {
	        ipos[0] = 0.0;
            ipos[1] = 0.0;
            ipos[2] = 0.0;
          }
	      else {
            ipos[0] = fGetOneDirecSpeedIncomSite(0, &lbf[ilen*lbsitelength]);
            ipos[1] = fGetOneDirecSpeedIncomSite(1, &lbf[ilen*lbsitelength]);
            ipos[2] = fGetOneDirecSpeedIncomSite(2, &lbf[ilen*lbsitelength]);
          }
          if (!bigend) fByteSwap(ipos,sizeof(float),3);
	      file.write((char*)&ipos, 3*sizeof(float));
        }
      }
    }
  }
  // write phase field/space property
  kpos=sizeof(int)*ilen1*ilen2*ilen3;
  if (!bigend) fByteSwap(&kpos,sizeof(unsigned int),1);
  file.write(reinterpret_cast<const char*>(&kpos), sizeof(unsigned int));
  for(k=kstart; k<kend; k++)
    for(j=jstart; j<jend; j++) {
      for(i=istart; i<iend; i++) {
	    ilen=(i * lbdm.youter + j) * lbdm.zouter + k;
	    jpos=lbphi[ilen];
        if (!bigend) fByteSwap(&jpos,sizeof(int),1);
	    file.write(reinterpret_cast<const char*>(&jpos), sizeof(int));
      }
    }	

  // write grid points
  kpos=3*sizeof(float)*ilen1*ilen2*ilen3;
  if (!bigend) fByteSwap(&kpos,sizeof(unsigned int),1);
  file.write(reinterpret_cast<const char*>(&kpos), sizeof(unsigned int));
  for(k=kstart; k<kend; k++)
    for(j=jstart; j<jend; j++) {
      for(i=istart; i<iend; i++) {
	    ipos[0]=(lbdm.xs + i - lbdm.bwid)*float(lbdx);
	    ipos[1]=(lbdm.ys + j - lbdm.bwid)*float(lbdx);
	    ipos[2]=(lbdm.zs + k - lbdm.bwid)*float(lbdx);
        if (!bigend) fByteSwap(ipos,sizeof(float),3);
	    file.write((char*)&ipos, 3*sizeof(float));
      }
    }

  file<<"</AppendedData>"<<endl;
  file<<"</VTKFile>"<<endl;
  
  file.close();
  
  return 0;
}


int fsOutputVTKP3D(const char* filename="lbout", int iprop=0)
{
  int i, j, k, istart, iend, jstart, jend, kstart, kend;
  float ipos[3];
  int jpos;
  long ilen=0;
  char buf[80];
  double rho, frac;
    
  if(lbdm.size>1)
    sprintf(buf, "%s%.6dat%.6d.vts", filename, lbdm.rank, qVersion);
  else
    sprintf(buf, "%s%.6d.vts", filename, qVersion);
  ofstream file(buf);
  file<<"<?xml version=\"1.0\"?>"<<endl;
  file<<"<VTKFile type=\"StructuredGrid\" version=\"0.1\" byte_order=\"BigEndian\">"<<endl;
  istart = 0; iend = lbdm.xouter; 
  if(lbdm.xcor == 0)
    istart = lbdm.bwid;
  if(lbdm.xcor == lbdm.xdim-1)
    iend = lbdm.xouter - lbdm.bwid;

  jstart = 0; jend = lbdm.youter; 
  if(lbdm.ycor == 0)
    jstart = lbdm.bwid;
  if(lbdm.ycor == lbdm.ydim-1)
    jend = lbdm.youter - lbdm.bwid;

  kstart = 0; kend = lbdm.zouter; 
  if(lbdm.zcor == 0)
    kstart = lbdm.bwid;
  if(lbdm.zcor == lbdm.zdim-1)
    kend = lbdm.zouter - lbdm.bwid;

  file<<"<StructuredGrid WholeExtent=\"";
  file<<(lbdm.xs+istart-lbdm.bwid)<<" "<<(lbdm.xs+iend-lbdm.bwid-1)
      <<" "<<(lbdm.ys+jstart-lbdm.bwid)<<" "<<(lbdm.ys+jend-lbdm.bwid-1)
      <<" "<<(lbdm.zs+kstart-lbdm.bwid)<<" "<<(lbdm.zs+kend-lbdm.bwid-1)<<"\">"<<endl;
  file<<"<Piece Extent=\""<<(lbdm.xs+istart-lbdm.bwid)<<" "<<(lbdm.xs+iend-lbdm.bwid-1)
      <<" "<<(lbdm.ys+jstart-lbdm.bwid)<<" "<<(lbdm.ys+jend-lbdm.bwid-1)
      <<" "<<(lbdm.zs+kstart-lbdm.bwid)<<" "<<(lbdm.zs+kend-lbdm.bwid-1)<<"\">"<<endl;
  // write grid points
  file<<"<Points>"<<endl;
  file<<"<DataArray type=\"Float32\" NumberOfComponents=\"3\" format=\"ascii\">"<<endl;
  for(k=kstart; k<kend; k++)
    for(j=jstart; j<jend; j++)
      for(i=istart; i<iend; i++)
	    file<<(lbdm.xs+i-lbdm.bwid)*float(lbdx)<<" "<<(lbdm.ys+j-lbdm.bwid)*float(lbdx)<<" "<<(lbdm.zs+k-lbdm.bwid)*float(lbdx)<<" ";
  file<<endl;
  file<<"</DataArray>"<<endl;
  file<<"</Points>"<<endl;
  file<<"<PointData Scalars=\"density\" Vectors=\"velocity\">"<<endl;
  // write density
  file<<"<DataArray Name=\"density\" type=\"Float32\" format=\"ascii\">"<<endl;
  if(interact==5 && lbsy.nf>1) {
    for(k=kstart; k<kend; k++) {
      for(j=jstart; j<jend; j++) {
        for(i=istart; i<iend; i++) {
          ilen = (i * lbdm.youter + j) * lbdm.zouter + k;
          rho = fGetOneMassSite(&lbf[ilen*lbsitelength]);
          frac = fGetFracSwiftSite(iprop, &lbf[ilen*lbsitelength]);
	      ipos[0] = float(rho*frac);
	      file<<ipos[0]<<" ";
        }
      }
    }
  }
  else {
    for(k=kstart; k<kend; k++) {
      for(j=jstart; j<jend; j++) {
        for(i=istart; i<iend; i++) {
          ilen = (i * lbdm.youter + j) * lbdm.zouter + k;
	      ipos[0] = float(fGetOneMassSite(&lbf[ilen*lbsitelength+iprop]));
	      file<<ipos[0]<<" ";
        }
      }
    }
  }
  file<<endl;
  file<<"</DataArray>"<<endl;
  // write velocity
  file<<"<DataArray Name=\"velocity\" type=\"Float32\" NumberOfComponents=\"3\" format=\"ascii\">"<<endl;
  if(interact==5) {
    for(k=kstart; k<kend; k++) {
      for(j=jstart; j<jend; j++) {
        for(i=istart; i<iend; i++) {
	      ilen = (i * lbdm.youter + j) * lbdm.zouter + k;
  	      if(lbphi[ilen] == 12 || lbphi[ilen] == 13) {
	        ipos[0] = 0.0;
            ipos[1] = 0.0;
            ipos[2] = 0.0;
          }
	      else {
            ipos[0] = fGetOneDirecSpeedSwiftSite(0, &lbf[ilen*lbsitelength]);
            ipos[1] = fGetOneDirecSpeedSwiftSite(1, &lbf[ilen*lbsitelength]);
            ipos[2] = fGetOneDirecSpeedSwiftSite(2, &lbf[ilen*lbsitelength]);
          }
	      file<<ipos[0]<<" "<<ipos[1]<<" "<<ipos[2]<<" ";
	    }
      }
    }
  }
  else if(!incompress) {
    for(k=kstart; k<kend; k++) {
      for(j=jstart; j<jend; j++) {
        for(i=istart; i<iend; i++) {
	      ilen = (i * lbdm.youter + j) * lbdm.zouter + k;
  	      if(lbphi[ilen] == 12 || lbphi[ilen] == 13) {
	        ipos[0] = 0.0;
            ipos[1] = 0.0;
            ipos[2] = 0.0;
          }
	      else {
            ipos[0] = fGetOneDirecSpeedSite(0, &lbf[ilen*lbsitelength]);
            ipos[1] = fGetOneDirecSpeedSite(1, &lbf[ilen*lbsitelength]);
            ipos[2] = fGetOneDirecSpeedSite(2, &lbf[ilen*lbsitelength]);
          }
	      file<<ipos[0]<<" "<<ipos[1]<<" "<<ipos[2]<<" ";
	    }
      }
    }
  }
  else {
    for(k=kstart; k<kend; k++) {
      for(j=jstart; j<jend; j++) {
        for(i=istart; i<iend; i++) {
	      ilen = (i * lbdm.youter + j) * lbdm.zouter + k;
  	      if(lbphi[ilen] == 12 || lbphi[ilen] == 13) {
	        ipos[0] = 0.0;
            ipos[1] = 0.0;
            ipos[2] = 0.0;
          }
	      else {
            ipos[0] = fGetOneDirecSpeedIncomSite(0, &lbf[ilen*lbsitelength]);
            ipos[1] = fGetOneDirecSpeedIncomSite(1, &lbf[ilen*lbsitelength]);
            ipos[2] = fGetOneDirecSpeedIncomSite(2, &lbf[ilen*lbsitelength]);
          }
	      file<<ipos[0]<<" "<<ipos[1]<<" "<<ipos[2]<<" ";
	    }
      }
    }
  }

  file<<endl;
  file<<"</DataArray>"<<endl;
  // write phase field/space property
  file<<"<DataArray Name=\"phase_field\" type=\"Int32\" format=\"ascii\">"<<endl;
  for(k=kstart; k<kend; k++)
    for(j=jstart; j<jend; j++)
      for(i=istart; i<iend; i++)
	    {
	      ilen = (i * lbdm.youter + j) * lbdm.zouter + k;
	      jpos=lbphi[ilen];
	      file<<jpos<<" ";
	    }
  file<<endl;
  file<<"</DataArray>"<<endl;
  file<<"</PointData>"<<endl;
  file<<"</Piece>"<<endl;
  file<<"</StructuredGrid>"<<endl;
  file<<"</VTKFile>"<<endl;
  file.close();
  return 0;
}


int fOutputVTKP2D(const char* filename="lbout", int iprop=0)
{

  // output .vts file with macroscopic mass density and velocity for fluid iprop

  int i, j, istart, iend, jstart, jend, offset;
  float ipos[3];
  int jpos;
  long kpos;
  int ilen=0, ilen1=0, ilen2=0;
  char buf[80];
  double rho, frac;
    
  if(lbdm.size>1)
    sprintf(buf, "%s%.6dat%.6d.vts", filename, lbdm.rank, qVersion);
  else
    sprintf(buf, "%s%.6d.vts", filename, qVersion);
  ofstream file(buf, ios::binary);

  file<<"<?xml version=\"1.0\"?>"<<endl;
  file<<"<VTKFile type=\"StructuredGrid\" version=\"0.1\" byte_order=\"BigEndian\">"<<endl;

  // determine extent of piece
  istart = 0; iend = lbdm.xouter; 
  if(lbdm.xcor == 0)
    istart = lbdm.bwid;
  if(lbdm.xcor == lbdm.xdim-1)
    iend = lbdm.xouter - lbdm.bwid;

  jstart = 0; jend = lbdm.youter; 
  if(lbdm.ycor == 0)
    jstart = lbdm.bwid;
  if(lbdm.ycor == lbdm.ydim-1)
    jend = lbdm.youter - lbdm.bwid;

  file<<"<StructuredGrid WholeExtent=\"";
  file<<(lbdm.xs+istart-lbdm.bwid)<<" "<<(lbdm.xs+iend-lbdm.bwid-1)
      <<" "<<(lbdm.ys+jstart-lbdm.bwid)<<" "<<(lbdm.ys+jend-lbdm.bwid-1)<<" 0 0\">"<<endl;
  file<<"<Piece Extent=\""<<(lbdm.xs+istart-lbdm.bwid)<<" "<<(lbdm.xs+iend-lbdm.bwid-1)
      <<" "<<(lbdm.ys+jstart-lbdm.bwid)<<" "<<(lbdm.ys+jend-lbdm.bwid-1)<<" 0 0\">"<<endl;

  file<<"<PointData Scalars=\"phase_field\" Vectors=\"velocity\">"<<endl;

  // determine number of data points
  ilen1=lbdm.xouter;
  if(lbdm.xcor == 0)
    ilen1 -= lbdm.bwid;
  if(lbdm.xcor == lbdm.xdim-1)
    ilen1 -= lbdm.bwid;

  ilen2=lbdm.youter;
  if(lbdm.ycor == 0)
    ilen2 -= lbdm.bwid;
  if(lbdm.ycor == lbdm.ydim-1)
    ilen2 -= lbdm.bwid;

  offset = 0;
  file<<"<DataArray Name=\"density\" type=\"Float32\" format=\"appended\" offset=\""<<offset<<"\">"<<endl;
  offset += sizeof(float)*ilen1*ilen2 + sizeof(unsigned int);
  file<<"</DataArray>"<<endl;
  file<<"<DataArray Name=\"velocity\" type=\"Float32\" NumberOfComponents=\"3\" format=\"appended\" offset=\""<<offset<<"\">"<<endl;
  offset += 3*sizeof(float)*ilen1*ilen2 + sizeof(unsigned int);
  file<<"</DataArray>"<<endl;
  file<<"<DataArray Name=\"phase_field\" type=\"Int32\" format=\"appended\" offset=\""<<offset<<"\">"<<endl;
  offset += sizeof(int)*ilen1*ilen2 + sizeof(unsigned int);
  file<<"</DataArray>"<<endl;
  file<<"</PointData>"<<endl;
  file<<"<Points>"<<endl;
  file<<"<DataArray type=\"Float32\" NumberOfComponents=\"3\" format=\"appended\" offset=\""<<offset<<"\">"<<endl;
  file<<"</DataArray>"<<endl;
  file<<"</Points>"<<endl;
  file<<"</Piece>"<<endl;
  file<<"</StructuredGrid>"<<endl;

  file<<"<AppendedData encoding=\"raw\">"<<endl;
  file<<"_";  

  // write density
  kpos=sizeof(float)*ilen1*ilen2;
  if (!bigend) fByteSwap(&kpos,sizeof(unsigned int),1);
  file.write(reinterpret_cast<const char*>(&kpos), sizeof(unsigned int));
  if(interact==5 && lbsy.nf>1) {
    for(j=jstart; j<jend; j++) {
      for(i=istart; i<iend; i++) {
        ilen = i * lbdm.youter + j;
        rho = fGetOneMassSite(&lbf[ilen*lbsitelength]);
        frac = fGetFracSwiftSite(iprop, &lbf[ilen*lbsitelength]);
        ipos[0] = float(rho*frac);
        if (!bigend) fByteSwap(ipos,sizeof(float),1);
        file.write((char*)&ipos[0], sizeof(float));
      }
    }
  }
  else {
    for(j=jstart; j<jend; j++) {
      for(i=istart; i<iend; i++) {
        ilen = i * lbdm.youter + j;
        ipos[0] = float(fGetOneMassSite(&lbf[ilen*lbsitelength+iprop]));
        if (!bigend) fByteSwap(ipos,sizeof(float),1);
        file.write((char*)&ipos[0], sizeof(float));
      }
    }
  }

  // write velocity
  kpos=3*sizeof(float)*ilen1*ilen2;
  if (!bigend) fByteSwap(&kpos,sizeof(unsigned int),1);
  file.write(reinterpret_cast<const char*>(&kpos), sizeof(unsigned int));
  if (interact==5) {
    for(j=jstart; j<jend; j++) {
      for(i=istart; i<iend; i++) {
        ilen = i * lbdm.youter + j;
        if(lbphi[ilen] == 12 || lbphi[ilen] == 13) {
	      ipos[0] = 0.0;
          ipos[1] = 0.0;
        }
        else {
          ipos[0] = fGetOneDirecSpeedSite(0, &lbf[ilen*lbsitelength]);
          ipos[1] = fGetOneDirecSpeedSite(1, &lbf[ilen*lbsitelength]);
        }
        ipos[2] = 0.0;
        if (!bigend) fByteSwap(ipos,sizeof(float),3);
        file.write((char*)&ipos, 3*sizeof(float));
      }
    }
  }
  else if (!incompress) {
    for(j=jstart; j<jend; j++) {
      for(i=istart; i<iend; i++) {
        ilen = i * lbdm.youter + j;
        if(lbphi[ilen] == 12 || lbphi[ilen] == 13) {
	      ipos[0] = 0.0;
          ipos[1] = 0.0;
        }
        else {
          ipos[0] = fGetOneDirecSpeedSite(0, &lbf[ilen*lbsitelength]);
          ipos[1] = fGetOneDirecSpeedSite(1, &lbf[ilen*lbsitelength]);
        }
        ipos[2] = 0.0;
        if (!bigend) fByteSwap(ipos,sizeof(float),3);
        file.write((char*)&ipos, 3*sizeof(float));
      }
    }
  }
  else {
    for(j=jstart; j<jend; j++) {
      for(i=istart; i<iend; i++) {
        ilen = i * lbdm.youter + j;
        if(lbphi[ilen] == 12 || lbphi[ilen] == 13) {
	      ipos[0] = 0.0;
          ipos[1] = 0.0;
        }
        else {
          ipos[0] = fGetOneDirecSpeedIncomSite(0, &lbf[ilen*lbsitelength]);
          ipos[1] = fGetOneDirecSpeedIncomSite(1, &lbf[ilen*lbsitelength]);
        }
        ipos[2] = 0.0;
        if (!bigend) fByteSwap(ipos,sizeof(float),3);
        file.write((char*)&ipos, 3*sizeof(float));
      }
    }
  }

  // write phase field/space property
  kpos=sizeof(int)*ilen1*ilen2;
  if (!bigend) fByteSwap(&kpos,sizeof(unsigned int),1);
  file.write(reinterpret_cast<const char*>(&kpos), sizeof(unsigned int));
  for(j=jstart; j<jend; j++)
    for(i=istart; i<iend; i++) {
      ilen=i * lbdm.youter + j;
      jpos=lbphi[ilen];
      if (!bigend) fByteSwap(&jpos,sizeof(int),1);
      file.write(reinterpret_cast<const char*>(&jpos), sizeof(int));
    }

  // write grid points
  kpos=3*sizeof(float)*ilen1*ilen2;
  if (!bigend) fByteSwap(&kpos,sizeof(unsigned int),1);
  file.write(reinterpret_cast<const char*>(&kpos), sizeof(unsigned int));
  for(j=jstart; j<jend; j++)
    for(i=istart; i<iend; i++) {
      ipos[0]=(lbdm.xs + i - lbdm.bwid)*float(lbdx);
      ipos[1]=(lbdm.ys + j - lbdm.bwid)*float(lbdx);
      ipos[2]=0.0;
      if (!bigend) fByteSwap(ipos,sizeof(float),3);
      file.write((char*)&ipos, 3*sizeof(float));
    }

  file<<"</AppendedData>"<<endl;
  file<<"</VTKFile>"<<endl;
  
  file.close();
  
  return 0;
}


int fsOutputVTKP2D(const char* filename="lbout", int iprop=0)
{
  int i, j, istart, iend, jstart, jend;
  float ipos[3];
  int jpos;
  long ilen=0;
  char buf[80];
  double rho, frac;
    
  if(lbdm.size>1)
    sprintf(buf, "%s%.6dat%.6d.vts", filename, lbdm.rank, qVersion);
  else
    sprintf(buf, "%s%.6d.vts", filename, qVersion);
  ofstream file(buf);
  file<<"<?xml version=\"1.0\"?>"<<endl;
  file<<"<VTKFile type=\"StructuredGrid\" version=\"0.1\" byte_order=\"BigEndian\">"<<endl;
  istart = 0; iend = lbdm.xouter; 
  if(lbdm.xcor == 0)
    istart = lbdm.bwid;
  if(lbdm.xcor == lbdm.xdim-1)
    iend = lbdm.xouter - lbdm.bwid;

  jstart = 0; jend = lbdm.youter; 
  if(lbdm.ycor == 0)
    jstart = lbdm.bwid;
  if(lbdm.ycor == lbdm.ydim-1)
    jend = lbdm.youter - lbdm.bwid;

  file<<"<StructuredGrid WholeExtent=\"";
  file<<(lbdm.xs+istart-lbdm.bwid)<<" "<<(lbdm.xs+iend-lbdm.bwid-1)
      <<" "<<(lbdm.ys+jstart-lbdm.bwid)<<" "<<(lbdm.ys+jend-lbdm.bwid-1)<<" 0 0\">"<<endl;
  file<<"<Piece Extent=\""<<(lbdm.xs+istart-lbdm.bwid)<<" "<<(lbdm.xs+iend-lbdm.bwid-1)
      <<" "<<(lbdm.ys+jstart-lbdm.bwid)<<" "<<(lbdm.ys+jend-lbdm.bwid-1)<<" 0 0\">"<<endl;
  // write grid points
  file<<"<Points>"<<endl;
  file<<"<DataArray type=\"Float32\" NumberOfComponents=\"3\" format=\"ascii\">"<<endl;
  for(j=jstart; j<jend; j++)
    for(i=istart; i<iend; i++)
      file<<(lbdm.xs+i-lbdm.bwid)*float(lbdx)<<" "<<(lbdm.ys+j-lbdm.bwid)*float(lbdx)<<" "<<0.0<<" ";
  file<<endl;
  file<<"</DataArray>"<<endl;
  file<<"</Points>"<<endl;
  file<<"<PointData Scalars=\"density\" Vectors=\"velocity\">"<<endl;
  // write density
  file<<"<DataArray Name=\"density\" type=\"Float32\" format=\"ascii\">"<<endl;
  if(interact==5 && lbsy.nf>1) {
    for(j=jstart; j<jend; j++) {
      for(i=istart; i<iend; i++) {
        ilen = i * lbdm.youter + j;
        rho = fGetOneMassSite(&lbf[ilen*lbsitelength]);
        frac = fGetFracSite(iprop, &lbf[ilen*lbsitelength]);
	    ipos[0] = float(rho*frac);
	    file<<ipos[0]<<" ";
      }
    }
  }
  else {
    for(j=jstart; j<jend; j++) {
      for(i=istart; i<iend; i++) {
	    ilen = i * lbdm.youter + j;
	    ipos[0] = float(fGetOneMassSite(&lbf[ilen*lbsitelength+iprop]));
	    file<<ipos[0]<<" ";
      }
    }
  }
  file<<endl;
  file<<"</DataArray>"<<endl;
  // write velocity
  file<<"<DataArray Name=\"velocity\" type=\"Float32\" NumberOfComponents=\"3\" format=\"ascii\">"<<endl;
  if (interact==5) {
    for(j=jstart; j<jend; j++) {
      for(i=istart; i<iend; i++) {
	    ilen = i * lbdm.youter + j;
        if(lbphi[ilen] == 12 || lbphi[ilen] == 13) {
	      ipos[0] = 0.0;
          ipos[1] = 0.0;
        }
	    else {
          ipos[0] = fGetOneDirecSpeedSite(0, &lbf[ilen*lbsitelength]);
          ipos[1] = fGetOneDirecSpeedSite(1, &lbf[ilen*lbsitelength]);
        }
	    file<<ipos[0]<<" "<<ipos[1]<<" "<<0.0<<" ";
      }
    }
  }
  else if (!incompress) {
    for(j=jstart; j<jend; j++) {
      for(i=istart; i<iend; i++) {
	    ilen = i * lbdm.youter + j;
        if(lbphi[ilen] == 12 || lbphi[ilen] == 13) {
	      ipos[0] = 0.0;
          ipos[1] = 0.0;
        }
	    else {
          ipos[0] = fGetOneDirecSpeedSite(0, &lbf[ilen*lbsitelength]);
          ipos[1] = fGetOneDirecSpeedSite(1, &lbf[ilen*lbsitelength]);
        }
	    file<<ipos[0]<<" "<<ipos[1]<<" "<<0.0<<" ";
      }
    }
  }
  else {
    for(j=jstart; j<jend; j++) {
      for(i=istart; i<iend; i++) {
	    ilen = i * lbdm.youter + j;
        if(lbphi[ilen] == 12 || lbphi[ilen] == 13) {
	      ipos[0] = 0.0;
          ipos[1] = 0.0;
        }
	    else {
          ipos[0] = fGetOneDirecSpeedIncomSite(0, &lbf[ilen*lbsitelength]);
          ipos[1] = fGetOneDirecSpeedIncomSite(1, &lbf[ilen*lbsitelength]);
        }
	    file<<ipos[0]<<" "<<ipos[1]<<" "<<0.0<<" ";
      }
    }
  }

  file<<endl;
  file<<"</DataArray>"<<endl;
  // write phase field/space property
  file<<"<DataArray Name=\"phase_field\" type=\"Int32\" format=\"ascii\">"<<endl;
  for(j=jstart; j<jend; j++)
    for(i=istart; i<iend; i++)
      {
	    ilen = i * lbdm.youter + j;
	    jpos=lbphi[ilen];
	    file<<jpos<<" ";
      }
  file<<endl;
  file<<"</DataArray>"<<endl;
  file<<"</PointData>"<<endl;
  file<<"</Piece>"<<endl;
  file<<"</StructuredGrid>"<<endl;
  file<<"</VTKFile>"<<endl;
  file.close();
  return 0;
}


int fOutputVTKCA3D(const char* filename="lbout", int iprop=0)
{

  // output .vts file with mass fraction and velocity for fluid iprop

  int i, j, k, istart, iend, jstart, jend, kstart, kend, offset;
  float ipos[3];
  int jpos;
  long kpos;
  int ilen=0, ilen1=0, ilen2=0, ilen3=0;
  char buf[80];
  if(lbdm.size>1)
    sprintf(buf, "%s%.6dat%.6d.vts", filename, lbdm.rank, qVersion);
  else
    sprintf(buf, "%s%.6d.vts", filename, qVersion);
  ofstream file(buf, ios::binary);

  file<<"<?xml version=\"1.0\"?>"<<endl;
  file<<"<VTKFile type=\"StructuredGrid\" version=\"0.1\" byte_order=\"BigEndian\">"<<endl;

  // determine extent of piece
  istart = 0; iend = lbdm.xouter; 
  if(lbdm.xcor == 0)
    istart = lbdm.bwid;
  if(lbdm.xcor == lbdm.xdim-1)
    iend = lbdm.xouter - lbdm.bwid;

  jstart = 0; jend = lbdm.youter; 
  if(lbdm.ycor == 0)
    jstart = lbdm.bwid;
  if(lbdm.ycor == lbdm.ydim-1)
    jend = lbdm.youter - lbdm.bwid;

  kstart = 0; kend = lbdm.zouter; 
  if(lbdm.zcor == 0)
    kstart = lbdm.bwid;
  if(lbdm.zcor == lbdm.zdim-1)
    kend = lbdm.zouter - lbdm.bwid;

  file<<"<StructuredGrid WholeExtent=\"";
  file<<(lbdm.xs+istart-lbdm.bwid)<<" "<<(lbdm.xs+iend-lbdm.bwid-1)
      <<" "<<(lbdm.ys+jstart-lbdm.bwid)<<" "<<(lbdm.ys+jend-lbdm.bwid-1)
      <<" "<<(lbdm.zs+kstart-lbdm.bwid)<<" "<<(lbdm.zs+kend-lbdm.bwid-1)<<"\">"<<endl;
  file<<"<Piece Extent=\""<<(lbdm.xs+istart-lbdm.bwid)<<" "<<(lbdm.xs+iend-lbdm.bwid-1)
      <<" "<<(lbdm.ys+jstart-lbdm.bwid)<<" "<<(lbdm.ys+jend-lbdm.bwid-1)
      <<" "<<(lbdm.zs+kstart-lbdm.bwid)<<" "<<(lbdm.zs+kend-lbdm.bwid-1)<<"\">"<<endl;

  file<<"<PointData Scalars=\"phase_field\" Vectors=\"velocity\">"<<endl;

  // determine number of data points
  ilen1=lbdm.xouter;
  if(lbdm.xcor == 0)
    ilen1 -= lbdm.bwid;
  if(lbdm.xcor == lbdm.xdim-1)
    ilen1 -= lbdm.bwid;

  ilen2=lbdm.youter;
  if(lbdm.ycor == 0)
    ilen2 -= lbdm.bwid;
  if(lbdm.ycor == lbdm.ydim-1)
    ilen2 -= lbdm.bwid;

  ilen3=lbdm.zouter;
  if(lbdm.zcor == 0)
    ilen3 -= lbdm.bwid;
  if(lbdm.zcor == lbdm.zdim-1)
    ilen3 -= lbdm.bwid;

  offset = 0;
  file<<"<DataArray Name=\"fraction\" type=\"Float32\" format=\"appended\" offset=\""<<offset<<"\">"<<endl;
  offset += sizeof(float)*ilen1*ilen2*ilen3 + sizeof(unsigned int);
  file<<"</DataArray>"<<endl;
  file<<"<DataArray Name=\"velocity\" type=\"Float32\" NumberOfComponents=\"3\" format=\"appended\" offset=\""<<offset<<"\">"<<endl;
  offset += 3*sizeof(float)*ilen1*ilen2*ilen3 + sizeof(unsigned int);
  file<<"</DataArray>"<<endl;
  file<<"<DataArray Name=\"phase_field\" type=\"Int32\" format=\"appended\" offset=\""<<offset<<"\">"<<endl;
  offset += sizeof(int)*ilen1*ilen2*ilen3 + sizeof(unsigned int);
  file<<"</DataArray>"<<endl;
  file<<"</PointData>"<<endl;
  file<<"<Points>"<<endl;
  file<<"<DataArray type=\"Float32\" NumberOfComponents=\"3\" format=\"appended\" offset=\""<<offset<<"\">"<<endl;
  file<<"</DataArray>"<<endl;
  file<<"</Points>"<<endl;
  file<<"</Piece>"<<endl;
  file<<"</StructuredGrid>"<<endl;

  file<<"<AppendedData encoding=\"raw\">"<<endl;
  file<<"_";  

  // write mass fraction
  kpos=sizeof(float)*ilen1*ilen2*ilen3;
  if (!bigend) fByteSwap(&kpos,sizeof(unsigned int),1);
  file.write(reinterpret_cast<const char*>(&kpos), sizeof(unsigned int));
  if(interact==5 && lbsy.nf>1) {
    for(k=kstart; k<kend; k++) {
      for(j=jstart; j<jend; j++) {
        for(i=istart; i<iend; i++) {
	      ilen = (i * lbdm.youter + j) * lbdm.zouter + k;
  	      ipos[0] = float(fGetFracSwiftSite(iprop, &lbf[ilen*lbsitelength]));
          if (!bigend) fByteSwap(ipos,sizeof(float),1);
	      file.write((char*)&ipos[0], sizeof(float));
        }
      }
    }
  }
  else {
    for(k=kstart; k<kend; k++) {
      for(j=jstart; j<jend; j++) {
        for(i=istart; i<iend; i++) {
	      ilen = (i * lbdm.youter + j) * lbdm.zouter + k;
  	      ipos[0] = float(fGetFracSite(iprop, &lbf[ilen*lbsitelength]));
          if (!bigend) fByteSwap(ipos,sizeof(float),1);
	      file.write((char*)&ipos[0], sizeof(float));
        }
      }
    }
  }
  // write velocity
  kpos=3*sizeof(float)*ilen1*ilen2*ilen3;
  if (!bigend) fByteSwap(&kpos,sizeof(unsigned int),1);
  file.write(reinterpret_cast<const char*>(&kpos), sizeof(unsigned int));
  if(interact==5) {
    for(k=kstart; k<kend; k++) {
      for(j=jstart; j<jend; j++) {
        for(i=istart; i<iend; i++) {
	      ilen = (i * lbdm.youter + j) * lbdm.zouter + k;
 	      if(lbphi[ilen] == 12 || lbphi[ilen] == 13) {
	        ipos[0] = 0.0;
            ipos[1] = 0.0;
            ipos[2] = 0.0;
          }
	      else {
            ipos[0] = fGetOneDirecSpeedSwiftSite(0, &lbf[ilen*lbsitelength]);
            ipos[1] = fGetOneDirecSpeedSwiftSite(1, &lbf[ilen*lbsitelength]);
            ipos[2] = fGetOneDirecSpeedSwiftSite(2, &lbf[ilen*lbsitelength]);
          }
          if (!bigend) fByteSwap(ipos,sizeof(float),3);
  	      file.write((char*)&ipos, 3*sizeof(float));
        }
      }
    }
  }
  else if(!incompress) {
    for(k=kstart; k<kend; k++) {
      for(j=jstart; j<jend; j++) {
        for(i=istart; i<iend; i++) {
	      ilen = (i * lbdm.youter + j) * lbdm.zouter + k;
 	      if(lbphi[ilen] == 12 || lbphi[ilen] == 13) {
	        ipos[0] = 0.0;
            ipos[1] = 0.0;
            ipos[2] = 0.0;
          }
	      else {
            ipos[0] = fGetOneDirecSpeedSite(0, &lbf[ilen*lbsitelength]);
            ipos[1] = fGetOneDirecSpeedSite(1, &lbf[ilen*lbsitelength]);
            ipos[2] = fGetOneDirecSpeedSite(2, &lbf[ilen*lbsitelength]);
          }
          if (!bigend) fByteSwap(ipos,sizeof(float),3);
  	      file.write((char*)&ipos, 3*sizeof(float));
        }
      }
    }
  }
  else {
    for(k=kstart; k<kend; k++) {
      for(j=jstart; j<jend; j++) {
        for(i=istart; i<iend; i++) {
	      ilen = (i * lbdm.youter + j) * lbdm.zouter + k;
 	      if(lbphi[ilen] == 12 || lbphi[ilen] == 13) {
	        ipos[0] = 0.0;
            ipos[1] = 0.0;
            ipos[2] = 0.0;
          }
	      else {
            ipos[0] = fGetOneDirecSpeedIncomSite(0, &lbf[ilen*lbsitelength]);
            ipos[1] = fGetOneDirecSpeedIncomSite(1, &lbf[ilen*lbsitelength]);
            ipos[2] = fGetOneDirecSpeedIncomSite(2, &lbf[ilen*lbsitelength]);
          }
          if (!bigend) fByteSwap(ipos,sizeof(float),3);
  	      file.write((char*)&ipos, 3*sizeof(float));
        }
      }
    }
  }

  // write phase field/space property
  kpos=sizeof(int)*ilen1*ilen2*ilen3;
  if (!bigend) fByteSwap(&kpos,sizeof(unsigned int),1);
  file.write(reinterpret_cast<const char*>(&kpos), sizeof(unsigned int));
  for(k=kstart; k<kend; k++)
    for(j=jstart; j<jend; j++) {
      for(i=istart; i<iend; i++) {
	    ilen=(i * lbdm.youter + j) * lbdm.zouter + k;
	    jpos=lbphi[ilen];
        if (!bigend) fByteSwap(&jpos,sizeof(int),1);
	    file.write(reinterpret_cast<const char*>(&jpos), sizeof(int));
      }
    }	

  // write grid points
  kpos=3*sizeof(float)*ilen1*ilen2*ilen3;
  if (!bigend) fByteSwap(&kpos,sizeof(unsigned int),1);
  file.write(reinterpret_cast<const char*>(&kpos), sizeof(unsigned int));
  for(k=kstart; k<kend; k++)
    for(j=jstart; j<jend; j++) {
      for(i=istart; i<iend; i++) {
	    ipos[0]=(lbdm.xs + i - lbdm.bwid)*float(lbdx);
	    ipos[1]=(lbdm.ys + j - lbdm.bwid)*float(lbdx);
        ipos[2]=(lbdm.zs + k - lbdm.bwid)*float(lbdx);
        if (!bigend) fByteSwap(ipos,sizeof(float),3);
	    file.write((char*)&ipos, 3*sizeof(float));
      }
    }

  file<<"</AppendedData>"<<endl;
  file<<"</VTKFile>"<<endl;
  
  file.close();
  
  return 0;
}


int fsOutputVTKCA3D(const char* filename="lbout", int iprop=0)
{
  int i, j, k, istart, iend, jstart, jend, kstart, kend;
  float ipos[3];
  int jpos;
  long ilen=0;
  char buf[80];
  if(lbdm.size>1)
    sprintf(buf, "%s%.6dat%.6d.vts", filename, lbdm.rank, qVersion);
  else
    sprintf(buf, "%s%.6d.vts", filename, qVersion);
  ofstream file(buf);
  file<<"<?xml version=\"1.0\"?>"<<endl;
  file<<"<VTKFile type=\"StructuredGrid\" version=\"0.1\" byte_order=\"BigEndian\">"<<endl;
  istart = 0; iend = lbdm.xouter; 
  if(lbdm.xcor == 0)
    istart = lbdm.bwid;
  if(lbdm.xcor == lbdm.xdim-1)
    iend = lbdm.xouter - lbdm.bwid;

  jstart = 0; jend = lbdm.youter; 
  if(lbdm.ycor == 0)
    jstart = lbdm.bwid;
  if(lbdm.ycor == lbdm.ydim-1)
    jend = lbdm.youter - lbdm.bwid;

  kstart = 0; kend = lbdm.zouter; 
  if(lbdm.zcor == 0)
    kstart = lbdm.bwid;
  if(lbdm.zcor == lbdm.zdim-1)
    kend = lbdm.zouter - lbdm.bwid;

  file<<"<StructuredGrid WholeExtent=\"";
  file<<(lbdm.xs+istart-lbdm.bwid)<<" "<<(lbdm.xs+iend-lbdm.bwid-1)
      <<" "<<(lbdm.ys+jstart-lbdm.bwid)<<" "<<(lbdm.ys+jend-lbdm.bwid-1)
      <<" "<<(lbdm.zs+kstart-lbdm.bwid)<<" "<<(lbdm.zs+kend-lbdm.bwid-1)<<"\">"<<endl;
  file<<"<Piece Extent=\""<<(lbdm.xs+istart-lbdm.bwid)<<" "<<(lbdm.xs+iend-lbdm.bwid-1)
      <<" "<<(lbdm.ys+jstart-lbdm.bwid)<<" "<<(lbdm.ys+jend-lbdm.bwid-1)
      <<" "<<(lbdm.zs+kstart-lbdm.bwid)<<" "<<(lbdm.zs+kend-lbdm.bwid-1)<<"\">"<<endl;
    
  // write grid points
  file<<"<Points>"<<endl;
  file<<"<DataArray type=\"Float32\" NumberOfComponents=\"3\" format=\"ascii\">"<<endl;
  for(k=kstart; k<kend; k++)
    for(j=jstart; j<jend; j++)
      for(i=istart; i<iend; i++)
	    file<<(lbdm.xs+i-lbdm.bwid)*float(lbdx)<<" "<<(lbdm.ys+j-lbdm.bwid)*float(lbdx)<<" "<<(lbdm.zs+k-lbdm.bwid)*float(lbdx)<<" ";
  file<<endl;
  file<<"</DataArray>"<<endl;
  file<<"</Points>"<<endl;
  file<<"<PointData Scalars=\"fraction\" Vectors=\"velocity\">"<<endl;
  // write mass fraction
  file<<"<DataArray Name=\"fraction\" type=\"Float32\" format=\"ascii\">"<<endl;
  if(interact==5 && lbsy.nf>1) {
    for(k=kstart; k<kend; k++) {
      for(j=jstart; j<jend; j++) {
        for(i=istart; i<iend; i++) {
          ilen = (i * lbdm.youter + j) * lbdm.zouter + k;
	      ipos[0] = float(fGetFracSwiftSite(iprop, &lbf[ilen*lbsitelength]));
	      file<<ipos[0]<<" ";
        }
      }
    }
  }
  else {
    for(k=kstart; k<kend; k++) {
      for(j=jstart; j<jend; j++) {
        for(i=istart; i<iend; i++) {
          ilen = (i * lbdm.youter + j) * lbdm.zouter + k;
	      ipos[0] = float(fGetFracSite(iprop, &lbf[ilen*lbsitelength]));
	      file<<ipos[0]<<" ";
        }
      }
    }
  }
  file<<endl;
  file<<"</DataArray>"<<endl;
  // write velocity
  file<<"<DataArray Name=\"velocity\" type=\"Float32\" NumberOfComponents=\"3\" format=\"ascii\">"<<endl;
  if(interact==5) {
    for(k=kstart; k<kend; k++) {
      for(j=jstart; j<jend; j++) {
        for(i=istart; i<iend; i++) {
          ilen = (i * lbdm.youter + j) * lbdm.zouter + k;
	      if(lbphi[ilen] == 12 || lbphi[ilen] == 13) {
	        ipos[0] = 0.0;
            ipos[1] = 0.0;
            ipos[2] = 0.0;
          }
          else {
            ipos[0] = fGetOneDirecSpeedSite(0, &lbf[ilen*lbsitelength]);
            ipos[1] = fGetOneDirecSpeedSite(1, &lbf[ilen*lbsitelength]);
            ipos[2] = fGetOneDirecSpeedSite(2, &lbf[ilen*lbsitelength]);
          }
	      file<<ipos[0]<<" "<<ipos[1]<<" "<<ipos[2]<<" ";
        }
      }
    }
  }
  else if(!incompress) {
    for(k=kstart; k<kend; k++) {
      for(j=jstart; j<jend; j++) {
        for(i=istart; i<iend; i++) {
          ilen = (i * lbdm.youter + j) * lbdm.zouter + k;
	      if(lbphi[ilen] == 12 || lbphi[ilen] == 13) {
	        ipos[0] = 0.0;
            ipos[1] = 0.0;
            ipos[2] = 0.0;
          }
          else {
            ipos[0] = fGetOneDirecSpeedSite(0, &lbf[ilen*lbsitelength]);
            ipos[1] = fGetOneDirecSpeedSite(1, &lbf[ilen*lbsitelength]);
            ipos[2] = fGetOneDirecSpeedSite(2, &lbf[ilen*lbsitelength]);
          }
	      file<<ipos[0]<<" "<<ipos[1]<<" "<<ipos[2]<<" ";
        }
      }
    }
  }
  else {
    for(k=kstart; k<kend; k++) {
      for(j=jstart; j<jend; j++) {
        for(i=istart; i<iend; i++) {
          ilen = (i * lbdm.youter + j) * lbdm.zouter + k;
	      if(lbphi[ilen] == 12 || lbphi[ilen] == 13) {
	        ipos[0] = 0.0;
            ipos[1] = 0.0;
            ipos[2] = 0.0;
          }
          else {
            ipos[0] = fGetOneDirecSpeedIncomSite(0, &lbf[ilen*lbsitelength]);
            ipos[1] = fGetOneDirecSpeedIncomSite(1, &lbf[ilen*lbsitelength]);
            ipos[2] = fGetOneDirecSpeedIncomSite(2, &lbf[ilen*lbsitelength]);
          }
	      file<<ipos[0]<<" "<<ipos[1]<<" "<<ipos[2]<<" ";
        }
      }
    }
  }

  file<<endl;
  file<<"</DataArray>"<<endl;
  // write phase field/space property
  file<<"<DataArray Name=\"phase_field\" type=\"Int32\" format=\"ascii\">"<<endl;
  for(k=kstart; k<kend; k++)
    for(j=jstart; j<jend; j++)
      for(i=istart; i<iend; i++)
	    {
	      ilen = (i * lbdm.youter + j) * lbdm.zouter + k;
	      jpos=lbphi[ilen];
	      file<<jpos<<" ";
	    }
  file<<endl;
  file<<"</DataArray>"<<endl;
  file<<"</PointData>"<<endl;
  file<<"</Piece>"<<endl;
  file<<"</StructuredGrid>"<<endl;
  file<<"</VTKFile>"<<endl;
  file.close();
  return 0;
}


int fOutputVTKCA2D(const char* filename="lbout", int iprop=0)
{

  // output .vts file with mass fraction and velocity for fluid iprop

  int i, j, istart, iend, jstart, jend, offset;
  float ipos[3];
  int jpos;
  long kpos;
  int ilen=0, ilen1=0, ilen2=0;
  char buf[80];
  if(lbdm.size>1)
    sprintf(buf, "%s%.6dat%.6d.vts", filename, lbdm.rank, qVersion);
  else
    sprintf(buf, "%s%.6d.vts", filename, qVersion);
  ofstream file(buf, ios::binary);

  file<<"<?xml version=\"1.0\"?>"<<endl;
  file<<"<VTKFile type=\"StructuredGrid\" version=\"0.1\" byte_order=\"BigEndian\">"<<endl;

  // determine extent of piece
  istart = 0; iend = lbdm.xouter; 
  if(lbdm.xcor == 0)
    istart = lbdm.bwid;
  if(lbdm.xcor == lbdm.xdim-1)
    iend = lbdm.xouter - lbdm.bwid;

  jstart = 0; jend = lbdm.youter; 
  if(lbdm.ycor == 0)
    jstart = lbdm.bwid;
  if(lbdm.ycor == lbdm.ydim-1)
    jend = lbdm.youter - lbdm.bwid;

  file<<"<StructuredGrid WholeExtent=\"";
  file<<(lbdm.xs+istart-lbdm.bwid)<<" "<<(lbdm.xs+iend-lbdm.bwid-1)
      <<" "<<(lbdm.ys+jstart-lbdm.bwid)<<" "<<(lbdm.ys+jend-lbdm.bwid-1)<<" 0 0\">"<<endl;
  file<<"<Piece Extent=\""<<(lbdm.xs+istart-lbdm.bwid)<<" "<<(lbdm.xs+iend-lbdm.bwid-1)
      <<" "<<(lbdm.ys+jstart-lbdm.bwid)<<" "<<(lbdm.ys+jend-lbdm.bwid-1)<<" 0 0\">"<<endl;

  file<<"<PointData Scalars=\"phase_field\" Vectors=\"velocity\">"<<endl;

  // determine number of data points
  ilen1=lbdm.xouter;
  if(lbdm.xcor == 0)
    ilen1 -= lbdm.bwid;
  if(lbdm.xcor == lbdm.xdim-1)
    ilen1 -= lbdm.bwid;

  ilen2=lbdm.youter;
  if(lbdm.ycor == 0)
    ilen2 -= lbdm.bwid;
  if(lbdm.ycor == lbdm.ydim-1)
    ilen2 -= lbdm.bwid;

  offset = 0;
  file<<"<DataArray Name=\"fraction\" type=\"Float32\" format=\"appended\" offset=\""<<offset<<"\">"<<endl;
  offset += sizeof(float)*ilen1*ilen2 + sizeof(unsigned int);
  file<<"</DataArray>"<<endl;
  file<<"<DataArray Name=\"velocity\" type=\"Float32\" NumberOfComponents=\"3\" format=\"appended\" offset=\""<<offset<<"\">"<<endl;
  offset += 3*sizeof(float)*ilen1*ilen2 + sizeof(unsigned int);
  file<<"</DataArray>"<<endl;
  file<<"<DataArray Name=\"phase_field\" type=\"Int32\" format=\"appended\" offset=\""<<offset<<"\">"<<endl;
  offset += sizeof(int)*ilen1*ilen2 + sizeof(unsigned int);
  file<<"</DataArray>"<<endl;
  file<<"</PointData>"<<endl;
  file<<"<Points>"<<endl;
  file<<"<DataArray type=\"Float32\" NumberOfComponents=\"3\" format=\"appended\" offset=\""<<offset<<"\">"<<endl;
  file<<"</DataArray>"<<endl;
  file<<"</Points>"<<endl;
  file<<"</Piece>"<<endl;
  file<<"</StructuredGrid>"<<endl;

  file<<"<AppendedData encoding=\"raw\">"<<endl;
  file<<"_";  

  // write mass fraction
  kpos=sizeof(float)*ilen1*ilen2;
  if (!bigend) fByteSwap(&kpos,sizeof(unsigned int),1);
  file.write(reinterpret_cast<const char*>(&kpos), sizeof(unsigned int));
  if(interact==5) {
    for(j=jstart; j<jend; j++) {
      for(i=istart; i<iend; i++) {
        ilen = i * lbdm.youter + j;
        ipos[0] = float(fGetFracSwiftSite(iprop, &lbf[ilen*lbsitelength]));
        if (!bigend) fByteSwap(ipos,sizeof(float),1);
        file.write((char*)&ipos[0], sizeof(float));
      }
    }
  }
  else {
    for(j=jstart; j<jend; j++) {
      for(i=istart; i<iend; i++) {
        ilen = i * lbdm.youter + j;
        ipos[0] = float(fGetFracSite(iprop, &lbf[ilen*lbsitelength]));
        if (!bigend) fByteSwap(ipos,sizeof(float),1);
        file.write((char*)&ipos[0], sizeof(float));
      }
    }
  }

  // write velocity
  kpos=3*sizeof(float)*ilen1*ilen2;
  if (!bigend) fByteSwap(&kpos,sizeof(unsigned int),1);
  file.write(reinterpret_cast<const char*>(&kpos), sizeof(unsigned int));
  if(interact==5) {
    for(j=jstart; j<jend; j++) {
      for(i=istart; i<iend; i++) {
        ilen = i * lbdm.youter + j;
        if(lbphi[ilen] == 12 || lbphi[ilen] == 13) {
	      ipos[0] = 0.0;
          ipos[1] = 0.0;
        }
        else {
          ipos[0] = fGetOneDirecSpeedSwiftSite(0, &lbf[ilen*lbsitelength]);
          ipos[1] = fGetOneDirecSpeedSwiftSite(1, &lbf[ilen*lbsitelength]);
        }
        ipos[2] = 0.0;
        if (!bigend) fByteSwap(ipos,sizeof(float),3);
        file.write((char*)&ipos, 3*sizeof(float));
      }
    }
  }
  else if(!incompress) {
    for(j=jstart; j<jend; j++) {
      for(i=istart; i<iend; i++) {
        ilen = i * lbdm.youter + j;
        if(lbphi[ilen] == 12 || lbphi[ilen] == 13) {
	      ipos[0] = 0.0;
          ipos[1] = 0.0;
        }
        else {
          ipos[0] = fGetOneDirecSpeedSite(0, &lbf[ilen*lbsitelength]);
          ipos[1] = fGetOneDirecSpeedSite(1, &lbf[ilen*lbsitelength]);
        }
        ipos[2] = 0.0;
        if (!bigend) fByteSwap(ipos,sizeof(float),3);
        file.write((char*)&ipos, 3*sizeof(float));
      }
    }
  }
  else {
    for(j=jstart; j<jend; j++) {
      for(i=istart; i<iend; i++) {
        ilen = i * lbdm.youter + j;
        if(lbphi[ilen] == 12 || lbphi[ilen] == 13) {
	      ipos[0] = 0.0;
          ipos[1] = 0.0;
        }
        else {
          ipos[0] = fGetOneDirecSpeedIncomSite(0, &lbf[ilen*lbsitelength]);
          ipos[1] = fGetOneDirecSpeedIncomSite(1, &lbf[ilen*lbsitelength]);
        }
        ipos[2] = 0.0;
        if (!bigend) fByteSwap(ipos,sizeof(float),3);
        file.write((char*)&ipos, 3*sizeof(float));
      }
    }
  }

  // write phase field/space property
  kpos=sizeof(int)*ilen1*ilen2;
  if (!bigend) fByteSwap(&kpos,sizeof(unsigned int),1);
  file.write(reinterpret_cast<const char*>(&kpos), sizeof(unsigned int));
  for(j=jstart; j<jend; j++)
    for(i=istart; i<iend; i++) {
      ilen=i * lbdm.youter + j;
      jpos=lbphi[ilen];
      if (!bigend) fByteSwap(&jpos,sizeof(int),1);
      file.write(reinterpret_cast<const char*>(&jpos), sizeof(int));
    }

  // write grid points
  kpos=3*sizeof(float)*ilen1*ilen2;
  if (!bigend) fByteSwap(&kpos,sizeof(unsigned int),1);
  file.write(reinterpret_cast<const char*>(&kpos), sizeof(unsigned int));
  for(j=jstart; j<jend; j++)
    for(i=istart; i<iend; i++) {
      ipos[0]=(lbdm.xs + i - lbdm.bwid)*float(lbdx);
      ipos[1]=(lbdm.ys + j - lbdm.bwid)*float(lbdx);
      ipos[2]=0.0;
      if (!bigend) fByteSwap(ipos,sizeof(float),3);
      file.write((char*)&ipos, 3*sizeof(float));
    }

  file<<"</AppendedData>"<<endl;
  file<<"</VTKFile>"<<endl;
  
  file.close();
  
  return 0;
}


int fsOutputVTKCA2D(const char* filename="lbout", int iprop=0)
{
  int i, j, istart, iend, jstart, jend;
  float ipos[3];
  int jpos;
  long ilen=0;
  char buf[80];
  if(lbdm.size>1)
    sprintf(buf, "%s%.6dat%.6d.vts", filename, lbdm.rank, qVersion);
  else
    sprintf(buf, "%s%.6d.vts", filename, qVersion);
  ofstream file(buf);
  file<<"<?xml version=\"1.0\"?>"<<endl;
  istart = 0; iend = lbdm.xouter; 
  if(lbdm.xcor == 0)
    istart = lbdm.bwid;
  if(lbdm.xcor == lbdm.xdim-1)
    iend = lbdm.xouter - lbdm.bwid;

  jstart = 0; jend = lbdm.youter; 
  if(lbdm.ycor == 0)
    jstart = lbdm.bwid;
  if(lbdm.ycor == lbdm.ydim-1)
    jend = lbdm.youter - lbdm.bwid;

  file<<"<StructuredGrid WholeExtent=\"";
  file<<(lbdm.xs+istart-lbdm.bwid)<<" "<<(lbdm.xs+iend-lbdm.bwid-1)
      <<" "<<(lbdm.ys+jstart-lbdm.bwid)<<" "<<(lbdm.ys+jend-lbdm.bwid-1)<<" 0 0\">"<<endl;
  file<<"<Piece Extent=\""<<(lbdm.xs+istart-lbdm.bwid)<<" "<<(lbdm.xs+iend-lbdm.bwid-1)
      <<" "<<(lbdm.ys+jstart-lbdm.bwid)<<" "<<(lbdm.ys+jend-lbdm.bwid-1)<<" 0 0\">"<<endl;
  // write grid points
  file<<"<Points>"<<endl;
  file<<"<DataArray type=\"Float32\" NumberOfComponents=\"3\" format=\"ascii\">"<<endl;
  for(j=jstart; j<jend; j++)
    for(i=istart; i<iend; i++)
      file<<(lbdm.xs+i-lbdm.bwid)*float(lbdx)<<" "<<(lbdm.ys+j-lbdm.bwid)*float(lbdx)<<" "<<0.0<<" ";
  file<<endl;
  file<<"</DataArray>"<<endl;
  file<<"</Points>"<<endl;
  file<<"<PointData Scalars=\"fraction\" Vectors=\"velocity\">"<<endl;
  // write mass fraction
  file<<"<DataArray Name=\"fraction\" type=\"Float32\" format=\"ascii\">"<<endl;
  if(interact==5 && lbsy.nf>1) {
    for(j=jstart; j<jend; j++) {
      for(i=istart; i<iend; i++) {
        ilen = i * lbdm.youter + j;
	    ipos[0] = float(fGetFracSwiftSite(iprop, &lbf[ilen*lbsitelength]));
	    file<<ipos[0]<<" ";
      }
    }
  }
  else {
    for(j=jstart; j<jend; j++) {
      for(i=istart; i<iend; i++) {
        ilen = i * lbdm.youter + j;
	    ipos[0] = float(fGetFracSite(iprop, &lbf[ilen*lbsitelength]));
	    file<<ipos[0]<<" ";
      }
    }
  }
  file<<endl;
  file<<"</DataArray>"<<endl;
  // write velocity
  file<<"<DataArray Name=\"velocity\" type=\"Float32\" NumberOfComponents=\"3\" format=\"ascii\">"<<endl;
  if(interact==5) {
    for(j=jstart; j<jend; j++) {
      for(i=istart; i<iend; i++) {
        ilen = i * lbdm.youter + j;
        if(lbphi[ilen] == 12 || lbphi[ilen] == 13) {
  	      ipos[0] = 0.0;
          ipos[1] = 0.0;
        }
        else {
          ipos[0] = fGetOneDirecSpeedSwiftSite(0, &lbf[ilen*lbsitelength]);
          ipos[1] = fGetOneDirecSpeedSwiftSite(1, &lbf[ilen*lbsitelength]);
        }
        file<<ipos[0]<<" "<<ipos[1]<<" "<<0.0<<" ";
      }
    }
  }
  else if(!incompress) {
    for(j=jstart; j<jend; j++) {
      for(i=istart; i<iend; i++) {
        ilen = i * lbdm.youter + j;
        if(lbphi[ilen] == 12 || lbphi[ilen] == 13) {
  	      ipos[0] = 0.0;
          ipos[1] = 0.0;
        }
        else {
          ipos[0] = fGetOneDirecSpeedSite(0, &lbf[ilen*lbsitelength]);
          ipos[1] = fGetOneDirecSpeedSite(1, &lbf[ilen*lbsitelength]);
        }
        file<<ipos[0]<<" "<<ipos[1]<<" "<<0.0<<" ";
      }
    }
  }
  else {
    for(j=jstart; j<jend; j++) {
      for(i=istart; i<iend; i++) {
        ilen = i * lbdm.youter + j;
        if(lbphi[ilen] == 12 || lbphi[ilen] == 13) {
  	      ipos[0] = 0.0;
          ipos[1] = 0.0;
        }
        else {
          ipos[0] = fGetOneDirecSpeedIncomSite(0, &lbf[ilen*lbsitelength]);
          ipos[1] = fGetOneDirecSpeedIncomSite(1, &lbf[ilen*lbsitelength]);
        }
        file<<ipos[0]<<" "<<ipos[1]<<" "<<0.0<<" ";
      }
    }
  }

  file<<endl;
  file<<"</DataArray>"<<endl;
  // write phase field/space property
  file<<"<DataArray Name=\"phase_field\" type=\"Int32\" format=\"ascii\">"<<endl;
  for(j=jstart; j<jend; j++)
    for(i=istart; i<iend; i++)
      {
	    ilen = i * lbdm.youter + j;
	    jpos=lbphi[ilen];
	    file<<jpos<<" ";
      }
  file<<endl;
  file<<"</DataArray>"<<endl;
  file<<"</PointData>"<<endl;
  file<<"</Piece>"<<endl;
  file<<"</StructuredGrid>"<<endl;
  file<<"</VTKFile>"<<endl;
  file.close();
  return 0;
}


int fOutputVTKCB3D(const char* filename="lbout", int iprop=0)
{

  // output .vts file with concentration and velocity for solute iprop

  int i, j, k, istart, iend, jstart, jend, kstart, kend, offset;
  float ipos[3];
  int jpos;
  long kpos;
  int ilen=0, ilen1=0, ilen2=0, ilen3=0;
  char buf[80];
  if(lbdm.size>1)
    sprintf(buf, "%s%.6dat%.6d.vts", filename, lbdm.rank, qVersion);
  else
    sprintf(buf, "%s%.6d.vts", filename, qVersion);
  ofstream file(buf, ios::binary);

  file<<"<?xml version=\"1.0\"?>"<<endl;
  file<<"<VTKFile type=\"StructuredGrid\" version=\"0.1\" byte_order=\"BigEndian\">"<<endl;

  // determine extent of piece
  istart = 0; iend = lbdm.xouter; 
  if(lbdm.xcor == 0)
    istart = lbdm.bwid;
  if(lbdm.xcor == lbdm.xdim-1)
    iend = lbdm.xouter - lbdm.bwid;

  jstart = 0; jend = lbdm.youter; 
  if(lbdm.ycor == 0)
    jstart = lbdm.bwid;
  if(lbdm.ycor == lbdm.ydim-1)
    jend = lbdm.youter - lbdm.bwid;

  kstart = 0; kend = lbdm.zouter; 
  if(lbdm.zcor == 0)
    kstart = lbdm.bwid;
  if(lbdm.zcor == lbdm.zdim-1)
    kend = lbdm.zouter - lbdm.bwid;

  file<<"<StructuredGrid WholeExtent=\"";
  file<<(lbdm.xs+istart-lbdm.bwid)<<" "<<(lbdm.xs+iend-lbdm.bwid-1)
      <<" "<<(lbdm.ys+jstart-lbdm.bwid)<<" "<<(lbdm.ys+jend-lbdm.bwid-1)
      <<" "<<(lbdm.zs+kstart-lbdm.bwid)<<" "<<(lbdm.zs+kend-lbdm.bwid-1)<<"\">"<<endl;
  file<<"<Piece Extent=\""<<(lbdm.xs+istart-lbdm.bwid)<<" "<<(lbdm.xs+iend-lbdm.bwid-1)
      <<" "<<(lbdm.ys+jstart-lbdm.bwid)<<" "<<(lbdm.ys+jend-lbdm.bwid-1)
      <<" "<<(lbdm.zs+kstart-lbdm.bwid)<<" "<<(lbdm.zs+kend-lbdm.bwid-1)<<"\">"<<endl;

  file<<"<PointData Scalars=\"phase_field\" Vectors=\"velocity\">"<<endl;

  // determine number of data points
  ilen1=lbdm.xouter;
  if(lbdm.xcor == 0)
    ilen1 -= lbdm.bwid;
  if(lbdm.xcor == lbdm.xdim-1)
    ilen1 -= lbdm.bwid;

  ilen2=lbdm.youter;
  if(lbdm.ycor == 0)
    ilen2 -= lbdm.bwid;
  if(lbdm.ycor == lbdm.ydim-1)
    ilen2 -= lbdm.bwid;

  ilen3=lbdm.zouter;
  if(lbdm.zcor == 0)
    ilen3 -= lbdm.bwid;
  if(lbdm.zcor == lbdm.zdim-1)
    ilen3 -= lbdm.bwid;

  offset = 0;
  file<<"<DataArray Name=\"concentration\" type=\"Float32\" format=\"appended\" offset=\""<<offset<<"\">"<<endl;
  offset += sizeof(float)*ilen1*ilen2*ilen3 + sizeof(unsigned int);
  file<<"</DataArray>"<<endl;
  file<<"<DataArray Name=\"velocity\" type=\"Float32\" NumberOfComponents=\"3\" format=\"appended\" offset=\""<<offset<<"\">"<<endl;
  offset += 3*sizeof(float)*ilen1*ilen2*ilen3 + sizeof(unsigned int);
  file<<"</DataArray>"<<endl;
  file<<"<DataArray Name=\"phase_field\" type=\"Int32\" format=\"appended\" offset=\""<<offset<<"\">"<<endl;
  offset += sizeof(int)*ilen1*ilen2*ilen3 + sizeof(unsigned int);
  file<<"</DataArray>"<<endl;
  file<<"</PointData>"<<endl;
  file<<"<Points>"<<endl;
  file<<"<DataArray type=\"Float32\" NumberOfComponents=\"3\" format=\"appended\" offset=\""<<offset<<"\">"<<endl;
  file<<"</DataArray>"<<endl;
  file<<"</Points>"<<endl;
  file<<"</Piece>"<<endl;
  file<<"</StructuredGrid>"<<endl;

  file<<"<AppendedData encoding=\"raw\">"<<endl;
  file<<"_";  

  // write solute concentration
  kpos=sizeof(float)*ilen1*ilen2*ilen3;
  if (!bigend) fByteSwap(&kpos,sizeof(unsigned int),1);
  file.write(reinterpret_cast<const char*>(&kpos), sizeof(unsigned int));
  for(k=kstart; k<kend; k++)
    for(j=jstart; j<jend; j++) {
      for(i=istart; i<iend; i++) {
	    ilen = (i * lbdm.youter + j) * lbdm.zouter + k;
	    ipos[0] = float(fGetOneConcSite(iprop, ilen));
        if (!bigend) fByteSwap(ipos,sizeof(float),1);
	    file.write((char*)&ipos[0], sizeof(float));
      }
    }

  // write velocity
  kpos=3*sizeof(float)*ilen1*ilen2*ilen3;
  if (!bigend) fByteSwap(&kpos,sizeof(unsigned int),1);
  file.write(reinterpret_cast<const char*>(&kpos), sizeof(unsigned int));
  if(interact==5) {
    for(k=kstart; k<kend; k++) {
      for(j=jstart; j<jend; j++) {
        for(i=istart; i<iend; i++) {
	      ilen = (i * lbdm.youter + j) * lbdm.zouter + k;
  	      if(lbphi[ilen] == 12 || lbphi[ilen] == 13) {
	        ipos[0] = 0.0;
            ipos[1] = 0.0;
            ipos[2] = 0.0;
          }
	      else {
            ipos[0] = fGetOneDirecSpeedSite(0, &lbf[ilen*lbsitelength]);
            ipos[1] = fGetOneDirecSpeedSite(1, &lbf[ilen*lbsitelength]);
            ipos[2] = fGetOneDirecSpeedSite(2, &lbf[ilen*lbsitelength]);
          }
          if (!bigend) fByteSwap(ipos,sizeof(float),3);
  	      file.write((char*)&ipos, 3*sizeof(float));
        }
      }
    }
  }
  else if(!incompress) {
    for(k=kstart; k<kend; k++) {
      for(j=jstart; j<jend; j++) {
        for(i=istart; i<iend; i++) {
	      ilen = (i * lbdm.youter + j) * lbdm.zouter + k;
  	      if(lbphi[ilen] == 12 || lbphi[ilen] == 13) {
	        ipos[0] = 0.0;
            ipos[1] = 0.0;
            ipos[2] = 0.0;
          }
	      else {
            ipos[0] = fGetOneDirecSpeedSite(0, &lbf[ilen*lbsitelength]);
            ipos[1] = fGetOneDirecSpeedSite(1, &lbf[ilen*lbsitelength]);
            ipos[2] = fGetOneDirecSpeedSite(2, &lbf[ilen*lbsitelength]);
          }
          if (!bigend) fByteSwap(ipos,sizeof(float),3);
  	      file.write((char*)&ipos, 3*sizeof(float));
        }
      }
    }
  }
  else {
    for(k=kstart; k<kend; k++) {
      for(j=jstart; j<jend; j++) {
        for(i=istart; i<iend; i++) {
	      ilen = (i * lbdm.youter + j) * lbdm.zouter + k;
  	      if(lbphi[ilen] == 12 || lbphi[ilen] == 13) {
	        ipos[0] = 0.0;
            ipos[1] = 0.0;
            ipos[2] = 0.0;
          }
	      else {
            ipos[0] = fGetOneDirecSpeedIncomSite(0, &lbf[ilen*lbsitelength]);
            ipos[1] = fGetOneDirecSpeedIncomSite(1, &lbf[ilen*lbsitelength]);
            ipos[2] = fGetOneDirecSpeedIncomSite(2, &lbf[ilen*lbsitelength]);
          }
          if (!bigend) fByteSwap(ipos,sizeof(float),3);
  	      file.write((char*)&ipos, 3*sizeof(float));
        }
      }
    }
  }

  // write phase field/space property
  kpos=sizeof(int)*ilen1*ilen2*ilen3;
  if (!bigend) fByteSwap(&kpos,sizeof(unsigned int),1);
  file.write(reinterpret_cast<const char*>(&kpos), sizeof(unsigned int));
  for(k=kstart; k<kend; k++)
    for(j=jstart; j<jend; j++) {
      for(i=istart; i<iend; i++) {
	    ilen=(i * lbdm.youter + j) * lbdm.zouter + k;
	    jpos=lbphi[ilen];
        if (!bigend) fByteSwap(&jpos,sizeof(int),1);
	    file.write(reinterpret_cast<const char*>(&jpos), sizeof(int));
      }
    }	

  // write grid points
  kpos=3*sizeof(float)*ilen1*ilen2*ilen3;
  if (!bigend) fByteSwap(&kpos,sizeof(unsigned int),1);
  file.write(reinterpret_cast<const char*>(&kpos), sizeof(unsigned int));
  for(k=kstart; k<kend; k++)
    for(j=jstart; j<jend; j++) {
      for(i=istart; i<iend; i++) {
	    ipos[0]=(lbdm.xs + i - lbdm.bwid)*float(lbdx);
	    ipos[1]=(lbdm.ys + j - lbdm.bwid)*float(lbdx);
	    ipos[2]=(lbdm.zs + k - lbdm.bwid)*float(lbdx);
        if (!bigend) fByteSwap(ipos,sizeof(float),3);
	    file.write((char*)&ipos, 3*sizeof(float));
      }
    }

  file<<"</AppendedData>"<<endl;
  file<<"</VTKFile>"<<endl;
  
  file.close();
  
  return 0;
}


int fsOutputVTKCB3D(const char* filename="lbout", int iprop=0)
{
  int i, j, k, istart, iend, jstart, jend, kstart, kend;
  float ipos[3];
  int jpos;
  long ilen=0;
  char buf[80];
  if(lbdm.size>1)
    sprintf(buf, "%s%.6dat%.6d.vts", filename, lbdm.rank, qVersion);
  else
    sprintf(buf, "%s%.6d.vts", filename, qVersion);
  ofstream file(buf);
  file<<"<?xml version=\"1.0\"?>"<<endl;
  file<<"<VTKFile type=\"StructuredGrid\" version=\"0.1\" byte_order=\"BigEndian\">"<<endl;
  istart = 0; iend = lbdm.xouter; 
  if(lbdm.xcor == 0)
    istart = lbdm.bwid;
  if(lbdm.xcor == lbdm.xdim-1)
    iend = lbdm.xouter - lbdm.bwid;

  jstart = 0; jend = lbdm.youter; 
  if(lbdm.ycor == 0)
    jstart = lbdm.bwid;
  if(lbdm.ycor == lbdm.ydim-1)
    jend = lbdm.youter - lbdm.bwid;

  kstart = 0; kend = lbdm.zouter; 
  if(lbdm.zcor == 0)
    kstart = lbdm.bwid;
  if(lbdm.zcor == lbdm.zdim-1)
    kend = lbdm.zouter - lbdm.bwid;

  file<<"<StructuredGrid WholeExtent=\"";
  file<<(lbdm.xs+istart-lbdm.bwid)<<" "<<(lbdm.xs+iend-lbdm.bwid-1)
      <<" "<<(lbdm.ys+jstart-lbdm.bwid)<<" "<<(lbdm.ys+jend-lbdm.bwid-1)
      <<" "<<(lbdm.zs+kstart-lbdm.bwid)<<" "<<(lbdm.zs+kend-lbdm.bwid-1)<<"\">"<<endl;
  file<<"<Piece Extent=\""<<(lbdm.xs+istart-lbdm.bwid)<<" "<<(lbdm.xs+iend-lbdm.bwid-1)
      <<" "<<(lbdm.ys+jstart-lbdm.bwid)<<" "<<(lbdm.ys+jend-lbdm.bwid-1)
      <<" "<<(lbdm.zs+kstart-lbdm.bwid)<<" "<<(lbdm.zs+kend-lbdm.bwid-1)<<"\">"<<endl;
  // write grid points
  file<<"<Points>"<<endl;
  file<<"<DataArray type=\"Float32\" NumberOfComponents=\"3\" format=\"ascii\">"<<endl;
  for(k=kstart; k<kend; k++)
    for(j=jstart; j<jend; j++)
      for(i=istart; i<iend; i++)
	    file<<(lbdm.xs+i-lbdm.bwid)*float(lbdx)<<" "<<(lbdm.ys+j-lbdm.bwid)*float(lbdx)<<" "<<(lbdm.zs+k-lbdm.bwid)*float(lbdx)<<" ";
  file<<endl;
  file<<"</DataArray>"<<endl;
  file<<"</Points>"<<endl;
  file<<"<PointData Scalars=\"concentration\" Vectors=\"velocity\">"<<endl;
  // write density
  file<<"<DataArray Name=\"concentration\" type=\"Float32\" format=\"ascii\">"<<endl;
  for(k=kstart; k<kend; k++)
    for(j=jstart; j<jend; j++)
      for(i=istart; i<iend; i++)
	    {
	      ilen = (i * lbdm.youter + j) * lbdm.zouter + k;
	      ipos[0] = float(fGetOneConcSite(iprop, ilen));
	      file<<ipos[0]<<" ";
	    }
  file<<endl;
  file<<"</DataArray>"<<endl;
  // write velocity
  file<<"<DataArray Name=\"velocity\" type=\"Float32\" NumberOfComponents=\"3\" format=\"ascii\">"<<endl;
  if(interact==5) {
    for(k=kstart; k<kend; k++) {
      for(j=jstart; j<jend; j++) {
        for(i=istart; i<iend; i++) {
	      ilen = (i * lbdm.youter + j) * lbdm.zouter + k;
  	      if(lbphi[ilen] == 12 || lbphi[ilen] == 13) {
	        ipos[0] = 0.0;
            ipos[1] = 0.0;
            ipos[2] = 0.0;
          }
	      else {
            ipos[0] = fGetOneDirecSpeedSite(0, &lbf[ilen*lbsitelength]);
            ipos[1] = fGetOneDirecSpeedSite(1, &lbf[ilen*lbsitelength]);
            ipos[2] = fGetOneDirecSpeedSite(2, &lbf[ilen*lbsitelength]);
          }
	      file<<ipos[0]<<" "<<ipos[1]<<" "<<ipos[2]<<" ";
        }
      }
    }
  }
  else if(!incompress) {
    for(k=kstart; k<kend; k++) {
      for(j=jstart; j<jend; j++) {
        for(i=istart; i<iend; i++) {
	      ilen = (i * lbdm.youter + j) * lbdm.zouter + k;
  	      if(lbphi[ilen] == 12 || lbphi[ilen] == 13) {
	        ipos[0] = 0.0;
            ipos[1] = 0.0;
            ipos[2] = 0.0;
          }
	      else {
            ipos[0] = fGetOneDirecSpeedSite(0, &lbf[ilen*lbsitelength]);
            ipos[1] = fGetOneDirecSpeedSite(1, &lbf[ilen*lbsitelength]);
            ipos[2] = fGetOneDirecSpeedSite(2, &lbf[ilen*lbsitelength]);
          }
	      file<<ipos[0]<<" "<<ipos[1]<<" "<<ipos[2]<<" ";
        }
      }
    }
  }
  else {
    for(k=kstart; k<kend; k++) {
      for(j=jstart; j<jend; j++) {
        for(i=istart; i<iend; i++) {
	      ilen = (i * lbdm.youter + j) * lbdm.zouter + k;
  	      if(lbphi[ilen] == 12 || lbphi[ilen] == 13) {
	        ipos[0] = 0.0;
            ipos[1] = 0.0;
            ipos[2] = 0.0;
          }
	      else {
            ipos[0] = fGetOneDirecSpeedIncomSite(0, &lbf[ilen*lbsitelength]);
            ipos[1] = fGetOneDirecSpeedIncomSite(1, &lbf[ilen*lbsitelength]);
            ipos[2] = fGetOneDirecSpeedIncomSite(2, &lbf[ilen*lbsitelength]);
          }
	      file<<ipos[0]<<" "<<ipos[1]<<" "<<ipos[2]<<" ";
        }
      }
    }
  }

  file<<endl;
  file<<"</DataArray>"<<endl;
  // write phase field/space property
  file<<"<DataArray Name=\"phase_field\" type=\"Int32\" format=\"ascii\">"<<endl;
  for(k=kstart; k<kend; k++)
    for(j=jstart; j<jend; j++)
      for(i=istart; i<iend; i++)
	    {
	      ilen = (i * lbdm.youter + j) * lbdm.zouter + k;
	      jpos=lbphi[ilen];
	      file<<jpos<<" ";
	    }
  file<<endl;
  file<<"</DataArray>"<<endl;
  file<<"</PointData>"<<endl;
  file<<"</Piece>"<<endl;
  file<<"</StructuredGrid>"<<endl;
  file<<"</VTKFile>"<<endl;
  file.close();
  return 0;
}


int fOutputVTKCB2D(const char* filename="lbout", int iprop=0)
{

  // output .vts file with concentration and velocity for solute iprop

  int i, j, istart, iend, jstart, jend, offset;
  float ipos[3];
  int jpos;
  long kpos;
  int ilen=0, ilen1=0, ilen2=0;
  char buf[80];
  if(lbdm.size>1)
    sprintf(buf, "%s%.6dat%.6d.vts", filename, lbdm.rank, qVersion);
  else
    sprintf(buf, "%s%.6d.vts", filename, qVersion);
  ofstream file(buf, ios::binary);

  file<<"<?xml version=\"1.0\"?>"<<endl;
  file<<"<VTKFile type=\"StructuredGrid\" version=\"0.1\" byte_order=\"BigEndian\">"<<endl;

  // determine extent of piece
  istart = 0; iend = lbdm.xouter; 
  if(lbdm.xcor == 0)
    istart = lbdm.bwid;
  if(lbdm.xcor == lbdm.xdim-1)
    iend = lbdm.xouter - lbdm.bwid;

  jstart = 0; jend = lbdm.youter; 
  if(lbdm.ycor == 0)
    jstart = lbdm.bwid;
  if(lbdm.ycor == lbdm.ydim-1)
    jend = lbdm.youter - lbdm.bwid;

  file<<"<StructuredGrid WholeExtent=\"";
  file<<(lbdm.xs+istart-lbdm.bwid)<<" "<<(lbdm.xs+iend-lbdm.bwid-1)
      <<" "<<(lbdm.ys+jstart-lbdm.bwid)<<" "<<(lbdm.ys+jend-lbdm.bwid-1)<<" 0 0\">"<<endl;
  file<<"<Piece Extent=\""<<(lbdm.xs+istart-lbdm.bwid)<<" "<<(lbdm.xs+iend-lbdm.bwid-1)
      <<" "<<(lbdm.ys+jstart-lbdm.bwid)<<" "<<(lbdm.ys+jend-lbdm.bwid-1)<<" 0 0\">"<<endl;

  file<<"<PointData Scalars=\"phase_field\" Vectors=\"velocity\">"<<endl;

  // determine number of data points
  ilen1=lbdm.xouter;
  if(lbdm.xcor == 0)
    ilen1 -= lbdm.bwid;
  if(lbdm.xcor == lbdm.xdim-1)
    ilen1 -= lbdm.bwid;

  ilen2=lbdm.youter;
  if(lbdm.ycor == 0)
    ilen2 -= lbdm.bwid;
  if(lbdm.ycor == lbdm.ydim-1)
    ilen2 -= lbdm.bwid;

  offset = 0;
  file<<"<DataArray Name=\"concentration\" type=\"Float32\" format=\"appended\" offset=\""<<offset<<"\">"<<endl;
  offset += sizeof(float)*ilen1*ilen2 + sizeof(unsigned int);
  file<<"</DataArray>"<<endl;
  file<<"<DataArray Name=\"velocity\" type=\"Float32\" NumberOfComponents=\"3\" format=\"appended\" offset=\""<<offset<<"\">"<<endl;
  offset += 3*sizeof(float)*ilen1*ilen2 + sizeof(unsigned int);
  file<<"</DataArray>"<<endl;
  file<<"<DataArray Name=\"phase_field\" type=\"Int32\" format=\"appended\" offset=\""<<offset<<"\">"<<endl;
  offset += sizeof(int)*ilen1*ilen2 + sizeof(unsigned int);
  file<<"</DataArray>"<<endl;
  file<<"</PointData>"<<endl;
  file<<"<Points>"<<endl;
  file<<"<DataArray type=\"Float32\" NumberOfComponents=\"3\" format=\"appended\" offset=\""<<offset<<"\">"<<endl;
  file<<"</DataArray>"<<endl;
  file<<"</Points>"<<endl;
  file<<"</Piece>"<<endl;
  file<<"</StructuredGrid>"<<endl;

  file<<"<AppendedData encoding=\"raw\">"<<endl;
  file<<"_";  

  // write solute concentration
  kpos=sizeof(float)*ilen1*ilen2;
  if (!bigend) fByteSwap(&kpos,sizeof(unsigned int),1);
  file.write(reinterpret_cast<const char*>(&kpos), sizeof(unsigned int));
  for(j=jstart; j<jend; j++)
    for(i=istart; i<iend; i++) {
      ilen = i * lbdm.youter + j;
      ipos[0] = float(fGetOneConcSite(iprop, ilen));
      if (!bigend) fByteSwap(ipos,sizeof(float),1);
      file.write((char*)&ipos[0], sizeof(float));
    }

  // write velocity
  kpos=3*sizeof(float)*ilen1*ilen2;
  if (!bigend) fByteSwap(&kpos,sizeof(unsigned int),1);
  file.write(reinterpret_cast<const char*>(&kpos), sizeof(unsigned int));
  if(interact==5) {
    for(j=jstart; j<jend; j++) {
      for(i=istart; i<iend; i++) {
        ilen = i * lbdm.youter + j;
        if(lbphi[ilen] == 12 || lbphi[ilen] == 13) {
  	      ipos[0] = 0.0;
          ipos[1] = 0.0;
          ipos[2] = 0.0;
        }
        else {
          ipos[0] = fGetOneDirecSpeedSite(0, &lbf[ilen*lbsitelength]);
          ipos[1] = fGetOneDirecSpeedSite(1, &lbf[ilen*lbsitelength]);
          ipos[2] = 0.0;
        }
        if (!bigend) fByteSwap(ipos,sizeof(float),3);
        file.write((char*)&ipos, 3*sizeof(float));
      }
    }
  }
  else if(!incompress) {
    for(j=jstart; j<jend; j++) {
      for(i=istart; i<iend; i++) {
        ilen = i * lbdm.youter + j;
        if(lbphi[ilen] == 12 || lbphi[ilen] == 13) {
  	      ipos[0] = 0.0;
          ipos[1] = 0.0;
          ipos[2] = 0.0;
        }
        else {
          ipos[0] = fGetOneDirecSpeedSite(0, &lbf[ilen*lbsitelength]);
          ipos[1] = fGetOneDirecSpeedSite(1, &lbf[ilen*lbsitelength]);
          ipos[2] = 0.0;
        }
        if (!bigend) fByteSwap(ipos,sizeof(float),3);
        file.write((char*)&ipos, 3*sizeof(float));
      }
    }
  }
  else {
    for(j=jstart; j<jend; j++) {
      for(i=istart; i<iend; i++) {
        ilen = i * lbdm.youter + j;
        if(lbphi[ilen] == 12 || lbphi[ilen] == 13) {
  	      ipos[0] = 0.0;
          ipos[1] = 0.0;
          ipos[2] = 0.0;
        }
        else {
          ipos[0] = fGetOneDirecSpeedIncomSite(0, &lbf[ilen*lbsitelength]);
          ipos[1] = fGetOneDirecSpeedIncomSite(1, &lbf[ilen*lbsitelength]);
          ipos[2] = 0.0;
        }
        if (!bigend) fByteSwap(ipos,sizeof(float),3);
        file.write((char*)&ipos, 3*sizeof(float));
      }
    }
  }

  // write phase field/space property
  kpos=sizeof(int)*ilen1*ilen2;
  if (!bigend) fByteSwap(&kpos,sizeof(unsigned int),1);
  file.write(reinterpret_cast<const char*>(&kpos), sizeof(unsigned int));
  for(j=jstart; j<jend; j++)
    for(i=istart; i<iend; i++) {
      ilen=i * lbdm.youter + j;
      jpos=lbphi[ilen];
      if (!bigend) fByteSwap(&jpos,sizeof(int),1);
      file.write(reinterpret_cast<const char*>(&jpos), sizeof(int));
    }

  // write grid points
  kpos=3*sizeof(float)*ilen1*ilen2;
  if (!bigend) fByteSwap(&kpos,sizeof(unsigned int),1);
  file.write(reinterpret_cast<const char*>(&kpos), sizeof(unsigned int));
  for(j=jstart; j<jend; j++)
    for(i=istart; i<iend; i++) {
      ipos[0]=(lbdm.xs + i - lbdm.bwid)*float(lbdx);
      ipos[1]=(lbdm.ys + j - lbdm.bwid)*float(lbdx);
      ipos[2]=0.0;
      if (!bigend) fByteSwap(ipos,sizeof(float),3);
      file.write((char*)&ipos, 3*sizeof(float));
    }

  file<<"</AppendedData>"<<endl;
  file<<"</VTKFile>"<<endl;
  
  file.close();
  
  return 0;
}


int fsOutputVTKCB2D(const char* filename="lbout", int iprop=0)
{
  int i, j, istart, iend, jstart, jend;
  float ipos[3];
  int jpos;
  long ilen=0;
  char buf[80];
  if(lbdm.size>1)
    sprintf(buf, "%s%.6dat%.6d.vts", filename, lbdm.rank, qVersion);
  else
    sprintf(buf, "%s%.6d.vts", filename, qVersion);
  ofstream file(buf);
  file<<"<?xml version=\"1.0\"?>"<<endl;
  file<<"<VTKFile type=\"StructuredGrid\" version=\"0.1\" byte_order=\"BigEndian\">"<<endl;
  istart = 0; iend = lbdm.xouter; 
  if(lbdm.xcor == 0)
    istart = lbdm.bwid;
  if(lbdm.xcor == lbdm.xdim-1)
    iend = lbdm.xouter - lbdm.bwid;

  jstart = 0; jend = lbdm.youter; 
  if(lbdm.ycor == 0)
    jstart = lbdm.bwid;
  if(lbdm.ycor == lbdm.ydim-1)
    jend = lbdm.youter - lbdm.bwid;

  file<<"<StructuredGrid WholeExtent=\"";
  file<<(lbdm.xs+istart-lbdm.bwid)<<" "<<(lbdm.xs+iend-lbdm.bwid-1)
      <<" "<<(lbdm.ys+jstart-lbdm.bwid)<<" "<<(lbdm.ys+jend-lbdm.bwid-1)<<" 0 0\">"<<endl;
  file<<"<Piece Extent=\""<<(lbdm.xs+istart-lbdm.bwid)<<" "<<(lbdm.xs+iend-lbdm.bwid-1)
      <<" "<<(lbdm.ys+jstart-lbdm.bwid)<<" "<<(lbdm.ys+jend-lbdm.bwid-1)<<" 0 0\">"<<endl;
  // write grid points
  file<<"<Points>"<<endl;
  file<<"<DataArray type=\"Float32\" NumberOfComponents=\"3\" format=\"ascii\">"<<endl;
  for(j=jstart; j<jend; j++)
    for(i=istart; i<iend; i++)
      file<<(lbdm.xs+i-lbdm.bwid)*float(lbdx)<<" "<<(lbdm.ys+j-lbdm.bwid)*float(lbdx)<<" "<<0.0<<" ";
  file<<endl;
  file<<"</DataArray>"<<endl;
  file<<"</Points>"<<endl;
  file<<"<PointData Scalars=\"concentration\" Vectors=\"velocity\">"<<endl;
  // write density
  file<<"<DataArray Name=\"concentration\" type=\"Float32\" format=\"ascii\">"<<endl;
  for(j=jstart; j<jend; j++)
    for(i=istart; i<iend; i++)
      {
	    ilen = i * lbdm.youter + j;
	    ipos[0] = float(fGetOneConcSite(iprop, ilen));
	    file<<ipos[0]<<" ";
      }
  file<<endl;
  file<<"</DataArray>"<<endl;
  // write velocity
  file<<"<DataArray Name=\"velocity\" type=\"Float32\" NumberOfComponents=\"3\" format=\"ascii\">"<<endl;
  if(interact==5) {
    for(j=jstart; j<jend; j++) {
      for(i=istart; i<iend; i++) {
        ilen = i * lbdm.youter + j;
        if(lbphi[ilen] == 12 || lbphi[ilen] == 13) {
  	      ipos[0] = 0.0;
          ipos[1] = 0.0;
        }
        else {
          ipos[0] = fGetOneDirecSpeedSite(0, &lbf[ilen*lbsitelength]);
          ipos[1] = fGetOneDirecSpeedSite(1, &lbf[ilen*lbsitelength]);
        }
        file<<ipos[0]<<" "<<ipos[1]<<" "<<0.0<<" ";
      }
    }
  }
  else if(!incompress) {
    for(j=jstart; j<jend; j++) {
      for(i=istart; i<iend; i++) {
        ilen = i * lbdm.youter + j;
        if(lbphi[ilen] == 12 || lbphi[ilen] == 13) {
  	      ipos[0] = 0.0;
          ipos[1] = 0.0;
        }
        else {
          ipos[0] = fGetOneDirecSpeedSite(0, &lbf[ilen*lbsitelength]);
          ipos[1] = fGetOneDirecSpeedSite(1, &lbf[ilen*lbsitelength]);
        }
        file<<ipos[0]<<" "<<ipos[1]<<" "<<0.0<<" ";
      }
    }
  }
  else {
    for(j=jstart; j<jend; j++) {
      for(i=istart; i<iend; i++) {
        ilen = i * lbdm.youter + j;
        if(lbphi[ilen] == 12 || lbphi[ilen] == 13) {
  	      ipos[0] = 0.0;
          ipos[1] = 0.0;
        }
        else {
          ipos[0] = fGetOneDirecSpeedIncomSite(0, &lbf[ilen*lbsitelength]);
          ipos[1] = fGetOneDirecSpeedIncomSite(1, &lbf[ilen*lbsitelength]);
        }
        file<<ipos[0]<<" "<<ipos[1]<<" "<<0.0<<" ";
      }
    }
  }

  file<<endl;
  file<<"</DataArray>"<<endl;
  // write phase field/space property
  file<<"<DataArray Name=\"phase_field\" type=\"Int32\" format=\"ascii\">"<<endl;
  for(j=jstart; j<jend; j++)
    for(i=istart; i<iend; i++)
      {
	    ilen = i * lbdm.youter + j;
	    jpos=lbphi[ilen];
	    file<<jpos<<" ";
      }
  file<<endl;
  file<<"</DataArray>"<<endl;
  file<<"</PointData>"<<endl;
  file<<"</Piece>"<<endl;
  file<<"</StructuredGrid>"<<endl;
  file<<"</VTKFile>"<<endl;
  file.close();
  return 0;
}


int fOutputVTKT3D(const char* filename="lbout")
{

  // output .vts file with scalar temperature and velocity

  int i, j, k, istart, iend, jstart, jend, kstart, kend, offset;
  float ipos[3];
  int jpos;
  long kpos;
  int ilen=0, ilen1=0, ilen2=0, ilen3=0;
  char buf[80];
  if(lbdm.size>1)
    sprintf(buf, "%s%.6dat%.6d.vts", filename, lbdm.rank, qVersion);
  else
    sprintf(buf, "%s%.6d.vts", filename, qVersion);
  ofstream file(buf, ios::binary);

  file<<"<?xml version=\"1.0\"?>"<<endl;
  file<<"<VTKFile type=\"StructuredGrid\" version=\"0.1\" byte_order=\"BigEndian\">"<<endl;

  // determine extent of piece
  istart = 0; iend = lbdm.xouter; 
  if(lbdm.xcor == 0)
    istart = lbdm.bwid;
  if(lbdm.xcor == lbdm.xdim-1)
    iend = lbdm.xouter - lbdm.bwid;

  jstart = 0; jend = lbdm.youter; 
  if(lbdm.ycor == 0)
    jstart = lbdm.bwid;
  if(lbdm.ycor == lbdm.ydim-1)
    jend = lbdm.youter - lbdm.bwid;

  kstart = 0; kend = lbdm.zouter; 
  if(lbdm.zcor == 0)
    kstart = lbdm.bwid;
  if(lbdm.zcor == lbdm.zdim-1)
    kend = lbdm.zouter - lbdm.bwid;

  file<<"<StructuredGrid WholeExtent=\"";
  file<<(lbdm.xs+istart-lbdm.bwid)<<" "<<(lbdm.xs+iend-lbdm.bwid-1)
      <<" "<<(lbdm.ys+jstart-lbdm.bwid)<<" "<<(lbdm.ys+jend-lbdm.bwid-1)
      <<" "<<(lbdm.zs+kstart-lbdm.bwid)<<" "<<(lbdm.zs+kend-lbdm.bwid-1)<<"\">"<<endl;
  file<<"<Piece Extent=\""<<(lbdm.xs+istart-lbdm.bwid)<<" "<<(lbdm.xs+iend-lbdm.bwid-1)
      <<" "<<(lbdm.ys+jstart-lbdm.bwid)<<" "<<(lbdm.ys+jend-lbdm.bwid-1)
      <<" "<<(lbdm.zs+kstart-lbdm.bwid)<<" "<<(lbdm.zs+kend-lbdm.bwid-1)<<"\">"<<endl;

  file<<"<PointData Scalars=\"phase_field\" Vectors=\"velocity\">"<<endl;

  // determine number of data points
  ilen1=lbdm.xouter;
  if(lbdm.xcor == 0)
    ilen1 -= lbdm.bwid;
  if(lbdm.xcor == lbdm.xdim-1)
    ilen1 -= lbdm.bwid;

  ilen2=lbdm.youter;
  if(lbdm.ycor == 0)
    ilen2 -= lbdm.bwid;
  if(lbdm.ycor == lbdm.ydim-1)
    ilen2 -= lbdm.bwid;

  ilen3=lbdm.zouter;
  if(lbdm.zcor == 0)
    ilen3 -= lbdm.bwid;
  if(lbdm.zcor == lbdm.zdim-1)
    ilen3 -= lbdm.bwid;

  offset = 0;
  file<<"<DataArray Name=\"temperature\" type=\"Float32\" format=\"appended\" offset=\""<<offset<<"\">"<<endl;
  offset += sizeof(float)*ilen1*ilen2*ilen3 + sizeof(unsigned int);
  file<<"</DataArray>"<<endl;
  file<<"<DataArray Name=\"velocity\" type=\"Float32\" NumberOfComponents=\"3\" format=\"appended\" offset=\""<<offset<<"\">"<<endl;
  offset += 3*sizeof(float)*ilen1*ilen2*ilen3 + sizeof(unsigned int);
  file<<"</DataArray>"<<endl;
  file<<"<DataArray Name=\"phase_field\" type=\"Int32\" format=\"appended\" offset=\""<<offset<<"\">"<<endl;
  offset += sizeof(int)*ilen1*ilen2*ilen3 + sizeof(unsigned int);
  file<<"</DataArray>"<<endl;
  file<<"</PointData>"<<endl;
  file<<"<Points>"<<endl;
  file<<"<DataArray type=\"Float32\" NumberOfComponents=\"3\" format=\"appended\" offset=\""<<offset<<"\">"<<endl;
  file<<"</DataArray>"<<endl;
  file<<"</Points>"<<endl;
  file<<"</Piece>"<<endl;
  file<<"</StructuredGrid>"<<endl;

  file<<"<AppendedData encoding=\"raw\">"<<endl;
  file<<"_";  

  // write temperature
  kpos=sizeof(float)*ilen1*ilen2*ilen3;
  if (!bigend) fByteSwap(&kpos,sizeof(unsigned int),1);
  file.write(reinterpret_cast<const char*>(&kpos), sizeof(unsigned int));
  for(k=kstart; k<kend; k++)
    for(j=jstart; j<jend; j++) {
      for(i=istart; i<iend; i++) {
	    ilen = (i * lbdm.youter + j) * lbdm.zouter + k;
	    ipos[0] = float(fGetTemperatureSite(ilen));
        if (!bigend) fByteSwap(ipos,sizeof(float),1);
	    file.write((char*)&ipos[0], sizeof(float));
      }
    }

  // write velocity
  kpos=3*sizeof(float)*ilen1*ilen2*ilen3;
  if (!bigend) fByteSwap(&kpos,sizeof(unsigned int),1);
  file.write(reinterpret_cast<const char*>(&kpos), sizeof(unsigned int));
  if(interact==5) {
    for(k=kstart; k<kend; k++) {
      for(j=jstart; j<jend; j++) {
        for(i=istart; i<iend; i++) {
	      ilen = (i * lbdm.youter + j) * lbdm.zouter + k;
  	      if(lbphi[ilen] == 12 || lbphi[ilen] == 13) {
	        ipos[0] = 0.0;
            ipos[1] = 0.0;
            ipos[2] = 0.0;
          }
	      else {
            ipos[0] = fGetOneDirecSpeedSite(0, &lbf[ilen*lbsitelength]);
            ipos[1] = fGetOneDirecSpeedSite(1, &lbf[ilen*lbsitelength]);
            ipos[2] = fGetOneDirecSpeedSite(2, &lbf[ilen*lbsitelength]);
          }
          if (!bigend) fByteSwap(ipos,sizeof(float),3);
	      file.write((char*)&ipos, 3*sizeof(float));
        }
      }
    }
  }
  else if(!incompress) {
    for(k=kstart; k<kend; k++) {
      for(j=jstart; j<jend; j++) {
        for(i=istart; i<iend; i++) {
	      ilen = (i * lbdm.youter + j) * lbdm.zouter + k;
  	      if(lbphi[ilen] == 12 || lbphi[ilen] == 13) {
	        ipos[0] = 0.0;
            ipos[1] = 0.0;
            ipos[2] = 0.0;
          }
	      else {
            ipos[0] = fGetOneDirecSpeedSite(0, &lbf[ilen*lbsitelength]);
            ipos[1] = fGetOneDirecSpeedSite(1, &lbf[ilen*lbsitelength]);
            ipos[2] = fGetOneDirecSpeedSite(2, &lbf[ilen*lbsitelength]);
          }
          if (!bigend) fByteSwap(ipos,sizeof(float),3);
	      file.write((char*)&ipos, 3*sizeof(float));
        }
      }
    }
  }
  else {
    for(k=kstart; k<kend; k++) {
      for(j=jstart; j<jend; j++) {
        for(i=istart; i<iend; i++) {
	      ilen = (i * lbdm.youter + j) * lbdm.zouter + k;
  	      if(lbphi[ilen] == 12 || lbphi[ilen] == 13) {
	        ipos[0] = 0.0;
            ipos[1] = 0.0;
            ipos[2] = 0.0;
          }
	      else {
            ipos[0] = fGetOneDirecSpeedIncomSite(0, &lbf[ilen*lbsitelength]);
            ipos[1] = fGetOneDirecSpeedIncomSite(1, &lbf[ilen*lbsitelength]);
            ipos[2] = fGetOneDirecSpeedIncomSite(2, &lbf[ilen*lbsitelength]);
          }
          if (!bigend) fByteSwap(ipos,sizeof(float),3);
	      file.write((char*)&ipos, 3*sizeof(float));
        }
      }
    }
  }

  // write phase field/space property
  kpos=sizeof(int)*ilen1*ilen2*ilen3;
  if (!bigend) fByteSwap(&kpos,sizeof(unsigned int),1);
  file.write(reinterpret_cast<const char*>(&kpos), sizeof(unsigned int));
  for(k=kstart; k<kend; k++)
    for(j=jstart; j<jend; j++) {
      for(i=istart; i<iend; i++) {
	    ilen=(i * lbdm.youter + j) * lbdm.zouter + k;
	    jpos=lbphi[ilen];
        if (!bigend) fByteSwap(&jpos,sizeof(int),1);
	    file.write(reinterpret_cast<const char*>(&jpos), sizeof(int));
      }
    }	

  // write grid points
  kpos=3*sizeof(float)*ilen1*ilen2*ilen3;
  if (!bigend) fByteSwap(&kpos,sizeof(unsigned int),1);
  file.write(reinterpret_cast<const char*>(&kpos), sizeof(unsigned int));
  for(k=kstart; k<kend; k++)
    for(j=jstart; j<jend; j++) {
      for(i=istart; i<iend; i++) {
	    ipos[0]=(lbdm.xs + i - lbdm.bwid)*float(lbdx);
	    ipos[1]=(lbdm.ys + j - lbdm.bwid)*float(lbdx);
	    ipos[2]=(lbdm.zs + k - lbdm.bwid)*float(lbdx);
        if (!bigend) fByteSwap(ipos,sizeof(float),3);
	    file.write((char*)&ipos, 3*sizeof(float));
      }
    }

  file<<"</AppendedData>"<<endl;
  file<<"</VTKFile>"<<endl;
  
  file.close();
  
  return 0;
}


int fsOutputVTKT3D(const char* filename="lbout")
{
  int i, j, k, istart, iend, jstart, jend, kstart, kend;
  float ipos[3];
  int jpos;
  long ilen=0;
  char buf[80];
  if(lbdm.size>1)
    sprintf(buf, "%s%.6dat%.6d.vts", filename, lbdm.rank, qVersion);
  else
    sprintf(buf, "%s%.6d.vts", filename, qVersion);
  ofstream file(buf);
  file<<"<?xml version=\"1.0\"?>"<<endl;
  file<<"<VTKFile type=\"StructuredGrid\" version=\"0.1\" byte_order=\"BigEndian\">"<<endl;
  istart = 0; iend = lbdm.xouter; 
  if(lbdm.xcor == 0)
    istart = lbdm.bwid;
  if(lbdm.xcor == lbdm.xdim-1)
    iend = lbdm.xouter - lbdm.bwid;

  jstart = 0; jend = lbdm.youter; 
  if(lbdm.ycor == 0)
    jstart = lbdm.bwid;
  if(lbdm.ycor == lbdm.ydim-1)
    jend = lbdm.youter - lbdm.bwid;

  kstart = 0; kend = lbdm.zouter; 
  if(lbdm.zcor == 0)
    kstart = lbdm.bwid;
  if(lbdm.zcor == lbdm.zdim-1)
    kend = lbdm.zouter - lbdm.bwid;

  file<<"<StructuredGrid WholeExtent=\"";
  file<<(lbdm.xs+istart-lbdm.bwid)<<" "<<(lbdm.xs+iend-lbdm.bwid-1)
      <<" "<<(lbdm.ys+jstart-lbdm.bwid)<<" "<<(lbdm.ys+jend-lbdm.bwid-1)
      <<" "<<(lbdm.zs+kstart-lbdm.bwid)<<" "<<(lbdm.zs+kend-lbdm.bwid-1)<<"\">"<<endl;
  file<<"<Piece Extent=\""<<(lbdm.xs+istart-lbdm.bwid)<<" "<<(lbdm.xs+iend-lbdm.bwid-1)
      <<" "<<(lbdm.ys+jstart-lbdm.bwid)<<" "<<(lbdm.ys+jend-lbdm.bwid-1)
      <<" "<<(lbdm.zs+kstart-lbdm.bwid)<<" "<<(lbdm.zs+kend-lbdm.bwid-1)<<"\">"<<endl;
  // write grid points
  file<<"<Points>"<<endl;
  file<<"<DataArray type=\"Float32\" NumberOfComponents=\"3\" format=\"ascii\">"<<endl;
  for(k=kstart; k<kend; k++)
    for(j=jstart; j<jend; j++)
      for(i=istart; i<iend; i++)
	    file<<(lbdm.xs+i-lbdm.bwid)*float(lbdx)<<" "<<(lbdm.ys+j-lbdm.bwid)*float(lbdx)<<" "<<(lbdm.zs+k-lbdm.bwid)*float(lbdx)<<" ";
  file<<endl;
  file<<"</DataArray>"<<endl;
  file<<"</Points>"<<endl;
  file<<"<PointData Scalars=\"temperature\" Vectors=\"velocity\">"<<endl;
  // write density
  file<<"<DataArray Name=\"temperature\" type=\"Float32\" format=\"ascii\">"<<endl;
  for(k=kstart; k<kend; k++)
    for(j=jstart; j<jend; j++)
      for(i=istart; i<iend; i++)
	    {
	      ilen = (i * lbdm.youter + j) * lbdm.zouter + k;
	      ipos[0] = float(fGetTemperatureSite(ilen));
	      file<<ipos[0]<<" ";
	    }
  file<<endl;
  file<<"</DataArray>"<<endl;
  // write velocity
  file<<"<DataArray Name=\"velocity\" type=\"Float32\" NumberOfComponents=\"3\" format=\"ascii\">"<<endl;
  if(interact) {
    for(k=kstart; k<kend; k++) {
      for(j=jstart; j<jend; j++) {
        for(i=istart; i<iend; i++) {
          ilen = (i * lbdm.youter + j) * lbdm.zouter + k;
  	      if(lbphi[ilen] == 12 || lbphi[ilen] == 13) {
	        ipos[0] = 0.0;
            ipos[1] = 0.0;
            ipos[2] = 0.0;
          }
	      else {
            ipos[0] = fGetOneDirecSpeedSite(0, &lbf[ilen*lbsitelength]);
            ipos[1] = fGetOneDirecSpeedSite(1, &lbf[ilen*lbsitelength]);
            ipos[2] = fGetOneDirecSpeedSite(2, &lbf[ilen*lbsitelength]);
          }
	      file<<ipos[0]<<" "<<ipos[1]<<" "<<ipos[2]<<" ";
        }
      }
    }
  }
  else if(!incompress) {
    for(k=kstart; k<kend; k++) {
      for(j=jstart; j<jend; j++) {
        for(i=istart; i<iend; i++) {
          ilen = (i * lbdm.youter + j) * lbdm.zouter + k;
  	      if(lbphi[ilen] == 12 || lbphi[ilen] == 13) {
	        ipos[0] = 0.0;
            ipos[1] = 0.0;
            ipos[2] = 0.0;
          }
	      else {
            ipos[0] = fGetOneDirecSpeedSite(0, &lbf[ilen*lbsitelength]);
            ipos[1] = fGetOneDirecSpeedSite(1, &lbf[ilen*lbsitelength]);
            ipos[2] = fGetOneDirecSpeedSite(2, &lbf[ilen*lbsitelength]);
          }
	      file<<ipos[0]<<" "<<ipos[1]<<" "<<ipos[2]<<" ";
        }
      }
    }
  }
  else {
    for(k=kstart; k<kend; k++) {
      for(j=jstart; j<jend; j++) {
        for(i=istart; i<iend; i++) {
          ilen = (i * lbdm.youter + j) * lbdm.zouter + k;
	      if(lbphi[ilen] == 12 || lbphi[ilen] == 13) {
	        ipos[0] = 0.0;
            ipos[1] = 0.0;
            ipos[2] = 0.0;
          }
	      else {
            ipos[0] = fGetOneDirecSpeedIncomSite(0, &lbf[ilen*lbsitelength]);
            ipos[1] = fGetOneDirecSpeedIncomSite(1, &lbf[ilen*lbsitelength]);
            ipos[2] = fGetOneDirecSpeedIncomSite(2, &lbf[ilen*lbsitelength]);
          }
	      file<<ipos[0]<<" "<<ipos[1]<<" "<<ipos[2]<<" ";
        }
      }
    }
  }

  file<<endl;
  file<<"</DataArray>"<<endl;
  // write phase field/space property
  file<<"<DataArray Name=\"phase_field\" type=\"Int32\" format=\"ascii\">"<<endl;
  for(k=kstart; k<kend; k++)
    for(j=jstart; j<jend; j++)
      for(i=istart; i<iend; i++)
	    {
	      ilen = (i * lbdm.youter + j) * lbdm.zouter + k;
	      jpos=lbphi[ilen];
	      file<<jpos<<" ";
	    }
  file<<endl;
  file<<"</DataArray>"<<endl;
  file<<"</PointData>"<<endl;
  file<<"</Piece>"<<endl;
  file<<"</StructuredGrid>"<<endl;
  file<<"</VTKFile>"<<endl;
  file.close();
  return 0;
}


int fOutputVTKT2D(const char* filename="lbout")
{

  // output .vts file with scalar temperature and velocity

  int i, j, istart, iend, jstart, jend, offset;
  float ipos[3];
  int jpos;
  long kpos;
  int ilen=0, ilen1=0, ilen2=0;
  char buf[80];
  if(lbdm.size>1)
    sprintf(buf, "%s%.6dat%.6d.vts", filename, lbdm.rank, qVersion);
  else
    sprintf(buf, "%s%.6d.vts", filename, qVersion);
  ofstream file(buf, ios::binary);

  file<<"<?xml version=\"1.0\"?>"<<endl;
  file<<"<VTKFile type=\"StructuredGrid\" version=\"0.1\" byte_order=\"BigEndian\">"<<endl;

  // determine extent of piece
  istart = 0; iend = lbdm.xouter; 
  if(lbdm.xcor == 0)
    istart = lbdm.bwid;
  if(lbdm.xcor == lbdm.xdim-1)
    iend = lbdm.xouter - lbdm.bwid;

  jstart = 0; jend = lbdm.youter; 
  if(lbdm.ycor == 0)
    jstart = lbdm.bwid;
  if(lbdm.ycor == lbdm.ydim-1)
    jend = lbdm.youter - lbdm.bwid;

  file<<"<StructuredGrid WholeExtent=\"";
  file<<(lbdm.xs+istart-lbdm.bwid)<<" "<<(lbdm.xs+iend-lbdm.bwid-1)
      <<" "<<(lbdm.ys+jstart-lbdm.bwid)<<" "<<(lbdm.ys+jend-lbdm.bwid-1)<<" 0 0\">"<<endl;
  file<<"<Piece Extent=\""<<(lbdm.xs+istart-lbdm.bwid)<<" "<<(lbdm.xs+iend-lbdm.bwid-1)
      <<" "<<(lbdm.ys+jstart-lbdm.bwid)<<" "<<(lbdm.ys+jend-lbdm.bwid-1)<<" 0 0\">"<<endl;

  file<<"<PointData Scalars=\"phase_field\" Vectors=\"velocity\">"<<endl;

  // determine number of data points
  ilen1=lbdm.xouter;
  if(lbdm.xcor == 0)
    ilen1 -= lbdm.bwid;
  if(lbdm.xcor == lbdm.xdim-1)
    ilen1 -= lbdm.bwid;

  ilen2=lbdm.youter;
  if(lbdm.ycor == 0)
    ilen2 -= lbdm.bwid;
  if(lbdm.ycor == lbdm.ydim-1)
    ilen2 -= lbdm.bwid;

  offset = 0;
  file<<"<DataArray Name=\"temperature\" type=\"Float32\" format=\"appended\" offset=\""<<offset<<"\">"<<endl;
  offset += sizeof(float)*ilen1*ilen2 + sizeof(unsigned int);
  file<<"</DataArray>"<<endl;
  file<<"<DataArray Name=\"velocity\" type=\"Float32\" NumberOfComponents=\"3\" format=\"appended\" offset=\""<<offset<<"\">"<<endl;
  offset += 3*sizeof(float)*ilen1*ilen2 + sizeof(unsigned int);
  file<<"</DataArray>"<<endl;
  file<<"<DataArray Name=\"phase_field\" type=\"Int32\" format=\"appended\" offset=\""<<offset<<"\">"<<endl;
  offset += sizeof(int)*ilen1*ilen2 + sizeof(unsigned int);
  file<<"</DataArray>"<<endl;
  file<<"</PointData>"<<endl;
  file<<"<Points>"<<endl;
  file<<"<DataArray type=\"Float32\" NumberOfComponents=\"3\" format=\"appended\" offset=\""<<offset<<"\">"<<endl;
  file<<"</DataArray>"<<endl;
  file<<"</Points>"<<endl;
  file<<"</Piece>"<<endl;
  file<<"</StructuredGrid>"<<endl;

  file<<"<AppendedData encoding=\"raw\">"<<endl;
  file<<"_";  

  // write temperature
  kpos=sizeof(float)*ilen1*ilen2;
  if (!bigend) fByteSwap(&kpos,sizeof(unsigned int),1);
  file.write(reinterpret_cast<const char*>(&kpos), sizeof(unsigned int));
  for(j=jstart; j<jend; j++)
    for(i=istart; i<iend; i++) {
      ilen = i * lbdm.youter + j;
	    ipos[0] = float(fGetTemperatureSite(ilen));
        if (!bigend) fByteSwap(ipos,sizeof(float),1);
	    file.write((char*)&ipos[0], sizeof(float));
    }

  // write velocity
  kpos=3*sizeof(float)*ilen1*ilen2;
  if (!bigend) fByteSwap(&kpos,sizeof(unsigned int),1);
  file.write(reinterpret_cast<const char*>(&kpos), sizeof(unsigned int));
  if(interact==5) {
    for(j=jstart; j<jend; j++) {
      for(i=istart; i<iend; i++) {
        ilen = i * lbdm.youter + j;
        if(lbphi[ilen] == 12 || lbphi[ilen] == 13) {
  	      ipos[0] = 0.0;
          ipos[1] = 0.0;
        }
        else {
          ipos[0] = fGetOneDirecSpeedSite(0, &lbf[ilen*lbsitelength]);
          ipos[1] = fGetOneDirecSpeedSite(1, &lbf[ilen*lbsitelength]);
        }
        ipos[2] = 0.0;
        if (!bigend) fByteSwap(ipos,sizeof(float),3);
        file.write((char*)&ipos, 3*sizeof(float));
      }
    }
  }
  else if(!incompress) {
    for(j=jstart; j<jend; j++) {
      for(i=istart; i<iend; i++) {
        ilen = i * lbdm.youter + j;
        if(lbphi[ilen] == 12 || lbphi[ilen] == 13) {
  	      ipos[0] = 0.0;
          ipos[1] = 0.0;
        }
        else {
          ipos[0] = fGetOneDirecSpeedSite(0, &lbf[ilen*lbsitelength]);
          ipos[1] = fGetOneDirecSpeedSite(1, &lbf[ilen*lbsitelength]);
        }
        ipos[2] = 0.0;
        if (!bigend) fByteSwap(ipos,sizeof(float),3);
        file.write((char*)&ipos, 3*sizeof(float));
      }
    }
  }
  else {
    for(j=jstart; j<jend; j++) {
      for(i=istart; i<iend; i++) {
        ilen = i * lbdm.youter + j;
        if(lbphi[ilen] == 12 || lbphi[ilen] == 13) {
  	      ipos[0] = 0.0;
          ipos[1] = 0.0;
        }
        else {
          ipos[0] = fGetOneDirecSpeedIncomSite(0, &lbf[ilen*lbsitelength]);
          ipos[1] = fGetOneDirecSpeedIncomSite(1, &lbf[ilen*lbsitelength]);
        }
        ipos[2] = 0.0;
        if (!bigend) fByteSwap(ipos,sizeof(float),3);
        file.write((char*)&ipos, 3*sizeof(float));
      }
    }
  }

  // write phase field/space property
  kpos=sizeof(int)*ilen1*ilen2;
  if (!bigend) fByteSwap(&kpos,sizeof(unsigned int),1);
  file.write(reinterpret_cast<const char*>(&kpos), sizeof(unsigned int));
  for(j=jstart; j<jend; j++)
    for(i=istart; i<iend; i++) {
      ilen=i * lbdm.youter + j;
      jpos=lbphi[ilen];
      if (!bigend) fByteSwap(&jpos,sizeof(int),1);
      file.write(reinterpret_cast<const char*>(&jpos), sizeof(int));
    }

  // write grid points
  kpos=3*sizeof(float)*ilen1*ilen2;
  if (!bigend) fByteSwap(&kpos,sizeof(unsigned int),1);
  file.write(reinterpret_cast<const char*>(&kpos), sizeof(unsigned int));
  for(j=jstart; j<jend; j++)
    for(i=istart; i<iend; i++) {
      ipos[0]=(lbdm.xs + i - lbdm.bwid)*float(lbdx);
      ipos[1]=(lbdm.ys + j - lbdm.bwid)*float(lbdx);
      ipos[2]=0.0;
      if (!bigend) fByteSwap(ipos,sizeof(float),3);
      file.write((char*)&ipos, 3*sizeof(float));
    }

  file<<"</AppendedData>"<<endl;
  file<<"</VTKFile>"<<endl;
  
  file.close();
  
  return 0;
}


int fsOutputVTKT2D(const char* filename="lbout")
{
  int i, j, istart, iend, jstart, jend;
  float ipos[3];
  int jpos;
  long ilen=0;
  char buf[80];
  if(lbdm.size>1)
    sprintf(buf, "%s%.6dat%.6d.vts", filename, lbdm.rank, qVersion);
  else
    sprintf(buf, "%s%.6d.vts", filename, qVersion);
  ofstream file(buf);
  file<<"<?xml version=\"1.0\"?>"<<endl;
  file<<"<VTKFile type=\"StructuredGrid\" version=\"0.1\" byte_order=\"BigEndian\">"<<endl;
  istart = 0; iend = lbdm.xouter; 
  if(lbdm.xcor == 0)
    istart = lbdm.bwid;
  if(lbdm.xcor == lbdm.xdim-1)
    iend = lbdm.xouter - lbdm.bwid;

  jstart = 0; jend = lbdm.youter; 
  if(lbdm.ycor == 0)
    jstart = lbdm.bwid;
  if(lbdm.ycor == lbdm.ydim-1)
    jend = lbdm.youter - lbdm.bwid;

  file<<"<StructuredGrid WholeExtent=\"";
  file<<(lbdm.xs+istart-lbdm.bwid)<<" "<<(lbdm.xs+iend-lbdm.bwid-1)
      <<" "<<(lbdm.ys+jstart-lbdm.bwid)<<" "<<(lbdm.ys+jend-lbdm.bwid-1)<<" 0 0\">"<<endl;
  file<<"<Piece Extent=\""<<(lbdm.xs+istart-lbdm.bwid)<<" "<<(lbdm.xs+iend-lbdm.bwid-1)
      <<" "<<(lbdm.ys+jstart-lbdm.bwid)<<" "<<(lbdm.ys+jend-lbdm.bwid-1)<<" 0 0\">"<<endl;
  // write grid points
  file<<"<Points>"<<endl;
  file<<"<DataArray type=\"Float32\" NumberOfComponents=\"3\" format=\"ascii\">"<<endl;
  for(j=jstart; j<jend; j++)
    for(i=istart; i<iend; i++)
      file<<(lbdm.xs+i-lbdm.bwid)*float(lbdx)<<" "<<(lbdm.ys+j-lbdm.bwid)*float(lbdx)<<" "<<0.0<<" ";
  file<<endl;
  file<<"</DataArray>"<<endl;
  file<<"</Points>"<<endl;
  file<<"<PointData Scalars=\"temperature\" Vectors=\"velocity\">"<<endl;
  // write density
  file<<"<DataArray Name=\"temperature\" type=\"Float32\" format=\"ascii\">"<<endl;
  for(j=jstart; j<jend; j++)
    for(i=istart; i<iend; i++)
      {
	    ilen = i * lbdm.youter + j;
	    ipos[0] = float(fGetTemperatureSite(ilen));
	    file<<ipos[0]<<" ";
      }
  file<<endl;
  file<<"</DataArray>"<<endl;
  // write velocity
  file<<"<DataArray Name=\"velocity\" type=\"Float32\" NumberOfComponents=\"3\" format=\"ascii\">"<<endl;
  if(interact==5) {
    for(j=jstart; j<jend; j++) {
      for(i=istart; i<iend; i++) {
        ilen = i * lbdm.youter + j;
        if(lbphi[ilen] == 12 || lbphi[ilen] == 13) {
	      ipos[0] = 0.0;
          ipos[1] = 0.0;
        }
        else {
          ipos[0] = fGetOneDirecSpeedSwiftSite(0, &lbf[ilen*lbsitelength]);
          ipos[1] = fGetOneDirecSpeedSwiftSite(1, &lbf[ilen*lbsitelength]);
        }
        file<<ipos[0]<<" "<<ipos[1]<<" "<<0.0<<" ";
      }
    }
  }
  else if(!incompress) {
    for(j=jstart; j<jend; j++) {
      for(i=istart; i<iend; i++) {
        ilen = i * lbdm.youter + j;
        if(lbphi[ilen] == 12 || lbphi[ilen] == 13) {
	      ipos[0] = 0.0;
          ipos[1] = 0.0;
        }
        else {
          ipos[0] = fGetOneDirecSpeedSite(0, &lbf[ilen*lbsitelength]);
          ipos[1] = fGetOneDirecSpeedSite(1, &lbf[ilen*lbsitelength]);
        }
        file<<ipos[0]<<" "<<ipos[1]<<" "<<0.0<<" ";
      }
    }
  }
  else {
    for(j=jstart; j<jend; j++) {
      for(i=istart; i<iend; i++) {
        ilen = i * lbdm.youter + j;
        if(lbphi[ilen] == 12 || lbphi[ilen] == 13) {
	      ipos[0] = 0.0;
          ipos[1] = 0.0;
        }
        else {
          ipos[0] = fGetOneDirecSpeedIncomSite(0, &lbf[ilen*lbsitelength]);
          ipos[1] = fGetOneDirecSpeedIncomSite(1, &lbf[ilen*lbsitelength]);
        }
        file<<ipos[0]<<" "<<ipos[1]<<" "<<0.0<<" ";
      }
    }
  }
  
  file<<endl;
  file<<"</DataArray>"<<endl;
  // write phase field/space property
  file<<"<DataArray Name=\"phase_field\" type=\"Int32\" format=\"ascii\">"<<endl;
  for(j=jstart; j<jend; j++)
    for(i=istart; i<iend; i++)
      {
	    ilen = i * lbdm.youter + j;
	    jpos=lbphi[ilen];
	    file<<jpos<<" ";
      }
  file<<endl;
  file<<"</DataArray>"<<endl;
  file<<"</PointData>"<<endl;
  file<<"</Piece>"<<endl;
  file<<"</StructuredGrid>"<<endl;
  file<<"</VTKFile>"<<endl;
  file.close();
  return 0;
}


