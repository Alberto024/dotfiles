/***********************************************
 *   DL_MESO       Version 2.6                 *
 *   Authors   :   R. S. Qin, M. A. Seaton     *
 *   Copyright :   STFC Daresbury Laboratory   *
 *             :   22/10/2015                  *
 ***********************************************/

long fNextStep(int q, int xpos, int ypos, int zpos)
{

  // find position of particle for next time step when moving along q 
  // direction to nearest neighbour

  return (fCppMod(xpos+lbvx[q], lbdm.xouter) * lbdm.youter
    + fCppMod(ypos+lbvy[q], lbdm.youter)) * lbdm.zouter
    + fCppMod(zpos+lbvz[q], lbdm.zouter);
}

long fNextStep(int q, int xpos, int ypos)
{

  // find position of particle for next time step when moving along q 
  // direction to nearest neighbour

  return fCppMod(xpos+lbvx[q], lbdm.xouter) * lbdm.youter
    + fCppMod(ypos+lbvy[q], lbdm.youter);
}

long fNextStep(int dx, int dy, int dz, long tpos)
{

  // find position of particle for next time step when moving along (dx, dy, dz)
  // direction to nearest neighbour
  int xpos, ypos, zpos;
  fGetCoord(tpos, xpos, ypos, zpos);
  return (fCppMod(xpos+dx, lbdm.xouter) * lbdm.youter 
    + fCppMod(ypos+dy, lbdm.youter)) * lbdm.zouter 
    + fCppMod(zpos+dz, lbdm.zouter);
}


int fMoveNonzeroAway(long tpos)
{
  int xpos, ypos, zpos;
  long spos, pos1;
  int qdim = lbsy.nf+lbsy.nc+lbsy.nt;
  int q;
  pos1 = tpos * lbsitelength;
  fGetCoord(tpos, xpos, ypos, zpos);
  for(int m=0; m<lbsitelength-lbsy.pf; m++)
    if(lbf[pos1+m] != 0) {
      q  = m / qdim;
      spos = fNextStep(q, xpos, ypos, zpos);
      lbf[spos * lbsitelength + m] += lbf[pos1+m];
      lbf[pos1+m] =0.0;
    }
  return 0;
}


int fBounceBackF(long tpos)
{

  // perform on-grid bounce-back for fluid distribution function
  
  long stpos=tpos * lbsitelength;
  int half = (lbsy.nq - 1) / 2;
  int qdim = lbsy.nf+lbsy.nc+lbsy.nt;

  for(int m=1; m<=half; m++)
    for(int j=0; j<lbsy.nf; j++)
      fSwapPair (lbf[stpos + m*qdim + j], lbf[stpos + (m+half)*qdim + j]);
    
/*
  for(int j=0; j<lbsy.nf; j++) {
    for(int m=0; m<lbsy.nq; m++) 
      lbfeq[lbopv[m]] = lbf[stpos + j*lbsy.nq + m];
    for(int m=0; m<lbsy.nq; m++)
      lbf[stpos + j*lbsy.nq + m] = lbfeq[m];
  } 
*/
    
  return 0;
}


int fBounceBackC(long tpos)
{

  // perform on-grid bounce-back for solute distribution function
  
  long stpos=tpos * lbsitelength + lbsy.nf;
  int half = (lbsy.nq - 1) / 2;
  int qdim = lbsy.nf+lbsy.nc+lbsy.nt;

  for(int m=1; m<=half; m++)
    for(int j=0; j<lbsy.nc; j++)
      fSwapPair (lbf[stpos + m*qdim + j], lbf[stpos + (m+half)*qdim + j]);
        
/*
  for(int j=0; j<lbsy.nc; j++) {
    for(int m=0; m<lbsy.nq; m++) 
      lbfeq[lbopv[m]] = lbf[stpos +j*lbsy.nq+ m];
    for(int m=0; m<lbsy.nq; m++)
      lbf[stpos +j*lbsy.nq+ m] = lbfeq[m];
  }    
*/

  return 0;
}


int fBounceBackT(long tpos)
{

  // perform on-grid bounce-back for temperature distribution function
  
  long stpos=tpos * lbsitelength + lbsy.nf + lbsy.nc;
  int half = (lbsy.nq - 1) / 2;
  int qdim = lbsy.nf+lbsy.nc+lbsy.nt;

  for(int m=1; m<=half; m++)
    for(int j=0; j<lbsy.nt; j++)
      fSwapPair (lbf[stpos + m*qdim], lbf[stpos + (m+half)*qdim]);
  
/*  for(int j=0; j<lbsy.nt; j++) {
      for(int m=0; m<lbsy.nq; m++)
        lbfeq[lbopv[m]] = lbf[stpos + m];
      for(int m=0; m<lbsy.nq; m++)
        lbf[stpos + m] = lbfeq[m];
      stpos += lbsy.nq;
    }
*/
    
  return 0;
}

int fMidBounceBackF(long tpos)
{

  // perform mid-link bounce-back for fluid distribution function
  
  long stpos= tpos * lbsitelength;
  long spos;
  int xpos, ypos, zpos;
  int qdim = lbsy.nf+lbsy.nc+lbsy.nt;

  fGetCoord(tpos, xpos, ypos, zpos); 
  for(int m=0; m<lbsy.nq; m++) {
    for(int j=0; j<lbsy.nf; j++) {
      spos = fNextStep(m, xpos, ypos, zpos);
      lbf[stpos + m*qdim + j] = lbf[spos * lbsitelength + lbopv[m]*qdim + j];
    }

  }
  return 0;
}


int fMidBounceBackC(long tpos)
{

  // perform mid-link bounce-back for solute distribution function
  
  long stpos=tpos * lbsitelength + lbsy.nf;
  long spos;
  int xpos, ypos, zpos;
  int qdim = lbsy.nf+lbsy.nc+lbsy.nt;

  fGetCoord(tpos, xpos, ypos, zpos);   
  for(int m=0; m<lbsy.nq; m++) {
    for(int j=0; j<lbsy.nc; j++) {
      spos = fNextStep(m, xpos, ypos, zpos);
      lbf[stpos + m*qdim + j] = lbf[spos * lbsitelength + (lbsy.nf + j) + lbopv[m]*qdim];
    }

  }    
  
  return 0;
}


int fMidBounceBackT(long tpos)
{

  // perform mid-link bounce-back for temperature distribution function
  
  long stpos=tpos * lbsitelength + lbsy.nf + lbsy.nc;
  long spos;
  int xpos, ypos, zpos;
  int qdim = lbsy.nf+lbsy.nc+lbsy.nt;

  fGetCoord(tpos, xpos, ypos, zpos);   
  for(int m=0; m<lbsy.nq; m++) {
    for(int j=0; j<lbsy.nt; j++) {
      spos = fNextStep(m, xpos, ypos, zpos);
      lbf[stpos + m*qdim] = lbf[spos * lbsitelength + (lbsy.nf + lbsy.nc) + lbopv[m]*qdim];
    }

  }    
  
  return 0;
}

int fSiteBlankF(long tpos)
{

  // set fluid distribution function at grid point tpos to zero (solid block)

  double *pt2 = &lbf[tpos * lbsitelength];
  int qdim = lbsy.nf+lbsy.nc+lbsy.nt;
  for(int m=0; m<lbsy.nq; m++) {
    for(int j=0; j<lbsy.nf; j++){
      pt2[m*qdim+j] = 0;
    }
  }
  pt2 = NULL;
  return 0;
}


int fSiteBlankC(long tpos)
{

  // set solute distribution function at grid point tpos to zero (solid block)

  double *pt2 = &lbf[tpos * lbsitelength + lbsy.nf];
  int qdim = lbsy.nf+lbsy.nc+lbsy.nt;
  for(int m=0; m<lbsy.nq; m++) {
    for(int j=0; j<lbsy.nc; j++){
      pt2[m*qdim+j] = 0;
    }
  }
  pt2 = NULL;
  return 0;
}

int fSiteBlankT(long tpos)
{

  // set temperature distribution function at grid point tpos to zero (solid 
  // block)
  
  double *pt2 = &lbf[tpos * lbsitelength + (lbsy.nf+lbsy.nc)*lbsy.nq];
  int qdim = lbsy.nf+lbsy.nc+lbsy.nt;
  for(int m=0; m<lbsy.nq; m++) {
    for(int j=0; j<lbsy.nt; j++){
      pt2[m*qdim+j] = 0;
    }
  }
  pt2 = NULL;
  return 0;
}

// D2Q9

int fD2Q9VCE(double v0, double v1, double *f0, double *f1, double *f2,
	     double *f3, double *f4, double *f5, double *f6,
	     double *f7, double *f8)
{

  // produce fixed velocity at top boundary (PSDF) for compressible/incompressible fluids

  double rho, rho0;
  double c1=2.0/3.0,c2=1.0/6.0;
  if(!incompress) {
    for(int i=0; i<lbsy.nf; i++) {
      rho = (f0[i]+f2[i]+f6[i]+2*(f1[i]+f7[i]+f8[i]))/(1.0+v1);
      f4[i]=f8[i]-c1*rho*v1;
      f3[i]=f7[i]+0.5*(f6[i]-f2[i])-0.5*rho*v0-rho*v1*c2;
      f5[i]=f1[i]-0.5*(f6[i]-f2[i])+0.5*rho*v0-rho*v1*c2;
    }
  }
  else {
    for(int i=0; i<lbsy.nf; i++) {
//     rho = f0+f2+f6+2*(f1+f7+f8)-rho0*v1;
      rho0 = lbincp[i];
      f4[i]=f8[i]-c1*rho0*v1;
      f3[i]=f7[i]+0.5*(f6[i]-f2[i])-0.5*rho0*v0-rho0*v1*c2;
      f5[i]=f1[i]-0.5*(f6[i]-f2[i])+0.5*rho0*v0-rho0*v1*c2;
    }
  }
  return 0;
}

int fD2Q9VCC(double *v, double * startpos, long tpos)
{

  // produce fixed velocity at concave corner for compressible fluids

  double *pt1=startpos;
  double rho[lbsy.nf];
  double p,p0;
  int qdim=lbsy.nf+lbsy.nc+lbsy.nt;
    
  fGetAllMassSite(rho, &lbf[tpos*lbsitelength]);
  if(!incompress) {
    for(int j=0; j<lbsy.nf; j++) {
      p = fEvapLimit(rho[j]);
      fGetEquilibriumF(lbfeq, v, p);
      for(int i=0; i<lbsy.nq; i++){
        pt1[i*qdim+j] =lbfeq[i];
      }
    }
  }
  else {
    for(int j=0; j<lbsy.nf; j++) {
      p = fEvapLimit(rho[j]);
      p0 = lbincp[j];
      fGetEquilibriumFIncom(lbfeq, v, p, p0);
      for(int i=0; i<lbsy.nq; i++){
        pt1[i*qdim+j] =lbfeq[i];
      }
    }
  }
  pt1 = NULL;
  return 0;
}

int fD2Q9VCCSwift(double *v, double * startpos, double * delpos, double dx, double dy, long tpos, double T)
{

  // produce fixed velocity at concave corner for fluids with
  // Swift free-energy interactions

  double *pt1=startpos;
  double *pt2=delpos;
  double rho[lbsy.nf], feq[lbsy.nf*lbsy.nq];
  double p,p0,omega,lambda,pb,mu;
  int qdim=lbsy.nf+lbsy.nc+lbsy.nt;
    
  fGetAllMassSite(rho, &lbf[tpos*lbsitelength]);
  
  if(lbsy.nf>1) {
    p = rho[0] + dx*pt1[0] + dy*pt1[1];
    p0 = rho[1] + dx*pt1[4] + dy*pt1[5];
    omega = 0.5*(1.0+p0)*lbtf[0]+0.5*(1.0-p0)*lbtf[1];
    pb = fGetBulkPressureSwift(p, p0, T);
    mu = fGetPotentialSwift(p0, pt2[7]);
    lambda = fGetLambdaSwift(p, omega, T);
    fGetEquilibriumFSwiftTwoFluid(feq, v, p, p0, pb, mu, lambda, pt2);
    for(int i=0; i<lbsy.nq; i++){
      pt1[i*qdim  ] =feq[2*i  ];
      pt1[i*qdim+1] =feq[2*i+1];
    }
  }
  else {
    p = rho[0] + dx*pt1[0] + dy*pt1[1];
    pb = fGetBulkPressureSwift(p, 0.0, T);
    lambda = fGetLambdaSwift(p, lbtf[0], T);
    fGetEquilibriumFSwiftOneFluid(feq, v, p, pb, lambda, pt2);
    for(int i=0; i<lbsy.nq; i++){
      pt1[i*qdim] =lbfeq[i];
    }
  }
  pt1 = NULL;
  pt2 = NULL;
  return 0;
}

int fD2Q9VF(long tpos, int prop, double *uwall)
{
  long spos = tpos * lbsitelength, tpos1;
  int qdim = lbsy.nf+lbsy.nc+lbsy.nt;
  int a3;
  double T;
  if(interact==5) {
    switch (prop) {
      case 49:
        uwall[0] = lbtopv[0]; uwall[1] = lbtopv[1]; uwall[2] = 0.0;
        fD2Q9VCE(uwall[0], uwall[1], &lbf[spos], &lbf[spos+1*qdim], &lbf[spos+2*qdim],
                 &lbf[spos+3*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim], &lbf[spos+6*qdim],
                 &lbf[spos+7*qdim], &lbf[spos+8*qdim]);
        break;
      case 47:
        uwall[0] = lbbotv[0]; uwall[1] = lbbotv[1]; uwall[2] = 0.0;
        fD2Q9VCE(-uwall[0], -uwall[1], &lbf[spos], &lbf[spos+5*qdim], &lbf[spos+6*qdim],
                 &lbf[spos+7*qdim], &lbf[spos+8*qdim], &lbf[spos+1*qdim], &lbf[spos+2*qdim],
                 &lbf[spos+3*qdim], &lbf[spos+4*qdim]);
        break;
      case 50:
        uwall[0] = lblefv[0]; uwall[1] = lblefv[1]; uwall[2] = 0.0;
        fD2Q9VCE(uwall[1], -uwall[0], &lbf[spos], &lbf[spos+3*qdim], &lbf[spos+4*qdim],
                 &lbf[spos+5*qdim], &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+8*qdim],
                 &lbf[spos+1*qdim], &lbf[spos+2*qdim]);
        break;
      case 48:
        uwall[0] = lbrigv[0]; uwall[1] = lbrigv[1]; uwall[2] = 0.0;
        fD2Q9VCE(-uwall[1], uwall[0], &lbf[spos], &lbf[spos+7*qdim], &lbf[spos+8*qdim],
                 &lbf[spos+1*qdim], &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+4*qdim],
                 &lbf[spos+5*qdim], &lbf[spos+6*qdim]);
        break;
      case 31:
        a3=lbphi[tpos]/100;
        tpos1 = fNextStep(1, 1, 0, tpos);
        if(a3==1 || a3==3 || a3==5 || a3==7)
          T = (lbsy.nt>0)?lbbott:lbsyst;
        else
          T = (lbsy.nt>0)?fGetTemperatureSite(tpos1):lbsyst;
        uwall[0] = lbbotv[0]; uwall[1] = lbbotv[1]; uwall[2] = 0.0;
        fD2Q9VCCSwift(uwall, &lbf[spos], &lbft[4*lbsy.nf*tpos], -0.5, -0.5, tpos1, T);
        break;
      case 32:
        a3=lbphi[tpos]/100;
        tpos1 = fNextStep(-1, 1, 0, tpos);
        if(a3==1 || a3==3 || a3==5 || a3==7)
          T = (lbsy.nt>0)?lbbott:lbsyst;
        else
          T = (lbsy.nt>0)?fGetTemperatureSite(tpos1):lbsyst;
        uwall[0] = lbbotv[0]; uwall[1] = lbbotv[1]; uwall[2] = 0.0;
        fD2Q9VCCSwift(uwall, &lbf[spos], &lbft[4*lbsy.nf*tpos], 0.5, -0.5, tpos1, T);
        break;
      case 33:
        a3=lbphi[tpos]/100;
        tpos1 = fNextStep(-1, -1, 0, tpos);
        if(a3==1 || a3==3 || a3==5 || a3==7)
          T = (lbsy.nt>0)?lbtopt:lbsyst;
        else
          T = (lbsy.nt>0)?fGetTemperatureSite(tpos1):lbsyst;
        uwall[0] = lbtopv[0]; uwall[1] = lbtopv[1]; uwall[2] = 0.0;
        fD2Q9VCCSwift(uwall, &lbf[spos], &lbft[4*lbsy.nf*tpos], 0.5, 0.5, tpos1, T);
        break;
      case 34:
        a3=lbphi[tpos]/100;
        tpos1 = fNextStep(1, -1, 0, tpos);
        if(a3==1 || a3==3 || a3==5 || a3==7)
          T = (lbsy.nt>0)?lbtopt:lbsyst;
        else
          T = (lbsy.nt>0)?fGetTemperatureSite(tpos1):lbsyst;
        uwall[0] = lbtopv[0]; uwall[1] = lbtopv[1]; uwall[2] = 0.0;
        fD2Q9VCCSwift(uwall, &lbf[spos], &lbft[4*lbsy.nf*tpos], -0.5, 0.5, tpos1, T);
        break;
    }
  }
  else {
    switch (prop) {
      case 49:
        uwall[0] = lbtopv[0]; uwall[1] = lbtopv[1]; uwall[2] = 0.0;
        fD2Q9VCE(uwall[0], uwall[1], &lbf[spos], &lbf[spos+1*qdim], &lbf[spos+2*qdim],
                 &lbf[spos+3*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim], &lbf[spos+6*qdim],
                 &lbf[spos+7*qdim], &lbf[spos+8*qdim]);
        break;
      case 47:
        uwall[0] = lbbotv[0]; uwall[1] = lbbotv[1]; uwall[2] = 0.0;
        fD2Q9VCE(-uwall[0], -uwall[1], &lbf[spos], &lbf[spos+5*qdim], &lbf[spos+6*qdim],
                 &lbf[spos+7*qdim], &lbf[spos+8*qdim], &lbf[spos+1*qdim], &lbf[spos+2*qdim],
                 &lbf[spos+3*qdim], &lbf[spos+4*qdim]);
        break;
      case 50:
        uwall[0] = lblefv[0]; uwall[1] = lblefv[1]; uwall[2] = 0.0;
        fD2Q9VCE(uwall[1], -uwall[0], &lbf[spos], &lbf[spos+3*qdim], &lbf[spos+4*qdim],
                 &lbf[spos+5*qdim], &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+8*qdim],
                 &lbf[spos+1*qdim], &lbf[spos+2*qdim]);
        break;
      case 48:
        uwall[0] = lbrigv[0]; uwall[1] = lbrigv[1]; uwall[2] = 0.0;
        fD2Q9VCE(-uwall[1], uwall[0], &lbf[spos], &lbf[spos+7*qdim], &lbf[spos+8*qdim],
                 &lbf[spos+1*qdim], &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+4*qdim],
                 &lbf[spos+5*qdim], &lbf[spos+6*qdim]);
        break;
      case 31:
        tpos1 = fNextStep(1, 1, 0, tpos);
        uwall[0] = lbbotv[0]; uwall[1] = lbbotv[1]; uwall[2] = 0.0;
        fD2Q9VCC(uwall, &lbf[spos], tpos1);
        break;
      case 32:
        tpos1 = fNextStep(-1, 1, 0, tpos);
        uwall[0] = lbbotv[0]; uwall[1] = lbbotv[1]; uwall[2] = 0.0;
        fD2Q9VCC(uwall, &lbf[spos], tpos1);
        break;
      case 33:
        tpos1 = fNextStep(-1, -1, 0, tpos);
        uwall[0] = lbtopv[0]; uwall[1] = lbtopv[1]; uwall[2] = 0.0;
        fD2Q9VCC(uwall, &lbf[spos], tpos1);
        break;
      case 34:
        tpos1 = fNextStep(1, -1, 0, tpos);
        uwall[0] = lbtopv[0]; uwall[1] = lbtopv[1]; uwall[2] = 0.0;
        fD2Q9VCC(uwall, &lbf[spos], tpos1);
        break;
    }
  }
  return 0;
}

int fD2Q9PCE(double *p, double *f0, double *f1, double *f2, double *f3,
	     double *f4, double *f5, double *f6, double *f7, double *f8, double &vel)
{

  // produce fixed density/pressure boundary for concave edge (PCED)

  double c1=2.0/3.0,c2=1.0/6.0;
  int qdim=lbsy.nf+lbsy.nc+lbsy.nt;
  double v,mass=0.0;
  vel=0.0;

  if(!incompress) {
    for(int i=0; i<lbsy.nf; i++) {
      v=f0[i]+f2[i]+f6[i]+2*(f1[i]+f7[i]+f8[i])-p[i];  // v = p*v1
      vel += v;
      mass += p[i];
      f4[i]=f8[i]-c1*v;
      f3[i]=f7[i]+0.5*(f6[i]-f2[i])-v*c2;
      f5[i]=f1[i]-0.5*(f6[i]-f2[i])-v*c2;
    }
  }
  else {
    for(int i=0; i<lbsy.nf; i++) {
      v=f0[i]+f2[i]+f6[i]+2*(f1[i]+f7[i]+f8[i])-p[i];  // v = p*v1
      vel += v;
      mass += lbincp[i];
      f4[i]=f8[i]-c1*v;
      f3[i]=f7[i]+0.5*(f6[i]-f2[i])-v*c2;
      f5[i]=f1[i]-0.5*(f6[i]-f2[i])-v*c2;
    }
  }
  vel *= fReciprocal(mass);
  return 0;
}


int fD2Q9PCESwift(double *p, double *f0, double *f1, double *f2, double *f3,
	     double *f4, double *f5, double *f6, double *f7, double *f8, double &vel)
{

  // produce fixed density/pressure boundary for concave edge (PCED)
  // with Swift free-energy interactions

  double c1=2.0/3.0,c2=1.0/6.0,c3=1.0/3.0;
  int qdim=lbsy.nf+lbsy.nc+lbsy.nt;
  double v,mass=0.0;
  vel=0.0;

  v=f0[0]+f2[0]+f6[0]+2*(f1[0]+f7[0]+f8[0])-p[0];  // v = p*v1
  vel += v;
  mass += p[0];
  f4[0]=f8[0]-c1*v;
  f3[0]=f7[0]+0.5*(f6[0]-f2[0])-v*c2;
  f5[0]=f1[0]-0.5*(f6[0]-f2[0])-v*c2;
  vel *= fReciprocal(mass);
  if(lbsy.nf>1) {
    f4[1]=p[1]*(1.0+c3*vel)-f0[1]-f2[1]-f6[1]-f8[1]-2.0*(f1[1]+f7[1]);
    f3[1]=f7[1]-c2*p[1]*vel;
    f5[1]=f1[1]-c2*p[1]*vel;
  }
  return 0;
}


int fD2Q9PCC(double *p, double *v, double * startpos)
{

  // produce fixed density/pressure at concave corner for compressible/incompressible fluids

  double *pt1=startpos;
  int qdim=lbsy.nf+lbsy.nc+lbsy.nt;
    
  if(!incompress) {
    for(int j=0; j<lbsy.nf; j++) {
      fGetEquilibriumF(lbfeq, v, p[j]);
      for(int i=0; i<lbsy.nq; i++){
        pt1[i*qdim+j] =lbfeq[i];
      }
    }
  }
  else {
    for(int j=0; j<lbsy.nf; j++) {
      fGetEquilibriumFIncom(lbfeq, v, p[j], lbincp[j]);
      for(int i=0; i<lbsy.nq; i++){
        pt1[i*qdim+j] =lbfeq[i];
      }
    }
  }
  pt1 = NULL;
  return 0;
}


int fD2Q9PCCSwift(double *p, double *v, double * startpos, double * delpos, double T)
{

  // produce fixed density/pressure at concave corner for fluids
  // with Swift free-energy interactions

  double *pt1=startpos;
  double *pt2=delpos;
  double feq[lbsy.nf*lbsy.nq];
  double omega,lambda,pb,mu;
  int qdim=lbsy.nf+lbsy.nc+lbsy.nt;
    
  if(lbsy.nf>1) {
    omega = 0.5*(1.0+p[1])*lbtf[0]+0.5*(1.0-p[1])*lbtf[1];
    pb = fGetBulkPressureSwift(p[0], p[1], T);
    mu = fGetPotentialSwift(p[1], pt2[7]);
    lambda = fGetLambdaSwift(p[0], omega, T);
    fGetEquilibriumFSwiftTwoFluid(feq, v, p[0], p[1], pb, mu, lambda, pt2);
    for(int i=0; i<lbsy.nq; i++){
      pt1[i*qdim  ] =feq[i];
      pt1[i*qdim+1] =feq[i+lbsy.nq];
    }
  }
  else {
    pb = fGetBulkPressureSwift(p[0], 0.0, T);
    lambda = fGetLambdaSwift(p[0], lbtf[0], T);
    fGetEquilibriumFSwiftOneFluid(feq, v, p[0], pb, lambda, pt2);
    for(int i=0; i<lbsy.nq; i++){
      pt1[i*qdim] =lbfeq[i];
    }
  }
  pt1 = NULL;
  pt2 = NULL;
  return 0;
}


int fD2Q9PF(long tpos, int prop, double *uwall)
{
  double moment, T;
  long tpos1,spos = tpos * lbsitelength;
  int qdim = lbsy.nf+lbsy.nc+lbsy.nt;
  int a3;

  uwall[0]=0.0; uwall[1]=0.0; uwall[2]=0.0;
  if(interact==5) {
    switch (prop) {
      case 49:
        fD2Q9PCESwift(lbtopp, &lbf[spos], &lbf[spos+1*qdim], &lbf[spos+2*qdim],
	         &lbf[spos+3*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim],
	         &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+8*qdim], moment);
        uwall[1] += moment;
        break;
      case 47:
        fD2Q9PCESwift(lbbotp, &lbf[spos], &lbf[spos+5*qdim], &lbf[spos+6*qdim],
             &lbf[spos+7*qdim], &lbf[spos+8*qdim], &lbf[spos+1*qdim],
             &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+4*qdim], moment);
        uwall[1] -= moment;
        break;
      case 50:
        fD2Q9PCESwift(lblefp, &lbf[spos], &lbf[spos+3*qdim], &lbf[spos+4*qdim],
             &lbf[spos+5*qdim], &lbf[spos+6*qdim], &lbf[spos+7*qdim],
             &lbf[spos+8*qdim], &lbf[spos+1*qdim], &lbf[spos+2*qdim], moment);
        uwall[0] -= moment;
        break;
      case 48:
        fD2Q9PCESwift(lbrigp, &lbf[spos], &lbf[spos+7*qdim], &lbf[spos+8*qdim],
             &lbf[spos+1*qdim], &lbf[spos+2*qdim], &lbf[spos+3*qdim],
             &lbf[spos+4*qdim], &lbf[spos+5*qdim], &lbf[spos+6*qdim], moment);
        uwall[0] += moment;
        break;
      case 31:
        a3=lbphi[tpos]/100;
        tpos1 = fNextStep(1, 1, 0, tpos);
        if(a3==1 || a3==3 || a3==5 || a3==7)
          T = (lbsy.nt>0)?lbleft:lbsyst;
        else
          T = (lbsy.nt>0)?fGetTemperatureSite(tpos1):lbsyst;
        fD2Q9PCCSwift(lblefp, uwall, &lbf[spos], &lbft[4*lbsy.nf*tpos], T);
        break;
      case 32:
        a3=lbphi[tpos]/100;
        tpos1 = fNextStep(-1, 1, 0, tpos);
        if(a3==1 || a3==3 || a3==5 || a3==7)
          T = (lbsy.nt>0)?lbrigt:lbsyst;
        else
          T = (lbsy.nt>0)?fGetTemperatureSite(tpos1):lbsyst;
        fD2Q9PCCSwift(lbrigp, uwall, &lbf[spos], &lbft[4*lbsy.nf*tpos], T);
        break;
      case 33:
        a3=lbphi[tpos]/100;
        tpos1 = fNextStep(-1, -1, 0, tpos);
        if(a3==1 || a3==3 || a3==5 || a3==7)
          T = (lbsy.nt>0)?lbrigt:lbsyst;
        else
          T = (lbsy.nt>0)?fGetTemperatureSite(tpos1):lbsyst;
        fD2Q9PCCSwift(lbrigp, uwall, &lbf[spos], &lbft[4*lbsy.nf*tpos], T);
        break;
      case 34:
        a3=lbphi[tpos]/100;
        tpos1 = fNextStep(1, -1, 0, tpos);
        if(a3==1 || a3==3 || a3==5 || a3==7)
          T = (lbsy.nt>0)?lbleft:lbsyst;
        else
          T = (lbsy.nt>0)?fGetTemperatureSite(tpos1):lbsyst;
        fD2Q9PCCSwift(lblefp, uwall, &lbf[spos], &lbft[4*lbsy.nf*tpos], T);
        break;
    }
  }
  else {
    switch (prop) {
      case 49:
        fD2Q9PCE(lbtopp, &lbf[spos], &lbf[spos+1*qdim], &lbf[spos+2*qdim],
	         &lbf[spos+3*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim],
	         &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+8*qdim], moment);
        uwall[1] += moment;
        break;
      case 47:
        fD2Q9PCE(lbbotp, &lbf[spos], &lbf[spos+5*qdim], &lbf[spos+6*qdim],
             &lbf[spos+7*qdim], &lbf[spos+8*qdim], &lbf[spos+1*qdim],
             &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+4*qdim], moment);
        uwall[1] -= moment;
        break;
      case 50:
        fD2Q9PCE(lblefp, &lbf[spos], &lbf[spos+3*qdim], &lbf[spos+4*qdim],
             &lbf[spos+5*qdim], &lbf[spos+6*qdim], &lbf[spos+7*qdim],
             &lbf[spos+8*qdim], &lbf[spos+1*qdim], &lbf[spos+2*qdim], moment);
        uwall[0] -= moment;
        break;
      case 48:
        fD2Q9PCE(lbrigp, &lbf[spos], &lbf[spos+7*qdim], &lbf[spos+8*qdim],
             &lbf[spos+1*qdim], &lbf[spos+2*qdim], &lbf[spos+3*qdim],
             &lbf[spos+4*qdim], &lbf[spos+5*qdim], &lbf[spos+6*qdim], moment);
        uwall[0] += moment;
        break;
      case 31:
        fD2Q9PCC(lblefp, uwall, &lbf[spos]);
        break;
      case 32:
        fD2Q9PCC(lbrigp, uwall, &lbf[spos]);
        break;
      case 33:
        fD2Q9PCC(lbrigp, uwall, &lbf[spos]);
        break;
      case 34:
        fD2Q9PCC(lblefp, uwall, &lbf[spos]);
        break;
    }
  }
  return 0;
}


int fD2Q9CCE(double *p, double v0, double v1, double *f0, double *f1, double *f2,
             double *f3, double *f4, double *f5, double *f6, double *f7, double *f8)
{

  // produce fixed concentration boundary for concave edge (CCED)

  double c1=1.0/9.0,c2=1.0/36.0;
  for(int i=0; i<lbsy.nc; i++) {
    double rho=6.0*(p[i]-f0[i]-f1[i]-f2[i]-f6[i]-f7[i]-f8[i])/(1.0-3.0*v1);
    f4[i]=c1*rho*(1.0-3.0*v1);
    f3[i]=c2*rho*(1.0-3.0*v0-3.0*v1);
    f5[i]=c2*rho*(1.0+3.0*v0-3.0*v1);
  }
  return 0;
}


int fD2Q9CCC(double *p, double *v, double * startpos)
{

  // produce fixed solute concentrations at concave corner

  double *pt1=startpos;
  int qdim=lbsy.nf+lbsy.nc+lbsy.nt;
    
  for(int j=0; j<lbsy.nc; j++) {
    fGetEquilibriumC(lbfeq, v, p[j]);
    for(int i=0; i<lbsy.nq; i++){
      pt1[i*qdim+j] =lbfeq[i];
    }
  }

  pt1 = NULL;
  return 0;
}

int fD2Q9PC(long tpos, int prop, double *uwall)
{
  long spos = tpos * lbsitelength + lbsy.nf;
  int qdim=lbsy.nf+lbsy.nc+lbsy.nt;
    
  if(lbsy.nc>0) {
    switch (prop) {
      case 49:
        fD2Q9CCE(lbtopc, uwall[0], uwall[1], &lbf[spos], &lbf[spos+1*qdim],
                 &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim],
                 &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+8*qdim]);
        break;
      case 47:
        fD2Q9CCE(lbbotc, -uwall[0], -uwall[1], &lbf[spos], &lbf[spos+5*qdim],
               &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+8*qdim], &lbf[spos+1*qdim],
               &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+4*qdim]);
        break;
      case 50:
        fD2Q9CCE(lblefc, uwall[1], -uwall[0], &lbf[spos], &lbf[spos+3*qdim],
                 &lbf[spos+4*qdim], &lbf[spos+5*qdim], &lbf[spos+6*qdim], &lbf[spos+7*qdim],
                 &lbf[spos+8*qdim], &lbf[spos+1*qdim], &lbf[spos+2*qdim]);
        break;
      case 48:
        fD2Q9CCE(lbrigc, -uwall[1], uwall[0], &lbf[spos], &lbf[spos+7*qdim],
                 &lbf[spos+8*qdim], &lbf[spos+1*qdim], &lbf[spos+2*qdim], &lbf[spos+3*qdim],
                 &lbf[spos+4*qdim], &lbf[spos+5*qdim], &lbf[spos+6*qdim]);
        break;
      case 31:
        fD2Q9CCC(lblefc, uwall, &lbf[spos]);
        break;
      case 32:
        fD2Q9CCC(lbrigc, uwall, &lbf[spos]);
        break;
      case 33:
        fD2Q9CCC(lbrigc, uwall, &lbf[spos]);
        break;
      case 34:
        fD2Q9CCC(lblefc, uwall, &lbf[spos]);
        break;
    }
  }
  return 0;  
}


int fD2Q9TCE(double p, double v0, double v1, double *f0, double *f1, double *f2,
             double *f3, double *f4, double *f5, double *f6, double *f7, double *f8)
{

  // produce fixed temperature for concave edge (TCED)

  double c1=1.0/9.0,c2=1.0/36.0;
  double rho=6.0*(p-f0[0]-f1[0]-f2[0]-f6[0]-f7[0]-f8[0])/(1.0-3.0*v1);
  f4[0]=c1*rho*(1.0-3.0*v1);
  f3[0]=c2*rho*(1.0-3.0*v0-3.0*v1);
  f5[0]=c2*rho*(1.0+3.0*v0-3.0*v1);
  return 0;
}


int fD2Q9TCC(double p, double *v, double * startpos)
{

  // produce fixed temperature at concave corner

  double *pt1=startpos;
  int qdim=lbsy.nf+lbsy.nc+lbsy.nt;

  fGetEquilibriumT(lbfeq, v, p);
  for(int i=0; i<lbsy.nq; i++){
    pt1[i*qdim] =lbfeq[i];
  }
  pt1 = NULL;
  return 0;
}


int fD2Q9PT(long tpos, int prop, double *uwall)
{
  long spos = tpos * lbsitelength + lbsy.nf + lbsy.nc;
  int qdim=lbsy.nf+lbsy.nc+lbsy.nt;

  if(lbsy.nt == 1) {
    switch (prop) {
      case 49:
        fD2Q9TCE(lbtopt, uwall[0], uwall[1], &lbf[spos], &lbf[spos+1*qdim],
                 &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim],
                 &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+8*qdim]);
        break;
      case 47:
        fD2Q9TCE(lbbott, -uwall[0], -uwall[1], &lbf[spos], &lbf[spos+5*qdim],
               &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+8*qdim], &lbf[spos+1*qdim],
               &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+4*qdim]);
        break;
      case 50:
        fD2Q9TCE(lbleft, uwall[1], -uwall[0], &lbf[spos], &lbf[spos+3*qdim],
                 &lbf[spos+4*qdim], &lbf[spos+5*qdim], &lbf[spos+6*qdim], &lbf[spos+7*qdim],
                 &lbf[spos+8*qdim], &lbf[spos+1*qdim], &lbf[spos+2*qdim]);
        break;
      case 48:
        fD2Q9TCE(lbrigt, -uwall[1], uwall[0], &lbf[spos], &lbf[spos+7*qdim],
                 &lbf[spos+8*qdim], &lbf[spos+1*qdim], &lbf[spos+2*qdim], &lbf[spos+3*qdim],
                 &lbf[spos+4*qdim], &lbf[spos+5*qdim], &lbf[spos+6*qdim]);
        break;
      case 31:
        fD2Q9TCC(lbleft, uwall, &lbf[spos]);
        break;
      case 32:
        fD2Q9TCC(lbrigt, uwall, &lbf[spos]);
        break;
      case 33:
        fD2Q9TCC(lbrigt, uwall, &lbf[spos]);
        break;
      case 34:
        fD2Q9TCC(lbleft, uwall, &lbf[spos]);
        break;
    }
  }
  return 0;  
}


// D3Q15

int fD3Q15VPS(double v0, double v1, double v2, double *f0, double *f1, double *f2,
              double *f3, double *f4, double *f5, double *f6, double *f7, double *f8,
              double *f9, double *f10, double *f11, double *f12, double *f13, double *f14)
{

  // produce fixed velocity at planar surface boundary for compressible/incompressible fluids:
  // expressed for top wall
  
  double rho, n1, n2;
  double c1=2.0/3.0,c2=1.0/12.0,c3=1.0/6.0;
  if(!incompress) {
    for(int i=0; i<lbsy.nf; i++) {
      rho=(f0[i]+f1[i]+f3[i]+f8[i]+f10[i]+2.0*(f6[i]+f7[i]+f9[i]+f11[i]+f12[i]))/(1.0+v1);
      n1=0.25*(f8[i]-f1[i])-c3*rho*v0;
      n2=0.25*(f10[i]-f3[i])-c3*rho*v2;
      f2[i]=f9[i]-c1*rho*v1;
      f4[i]=f11[i]-c2*rho*(v0+v1+v2)+n1+n2;
      f5[i]=f12[i]-c2*rho*(v0+v1-v2)+n1-n2;
      f13[i]=f6[i]+c2*rho*(v0-v1+v2)-n1-n2;
      f14[i]=f7[i]+c2*rho*(v0-v1-v2)-n1+n2;
    }
  }
  else {
    for(int i=0; i<lbsy.nf; i++) {
//     double rho=f0+f1+f3+f8+f10+2.0*(f6+f7+f9+f11+f12)-rho0*v1;
      double rho0 = lbincp[i];
      n1=0.25*(f8[i]-f1[i])-c3*rho0*v0;
      n2=0.25*(f10[i]-f3[i])-c3*rho0*v2;
      f2[i]=f9[i]-c1*rho0*v1;
      f4[i]=f11[i]-c2*rho0*(v0+v1+v2)+n1+n2;
      f5[i]=f12[i]-c2*rho0*(v0+v1-v2)+n1-n2;
      f13[i]=f6[i]+c2*rho0*(v0-v1+v2)-n1-n2;
      f14[i]=f7[i]+c2*rho0*(v0-v1-v2)-n1+n2;
    }
  }
  return 0;
}

int fD3Q15VCE(double *v, double * startpos, long tpos)
{

  // produce fixed velocity at convex or concave corner for compressible/incompressible fluids:
  // expressed for left-bottom-back corner (against velocity 7)

  double *pt1=startpos;
  double rho[lbsy.nf];
  double p,p0;
  int qdim=lbsy.nf+lbsy.nc+lbsy.nt;
  fGetAllMassSite(rho, &lbf[tpos*lbsitelength]);
  if(!incompress) {
    for(int j=0; j<lbsy.nf; j++) {
      p = fEvapLimit(rho[j]);
      fGetEquilibriumF(lbfeq, v, p);
      for(int i=0; i<lbsy.nq; i++){
        pt1[i*qdim+j] =lbfeq[i];
      }
    }
  }
  else {
    for(int j=0; j<lbsy.nf; j++) {
      p = fEvapLimit(rho[j]);
      p0 = lbincp[j];
      fGetEquilibriumFIncom(lbfeq, v, p, p0);
      for(int i=0; i<lbsy.nq; i++){
        pt1[i*qdim+j] =lbfeq[i];
      }
    }
  }
  pt1 = NULL;
  return 0;
}

int fD3Q15VCESwift(double *v, double * startpos, double * delpos, double dx, double dy, double dz, long tpos, double T)
{

  // produce fixed velocity at convex or concave corner for fluids with Swift free-energy interactions:
  // expressed for left-bottom-back corner (against velocity 7)

  double *pt1=startpos;
  double *pt2=delpos;
  double rho[lbsy.nf], feq[lbsy.nf*lbsy.nq];
  double p,p0,omega,lambda,pb,mu;
  int qdim=lbsy.nf+lbsy.nc+lbsy.nt;
    
  fGetAllMassSite(rho, &lbf[tpos*lbsitelength]);
  if(lbsy.nf>1) {
    p = rho[0] + dx*pt1[0] + dy*pt1[1] + dz*pt1[2];
    p0 = rho[1] + dx*pt1[4] + dy*pt1[5] + dz*pt1[6];
    omega = 0.5*(1.0+p0)*lbtf[0]+0.5*(1.0-p0)*lbtf[1];
    pb = fGetBulkPressureSwift(p, p0, T);
    mu = fGetPotentialSwift(p0, pt2[7]);
    lambda = fGetLambdaSwift(p, omega, T);
    fGetEquilibriumFSwiftTwoFluid(feq, v, p, p0, pb, mu, lambda, pt2);
    for(int i=0; i<lbsy.nq; i++){
      pt1[i*qdim  ] =feq[2*i  ];
      pt1[i*qdim+1] =feq[2*i+1];
    }
  }
  else {
    p = rho[0] + dx*pt1[0] + dy*pt1[1];
    pb = fGetBulkPressureSwift(p, 0.0, T);
    lambda = fGetLambdaSwift(p, lbtf[0], T);
    fGetEquilibriumFSwiftOneFluid(feq, v, p, pb, lambda, pt2);
    for(int i=0; i<lbsy.nq; i++){
      pt1[i*qdim] =lbfeq[i];
    }
  }
  pt1 = NULL;
  pt2 = NULL;
  return 0;
}

int fD3Q15VF(long tpos, int prop, double *uwall)
{
  long spos=tpos * lbsitelength;
  long rpos;
  int qdim = lbsy.nf+lbsy.nc+lbsy.nt;
  int a3;
  double T, c1=1.0/3.0;
    
  if(interact==5) {
    switch (prop) {
      case 22:
        uwall[0] = lbtopv[0]; uwall[1] = lbtopv[1]; uwall[2] = lbtopv[2];
        fD3Q15VPS(uwall[0], uwall[1], uwall[2], &lbf[spos], &lbf[spos+1*qdim],
                  &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim],
                  &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+8*qdim], &lbf[spos+9*qdim],
                  &lbf[spos+10*qdim], &lbf[spos+11*qdim], &lbf[spos+12*qdim], &lbf[spos+13*qdim],
                  &lbf[spos+14*qdim]);
        break;
      case 21:
        uwall[0] = lbbotv[0]; uwall[1] = lbbotv[1]; uwall[2] = lbbotv[2];
        fD3Q15VPS(uwall[0], -uwall[1], uwall[2], &lbf[spos], &lbf[spos+1*qdim],
                  &lbf[spos+9*qdim], &lbf[spos+3*qdim], &lbf[spos+6*qdim], &lbf[spos+7*qdim],
                  &lbf[spos+4*qdim], &lbf[spos+5*qdim], &lbf[spos+8*qdim], &lbf[spos+2*qdim],
                  &lbf[spos+10*qdim], &lbf[spos+13*qdim], &lbf[spos+14*qdim], &lbf[spos+11*qdim],
                  &lbf[spos+12*qdim]);
        break;
      case 23:
        uwall[0] = lbrigv[0]; uwall[1] = lbrigv[1]; uwall[2] = lbrigv[2];
        fD3Q15VPS(uwall[1], uwall[0], uwall[2], &lbf[spos], &lbf[spos+2*qdim],
                  &lbf[spos+1*qdim], &lbf[spos+3*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim],
                  &lbf[spos+14*qdim], &lbf[spos+13*qdim], &lbf[spos+9*qdim], &lbf[spos+8*qdim],
                  &lbf[spos+10*qdim], &lbf[spos+11*qdim], &lbf[spos+12*qdim], &lbf[spos+7*qdim],
                  &lbf[spos+6*qdim]);
        break;
      case 24:
        uwall[0] = lblefv[0]; uwall[1] = lblefv[1]; uwall[2] = lblefv[2];
        fD3Q15VPS(uwall[1], -uwall[0], uwall[2], &lbf[spos], &lbf[spos+2*qdim],
                  &lbf[spos+8*qdim], &lbf[spos+3*qdim], &lbf[spos+13*qdim], &lbf[spos+14*qdim],
                  &lbf[spos+4*qdim], &lbf[spos+5*qdim], &lbf[spos+9*qdim], &lbf[spos+1*qdim],
                  &lbf[spos+10*qdim], &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+11*qdim],
                  &lbf[spos+12*qdim]);
        break;
      case 25:
        uwall[0] = lbbacv[0]; uwall[1] = lbbacv[1]; uwall[2] = lbbacv[2];
        fD3Q15VPS(uwall[0], -uwall[2], uwall[1], &lbf[spos], &lbf[spos+1*qdim],
                  &lbf[spos+10*qdim], &lbf[spos+2*qdim], &lbf[spos+5*qdim], &lbf[spos+7*qdim],
                  &lbf[spos+4*qdim], &lbf[spos+6*qdim], &lbf[spos+8*qdim], &lbf[spos+3*qdim],
                  &lbf[spos+9*qdim], &lbf[spos+12*qdim], &lbf[spos+14*qdim], &lbf[spos+11*qdim],
                  &lbf[spos+13*qdim]);
        break;
      case 26:
        uwall[0] = lbfrov[0]; uwall[1] = lbfrov[1]; uwall[2] = lbfrov[2];
        fD3Q15VPS(uwall[0], uwall[2], uwall[1], &lbf[spos], &lbf[spos+1*qdim],
                  &lbf[spos+3*qdim], &lbf[spos+2*qdim], &lbf[spos+4*qdim], &lbf[spos+6*qdim],
                  &lbf[spos+5*qdim], &lbf[spos+7*qdim], &lbf[spos+8*qdim], &lbf[spos+10*qdim],
                  &lbf[spos+9*qdim], &lbf[spos+11*qdim], &lbf[spos+13*qdim], &lbf[spos+12*qdim],
                  &lbf[spos+14*qdim]);
        break;
      case 27:
        a3=lbphi[tpos]/100;
        rpos = fNextStep(1, 1, -1, tpos);
        if(a3==1 || a3==3 || a3==5 || a3==7)
          T = (lbsy.nt>0)?lbbott:lbsyst;
        else
          T = (lbsy.nt>0)?fGetTemperatureSite(rpos):lbsyst;
        uwall[0] = lbbotv[0]; uwall[1] = lbbotv[1]; uwall[2] = lbbotv[2];
        fD3Q15VCESwift(uwall, &lbf[spos], &lbft[4*lbsy.nf*tpos], -c1, -c1, c1, rpos, T);
        break;
      case 28:
        a3=lbphi[tpos]/100;
        rpos = fNextStep(-1, 1, -1, tpos);
        if(a3==1 || a3==3 || a3==5 || a3==7)
          T = (lbsy.nt>0)?lbbott:lbsyst;
        else
          T = (lbsy.nt>0)?fGetTemperatureSite(rpos):lbsyst;
        uwall[0] = lbbotv[0]; uwall[1] = lbbotv[1]; uwall[2] = lbbotv[2];
        fD3Q15VCESwift(uwall, &lbf[spos], &lbft[4*lbsy.nf*tpos], c1, -c1, c1, rpos, T);
        break;
      case 29:
        a3=lbphi[tpos]/100;
        rpos = fNextStep(-1, -1, -1, tpos);
        if(a3==1 || a3==3 || a3==5 || a3==7)
          T = (lbsy.nt>0)?lbtopt:lbsyst;
        else
          T = (lbsy.nt>0)?fGetTemperatureSite(rpos):lbsyst;
        uwall[0] = lbtopv[0]; uwall[1] = lbtopv[1]; uwall[2] = lbtopv[2];
        fD3Q15VCESwift(uwall, &lbf[spos], &lbft[4*lbsy.nf*tpos], c1, c1, c1, rpos, T);
        break;
      case 30:
        a3=lbphi[tpos]/100;
        rpos = fNextStep(1, -1, -1, tpos);
        if(a3==1 || a3==3 || a3==5 || a3==7)
          T = (lbsy.nt>0)?lbtopt:lbsyst;
        else
          T = (lbsy.nt>0)?fGetTemperatureSite(rpos):lbsyst;
        uwall[0] = lbtopv[0]; uwall[1] = lbtopv[1]; uwall[2] = lbtopv[2];
        fD3Q15VCESwift(uwall, &lbf[spos], &lbft[4*lbsy.nf*tpos], -c1, c1, c1, rpos, T);
        break;
      case 31:
        a3=lbphi[tpos]/100;
        rpos = fNextStep(1, 1, 1, tpos);
        if(a3==1 || a3==3 || a3==5 || a3==7)
          T = (lbsy.nt>0)?lbbott:lbsyst;
        else
          T = (lbsy.nt>0)?fGetTemperatureSite(rpos):lbsyst;
        uwall[0] = lbbotv[0]; uwall[1] = lbbotv[1]; uwall[2] = lbbotv[2];
        fD3Q15VCESwift(uwall, &lbf[spos], &lbft[4*lbsy.nf*tpos], -c1, -c1, -c1, rpos, T);
        break;
      case 32:
        a3=lbphi[tpos]/100;
        rpos = fNextStep(-1, 1, 1, tpos);
        if(a3==1 || a3==3 || a3==5 || a3==7)
          T = (lbsy.nt>0)?lbbott:lbsyst;
        else
          T = (lbsy.nt>0)?fGetTemperatureSite(rpos):lbsyst;
        uwall[0] = lbbotv[0]; uwall[1] = lbbotv[1]; uwall[2] = lbbotv[2];
        fD3Q15VCESwift(uwall, &lbf[spos], &lbft[4*lbsy.nf*tpos], c1, -c1, -c1, rpos, T);
        break;
      case 33:
        a3=lbphi[tpos]/100;
        rpos = fNextStep(-1, -1, 1, tpos);
        if(a3==1 || a3==3 || a3==5 || a3==7)
          T = (lbsy.nt>0)?lbtopt:lbsyst;
        else
          T = (lbsy.nt>0)?fGetTemperatureSite(rpos):lbsyst;
        uwall[0] = lbtopv[0]; uwall[1] = lbtopv[1]; uwall[2] = lbtopv[2];
        fD3Q15VCESwift(uwall, &lbf[spos], &lbft[4*lbsy.nf*tpos], c1, c1, -c1, rpos, T);
        break;
      case 34:
        a3=lbphi[tpos]/100;
        rpos = fNextStep(1, -1, 1, tpos);
        if(a3==1 || a3==3 || a3==5 || a3==7)
          T = (lbsy.nt>0)?lbtopt:lbsyst;
        else
          T = (lbsy.nt>0)?fGetTemperatureSite(rpos):lbsyst;
        uwall[0] = lbtopv[0]; uwall[1] = lbtopv[1]; uwall[2] = lbtopv[2];
        fD3Q15VCESwift(uwall, &lbf[spos], &lbft[4*lbsy.nf*tpos], -c1, c1, -c1, rpos, T);
        break;
      case 43:
        a3=lbphi[tpos]/100;
        rpos = fNextStep(1, 1, 0, tpos);
        if(a3==1 || a3==3 || a3==5 || a3==7)
          T = (lbsy.nt>0)?lbbott:lbsyst;
        else
          T = (lbsy.nt>0)?fGetTemperatureSite(rpos):lbsyst;
        uwall[0] = lbbotv[0]; uwall[1] = lbbotv[1]; uwall[2] = lbbotv[2];
        fD3Q15VCESwift(uwall, &lbf[spos], &lbft[4*lbsy.nf*tpos], -0.5, -0.5, 0.0, rpos, T);
        break;
      case 44:
        a3=lbphi[tpos]/100;
        rpos = fNextStep(-1, 1, 0, tpos);
        if(a3==1 || a3==3 || a3==5 || a3==7)
          T = (lbsy.nt>0)?lbbott:lbsyst;
        else
          T = (lbsy.nt>0)?fGetTemperatureSite(rpos):lbsyst;
        uwall[0] = lbbotv[0]; uwall[1] = lbbotv[1]; uwall[2] = lbbotv[2];
        fD3Q15VCESwift(uwall, &lbf[spos], &lbft[4*lbsy.nf*tpos], 0.5, -0.5, 0.0, rpos, T);
        break;
      case 45:
        a3=lbphi[tpos]/100;
        rpos = fNextStep(-1, -1, 0, tpos);
        if(a3==1 || a3==3 || a3==5 || a3==7)
          T = (lbsy.nt>0)?lbtopt:lbsyst;
        else
          T = (lbsy.nt>0)?fGetTemperatureSite(rpos):lbsyst;
        uwall[0] = lbtopv[0]; uwall[1] = lbtopv[1]; uwall[2] = lbtopv[2];
        fD3Q15VCESwift(uwall, &lbf[spos], &lbft[4*lbsy.nf*tpos], 0.5, 0.5, 0.0, rpos, T);
        break;
      case 46:
        a3=lbphi[tpos]/100;
        rpos = fNextStep(1, -1, 0, tpos);
        if(a3==1 || a3==3 || a3==5 || a3==7)
          T = (lbsy.nt>0)?lbtopt:lbsyst;
        else
          T = (lbsy.nt>0)?fGetTemperatureSite(rpos):lbsyst;
        uwall[0] = lbtopv[0]; uwall[1] = lbtopv[1]; uwall[2] = lbtopv[2];
        fD3Q15VCESwift(uwall, &lbf[spos], &lbft[4*lbsy.nf*tpos], -0.5, 0.5, 0.0, rpos, T);
        break;
      case 47:
        a3=lbphi[tpos]/100;
        rpos = fNextStep(0, 1, 1, tpos);
        if(a3==1 || a3==3 || a3==5 || a3==7)
          T = (lbsy.nt>0)?lbbott:lbsyst;
        else
          T = (lbsy.nt>0)?fGetTemperatureSite(rpos):lbsyst;
        uwall[0] = lbbotv[0]; uwall[1] = lbbotv[1]; uwall[2] = lbbotv[2];
        fD3Q15VCESwift(uwall, &lbf[spos], &lbft[4*lbsy.nf*tpos], 0.0, -0.5, -0.5, rpos, T);
        break;
      case 48:
        a3=lbphi[tpos]/100;
        rpos = fNextStep(-1, 0, 1, tpos);
        if(a3==1 || a3==3 || a3==5 || a3==7)
          T = (lbsy.nt>0)?lbrigt:lbsyst;
        else
          T = (lbsy.nt>0)?fGetTemperatureSite(rpos):lbsyst;
        uwall[0] = lbrigv[0]; uwall[1] = lbrigv[1]; uwall[2] = lbrigv[2];
        fD3Q15VCESwift(uwall, &lbf[spos], &lbft[4*lbsy.nf*tpos], 0.5, 0.0, -0.5, rpos, T);
        break;
      case 49:
        a3=lbphi[tpos]/100;
        rpos = fNextStep(0, -1, 1, tpos);
        if(a3==1 || a3==3 || a3==5 || a3==7)
          T = (lbsy.nt>0)?lbtopt:lbsyst;
        else
          T = (lbsy.nt>0)?fGetTemperatureSite(rpos):lbsyst;
        uwall[0] = lbtopv[0]; uwall[1] = lbtopv[1]; uwall[2] = lbtopv[2];
        fD3Q15VCESwift(uwall, &lbf[spos], &lbft[4*lbsy.nf*tpos], 0.0, 0.5, -0.5, rpos, T);
        break;
      case 50:
        a3=lbphi[tpos]/100;
        rpos = fNextStep(1, 0, 1, tpos);
        if(a3==1 || a3==3 || a3==5 || a3==7)
          T = (lbsy.nt>0)?lbleft:lbsyst;
        else
          T = (lbsy.nt>0)?fGetTemperatureSite(rpos):lbsyst;
        uwall[0] = lblefv[0]; uwall[1] = lblefv[1]; uwall[2] = lblefv[2];
        fD3Q15VCESwift(uwall, &lbf[spos], &lbft[4*lbsy.nf*tpos], -0.5, 0.0, -0.5, rpos, T);
        break;
      case 51:
        a3=lbphi[tpos]/100;
        rpos = fNextStep(0, 1, -1, tpos);
        if(a3==1 || a3==3 || a3==5 || a3==7)
          T = (lbsy.nt>0)?lbbott:lbsyst;
        else
          T = (lbsy.nt>0)?fGetTemperatureSite(rpos):lbsyst;
        uwall[0] = lbbotv[0]; uwall[1] = lbbotv[1]; uwall[2] = lbbotv[2];
        fD3Q15VCESwift(uwall, &lbf[spos], &lbft[4*lbsy.nf*tpos], 0.0, -0.5, 0.5, rpos, T);
        break;
      case 52:
        a3=lbphi[tpos]/100;
        rpos = fNextStep(-1, 0, -1, tpos);
        if(a3==1 || a3==3 || a3==5 || a3==7)
          T = (lbsy.nt>0)?lbrigt:lbsyst;
        else
          T = (lbsy.nt>0)?fGetTemperatureSite(rpos):lbsyst;
        uwall[0] = lbrigv[0]; uwall[1] = lbrigv[1]; uwall[2] = lbrigv[2];
        fD3Q15VCESwift(uwall, &lbf[spos], &lbft[4*lbsy.nf*tpos], 0.5, 0.0, 0.5, rpos, T);
        break;
      case 53:
        a3=lbphi[tpos]/100;
        rpos = fNextStep(0 ,-1, -1, tpos);
        if(a3==1 || a3==3 || a3==5 || a3==7)
          T = (lbsy.nt>0)?lbtopt:lbsyst;
        else
          T = (lbsy.nt>0)?fGetTemperatureSite(rpos):lbsyst;
        uwall[0] = lbtopv[0]; uwall[1] = lbtopv[1]; uwall[2] = lbtopv[2];
        fD3Q15VCESwift(uwall, &lbf[spos], &lbft[4*lbsy.nf*tpos], 0.0, 0.5, 0.5, rpos, T);
        break;
      case 54:
        a3=lbphi[tpos]/100;
        if(a3==1 || a3==3 || a3==5 || a3==7)
          T = (lbsy.nt>0)?lbleft:lbsyst;
        else
          T = (lbsy.nt>0)?fGetTemperatureSite(rpos):lbsyst;
        rpos = fNextStep(1, 0, -1, tpos);
        uwall[0] = lblefv[0]; uwall[1] = lblefv[1]; uwall[2] = lblefv[2];
        fD3Q15VCESwift(uwall, &lbf[spos], &lbft[4*lbsy.nf*tpos], -0.5, 0.0, 0.5, rpos, T);
        break;
    }
  }
  else {
    switch (prop) {
      case 22:
        uwall[0] = lbtopv[0]; uwall[1] = lbtopv[1]; uwall[2] = lbtopv[2];
        fD3Q15VPS(uwall[0], uwall[1], uwall[2], &lbf[spos], &lbf[spos+1*qdim],
                  &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim],
                  &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+8*qdim], &lbf[spos+9*qdim],
                  &lbf[spos+10*qdim], &lbf[spos+11*qdim], &lbf[spos+12*qdim], &lbf[spos+13*qdim],
                  &lbf[spos+14*qdim]);
        break;
      case 21:
        uwall[0] = lbbotv[0]; uwall[1] = lbbotv[1]; uwall[2] = lbbotv[2];
        fD3Q15VPS(uwall[0], -uwall[1], uwall[2], &lbf[spos], &lbf[spos+1*qdim],
                  &lbf[spos+9*qdim], &lbf[spos+3*qdim], &lbf[spos+6*qdim], &lbf[spos+7*qdim],
                  &lbf[spos+4*qdim], &lbf[spos+5*qdim], &lbf[spos+8*qdim], &lbf[spos+2*qdim],
                  &lbf[spos+10*qdim], &lbf[spos+13*qdim], &lbf[spos+14*qdim], &lbf[spos+11*qdim],
                  &lbf[spos+12*qdim]);
        break;
      case 23:
        uwall[0] = lbrigv[0]; uwall[1] = lbrigv[1]; uwall[2] = lbrigv[2];
        fD3Q15VPS(uwall[1], uwall[0], uwall[2], &lbf[spos], &lbf[spos+2*qdim],
                  &lbf[spos+1*qdim], &lbf[spos+3*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim],
                  &lbf[spos+14*qdim], &lbf[spos+13*qdim], &lbf[spos+9*qdim], &lbf[spos+8*qdim],
                  &lbf[spos+10*qdim], &lbf[spos+11*qdim], &lbf[spos+12*qdim], &lbf[spos+7*qdim],
                  &lbf[spos+6*qdim]);
        break;
      case 24:
        uwall[0] = lblefv[0]; uwall[1] = lblefv[1]; uwall[2] = lblefv[2];
        fD3Q15VPS(uwall[1], -uwall[0], uwall[2], &lbf[spos], &lbf[spos+2*qdim],
                  &lbf[spos+8*qdim], &lbf[spos+3*qdim], &lbf[spos+13*qdim], &lbf[spos+14*qdim],
                  &lbf[spos+4*qdim], &lbf[spos+5*qdim], &lbf[spos+9*qdim], &lbf[spos+1*qdim],
                  &lbf[spos+10*qdim], &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+11*qdim],
                  &lbf[spos+12*qdim]);
        break;
      case 25:
        uwall[0] = lbbacv[0]; uwall[1] = lbbacv[1]; uwall[2] = lbbacv[2];
        fD3Q15VPS(uwall[0], -uwall[2], uwall[1], &lbf[spos], &lbf[spos+1*qdim],
                  &lbf[spos+10*qdim], &lbf[spos+2*qdim], &lbf[spos+5*qdim], &lbf[spos+7*qdim],
                  &lbf[spos+4*qdim], &lbf[spos+6*qdim], &lbf[spos+8*qdim], &lbf[spos+3*qdim],
                  &lbf[spos+9*qdim], &lbf[spos+12*qdim], &lbf[spos+14*qdim], &lbf[spos+11*qdim],
                  &lbf[spos+13*qdim]);
        break;
      case 26:
        uwall[0] = lbfrov[0]; uwall[1] = lbfrov[1]; uwall[2] = lbfrov[2];
        fD3Q15VPS(uwall[0], uwall[2], uwall[1], &lbf[spos], &lbf[spos+1*qdim],
                  &lbf[spos+3*qdim], &lbf[spos+2*qdim], &lbf[spos+4*qdim], &lbf[spos+6*qdim],
                  &lbf[spos+5*qdim], &lbf[spos+7*qdim], &lbf[spos+8*qdim], &lbf[spos+10*qdim],
                  &lbf[spos+9*qdim], &lbf[spos+11*qdim], &lbf[spos+13*qdim], &lbf[spos+12*qdim],
                  &lbf[spos+14*qdim]);
        break;
      case 27:
        rpos = fNextStep(1, 1, -1, tpos);
        uwall[0] = lbbotv[0]; uwall[1] = lbbotv[1]; uwall[2] = lbbotv[2];
        fD3Q15VCE(uwall, &lbf[spos], rpos);
        break;
      case 28:
        rpos = fNextStep(-1, 1, -1, tpos);
        uwall[0] = lbbotv[0]; uwall[1] = lbbotv[1]; uwall[2] = lbbotv[2];
        fD3Q15VCE(uwall, &lbf[spos], rpos);
        break;
      case 29:
        rpos = fNextStep(-1, -1, -1, tpos);
        uwall[0] = lbtopv[0]; uwall[1] = lbtopv[1]; uwall[2] = lbtopv[2];
        fD3Q15VCE(uwall, &lbf[spos], rpos);
        break;
      case 30:
        rpos = fNextStep(1, -1, -1, tpos);
        uwall[0] = lbtopv[0]; uwall[1] = lbtopv[1]; uwall[2] = lbtopv[2];
        fD3Q15VCE(uwall, &lbf[spos], rpos);
        break;
      case 31:
        rpos = fNextStep(1, 1, 1, tpos);
        uwall[0] = lbbotv[0]; uwall[1] = lbbotv[1]; uwall[2] = lbbotv[2];
        fD3Q15VCE(uwall, &lbf[spos], rpos);
        break;
      case 32:
        rpos = fNextStep(-1, 1, 1, tpos);
        uwall[0] = lbbotv[0]; uwall[1] = lbbotv[1]; uwall[2] = lbbotv[2];
        fD3Q15VCE(uwall, &lbf[spos], rpos);
        break;
      case 33:
        rpos = fNextStep(-1, -1, 1, tpos);
        uwall[0] = lbtopv[0]; uwall[1] = lbtopv[1]; uwall[2] = lbtopv[2];
        fD3Q15VCE(uwall, &lbf[spos], rpos);
        break;
      case 34:
        rpos = fNextStep(1, -1, 1, tpos);
        uwall[0] = lbtopv[0]; uwall[1] = lbtopv[1]; uwall[2] = lbtopv[2];
        fD3Q15VCE(uwall, &lbf[spos], rpos);
        break;
      case 43:
        rpos = fNextStep(1, 1, 0, tpos);
        uwall[0] = lbbotv[0]; uwall[1] = lbbotv[1]; uwall[2] = lbbotv[2];
        fD3Q15VCE(uwall, &lbf[spos], rpos);
        break;
      case 44:
        rpos = fNextStep(-1, 1, 0, tpos);
        uwall[0] = lbbotv[0]; uwall[1] = lbbotv[1]; uwall[2] = lbbotv[2];
        fD3Q15VCE(uwall, &lbf[spos], rpos);
        break;
      case 45:
        rpos = fNextStep(-1, -1, 0, tpos);
        uwall[0] = lbtopv[0]; uwall[1] = lbtopv[1]; uwall[2] = lbtopv[2];
        fD3Q15VCE(uwall, &lbf[spos], rpos);
        break;
      case 46:
        rpos = fNextStep(1, -1, 0, tpos);
        uwall[0] = lbtopv[0]; uwall[1] = lbtopv[1]; uwall[2] = lbtopv[2];
        fD3Q15VCE(uwall, &lbf[spos], rpos);
        break;
      case 47:
        rpos = fNextStep(0, 1, 1, tpos);
        uwall[0] = lbbotv[0]; uwall[1] = lbbotv[1]; uwall[2] = lbbotv[2];
        fD3Q15VCE(uwall, &lbf[spos], rpos);
        break;
      case 48:
        rpos = fNextStep(-1, 0, 1, tpos);
        uwall[0] = lbrigv[0]; uwall[1] = lbrigv[1]; uwall[2] = lbrigv[2];
        fD3Q15VCE(uwall, &lbf[spos], rpos);
        break;
      case 49:
        rpos = fNextStep(0, -1, 1, tpos);
        uwall[0] = lbtopv[0]; uwall[1] = lbtopv[1]; uwall[2] = lbtopv[2];
        fD3Q15VCE(uwall, &lbf[spos], rpos);
        break;
      case 50:
        rpos = fNextStep(1, 0, 1, tpos);
        uwall[0] = lblefv[0]; uwall[1] = lblefv[1]; uwall[2] = lblefv[2];
        fD3Q15VCE(uwall, &lbf[spos], rpos);
        break;
      case 51:
        rpos = fNextStep(0, 1, -1, tpos);
        uwall[0] = lbbotv[0]; uwall[1] = lbbotv[1]; uwall[2] = lbbotv[2];
        fD3Q15VCE(uwall, &lbf[spos], rpos);
        break;
      case 52:
        rpos = fNextStep(-1, 0, -1, tpos);
        uwall[0] = lbrigv[0]; uwall[1] = lbrigv[1]; uwall[2] = lbrigv[2];
        fD3Q15VCE(uwall, &lbf[spos], rpos);
        break;
      case 53:
        rpos = fNextStep(0 ,-1, -1, tpos);
        uwall[0] = lbtopv[0]; uwall[1] = lbtopv[1]; uwall[2] = lbtopv[2];
        fD3Q15VCE(uwall, &lbf[spos], rpos);
        break;
      case 54:
        rpos = fNextStep(1, 0, -1, tpos);
        uwall[0] = lblefv[0]; uwall[1] = lblefv[1]; uwall[2] = lblefv[2];
        fD3Q15VCE(uwall, &lbf[spos], rpos);
        break;
    }
  }
  return 0;
  
}

int fD3Q15PPS(double *p, double *f0, double *f1,
	      double *f2, double *f3, double *f4, double *f5,
	      double *f6, double *f7, double *f8, double *f9,
	      double *f10, double *f11, double *f12, double *f13,
	      double *f14, double &vel)
{

  // produce fixed pressure/density at planar surface: expressed for top wall

  double rx, rz, v;
  double c1=2.0/3.0,c2=1.0/12.0;
  double mass=0.0;
  vel=0.0;
  if(!incompress) {
    for(int i=0; i<lbsy.nf; i++) {
      v=(f0[i]+f1[i]+f3[i]+f8[i]+f10[i]+2.0*(f6[i]+f7[i]+f9[i]+f11[i]+f12[i]))-p[i];
      vel += v;
      mass += p[i];
      rx=0.25*(f8[i]-f1[i]);
      rz=0.25*(f10[i]-f3[i]);
      f2[i]=f9[i]-c1*v;
      f4[i]=f11[i]-c2*v+rx+rz;
      f5[i]=f12[i]-c2*v+rx-rz;
      f13[i]=f6[i]-c2*v-rx-rz;
      f14[i]=f7[i]-c2*v-rx+rz;
    }
  }
  else {
    for(int i=0; i<lbsy.nf; i++) {
      v=(f0[i]+f1[i]+f3[i]+f8[i]+f10[i]+2.0*(f6[i]+f7[i]+f9[i]+f11[i]+f12[i]))-p[i];
      vel += v;
      mass += lbincp[i];
      rx=0.25*(f8[i]-f1[i]);
      rz=0.25*(f10[i]-f3[i]);
      f2[i]=f9[i]-c1*v;
      f4[i]=f11[i]-c2*v+rx+rz;
      f5[i]=f12[i]-c2*v+rx-rz;
      f13[i]=f6[i]-c2*v-rx-rz;
      f14[i]=f7[i]-c2*v-rx+rz;
    }
  }
  vel *= fReciprocal(mass);
    
  return 0;
}

int fD3Q15PPSSwift(double *p, double *f0, double *f1,
	      double *f2, double *f3, double *f4, double *f5,
	      double *f6, double *f7, double *f8, double *f9,
	      double *f10, double *f11, double *f12, double *f13,
	      double *f14, double &vel)
{

  // produce fixed pressure/density at planar surface: expressed for top wall
  // with Swift free-energy interactions

  double rx, rz, v;
  double c1=2.0/3.0,c2=1.0/12.0,c3=1.0/3.0;
  double mass=0.0;
  vel=0.0;

  v=(f0[0]+f1[0]+f3[0]+f8[0]+f10[0]+2.0*(f6[0]+f7[0]+f9[0]+f11[0]+f12[0]))-p[0];
  vel += v;
  mass += p[0];
  rx=0.25*(f8[0]-f1[0]);
  rz=0.25*(f10[0]-f3[0]);
  f2[0]=f9[0]-c1*v;
  f4[0]=f11[0]-c2*v+rx+rz;
  f5[0]=f12[0]-c2*v+rx-rz;
  f13[0]=f6[0]-c2*v-rx-rz;
  f14[0]=f7[0]-c2*v-rx+rz;
  vel *= fReciprocal(mass);
  if(lbsy.nf>1) {
    f2[1]=p[1]*(1.0+c3*vel)-f0[1]-f1[1]-f3[1]-f8[1]-f9[1]-f10[1]-2.0*(f6[1]+f7[1]+f11[1]+f12[1]);
    f4[1]=f11[1]-c2*p[1]*vel;
    f5[1]=f12[1]-c2*p[1]*vel;
    f13[1]=f6[1]-c2*p[1]*vel;
    f14[1]=f7[1]-c2*p[1]*vel;
  }
    
  return 0;
}


int fD3Q15PCE(double *p, double *v, double * startpos)
{

  // produce fixed pressure/density at convex or concave corner for compressible/incompressible fluids

  double *pt1=startpos;
  int qdim=lbsy.nf+lbsy.nc+lbsy.nt;
    
  if(!incompress) {
    for(int j=0; j<lbsy.nf; j++) {
      fGetEquilibriumF(lbfeq, v, p[j]);
      for(int i=0; i<lbsy.nq; i++){
        pt1[i*qdim+j] =lbfeq[i];
      }
    }
  }
  else {
    for(int j=0; j<lbsy.nf; j++) {
      fGetEquilibriumFIncom(lbfeq, v, p[j], lbincp[j]);
      for(int i=0; i<lbsy.nq; i++){
        pt1[i*qdim+j] =lbfeq[i];
      }
    }
  }
  pt1 = NULL;
  return 0;
}

int fD3Q15PCESwift(double *p, double *v, double * startpos, double * delpos, double T)
{

  // produce fixed pressure/density at convex or concave corner for fluids
  // with Swift free-energy interactions

  double *pt1=startpos;
  double *pt2=delpos;
  double feq[lbsy.nf*lbsy.nq];
  double omega,lambda,pb,mu;
  int qdim=lbsy.nf+lbsy.nc+lbsy.nt;
    
  if(lbsy.nf>1) {
    omega = 0.5*(1.0+p[1])*lbtf[0]+0.5*(1.0-p[1])*lbtf[1];
    pb = fGetBulkPressureSwift(p[0], p[1], T);
    mu = fGetPotentialSwift(p[1], pt2[7]);
    lambda = fGetLambdaSwift(p[0], omega, T);
    fGetEquilibriumFSwiftTwoFluid(feq, v, p[0], p[1], pb, mu, lambda, pt2);
    for(int i=0; i<lbsy.nq; i++){
      pt1[i*qdim  ] =feq[i];
      pt1[i*qdim+1] =feq[i+lbsy.nq];
    }
  }
  else {
    pb = fGetBulkPressureSwift(p[0], 0.0, T);
    lambda = fGetLambdaSwift(p[0], lbtf[0], T);
    fGetEquilibriumFSwiftOneFluid(feq, v, p[0], pb, lambda, pt2);
    for(int i=0; i<lbsy.nq; i++){
      pt1[i*qdim] =lbfeq[i];
    }
  }
  pt1 = NULL;
  pt2 = NULL;
  return 0;
}

int fD3Q15PF(long tpos, int prop, double *uwall)
{
  double moment, T;
  long rpos,spos=tpos * lbsitelength;
  int qdim = lbsy.nf+lbsy.nc+lbsy.nt;
  int a3;
  uwall[0]=0.0; uwall[1]=0.0; uwall[2]=0.0;

  if(interact==5) {
    switch (prop) {
      case 22:
        fD3Q15PPSSwift(lbtopp, &lbf[spos], &lbf[spos+1*qdim],
                  &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim],
                  &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+8*qdim], &lbf[spos+9*qdim],
                  &lbf[spos+10*qdim], &lbf[spos+11*qdim], &lbf[spos+12*qdim], &lbf[spos+13*qdim],
                  &lbf[spos+14*qdim], moment);
        uwall[1] += moment;
        break;
      case 21:
        fD3Q15PPSSwift(lbbotp, &lbf[spos], &lbf[spos+1*qdim],
                    &lbf[spos+9*qdim], &lbf[spos+3*qdim], &lbf[spos+6*qdim], &lbf[spos+7*qdim],
                    &lbf[spos+4*qdim], &lbf[spos+5*qdim], &lbf[spos+8*qdim], &lbf[spos+2*qdim],
                    &lbf[spos+10*qdim], &lbf[spos+13*qdim], &lbf[spos+14*qdim], &lbf[spos+11*qdim],
                    &lbf[spos+12*qdim], moment);
        uwall[1] -= moment;
        break;
      case 23:
        fD3Q15PPSSwift(lbrigp, &lbf[spos], &lbf[spos+2*qdim],
                    &lbf[spos+1*qdim], &lbf[spos+3*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim],
                    &lbf[spos+14*qdim], &lbf[spos+13*qdim], &lbf[spos+9*qdim], &lbf[spos+8*qdim],
                    &lbf[spos+10*qdim], &lbf[spos+11*qdim], &lbf[spos+12*qdim], &lbf[spos+7*qdim],
                    &lbf[spos+6*qdim], moment);
        uwall[0] += moment;
        break;
      case 24:
        fD3Q15PPSSwift(lblefp, &lbf[spos], &lbf[spos+2*qdim],
                    &lbf[spos+8*qdim], &lbf[spos+3*qdim], &lbf[spos+13*qdim], &lbf[spos+14*qdim],
                    &lbf[spos+4*qdim], &lbf[spos+5*qdim], &lbf[spos+9*qdim], &lbf[spos+1*qdim],
                    &lbf[spos+10*qdim], &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+11*qdim],
                    &lbf[spos+12*qdim], moment);
        uwall[1] -= moment;
        break;
      case 25:
        fD3Q15PPSSwift(lbbacp, &lbf[spos], &lbf[spos+1*qdim],
                    &lbf[spos+10*qdim], &lbf[spos+2*qdim], &lbf[spos+5*qdim], &lbf[spos+7*qdim],
                    &lbf[spos+4*qdim], &lbf[spos+6*qdim], &lbf[spos+8*qdim], &lbf[spos+3*qdim],
                    &lbf[spos+9*qdim], &lbf[spos+12*qdim], &lbf[spos+14*qdim], &lbf[spos+11*qdim],
                    &lbf[spos+13*qdim], moment);
        uwall[2] -= moment;
        break;
      case 26:
        fD3Q15PPSSwift(lbfrop, &lbf[spos], &lbf[spos+1*qdim],
                    &lbf[spos+3*qdim], &lbf[spos+2*qdim], &lbf[spos+4*qdim], &lbf[spos+6*qdim],
                    &lbf[spos+5*qdim], &lbf[spos+7*qdim], &lbf[spos+8*qdim], &lbf[spos+10*qdim],
                    &lbf[spos+9*qdim], &lbf[spos+11*qdim], &lbf[spos+13*qdim], &lbf[spos+12*qdim],
                    &lbf[spos+14*qdim], moment);
        uwall[2] += moment;
        break;
      case 27:
        a3=lbphi[tpos]/100;
        rpos = fNextStep(1, 1, -1, tpos);
        if(a3==1 || a3==3 || a3==5 || a3==7)
          T = (lbsy.nt>0)?lbleft:lbsyst;
        else
          T = (lbsy.nt>0)?fGetTemperatureSite(rpos):lbsyst;
        fD3Q15PCESwift(lblefp, uwall, &lbf[spos], &lbft[4*lbsy.nf*spos], T);
        break;
      case 28:
        a3=lbphi[tpos]/100;
        rpos = fNextStep(-1, 1, -1, tpos);
        if(a3==1 || a3==3 || a3==5 || a3==7)
          T = (lbsy.nt>0)?lbrigt:lbsyst;
        else
          T = (lbsy.nt>0)?fGetTemperatureSite(rpos):lbsyst;
        fD3Q15PCESwift(lbrigp, uwall, &lbf[spos], &lbft[4*lbsy.nf*spos], T);
        break;
      case 29:
        a3=lbphi[tpos]/100;
        rpos = fNextStep(-1, -1, -1, tpos);
        if(a3==1 || a3==3 || a3==5 || a3==7)
          T = (lbsy.nt>0)?lbrigt:lbsyst;
        else
          T = (lbsy.nt>0)?fGetTemperatureSite(rpos):lbsyst;
        fD3Q15PCESwift(lbrigp, uwall, &lbf[spos], &lbft[4*lbsy.nf*spos], T);
        break;
      case 30:
        a3=lbphi[tpos]/100;
        rpos = fNextStep(1, -1, -1, tpos);
        if(a3==1 || a3==3 || a3==5 || a3==7)
          T = (lbsy.nt>0)?lbleft:lbsyst;
        else
          T = (lbsy.nt>0)?fGetTemperatureSite(rpos):lbsyst;
        fD3Q15PCESwift(lblefp, uwall, &lbf[spos], &lbft[4*lbsy.nf*spos], T);
        break;
      case 31:
        a3=lbphi[tpos]/100;
        rpos = fNextStep(1, 1, 1, tpos);
        if(a3==1 || a3==3 || a3==5 || a3==7)
          T = (lbsy.nt>0)?lbleft:lbsyst;
        else
          T = (lbsy.nt>0)?fGetTemperatureSite(rpos):lbsyst;
        fD3Q15PCESwift(lblefp, uwall, &lbf[spos], &lbft[4*lbsy.nf*spos], T);
        break;
      case 32:
        a3=lbphi[tpos]/100;
        rpos = fNextStep(-1, 1, 1, tpos);
        if(a3==1 || a3==3 || a3==5 || a3==7)
          T = (lbsy.nt>0)?lbrigt:lbsyst;
        else
          T = (lbsy.nt>0)?fGetTemperatureSite(rpos):lbsyst;
        fD3Q15PCESwift(lbrigp, uwall, &lbf[spos], &lbft[4*lbsy.nf*spos], T);
        break;
      case 33:
        a3=lbphi[tpos]/100;
        rpos = fNextStep(-1, -1, 1, tpos);
        if(a3==1 || a3==3 || a3==5 || a3==7)
          T = (lbsy.nt>0)?lbrigt:lbsyst;
        else
          T = (lbsy.nt>0)?fGetTemperatureSite(rpos):lbsyst;
        fD3Q15PCESwift(lbrigp, uwall, &lbf[spos], &lbft[4*lbsy.nf*spos], T);
        break;
      case 34:
        a3=lbphi[tpos]/100;
        rpos = fNextStep(1, -1, 1, tpos);
        if(a3==1 || a3==3 || a3==5 || a3==7)
          T = (lbsy.nt>0)?lbleft:lbsyst;
        else
          T = (lbsy.nt>0)?fGetTemperatureSite(rpos):lbsyst;
        fD3Q15PCESwift(lblefp, uwall, &lbf[spos], &lbft[4*lbsy.nf*spos], T);
        break;
      case 43:
        a3=lbphi[tpos]/100;
        rpos = fNextStep(1, 1, 0, tpos);
        if(a3==1 || a3==3 || a3==5 || a3==7)
          T = (lbsy.nt>0)?lbleft:lbsyst;
        else
          T = (lbsy.nt>0)?fGetTemperatureSite(rpos):lbsyst;
        fD3Q15PCESwift(lblefp, uwall, &lbf[spos], &lbft[4*lbsy.nf*spos], T);
        break;
      case 44:
        a3=lbphi[tpos]/100;
        rpos = fNextStep(-1, 1, 0, tpos);
        if(a3==1 || a3==3 || a3==5 || a3==7)
          T = (lbsy.nt>0)?lbrigt:lbsyst;
        else
          T = (lbsy.nt>0)?fGetTemperatureSite(rpos):lbsyst;
        fD3Q15PCESwift(lbrigp, uwall, &lbf[spos], &lbft[4*lbsy.nf*spos], T);
        break;
      case 45:
        a3=lbphi[tpos]/100;
        rpos = fNextStep(-1, -1, 0, tpos);
        if(a3==1 || a3==3 || a3==5 || a3==7)
          T = (lbsy.nt>0)?lbrigt:lbsyst;
        else
          T = (lbsy.nt>0)?fGetTemperatureSite(rpos):lbsyst;
        fD3Q15PCESwift(lbrigp, uwall, &lbf[spos], &lbft[4*lbsy.nf*spos], T);
        break;
      case 46:
        a3=lbphi[tpos]/100;
        rpos = fNextStep(1, -1, 0, tpos);
        if(a3==1 || a3==3 || a3==5 || a3==7)
          T = (lbsy.nt>0)?lbleft:lbsyst;
        else
          T = (lbsy.nt>0)?fGetTemperatureSite(rpos):lbsyst;
        fD3Q15PCESwift(lblefp, uwall, &lbf[spos], &lbft[4*lbsy.nf*spos], T);
        break;
      case 47:
        a3=lbphi[tpos]/100;
        rpos = fNextStep(0, 1, 1, tpos);
        if(a3==1 || a3==3 || a3==5 || a3==7)
          T = (lbsy.nt>0)?lbbott:lbsyst;
        else
          T = (lbsy.nt>0)?fGetTemperatureSite(rpos):lbsyst;
        fD3Q15PCESwift(lbbotp, uwall, &lbf[spos], &lbft[4*lbsy.nf*spos], T);
        break;
      case 48:
        a3=lbphi[tpos]/100;
        rpos = fNextStep(-1, 0, 1, tpos);
        if(a3==1 || a3==3 || a3==5 || a3==7)
          T = (lbsy.nt>0)?lbrigt:lbsyst;
        else
          T = (lbsy.nt>0)?fGetTemperatureSite(rpos):lbsyst;
        fD3Q15PCESwift(lbrigp, uwall, &lbf[spos], &lbft[4*lbsy.nf*spos], T);
        break;
      case 49:
        a3=lbphi[tpos]/100;
        rpos = fNextStep(0, -1, 1, tpos);
        if(a3==1 || a3==3 || a3==5 || a3==7)
          T = (lbsy.nt>0)?lbtopt:lbsyst;
        else
          T = (lbsy.nt>0)?fGetTemperatureSite(rpos):lbsyst;
        fD3Q15PCESwift(lbtopp, uwall, &lbf[spos], &lbft[4*lbsy.nf*spos], T);
        break;
      case 50:
        a3=lbphi[tpos]/100;
        rpos = fNextStep(1, 0, 1, tpos);
        if(a3==1 || a3==3 || a3==5 || a3==7)
          T = (lbsy.nt>0)?lbleft:lbsyst;
        else
          T = (lbsy.nt>0)?fGetTemperatureSite(rpos):lbsyst;
        fD3Q15PCESwift(lblefp, uwall, &lbf[spos], &lbft[4*lbsy.nf*spos], T);
        break;
      case 51:
        a3=lbphi[tpos]/100;
        rpos = fNextStep(0, 1, -1, tpos);
        if(a3==1 || a3==3 || a3==5 || a3==7)
          T = (lbsy.nt>0)?lbbott:lbsyst;
        else
          T = (lbsy.nt>0)?fGetTemperatureSite(rpos):lbsyst;
        fD3Q15PCESwift(lbbotp, uwall, &lbf[spos], &lbft[4*lbsy.nf*spos], T);
        break;
      case 52:
        a3=lbphi[tpos]/100;
        rpos = fNextStep(-1, 0, -1, tpos);
        if(a3==1 || a3==3 || a3==5 || a3==7)
          T = (lbsy.nt>0)?lbrigt:lbsyst;
        else
          T = (lbsy.nt>0)?fGetTemperatureSite(rpos):lbsyst;
        fD3Q15PCESwift(lbrigp, uwall, &lbf[spos], &lbft[4*lbsy.nf*spos], T);
        break;
      case 53:
        a3=lbphi[tpos]/100;
        rpos = fNextStep(0, -1, -1, tpos);
        if(a3==1 || a3==3 || a3==5 || a3==7)
          T = (lbsy.nt>0)?lbtopt:lbsyst;
        else
          T = (lbsy.nt>0)?fGetTemperatureSite(rpos):lbsyst;
        fD3Q15PCESwift(lbtopp, uwall, &lbf[spos], &lbft[4*lbsy.nf*spos], T);
        break;
      case 54:
        a3=lbphi[tpos]/100;
        rpos = fNextStep(1, 0, -1, tpos);
        if(a3==1 || a3==3 || a3==5 || a3==7)
          T = (lbsy.nt>0)?lbleft:lbsyst;
        else
          T = (lbsy.nt>0)?fGetTemperatureSite(rpos):lbsyst;
        fD3Q15PCESwift(lblefp, uwall, &lbf[spos], &lbft[4*lbsy.nf*spos], T);
        break;
    }
  }
  else {
    switch (prop) {
      case 22:
        fD3Q15PPS(lbtopp, &lbf[spos], &lbf[spos+1*qdim],
                  &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim],
                  &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+8*qdim], &lbf[spos+9*qdim],
                  &lbf[spos+10*qdim], &lbf[spos+11*qdim], &lbf[spos+12*qdim], &lbf[spos+13*qdim],
                  &lbf[spos+14*qdim], moment);
        uwall[1] += moment;
        break;
      case 21:
        fD3Q15PPS(lbbotp, &lbf[spos], &lbf[spos+1*qdim],
                    &lbf[spos+9*qdim], &lbf[spos+3*qdim], &lbf[spos+6*qdim], &lbf[spos+7*qdim],
                    &lbf[spos+4*qdim], &lbf[spos+5*qdim], &lbf[spos+8*qdim], &lbf[spos+2*qdim],
                    &lbf[spos+10*qdim], &lbf[spos+13*qdim], &lbf[spos+14*qdim], &lbf[spos+11*qdim],
                    &lbf[spos+12*qdim], moment);
        uwall[1] -= moment;
        break;
      case 23:
        fD3Q15PPS(lbrigp, &lbf[spos], &lbf[spos+2*qdim],
                    &lbf[spos+1*qdim], &lbf[spos+3*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim],
                    &lbf[spos+14*qdim], &lbf[spos+13*qdim], &lbf[spos+9*qdim], &lbf[spos+8*qdim],
                    &lbf[spos+10*qdim], &lbf[spos+11*qdim], &lbf[spos+12*qdim], &lbf[spos+7*qdim],
                    &lbf[spos+6*qdim], moment);
        uwall[0] += moment;
        break;
      case 24:
        fD3Q15PPS(lblefp, &lbf[spos], &lbf[spos+2*qdim],
                    &lbf[spos+8*qdim], &lbf[spos+3*qdim], &lbf[spos+13*qdim], &lbf[spos+14*qdim],
                    &lbf[spos+4*qdim], &lbf[spos+5*qdim], &lbf[spos+9*qdim], &lbf[spos+1*qdim],
                    &lbf[spos+10*qdim], &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+11*qdim],
                    &lbf[spos+12*qdim], moment);
        uwall[1] -= moment;
        break;
      case 25:
        fD3Q15PPS(lbbacp, &lbf[spos], &lbf[spos+1*qdim],
                    &lbf[spos+10*qdim], &lbf[spos+2*qdim], &lbf[spos+5*qdim], &lbf[spos+7*qdim],
                    &lbf[spos+4*qdim], &lbf[spos+6*qdim], &lbf[spos+8*qdim], &lbf[spos+3*qdim],
                    &lbf[spos+9*qdim], &lbf[spos+12*qdim], &lbf[spos+14*qdim], &lbf[spos+11*qdim],
                    &lbf[spos+13*qdim], moment);
        uwall[2] -= moment;
        break;
      case 26:
        fD3Q15PPS(lbfrop, &lbf[spos], &lbf[spos+1*qdim],
                    &lbf[spos+3*qdim], &lbf[spos+2*qdim], &lbf[spos+4*qdim], &lbf[spos+6*qdim],
                    &lbf[spos+5*qdim], &lbf[spos+7*qdim], &lbf[spos+8*qdim], &lbf[spos+10*qdim],
                    &lbf[spos+9*qdim], &lbf[spos+11*qdim], &lbf[spos+13*qdim], &lbf[spos+12*qdim],
                    &lbf[spos+14*qdim], moment);
        uwall[2] += moment;
        break;
      case 27:
        fD3Q15PCE(lblefp, uwall, &lbf[spos]);
        break;
      case 28:
        fD3Q15PCE(lbrigp, uwall, &lbf[spos]);
        break;
      case 29:
        fD3Q15PCE(lbrigp, uwall, &lbf[spos]);
        break;
      case 30:
        fD3Q15PCE(lblefp, uwall, &lbf[spos]);
        break;
      case 31:
        fD3Q15PCE(lblefp, uwall, &lbf[spos]);
        break;
      case 32:
        fD3Q15PCE(lbrigp, uwall, &lbf[spos]);
        break;
      case 33:
        fD3Q15PCE(lbrigp, uwall, &lbf[spos]);
        break;
      case 34:
        fD3Q15PCE(lblefp, uwall, &lbf[spos]);
        break;
      case 43:
        fD3Q15PCE(lblefp, uwall, &lbf[spos]);
        break;
      case 44:
        fD3Q15PCE(lbrigp, uwall, &lbf[spos]);
        break;
      case 45:
        fD3Q15PCE(lbrigp, uwall, &lbf[spos]);
        break;
      case 46:
        fD3Q15PCE(lblefp, uwall, &lbf[spos]);
        break;
      case 47:
        fD3Q15PCE(lbbotp, uwall, &lbf[spos]);
        break;
      case 48:
        fD3Q15PCE(lbrigp, uwall, &lbf[spos]);
        break;
      case 49:
        fD3Q15PCE(lbtopp, uwall, &lbf[spos]);
        break;
      case 50:
        fD3Q15PCE(lblefp, uwall, &lbf[spos]);
        break;
      case 51:
        fD3Q15PCE(lbbotp, uwall, &lbf[spos]);
        break;
      case 52:
        fD3Q15PCE(lbrigp, uwall, &lbf[spos]);
        break;
      case 53:
        fD3Q15PCE(lbtopp, uwall, &lbf[spos]);
        break;
      case 54:
        fD3Q15PCE(lblefp, uwall, &lbf[spos]);
        break;
    }
  }
  return 0;
}


int fD3Q15CPS(double *p, double v0, double v1, double v2, double *f0, double *f1,
	          double *f2, double *f3, double *f4, double *f5, double *f6,
              double *f7, double *f8, double *f9, double *f10, double *f11,
              double *f12, double *f13, double *f14)
{

  // produce fixed concentration at planar surface: expressed for top wall

  double rho;
  double c1=1.0/9.0,c2=1.0/72.0;

  for(int i=0; i<lbsy.nc; i++) {
    rho=6.0*(p[i]-f0[i]-f1[i]-f3[i]-f6[i]-f7[i]-f8[i]-f9[i]-f10[i]-f11[i]-f12[i])/(1.0-3.0*v1);
    f2[i]=c1*rho*(1.0-3.0*v1);
    f4[i]=c2*rho*(1.0-3.0*v0-3.0*v1-3.0*v2);
    f5[i]=c2*rho*(1.0-3.0*v0-3.0*v1+3.0*v2);
    f13[i]=c2*rho*(1.0+3.0*v0-3.0*v1+3.0*v2);
    f14[i]=c2*rho*(1.0+3.0*v0-3.0*v1-3.0*v2);
  }
  
  return 0;
}


int fD3Q15CCE(double *p, double *v, double * startpos)
{

  // produce fixed solute concentration at convex or concave corner:
  // expressed for left-bottom-back corner (against velocity 7)

  double *pt1=startpos;
  int qdim = lbsy.nf+lbsy.nc+lbsy.nt;

  for(int j=0; j<lbsy.nc; j++) {
    fGetEquilibriumC(lbfeq, v, p[j]);
    for(int i=0; i<lbsy.nq; i++){
      pt1[i*qdim+j] =lbfeq[i];
    }
  }
  pt1 = NULL;
  return 0;
}

int fD3Q15PC(long tpos, int prop, double *uwall)
{
  long spos=tpos * lbsitelength + lbsy.nf;
  int qdim=lbsy.nf+lbsy.nc+lbsy.nt;
    
  if(lbsy.nc>0) {
    switch (prop) {
      case 22:
        fD3Q15CPS(lbtopc, uwall[0], uwall[1], uwall[2], &lbf[spos], &lbf[spos+1*qdim],
		          &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim], &lbf[spos+6*qdim],
                  &lbf[spos+7*qdim], &lbf[spos+8*qdim], &lbf[spos+9*qdim], &lbf[spos+10*qdim], &lbf[spos+11*qdim],
                  &lbf[spos+12*qdim], &lbf[spos+13*qdim], &lbf[spos+14*qdim]);
        break;
      case 21:
        fD3Q15CPS(lbbotc, uwall[0], -uwall[1], uwall[2], &lbf[spos], &lbf[spos+1*qdim],
  	  	          &lbf[spos+9*qdim], &lbf[spos+3*qdim], &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+4*qdim],
                  &lbf[spos+5*qdim], &lbf[spos+8*qdim], &lbf[spos+2*qdim], &lbf[spos+10*qdim], &lbf[spos+13*qdim],
                  &lbf[spos+14*qdim], &lbf[spos+11*qdim], &lbf[spos+12*qdim]);
        break;
      case 23:
        fD3Q15CPS(lbrigc, uwall[1], uwall[0], uwall[2], &lbf[spos], &lbf[spos+2*qdim],
		          &lbf[spos+1*qdim], &lbf[spos+3*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim], &lbf[spos+14*qdim],
                  &lbf[spos+13*qdim], &lbf[spos+9*qdim], &lbf[spos+8*qdim], &lbf[spos+10*qdim], &lbf[spos+11*qdim],
                  &lbf[spos+12*qdim], &lbf[spos+7*qdim], &lbf[spos+6*qdim]);
        break;
      case 24:
        fD3Q15CPS(lblefc, uwall[1], -uwall[0], uwall[2], &lbf[spos], &lbf[spos+2*qdim],
		          &lbf[spos+8*qdim], &lbf[spos+3*qdim], &lbf[spos+13*qdim], &lbf[spos+14*qdim], &lbf[spos+4*qdim],
                  &lbf[spos+5*qdim], &lbf[spos+9*qdim], &lbf[spos+1*qdim], &lbf[spos+10*qdim], &lbf[spos+6*qdim],
                  &lbf[spos+7*qdim], &lbf[spos+11*qdim], &lbf[spos+12*qdim]);
        break;
      case 25:
        fD3Q15CPS(lbbacc, uwall[0], -uwall[2], uwall[1], &lbf[spos], &lbf[spos+1*qdim],
		          &lbf[spos+10*qdim], &lbf[spos+2*qdim], &lbf[spos+5*qdim], &lbf[spos+7*qdim], &lbf[spos+4*qdim],
                  &lbf[spos+6*qdim], &lbf[spos+8*qdim], &lbf[spos+3*qdim], &lbf[spos+9*qdim], &lbf[spos+12*qdim],
                  &lbf[spos+14*qdim], &lbf[spos+11*qdim], &lbf[spos+13*qdim]);
        break;
      case 26:
        fD3Q15CPS(lbfroc, uwall[0], uwall[2], uwall[1], &lbf[spos], &lbf[spos+1*qdim],
		          &lbf[spos+3*qdim], &lbf[spos+2*qdim], &lbf[spos+4*qdim], &lbf[spos+6*qdim], &lbf[spos+5*qdim],
                  &lbf[spos+7*qdim], &lbf[spos+8*qdim], &lbf[spos+10*qdim], &lbf[spos+9*qdim], &lbf[spos+11*qdim],
                  &lbf[spos+13*qdim], &lbf[spos+12*qdim], &lbf[spos+14*qdim]);
        break;
      case 27:
        fD3Q15CCE(lbbotc, uwall, &lbf[spos]);
        break;
      case 28:
        fD3Q15CCE(lbbotc, uwall, &lbf[spos]);
        break;
      case 29:
        fD3Q15CCE(lbtopc, uwall, &lbf[spos]);
        break;
      case 30:
        fD3Q15CCE(lbtopc, uwall, &lbf[spos]);
        break;
      case 31:
        fD3Q15CCE(lbbotc, uwall, &lbf[spos]);
        break;
      case 32:
        fD3Q15CCE(lbbotc, uwall, &lbf[spos]);
        break;
      case 33:
        fD3Q15CCE(lbtopc, uwall, &lbf[spos]);
        break;
      case 34:
        fD3Q15CCE(lbtopc, uwall, &lbf[spos]);
        break;
      case 43:
        fD3Q15CCE(lbbotc, uwall, &lbf[spos]);
        break;
      case 44:
        fD3Q15CCE(lbbotc, uwall, &lbf[spos]);
        break;
      case 45:
        fD3Q15CCE(lbtopc, uwall, &lbf[spos]);
        break;
      case 46:
        fD3Q15CCE(lbtopc, uwall, &lbf[spos]);
        break;
      case 47:
        fD3Q15CCE(lbbotc, uwall, &lbf[spos]);
        break;
      case 48:
        fD3Q15CCE(lbrigc, uwall, &lbf[spos]);
        break;
      case 49:
        fD3Q15CCE(lbtopc, uwall, &lbf[spos]);
        break;
      case 50:
        fD3Q15CCE(lblefc, uwall, &lbf[spos]);
        break;
      case 51:
        fD3Q15CCE(lbbotc, uwall, &lbf[spos]);
        break;
      case 52:
        fD3Q15CCE(lbrigc, uwall, &lbf[spos]);
        break;
      case 53:
        fD3Q15CCE(lbtopc, uwall, &lbf[spos]);
        break;
      case 54:
        fD3Q15CCE(lblefc, uwall, &lbf[spos]);
        break;
    }
  }
  return 0;  
}


int fD3Q15TPS(double p, double v0, double v1, double v2, double *f0, double *f1,
	          double *f2, double *f3, double *f4, double *f5, double *f6,
              double *f7, double *f8, double *f9, double *f10, double *f11,
              double *f12, double *f13, double *f14)
{

  // produce fixed concentration at planar surface: expressed for top wall

  double rho;
  double c1=1.0/9.0,c2=1.0/72.0;

  rho=6.0*(p-f0[0]-f1[0]-f3[0]-f6[0]-f7[0]-f8[0]-f9[0]-f10[0]-f11[0]-f12[0])/(1.0-3.0*v1);
  f2[0]=c1*rho*(1.0-3.0*v1);
  f4[0]=c2*rho*(1.0-3.0*v0-3.0*v1-3.0*v2);
  f5[0]=c2*rho*(1.0-3.0*v0-3.0*v1+3.0*v2);
  f13[0]=c2*rho*(1.0+3.0*v0-3.0*v1+3.0*v2);
  f14[0]=c2*rho*(1.0+3.0*v0-3.0*v1-3.0*v2);
  
  return 0;
}


int fD3Q15TCE(double p, double *v, double * startpos)
{

  // produce fixed temperature at convex or concave corner:
  // expressed for left-bottom-back corner (against velocity 7)

  double *pt1=startpos;
  int qdim = lbsy.nf+lbsy.nc+lbsy.nt;

  fGetEquilibriumT(lbfeq, v, p);
  for(int i=0; i<lbsy.nq; i++){
    pt1[i*qdim] =lbfeq[i];
  }
  pt1 = NULL;
  return 0;
}

int fD3Q15PT(long tpos, int prop, double *uwall)
{
  long spos=tpos * lbsitelength + lbsy.nf + lbsy.nc;
  int qdim = lbsy.nf+lbsy.nc+lbsy.nt;
    
  if(lbsy.nt == 1) {
    switch (prop) {
      case 22:
        fD3Q15TPS(lbtopt, uwall[0], uwall[1], uwall[2], &lbf[spos], &lbf[spos+1*qdim],
		          &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim], &lbf[spos+6*qdim],
                  &lbf[spos+7*qdim], &lbf[spos+8*qdim], &lbf[spos+9*qdim], &lbf[spos+10*qdim], &lbf[spos+11*qdim],
                  &lbf[spos+12*qdim], &lbf[spos+13*qdim], &lbf[spos+14*qdim]);
        break;
      case 21:
        fD3Q15TPS(lbbott, uwall[0], -uwall[1], uwall[2], &lbf[spos], &lbf[spos+1*qdim],
  	  	          &lbf[spos+9*qdim], &lbf[spos+3*qdim], &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+4*qdim],
                  &lbf[spos+5*qdim], &lbf[spos+8*qdim], &lbf[spos+2*qdim], &lbf[spos+10*qdim], &lbf[spos+13*qdim],
                  &lbf[spos+14*qdim], &lbf[spos+11*qdim], &lbf[spos+12*qdim]);
        break;
      case 23:
        fD3Q15TPS(lbrigt, uwall[1], uwall[0], uwall[2], &lbf[spos], &lbf[spos+2*qdim],
		          &lbf[spos+1*qdim], &lbf[spos+3*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim], &lbf[spos+14*qdim],
                  &lbf[spos+13*qdim], &lbf[spos+9*qdim], &lbf[spos+8*qdim], &lbf[spos+10*qdim], &lbf[spos+11*qdim],
                  &lbf[spos+12*qdim], &lbf[spos+7*qdim], &lbf[spos+6*qdim]);
        break;
      case 24:
        fD3Q15TPS(lbleft, uwall[1], -uwall[0], uwall[2], &lbf[spos], &lbf[spos+2*qdim],
		          &lbf[spos+8*qdim], &lbf[spos+3*qdim], &lbf[spos+13*qdim], &lbf[spos+14*qdim], &lbf[spos+4*qdim],
                  &lbf[spos+5*qdim], &lbf[spos+9*qdim], &lbf[spos+1*qdim], &lbf[spos+10*qdim], &lbf[spos+6*qdim],
                  &lbf[spos+7*qdim], &lbf[spos+11*qdim], &lbf[spos+12*qdim]);
        break;
      case 25:
        fD3Q15TPS(lbbact, uwall[0], -uwall[2], uwall[1], &lbf[spos], &lbf[spos+1*qdim],
		          &lbf[spos+10*qdim], &lbf[spos+2*qdim], &lbf[spos+5*qdim], &lbf[spos+7*qdim], &lbf[spos+4*qdim],
                  &lbf[spos+6*qdim], &lbf[spos+8*qdim], &lbf[spos+3*qdim], &lbf[spos+9*qdim], &lbf[spos+12*qdim],
                  &lbf[spos+14*qdim], &lbf[spos+11*qdim], &lbf[spos+13*qdim]);
        break;
      case 26:
        fD3Q15TPS(lbfrot, uwall[0], uwall[2], uwall[1], &lbf[spos], &lbf[spos+1*qdim],
		          &lbf[spos+3*qdim], &lbf[spos+2*qdim], &lbf[spos+4*qdim], &lbf[spos+6*qdim], &lbf[spos+5*qdim],
                  &lbf[spos+7*qdim], &lbf[spos+8*qdim], &lbf[spos+10*qdim], &lbf[spos+9*qdim], &lbf[spos+11*qdim],
                  &lbf[spos+13*qdim], &lbf[spos+12*qdim], &lbf[spos+14*qdim]);
        break;
      case 27:
        fD3Q15TCE(lbbott, uwall, &lbf[spos]);
        break;
      case 28:
        fD3Q15TCE(lbbott, uwall, &lbf[spos]);
        break;
      case 29:
        fD3Q15TCE(lbtopt, uwall, &lbf[spos]);
        break;
      case 30:
        fD3Q15TCE(lbtopt, uwall, &lbf[spos]);
        break;
      case 31:
        fD3Q15TCE(lbbott, uwall, &lbf[spos]);
        break;
      case 32:
        fD3Q15TCE(lbbott, uwall, &lbf[spos]);
        break;
      case 33:
        fD3Q15TCE(lbtopt, uwall, &lbf[spos]);
        break;
      case 34:
        fD3Q15TCE(lbtopt, uwall, &lbf[spos]);
        break;
      case 43:
        fD3Q15TCE(lbbott, uwall, &lbf[spos]);
        break;
      case 44:
        fD3Q15TCE(lbbott, uwall, &lbf[spos]);
        break;
      case 45:
        fD3Q15TCE(lbtopt, uwall, &lbf[spos]);
        break;
      case 46:
        fD3Q15TCE(lbtopt, uwall, &lbf[spos]);
        break;
      case 47:
        fD3Q15TCE(lbbott, uwall, &lbf[spos]);
        break;
      case 48:
        fD3Q15TCE(lbrigt, uwall, &lbf[spos]);
        break;
      case 49:
        fD3Q15TCE(lbtopt, uwall, &lbf[spos]);
        break;
      case 50:
        fD3Q15TCE(lbleft, uwall, &lbf[spos]);
        break;
      case 51:
        fD3Q15TCE(lbbott, uwall, &lbf[spos]);
        break;
      case 52:
        fD3Q15TCE(lbrigt, uwall, &lbf[spos]);
        break;
      case 53:
        fD3Q15TCE(lbtopt, uwall, &lbf[spos]);
        break;
      case 54:
        fD3Q15TCE(lbleft, uwall, &lbf[spos]);
        break;
    }
  }
  return 0;  
}


// D3Q19

int fD3Q19VPS(double v0, double v1, double v2, double *f0, double *f1, double *f2,
              double *f3, double *f4, double *f5, double *f6, double *f7, double *f8,
              double *f9, double *f10, double *f11, double *f12, double *f13, double *f14,
              double *f15, double *f16, double *f17, double *f18)
{

  // produce fixed velocity for compressible/incompressible fluids at planar surface boundary:
  // expressed for top wall
  
  double rho, n1, n2;
  double c1=1.0/3.0, c2=1.0/6.0;
  if(!incompress) {
    for(int i=0; i<lbsy.nf; i++) {
      rho=(f0[i]+f1[i]+f3[i]+f6[i]+f7[i]+f10[i]+f12[i]+f15[i]+f16[i]+2.0*(f5[i]+f11[i]+f13[i]+f17[i]+f18[i]))/(1.0+v1);
      n1=0.5*(f10[i]-f1[i]-f6[i]-f7[i]+f15[i]+f16[i])-c1*rho*v0;
      n2=0.5*(f12[i]-f3[i]-f6[i]+f7[i]+f15[i]-f16[i])-c1*rho*v2;
      f2[i]=f11[i]-c1*rho*v1;
      f4[i]=f13[i]-c2*rho*(v0+v1)+n1;
      f8[i]=f17[i]-c2*rho*(v1+v2)+n2;
      f9[i]=f18[i]-c2*rho*(v1-v2)-n2;
      f14[i]=f5[i]+c2*rho*(v0-v1)-n1;
    }
  }
  else {
    for(int i=0; i<lbsy.nf; i++) {
//     double rho=f0+f1+f3+f6+f7+f10+f12+f15+f16+2.0*(f5+f11+f13+f17+f18)-rho0*v1;
      double rho0=lbincp[i];
      n1=0.5*(f10[i]-f1[i]-f6[i]-f7[i]+f15[i]+f16[i])-c1*rho0*v0;
      n2=0.5*(f12[i]-f3[i]-f6[i]+f7[i]+f15[i]-f16[i])-c1*rho0*v2;
      f2[i]=f11[i]-c1*rho0*v1;
      f4[i]=f13[i]-c2*rho0*(v0+v1)+n1;
      f8[i]=f17[i]-c2*rho0*(v1+v2)+n2;
      f9[i]=f18[i]-c2*rho0*(v1-v2)-n2;
      f14[i]=f5[i]+c2*rho0*(v0-v1)-n1;
    }
  }
  return 0;
}

int fD3Q19VCE(double *v, double * startpos, long tpos)
{

  // produce fixed velocity at convex or concave corner for compressible/incompressible fluids

  double *pt1=startpos;
  double rho[lbsy.nf];
  double p,p0;
  int qdim=lbsy.nf+lbsy.nc+lbsy.nt;
  fGetAllMassSite(rho, &lbf[tpos*lbsitelength]);
  if(!incompress) {
    for(int j=0; j<lbsy.nf; j++) {
      p = fEvapLimit(rho[j]);
      fGetEquilibriumF(lbfeq, v, p);
      for(int i=0; i<lbsy.nq; i++){
        pt1[i*qdim+j] =lbfeq[i];
      }
    }
  }
  else {
    for(int j=0; j<lbsy.nf; j++) {
      p = fEvapLimit(rho[j]);
      p0 = lbincp[j];
      fGetEquilibriumFIncom(lbfeq, v, p, p0);
      for(int i=0; i<lbsy.nq; i++){
        pt1[i*qdim+j] =lbfeq[i];
      }
    }
  }
  pt1 = NULL;
  return 0;
}

int fD3Q19VCESwift(double *v, double * startpos, double * delpos, double dx, double dy, double dz, long tpos, double T)
{

  // produce fixed velocity at convex or concave corner for fluids with Swift free-energy interactions

  double *pt1=startpos;
  double *pt2=delpos;
  double rho[lbsy.nf], feq[lbsy.nf*lbsy.nq];
  double p,p0,omega,lambda,pb,mu;
  int qdim=lbsy.nf+lbsy.nc+lbsy.nt;
    
  fGetAllMassSite(rho, &lbf[tpos*lbsitelength]);
  if(lbsy.nf>1) {
    p = rho[0] + dx*pt1[0] + dy*pt1[1] + dz*pt1[2];
    p0 = rho[1] + dx*pt1[4] + dy*pt1[5] + dz*pt1[6];
    omega = 0.5*(1.0+p0)*lbtf[0]+0.5*(1.0-p0)*lbtf[1];
    pb = fGetBulkPressureSwift(p, p0, T);
    mu = fGetPotentialSwift(p0, pt2[7]);
    lambda = fGetLambdaSwift(p, omega, T);
    fGetEquilibriumFSwiftTwoFluid(feq, v, p, p0, pb, mu, lambda, pt2);
    for(int i=0; i<lbsy.nq; i++){
      pt1[i*qdim  ] =feq[2*i  ];
      pt1[i*qdim+1] =feq[2*i+1];
    }
  }
  else {
    p = rho[0] + dx*pt1[0] + dy*pt1[1];
    pb = fGetBulkPressureSwift(p, 0.0, T);
    lambda = fGetLambdaSwift(p, lbtf[0], T);
    fGetEquilibriumFSwiftOneFluid(feq, v, p, pb, lambda, pt2);
    for(int i=0; i<lbsy.nq; i++){
      pt1[i*qdim] =lbfeq[i];
    }
  }
  pt1 = NULL;
  pt2 = NULL;
  return 0;
}

int fD3Q19VF(long tpos, int prop, double *uwall)
{
  long spos=tpos * lbsitelength;
  long rpos;
  int qdim=lbsy.nf+lbsy.nc+lbsy.nt;
  int a3;
  double T, c1=1.0/3.0;
    
  if(interact==5) {
    switch (prop) {
      case 22:
        uwall[0] = lbtopv[0]; uwall[1] = lbtopv[1]; uwall[2] = lbtopv[2];
        fD3Q19VPS(uwall[0], uwall[1], uwall[2], &lbf[spos], &lbf[spos+1*qdim],
                  &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim],
                  &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+8*qdim], &lbf[spos+9*qdim],
                  &lbf[spos+10*qdim], &lbf[spos+11*qdim], &lbf[spos+12*qdim], &lbf[spos+13*qdim],
                  &lbf[spos+14*qdim], &lbf[spos+15*qdim], &lbf[spos+16*qdim], &lbf[spos+17*qdim],
                  &lbf[spos+18*qdim]);
        break;
      case 21:
        uwall[0] = lbbotv[0]; uwall[1] = lbbotv[1]; uwall[2] = lbbotv[2];
        fD3Q19VPS(-uwall[0], -uwall[1], uwall[2], &lbf[spos], &lbf[spos+10*qdim],
                  &lbf[spos+11*qdim], &lbf[spos+3*qdim], &lbf[spos+13*qdim], &lbf[spos+14*qdim],
                  &lbf[spos+16*qdim], &lbf[spos+15*qdim], &lbf[spos+18*qdim], &lbf[spos+17*qdim],
                  &lbf[spos+1*qdim], &lbf[spos+2*qdim], &lbf[spos+12*qdim], &lbf[spos+4*qdim],
                  &lbf[spos+5*qdim], &lbf[spos+7*qdim], &lbf[spos+6*qdim], &lbf[spos+9*qdim],
                  &lbf[spos+8*qdim]);
        break;
      case 23:
        uwall[0] = lbrigv[0]; uwall[1] = lbrigv[1]; uwall[2] = lbrigv[2];
        fD3Q19VPS(-uwall[1], uwall[0], uwall[2], &lbf[spos], &lbf[spos+11*qdim],
                  &lbf[spos+1*qdim], &lbf[spos+3*qdim], &lbf[spos+5*qdim], &lbf[spos+13*qdim],
                  &lbf[spos+18*qdim], &lbf[spos+17*qdim], &lbf[spos+6*qdim], &lbf[spos+7*qdim],
                  &lbf[spos+2*qdim], &lbf[spos+10*qdim], &lbf[spos+12*qdim], &lbf[spos+14*qdim],
                  &lbf[spos+4*qdim], &lbf[spos+9*qdim], &lbf[spos+8*qdim], &lbf[spos+15*qdim],
                  &lbf[spos+16*qdim]);
        break;
      case 24:
        uwall[0] = lblefv[0]; uwall[1] = lblefv[1]; uwall[2] = lblefv[2];
        fD3Q19VPS(uwall[1], -uwall[0], uwall[2], &lbf[spos], &lbf[spos+2*qdim],
                  &lbf[spos+10*qdim], &lbf[spos+3*qdim], &lbf[spos+14*qdim], &lbf[spos+4*qdim],
                  &lbf[spos+8*qdim], &lbf[spos+9*qdim], &lbf[spos+16*qdim], &lbf[spos+15*qdim],
                  &lbf[spos+11*qdim], &lbf[spos+1*qdim], &lbf[spos+12*qdim], &lbf[spos+5*qdim],
                  &lbf[spos+13*qdim], &lbf[spos+17*qdim], &lbf[spos+18*qdim], &lbf[spos+7*qdim],
                  &lbf[spos+6*qdim]);
        break;
      case 25:
        uwall[0] = lbbacv[0]; uwall[1] = lbbacv[1]; uwall[2] = lbbacv[2];
        fD3Q19VPS(uwall[0], -uwall[2], uwall[1], &lbf[spos], &lbf[spos+1*qdim],
                  &lbf[spos+12*qdim], &lbf[spos+2*qdim], &lbf[spos+7*qdim], &lbf[spos+6*qdim],
                  &lbf[spos+4*qdim], &lbf[spos+5*qdim], &lbf[spos+9*qdim], &lbf[spos+17*qdim],
                  &lbf[spos+10*qdim], &lbf[spos+3*qdim], &lbf[spos+11*qdim], &lbf[spos+16*qdim],
                  &lbf[spos+15*qdim], &lbf[spos+13*qdim], &lbf[spos+14*qdim], &lbf[spos+18*qdim],
                  &lbf[spos+8*qdim]);
        break;
      case 26:
        uwall[0] = lbfrov[0]; uwall[1] = lbfrov[1]; uwall[2] = lbfrov[2];
        fD3Q19VPS(uwall[0], uwall[2], -uwall[1], &lbf[spos], &lbf[spos+1*qdim],
                  &lbf[spos+3*qdim], &lbf[spos+11*qdim], &lbf[spos+6*qdim], &lbf[spos+7*qdim],
                  &lbf[spos+5*qdim], &lbf[spos+4*qdim], &lbf[spos+18*qdim], &lbf[spos+8*qdim],
                  &lbf[spos+10*qdim], &lbf[spos+12*qdim], &lbf[spos+2*qdim], &lbf[spos+15*qdim],
                  &lbf[spos+16*qdim], &lbf[spos+14*qdim], &lbf[spos+13*qdim], &lbf[spos+9*qdim],
                  &lbf[spos+17*qdim]);
        break;
      case 27:
        a3=lbphi[tpos]/100;
        rpos = fNextStep(1, 1, -1, tpos);
        if(a3==1 || a3==3 || a3==5 || a3==7)
          T = (lbsy.nt>0)?lbbott:lbsyst;
        else
          T = (lbsy.nt>0)?fGetTemperatureSite(rpos):lbsyst;
        uwall[0] = lbbotv[0]; uwall[1] = lbbotv[1]; uwall[2] = lbbotv[2];
        fD3Q19VCESwift(uwall, &lbf[spos], &lbft[4*lbsy.nf*tpos], -c1, -c1, c1, rpos, T);
        break;
      case 28:
        a3=lbphi[tpos]/100;
        rpos = fNextStep(-1, 1, -1, tpos);
        if(a3==1 || a3==3 || a3==5 || a3==7)
          T = (lbsy.nt>0)?lbbott:lbsyst;
        else
          T = (lbsy.nt>0)?fGetTemperatureSite(rpos):lbsyst;
        uwall[0] = lbbotv[0]; uwall[1] = lbbotv[1]; uwall[2] = lbbotv[2];
        fD3Q19VCESwift(uwall, &lbf[spos], &lbft[4*lbsy.nf*tpos], c1, -c1, c1, rpos, T);
        break;
      case 29:
        a3=lbphi[tpos]/100;
        rpos = fNextStep(-1, -1, -1, tpos);
        if(a3==1 || a3==3 || a3==5 || a3==7)
          T = (lbsy.nt>0)?lbtopt:lbsyst;
        else
          T = (lbsy.nt>0)?fGetTemperatureSite(rpos):lbsyst;
        uwall[0] = lbtopv[0]; uwall[1] = lbtopv[1]; uwall[2] = lbtopv[2];
        fD3Q19VCESwift(uwall, &lbf[spos], &lbft[4*lbsy.nf*tpos], c1, c1, c1, rpos, T);
        break;
      case 30:
        a3=lbphi[tpos]/100;
        rpos = fNextStep(1, -1, -1, tpos);
        if(a3==1 || a3==3 || a3==5 || a3==7)
          T = (lbsy.nt>0)?lbtopt:lbsyst;
        else
          T = (lbsy.nt>0)?fGetTemperatureSite(rpos):lbsyst;
        uwall[0] = lbtopv[0]; uwall[1] = lbtopv[1]; uwall[2] = lbtopv[2];
        fD3Q19VCESwift(uwall, &lbf[spos], &lbft[4*lbsy.nf*tpos], -c1, c1, c1, rpos, T);
        break;
      case 31:
        a3=lbphi[tpos]/100;
        rpos = fNextStep(1, 1, 1, tpos);
        if(a3==1 || a3==3 || a3==5 || a3==7)
          T = (lbsy.nt>0)?lbbott:lbsyst;
        else
          T = (lbsy.nt>0)?fGetTemperatureSite(rpos):lbsyst;
        uwall[0] = lbbotv[0]; uwall[1] = lbbotv[1]; uwall[2] = lbbotv[2];
        fD3Q19VCESwift(uwall, &lbf[spos], &lbft[4*lbsy.nf*tpos], -c1, -c1, -c1, rpos, T);
        break;
      case 32:
        a3=lbphi[tpos]/100;
        rpos = fNextStep(-1, 1, 1, tpos);
        if(a3==1 || a3==3 || a3==5 || a3==7)
          T = (lbsy.nt>0)?lbbott:lbsyst;
        else
          T = (lbsy.nt>0)?fGetTemperatureSite(rpos):lbsyst;
        uwall[0] = lbbotv[0]; uwall[1] = lbbotv[1]; uwall[2] = lbbotv[2];
        fD3Q19VCESwift(uwall, &lbf[spos], &lbft[4*lbsy.nf*tpos], c1, -c1, -c1, rpos, T);
        break;
      case 33:
        a3=lbphi[tpos]/100;
        rpos = fNextStep(-1, -1, 1, tpos);
        if(a3==1 || a3==3 || a3==5 || a3==7)
          T = (lbsy.nt>0)?lbtopt:lbsyst;
        else
          T = (lbsy.nt>0)?fGetTemperatureSite(rpos):lbsyst;
        uwall[0] = lbtopv[0]; uwall[1] = lbtopv[1]; uwall[2] = lbtopv[2];
        fD3Q19VCESwift(uwall, &lbf[spos], &lbft[4*lbsy.nf*tpos], c1, c1, -c1, rpos, T);
        break;
      case 34:
        a3=lbphi[tpos]/100;
        rpos = fNextStep(1, -1, 1, tpos);
        if(a3==1 || a3==3 || a3==5 || a3==7)
          T = (lbsy.nt>0)?lbtopt:lbsyst;
        else
          T = (lbsy.nt>0)?fGetTemperatureSite(rpos):lbsyst;
        uwall[0] = lbtopv[0]; uwall[1] = lbtopv[1]; uwall[2] = lbtopv[2];
        fD3Q19VCESwift(uwall, &lbf[spos], &lbft[4*lbsy.nf*tpos], -c1, c1, -c1, rpos, T);
        break;
      case 43:
        a3=lbphi[tpos]/100;
        rpos = fNextStep(1, 1, 0, tpos);
        if(a3==1 || a3==3 || a3==5 || a3==7)
          T = (lbsy.nt>0)?lbbott:lbsyst;
        else
          T = (lbsy.nt>0)?fGetTemperatureSite(rpos):lbsyst;
        uwall[0] = lbbotv[0]; uwall[1] = lbbotv[1]; uwall[2] = lbbotv[2];
        fD3Q19VCESwift(uwall, &lbf[spos], &lbft[4*lbsy.nf*tpos], -0.5, -0.5, 0.0, rpos, T);
        break;
      case 44:
        a3=lbphi[tpos]/100;
        rpos = fNextStep(-1, 1, 0, tpos);
        if(a3==1 || a3==3 || a3==5 || a3==7)
          T = (lbsy.nt>0)?lbbott:lbsyst;
        else
          T = (lbsy.nt>0)?fGetTemperatureSite(rpos):lbsyst;
        uwall[0] = lbbotv[0]; uwall[1] = lbbotv[1]; uwall[2] = lbbotv[2];
        fD3Q19VCESwift(uwall, &lbf[spos], &lbft[4*lbsy.nf*tpos], 0.5, -0.5, 0.0, rpos, T);
        break;
      case 45:
        a3=lbphi[tpos]/100;
        rpos = fNextStep(-1, -1, 0, tpos);
        if(a3==1 || a3==3 || a3==5 || a3==7)
          T = (lbsy.nt>0)?lbtopt:lbsyst;
        else
          T = (lbsy.nt>0)?fGetTemperatureSite(rpos):lbsyst;
        uwall[0] = lbtopv[0]; uwall[1] = lbtopv[1]; uwall[2] = lbtopv[2];
        fD3Q19VCESwift(uwall, &lbf[spos], &lbft[4*lbsy.nf*tpos], 0.5, 0.5, 0.0, rpos, T);
        break;
      case 46:
        a3=lbphi[tpos]/100;
        rpos = fNextStep(1, -1, 0, tpos);
        if(a3==1 || a3==3 || a3==5 || a3==7)
          T = (lbsy.nt>0)?lbtopt:lbsyst;
        else
          T = (lbsy.nt>0)?fGetTemperatureSite(rpos):lbsyst;
        uwall[0] = lbtopv[0]; uwall[1] = lbtopv[1]; uwall[2] = lbtopv[2];
        fD3Q19VCESwift(uwall, &lbf[spos], &lbft[4*lbsy.nf*tpos], -0.5, 0.5, 0.0, rpos, T);
        break;
      case 47:
        a3=lbphi[tpos]/100;
        rpos = fNextStep(0, 1, 1, tpos);
        if(a3==1 || a3==3 || a3==5 || a3==7)
          T = (lbsy.nt>0)?lbbott:lbsyst;
        else
          T = (lbsy.nt>0)?fGetTemperatureSite(rpos):lbsyst;
        uwall[0] = lbbotv[0]; uwall[1] = lbbotv[1]; uwall[2] = lbbotv[2];
        fD3Q19VCESwift(uwall, &lbf[spos], &lbft[4*lbsy.nf*tpos], 0.0, -0.5, -0.5, rpos, T);
        break;
      case 48:
        a3=lbphi[tpos]/100;
        rpos = fNextStep(-1, 0, 1, tpos);
        if(a3==1 || a3==3 || a3==5 || a3==7)
          T = (lbsy.nt>0)?lbrigt:lbsyst;
        else
          T = (lbsy.nt>0)?fGetTemperatureSite(rpos):lbsyst;
        uwall[0] = lbrigv[0]; uwall[1] = lbrigv[1]; uwall[2] = lbrigv[2];
        fD3Q19VCESwift(uwall, &lbf[spos], &lbft[4*lbsy.nf*tpos], 0.5, 0.0, -0.5, rpos, T);
        break;
      case 49:
        a3=lbphi[tpos]/100;
        rpos = fNextStep(0, -1, 1, tpos);
        if(a3==1 || a3==3 || a3==5 || a3==7)
          T = (lbsy.nt>0)?lbtopt:lbsyst;
        else
          T = (lbsy.nt>0)?fGetTemperatureSite(rpos):lbsyst;
        uwall[0] = lbtopv[0]; uwall[1] = lbtopv[1]; uwall[2] = lbtopv[2];
        fD3Q19VCESwift(uwall, &lbf[spos], &lbft[4*lbsy.nf*tpos], 0.0, 0.5, -0.5, rpos, T);
        break;
      case 50:
        a3=lbphi[tpos]/100;
        rpos = fNextStep(1, 0, 1, tpos);
        if(a3==1 || a3==3 || a3==5 || a3==7)
          T = (lbsy.nt>0)?lbleft:lbsyst;
        else
          T = (lbsy.nt>0)?fGetTemperatureSite(rpos):lbsyst;
        uwall[0] = lblefv[0]; uwall[1] = lblefv[1]; uwall[2] = lblefv[2];
        fD3Q19VCESwift(uwall, &lbf[spos], &lbft[4*lbsy.nf*tpos], -0.5, 0.0, -0.5, rpos, T);
        break;
      case 51:
        a3=lbphi[tpos]/100;
        rpos = fNextStep(0, 1, -1, tpos);
        if(a3==1 || a3==3 || a3==5 || a3==7)
          T = (lbsy.nt>0)?lbbott:lbsyst;
        else
          T = (lbsy.nt>0)?fGetTemperatureSite(rpos):lbsyst;
        uwall[0] = lbbotv[0]; uwall[1] = lbbotv[1]; uwall[2] = lbbotv[2];
        fD3Q19VCESwift(uwall, &lbf[spos], &lbft[4*lbsy.nf*tpos], 0.0, -0.5, 0.5, rpos, T);
        break;
      case 52:
        a3=lbphi[tpos]/100;
        rpos = fNextStep(-1, 0, -1, tpos);
        if(a3==1 || a3==3 || a3==5 || a3==7)
          T = (lbsy.nt>0)?lbrigt:lbsyst;
        else
          T = (lbsy.nt>0)?fGetTemperatureSite(rpos):lbsyst;
        uwall[0] = lbrigv[0]; uwall[1] = lbrigv[1]; uwall[2] = lbrigv[2];
        fD3Q19VCESwift(uwall, &lbf[spos], &lbft[4*lbsy.nf*tpos], 0.5, 0.0, 0.5, rpos, T);
        break;
      case 53:
        a3=lbphi[tpos]/100;
        rpos = fNextStep(0 ,-1, -1, tpos);
        if(a3==1 || a3==3 || a3==5 || a3==7)
          T = (lbsy.nt>0)?lbtopt:lbsyst;
        else
          T = (lbsy.nt>0)?fGetTemperatureSite(rpos):lbsyst;
        uwall[0] = lbtopv[0]; uwall[1] = lbtopv[1]; uwall[2] = lbtopv[2];
        fD3Q19VCESwift(uwall, &lbf[spos], &lbft[4*lbsy.nf*tpos], 0.0, 0.5, 0.5, rpos, T);
        break;
      case 54:
        a3=lbphi[tpos]/100;
        if(a3==1 || a3==3 || a3==5 || a3==7)
          T = (lbsy.nt>0)?lbleft:lbsyst;
        else
          T = (lbsy.nt>0)?fGetTemperatureSite(rpos):lbsyst;
        rpos = fNextStep(1, 0, -1, tpos);
        uwall[0] = lblefv[0]; uwall[1] = lblefv[1]; uwall[2] = lblefv[2];
        fD3Q19VCESwift(uwall, &lbf[spos], &lbft[4*lbsy.nf*tpos], -0.5, 0.0, 0.5, rpos, T);
        break;
    }
  }
  else {
    switch (prop) {
      case 22:
        uwall[0] = lbtopv[0]; uwall[1] = lbtopv[1]; uwall[2] = lbtopv[2];
        fD3Q19VPS(uwall[0], uwall[1], uwall[2], &lbf[spos], &lbf[spos+1*qdim],
                  &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim],
                  &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+8*qdim], &lbf[spos+9*qdim],
                  &lbf[spos+10*qdim], &lbf[spos+11*qdim], &lbf[spos+12*qdim], &lbf[spos+13*qdim],
                  &lbf[spos+14*qdim], &lbf[spos+15*qdim], &lbf[spos+16*qdim], &lbf[spos+17*qdim],
                  &lbf[spos+18*qdim]);
        break;
      case 21:
        uwall[0] = lbbotv[0]; uwall[1] = lbbotv[1]; uwall[2] = lbbotv[2];
        fD3Q19VPS(-uwall[0], -uwall[1], uwall[2], &lbf[spos], &lbf[spos+10*qdim],
                  &lbf[spos+11*qdim], &lbf[spos+3*qdim], &lbf[spos+13*qdim], &lbf[spos+14*qdim],
                  &lbf[spos+16*qdim], &lbf[spos+15*qdim], &lbf[spos+18*qdim], &lbf[spos+17*qdim],
                  &lbf[spos+1*qdim], &lbf[spos+2*qdim], &lbf[spos+12*qdim], &lbf[spos+4*qdim],
                  &lbf[spos+5*qdim], &lbf[spos+7*qdim], &lbf[spos+6*qdim], &lbf[spos+9*qdim],
                  &lbf[spos+8*qdim]);
        break;
      case 23:
        uwall[0] = lbrigv[0]; uwall[1] = lbrigv[1]; uwall[2] = lbrigv[2];
        fD3Q19VPS(-uwall[1], uwall[0], uwall[2], &lbf[spos], &lbf[spos+11*qdim],
                  &lbf[spos+1*qdim], &lbf[spos+3*qdim], &lbf[spos+5*qdim], &lbf[spos+13*qdim],
                  &lbf[spos+18*qdim], &lbf[spos+17*qdim], &lbf[spos+6*qdim], &lbf[spos+7*qdim],
                  &lbf[spos+2*qdim], &lbf[spos+10*qdim], &lbf[spos+12*qdim], &lbf[spos+14*qdim],
                  &lbf[spos+4*qdim], &lbf[spos+9*qdim], &lbf[spos+8*qdim], &lbf[spos+15*qdim],
                  &lbf[spos+16*qdim]);
        break;
      case 24:
        uwall[0] = lblefv[0]; uwall[1] = lblefv[1]; uwall[2] = lblefv[2];
        fD3Q19VPS(uwall[1], -uwall[0], uwall[2], &lbf[spos], &lbf[spos+2*qdim],
                  &lbf[spos+10*qdim], &lbf[spos+3*qdim], &lbf[spos+14*qdim], &lbf[spos+4*qdim],
                  &lbf[spos+8*qdim], &lbf[spos+9*qdim], &lbf[spos+16*qdim], &lbf[spos+15*qdim],
                  &lbf[spos+11*qdim], &lbf[spos+1*qdim], &lbf[spos+12*qdim], &lbf[spos+5*qdim],
                  &lbf[spos+13*qdim], &lbf[spos+17*qdim], &lbf[spos+18*qdim], &lbf[spos+7*qdim],
                  &lbf[spos+6*qdim]);
        break;
      case 25:
        uwall[0] = lbbacv[0]; uwall[1] = lbbacv[1]; uwall[2] = lbbacv[2];
        fD3Q19VPS(uwall[0], -uwall[2], uwall[1], &lbf[spos], &lbf[spos+1*qdim],
                  &lbf[spos+12*qdim], &lbf[spos+2*qdim], &lbf[spos+7*qdim], &lbf[spos+6*qdim],
                  &lbf[spos+4*qdim], &lbf[spos+5*qdim], &lbf[spos+9*qdim], &lbf[spos+17*qdim],
                  &lbf[spos+10*qdim], &lbf[spos+3*qdim], &lbf[spos+11*qdim], &lbf[spos+16*qdim],
                  &lbf[spos+15*qdim], &lbf[spos+13*qdim], &lbf[spos+14*qdim], &lbf[spos+18*qdim],
                  &lbf[spos+8*qdim]);
        break;
      case 26:
        uwall[0] = lbfrov[0]; uwall[1] = lbfrov[1]; uwall[2] = lbfrov[2];
        fD3Q19VPS(uwall[0], uwall[2], -uwall[1], &lbf[spos], &lbf[spos+1*qdim],
                  &lbf[spos+3*qdim], &lbf[spos+11*qdim], &lbf[spos+6*qdim], &lbf[spos+7*qdim],
                  &lbf[spos+5*qdim], &lbf[spos+4*qdim], &lbf[spos+18*qdim], &lbf[spos+8*qdim],
                  &lbf[spos+10*qdim], &lbf[spos+12*qdim], &lbf[spos+2*qdim], &lbf[spos+15*qdim],
                  &lbf[spos+16*qdim], &lbf[spos+14*qdim], &lbf[spos+13*qdim], &lbf[spos+9*qdim],
                  &lbf[spos+17*qdim]);
        break;
      case 27:
        rpos = fNextStep(1, 1, -1, tpos);
        uwall[0] = lbbotv[0]; uwall[1] = lbbotv[1]; uwall[2] = lbbotv[2];
        fD3Q19VCE(uwall, &lbf[spos], rpos);
        break;
      case 28:
        rpos = fNextStep(-1, 1, -1, tpos);
        uwall[0] = lbbotv[0]; uwall[1] = lbbotv[1]; uwall[2] = lbbotv[2];
        fD3Q19VCE(uwall, &lbf[spos], rpos);
        break;
      case 29:
        rpos = fNextStep(-1, -1, -1, tpos);
        uwall[0] = lbtopv[0]; uwall[1] = lbtopv[1]; uwall[2] = lbtopv[2];
        fD3Q19VCE(uwall, &lbf[spos], rpos);
        break;
      case 30:
        rpos = fNextStep(1, -1, -1, tpos);
        uwall[0] = lbtopv[0]; uwall[1] = lbtopv[1]; uwall[2] = lbtopv[2];
        fD3Q19VCE(uwall, &lbf[spos], rpos);
        break;
      case 31:
        rpos = fNextStep(1, 1, 1, tpos);
        uwall[0] = lbbotv[0]; uwall[1] = lbbotv[1]; uwall[2] = lbbotv[2];
        fD3Q19VCE(uwall, &lbf[spos], rpos);
        break;
      case 32:
        rpos = fNextStep(-1, 1, 1, tpos);
        uwall[0] = lbbotv[0]; uwall[1] = lbbotv[1]; uwall[2] = lbbotv[2];
        fD3Q19VCE(uwall, &lbf[spos], rpos);
        break;
      case 33:
        rpos = fNextStep(-1, -1, 1, tpos);
        uwall[0] = lbtopv[0]; uwall[1] = lbtopv[1]; uwall[2] = lbtopv[2];
        fD3Q19VCE(uwall, &lbf[spos], rpos);
        break;
      case 34:
        rpos = fNextStep(1, -1, 1, tpos);
        uwall[0] = lbtopv[0]; uwall[1] = lbtopv[1]; uwall[2] = lbtopv[2];
        fD3Q19VCE(uwall, &lbf[spos], rpos);
        break;
      case 43:
        rpos = fNextStep(1, 1, 0, tpos);
        uwall[0] = lbbotv[0]; uwall[1] = lbbotv[1]; uwall[2] = lbbotv[2];
        fD3Q19VCE(uwall, &lbf[spos], rpos);
        break;
      case 44:
        rpos = fNextStep(-1, 1, 0, tpos);
        uwall[0] = lbbotv[0]; uwall[1] = lbbotv[1]; uwall[2] = lbbotv[2];
        fD3Q19VCE(uwall, &lbf[spos], rpos);
        break;
      case 45:
        rpos = fNextStep(-1, -1, 0, tpos);
        uwall[0] = lbtopv[0]; uwall[1] = lbtopv[1]; uwall[2] = lbtopv[2];
        fD3Q19VCE(uwall, &lbf[spos], rpos);
        break;
      case 46:
        rpos = fNextStep(1, -1, 0, tpos);
        uwall[0] = lbtopv[0]; uwall[1] = lbtopv[1]; uwall[2] = lbtopv[2];
        fD3Q19VCE(uwall, &lbf[spos], rpos);
        break;
      case 47:
        rpos = fNextStep(0, 1, 1, tpos);
        uwall[0] = lbbotv[0]; uwall[1] = lbbotv[1]; uwall[2] = lbbotv[2];
        fD3Q19VCE(uwall, &lbf[spos], rpos);
        break;
      case 48:
        rpos = fNextStep(-1, 0, 1, tpos);
        uwall[0] = lbrigv[0]; uwall[1] = lbrigv[1]; uwall[2] = lbrigv[2];
        fD3Q19VCE(uwall, &lbf[spos], rpos);
        break;
      case 49:
        rpos = fNextStep(0, -1, 1, tpos);
        uwall[0] = lbtopv[0]; uwall[1] = lbtopv[1]; uwall[2] = lbtopv[2];
        fD3Q19VCE(uwall, &lbf[spos], rpos);
        break;
      case 50:
        rpos = fNextStep(1, 0, 1, tpos);
        uwall[0] = lblefv[0]; uwall[1] = lblefv[1]; uwall[2] = lblefv[2];
        fD3Q19VCE(uwall, &lbf[spos], rpos);
        break;
      case 51:
        rpos = fNextStep(0, 1, -1, tpos);
        uwall[0] = lbbotv[0]; uwall[1] = lbbotv[1]; uwall[2] = lbbotv[2];
        fD3Q19VCE(uwall, &lbf[spos], rpos);
        break;
      case 52:
        rpos = fNextStep(-1, 0, -1, tpos);
        uwall[0] = lbrigv[0]; uwall[1] = lbrigv[1]; uwall[2] = lbrigv[2];
        fD3Q19VCE(uwall, &lbf[spos], rpos);
        break;
      case 53:
        rpos = fNextStep(0, -1, -1, tpos);
        uwall[0] = lbtopv[0]; uwall[1] = lbtopv[1]; uwall[2] = lbtopv[2];
        fD3Q19VCE(uwall, &lbf[spos], rpos);
        break;
      case 54:
        rpos = fNextStep(1, 0, -1, tpos);
        uwall[0] = lblefv[0]; uwall[1] = lblefv[1]; uwall[2] = lblefv[2];
        fD3Q19VCE(uwall, &lbf[spos], rpos);
        break;
    }
  }
  
  return 0;
  
}


int fD3Q19PPS(double *p, double *f0, double *f1,
	      double *f2, double *f3, double *f4, double *f5,
	      double *f6, double *f7, double *f8, double *f9,
	      double *f10, double *f11, double *f12, double *f13,
	      double *f14, double *f15, double *f16, double *f17,
	      double *f18, double &vel)
{

  // produce fixed pressure/density at planar surface: expressed for top wall

  double rx, rz, v;
  double c1=1.0/3.0,c2=1.0/6.0;
  double mass=0.0;
  vel=0.0;
  if(!incompress) {
    for(int i=0; i<lbsy.nf; i++) {
      v=(f0[i]+f1[i]+f3[i]+f6[i]+f7[i]+f10[i]+f12[i]+f15[i]+f16[i]+2.0*(f5[i]+f11[i]+f13[i]+f17[i]+f18[i]))-p[i];
      vel += v;
      mass += p[i];
      rx=0.5*(f10[i]-f1[i]-f6[i]-f7[i]+f15[i]+f16[i]);
      rz=0.5*(f12[i]-f3[i]-f6[i]+f7[i]+f15[i]-f16[i]);
      f2[i]=f11[i]-c1*v;
      f4[i]=f13[i]-c2*v+rx;
      f8[i]=f17[i]-c2*v+rz;
      f9[i]=f18[i]-c2*v-rz;
      f14[i]=f5[i]-c2*v-rx;
    }
  }
  else {
    for(int i=0; i<lbsy.nf; i++) {
      v=(f0[i]+f1[i]+f3[i]+f6[i]+f7[i]+f10[i]+f12[i]+f15[i]+f16[i]+2.0*(f5[i]+f11[i]+f13[i]+f17[i]+f18[i]))-p[i];
      vel += v;
      mass += lbincp[i];
      rx=0.5*(f10[i]-f1[i]-f6[i]-f7[i]+f15[i]+f16[i]);
      rz=0.5*(f12[i]-f3[i]-f6[i]+f7[i]+f15[i]-f16[i]);
      f2[i]=f11[i]-c1*v;
      f4[i]=f13[i]-c2*v+rx;
      f8[i]=f17[i]-c2*v+rz;
      f9[i]=f18[i]-c2*v-rz;
      f14[i]=f5[i]-c2*v-rx;
    }
  }
  vel *= fReciprocal(mass);
  return 0;
}


int fD3Q19PPSSwift(double *p, double *f0, double *f1,
	      double *f2, double *f3, double *f4, double *f5,
	      double *f6, double *f7, double *f8, double *f9,
	      double *f10, double *f11, double *f12, double *f13,
	      double *f14, double *f15, double *f16, double *f17,
	      double *f18, double &vel)
{

  // produce fixed pressure/density at planar surface: expressed for top wall
  // with Swift free-energy interactions

  double rx, rz, v;
  double c1=1.0/3.0,c2=1.0/6.0,c3=2.0/3.0;
  double mass=0.0;
  vel=0.0;

  v=(f0[0]+f1[0]+f3[0]+f6[0]+f7[0]+f10[0]+f12[0]+f15[0]+f16[0]+2.0*(f5[0]+f11[0]+f13[0]+f17[0]+f18[0]))-p[0];
  vel += v;
  mass += p[0];
  rx=0.5*(f10[0]-f1[0]-f6[0]-f7[0]+f15[0]+f16[0]);
  rz=0.5*(f12[0]-f3[0]-f6[0]+f7[0]+f15[0]-f16[0]);
  f2[0]=f11[0]-c1*v;
  f4[0]=f13[0]-c2*v+rx;
  f8[0]=f17[0]-c2*v+rz;
  f9[0]=f18[0]-c2*v-rz;
  f14[0]=f5[0]-c2*v-rx;
  vel *= fReciprocal(mass);
  if(lbsy.nf>1) {
    f2[1]=p[1]*(1.0+c3*vel)-f0[1]-f1[1]-f3[1]-f6[1]-f7[1]-f10[1]-f11[1]-f12[1]-f15[1]-f16[1]-2.0*(f5[1]+f13[1]+f17[1]+f18[1]);
    f4[1]=f13[1]-c2*p[1]*vel;
    f8[1]=f17[1]-c2*p[1]*vel;
    f9[1]=f18[1]-c2*p[1]*vel;
    f14[1]=f5[1]-c2*p[1]*vel;
  }

  return 0;
}


int fD3Q19PCE(double *p, double *v, double * startpos)
{

  // produce fixed pressure/density at convex or concave corner for compressible/incompressible fluids

  double *pt1=startpos;
  int qdim=lbsy.nf+lbsy.nc+lbsy.nt;
    
  if(!incompress) {
    for(int j=0; j<lbsy.nf; j++) {
      fGetEquilibriumF(lbfeq, v, p[j]);
      for(int i=0; i<lbsy.nq; i++){
        pt1[i*qdim+j] =lbfeq[i];
      }
    }
  }
  else {
    for(int j=0; j<lbsy.nf; j++) {
      fGetEquilibriumFIncom(lbfeq, v, p[j], lbincp[j]);
      for(int i=0; i<lbsy.nq; i++){
        pt1[i*qdim+j] =lbfeq[i];
      }
    }
  }
  pt1 = NULL;
  return 0;
}

int fD3Q19PCESwift(double *p, double *v, double * startpos, double * delpos, double T)
{

  // produce fixed pressure/density at convex or concave corner for fluids
  // with Swift free-energy interactions

  double *pt1=startpos;
  double *pt2=delpos;
  double feq[lbsy.nf*lbsy.nq];
  double omega,lambda,pb,mu;
  int qdim=lbsy.nf+lbsy.nc+lbsy.nt;
    
  if(lbsy.nf>1) {
    omega = 0.5*(1.0+p[1])*lbtf[0]+0.5*(1.0-p[1])*lbtf[1];
    pb = fGetBulkPressureSwift(p[0], p[1], T);
    mu = fGetPotentialSwift(p[1], pt2[7]);
    lambda = fGetLambdaSwift(p[0], omega, T);
    fGetEquilibriumFSwiftTwoFluid(feq, v, p[0], p[1], pb, mu, lambda, pt2);
    for(int i=0; i<lbsy.nq; i++){
      pt1[i*qdim  ] =feq[i];
      pt1[i*qdim+1] =feq[i+lbsy.nq];
    }
  }
  else {
    pb = fGetBulkPressureSwift(p[0], 0.0, T);
    lambda = fGetLambdaSwift(p[0], lbtf[0], T);
    fGetEquilibriumFSwiftOneFluid(feq, v, p[0], pb, lambda, pt2);
    for(int i=0; i<lbsy.nq; i++){
      pt1[i*qdim] =lbfeq[i];
    }
  }
  pt1 = NULL;
  pt2 = NULL;
  return 0;
}


int fD3Q19PF(long tpos, int prop, double *uwall)
{
  double moment, T;
  long rpos,spos=tpos * lbsitelength;
  int qdim = lbsy.nf+lbsy.nc+lbsy.nt;
  int a3;
    
  uwall[0]=0.0; uwall[1]=0.0; uwall[2]=0.0;
  if(interact==5) {
    switch (prop) {
      case 22:
        fD3Q19PPSSwift(lbtopp, &lbf[spos], &lbf[spos+1*qdim],
                  &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim],
                  &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+8*qdim], &lbf[spos+9*qdim],
                  &lbf[spos+10*qdim], &lbf[spos+11*qdim], &lbf[spos+12*qdim], &lbf[spos+13*qdim],
                  &lbf[spos+14*qdim], &lbf[spos+15*qdim], &lbf[spos+16*qdim], &lbf[spos+17*qdim],
                  &lbf[spos+18*qdim], moment);
        uwall[1] += moment;
        break;
      case 21:
        fD3Q19PPSSwift(lbbotp, &lbf[spos], &lbf[spos+10*qdim],
                  &lbf[spos+11*qdim], &lbf[spos+3*qdim], &lbf[spos+13*qdim], &lbf[spos+14*qdim],
                  &lbf[spos+16*qdim], &lbf[spos+15*qdim], &lbf[spos+18*qdim], &lbf[spos+17*qdim],
                  &lbf[spos+1*qdim], &lbf[spos+2*qdim], &lbf[spos+12*qdim], &lbf[spos+4*qdim],
                  &lbf[spos+5*qdim], &lbf[spos+7*qdim], &lbf[spos+6*qdim], &lbf[spos+9*qdim],
                  &lbf[spos+8*qdim], moment);
        uwall[1] -= moment;
        break;
      case 23:
        fD3Q19PPSSwift(lbrigp, &lbf[spos], &lbf[spos+11*qdim],
                  &lbf[spos+1*qdim], &lbf[spos+3*qdim], &lbf[spos+5*qdim], &lbf[spos+13*qdim],
                  &lbf[spos+18*qdim], &lbf[spos+17*qdim], &lbf[spos+6*qdim], &lbf[spos+7*qdim],
                  &lbf[spos+2*qdim], &lbf[spos+10*qdim], &lbf[spos+12*qdim], &lbf[spos+14*qdim],
                  &lbf[spos+4*qdim], &lbf[spos+9*qdim], &lbf[spos+8*qdim], &lbf[spos+15*qdim],
                  &lbf[spos+16*qdim], moment);
        uwall[0] += moment;
        break;
      case 24:
        fD3Q19PPSSwift(lblefp, &lbf[spos], &lbf[spos+2*qdim],
                  &lbf[spos+10*qdim], &lbf[spos+3*qdim], &lbf[spos+14*qdim], &lbf[spos+4*qdim],
                  &lbf[spos+8*qdim], &lbf[spos+9*qdim], &lbf[spos+16*qdim], &lbf[spos+15*qdim],
                  &lbf[spos+11*qdim], &lbf[spos+1*qdim], &lbf[spos+12*qdim], &lbf[spos+5*qdim],
                  &lbf[spos+13*qdim], &lbf[spos+17*qdim], &lbf[spos+18*qdim], &lbf[spos+7*qdim],
                  &lbf[spos+6*qdim], moment);
        uwall[0] -= moment;
        break;
      case 25:
        fD3Q19PPSSwift(lbbacp, &lbf[spos], &lbf[spos+1*qdim],
                  &lbf[spos+12*qdim], &lbf[spos+2*qdim], &lbf[spos+7*qdim], &lbf[spos+6*qdim],
                  &lbf[spos+4*qdim], &lbf[spos+5*qdim], &lbf[spos+9*qdim], &lbf[spos+17*qdim],
                  &lbf[spos+10*qdim], &lbf[spos+3*qdim], &lbf[spos+11*qdim], &lbf[spos+16*qdim],
                  &lbf[spos+15*qdim], &lbf[spos+13*qdim], &lbf[spos+14*qdim], &lbf[spos+18*qdim],
                  &lbf[spos+8*qdim], moment);
        uwall[2] -= moment;
        break;
      case 26:
        fD3Q19PPSSwift(lbfrop, &lbf[spos], &lbf[spos+1*qdim],
                  &lbf[spos+3*qdim], &lbf[spos+11*qdim], &lbf[spos+6*qdim], &lbf[spos+7*qdim],
                  &lbf[spos+5*qdim], &lbf[spos+4*qdim], &lbf[spos+18*qdim], &lbf[spos+8*qdim],
                  &lbf[spos+10*qdim], &lbf[spos+12*qdim], &lbf[spos+2*qdim], &lbf[spos+15*qdim],
                  &lbf[spos+16*qdim], &lbf[spos+14*qdim], &lbf[spos+13*qdim], &lbf[spos+9*qdim],
                  &lbf[spos+17*qdim], moment);
        uwall[2] += moment;
        break;
      case 27:
        a3=lbphi[tpos]/100;
        rpos = fNextStep(1, 1, -1, tpos);
        if(a3==1 || a3==3 || a3==5 || a3==7)
          T = (lbsy.nt>0)?lbleft:lbsyst;
        else
          T = (lbsy.nt>0)?fGetTemperatureSite(rpos):lbsyst;
        fD3Q19PCESwift(lblefp, uwall, &lbf[spos], &lbft[4*lbsy.nf*spos], T);
        break;
      case 28:
        a3=lbphi[tpos]/100;
        rpos = fNextStep(-1, 1, -1, tpos);
        if(a3==1 || a3==3 || a3==5 || a3==7)
          T = (lbsy.nt>0)?lbrigt:lbsyst;
        else
          T = (lbsy.nt>0)?fGetTemperatureSite(rpos):lbsyst;
        fD3Q19PCESwift(lbrigp, uwall, &lbf[spos], &lbft[4*lbsy.nf*spos], T);
        break;
      case 29:
        a3=lbphi[tpos]/100;
        rpos = fNextStep(-1, -1, -1, tpos);
        if(a3==1 || a3==3 || a3==5 || a3==7)
          T = (lbsy.nt>0)?lbrigt:lbsyst;
        else
          T = (lbsy.nt>0)?fGetTemperatureSite(rpos):lbsyst;
        fD3Q19PCESwift(lbrigp, uwall, &lbf[spos], &lbft[4*lbsy.nf*spos], T);
        break;
      case 30:
        a3=lbphi[tpos]/100;
        rpos = fNextStep(1, -1, -1, tpos);
        if(a3==1 || a3==3 || a3==5 || a3==7)
          T = (lbsy.nt>0)?lbleft:lbsyst;
        else
          T = (lbsy.nt>0)?fGetTemperatureSite(rpos):lbsyst;
        fD3Q19PCESwift(lblefp, uwall, &lbf[spos], &lbft[4*lbsy.nf*spos], T);
        break;
      case 31:
        a3=lbphi[tpos]/100;
        rpos = fNextStep(1, 1, 1, tpos);
        if(a3==1 || a3==3 || a3==5 || a3==7)
          T = (lbsy.nt>0)?lbleft:lbsyst;
        else
          T = (lbsy.nt>0)?fGetTemperatureSite(rpos):lbsyst;
        fD3Q19PCESwift(lblefp, uwall, &lbf[spos], &lbft[4*lbsy.nf*spos], T);
        break;
      case 32:
        a3=lbphi[tpos]/100;
        rpos = fNextStep(-1, 1, 1, tpos);
        if(a3==1 || a3==3 || a3==5 || a3==7)
          T = (lbsy.nt>0)?lbrigt:lbsyst;
        else
          T = (lbsy.nt>0)?fGetTemperatureSite(rpos):lbsyst;
        fD3Q19PCESwift(lbrigp, uwall, &lbf[spos], &lbft[4*lbsy.nf*spos], T);
        break;
      case 33:
        a3=lbphi[tpos]/100;
        rpos = fNextStep(-1, -1, 1, tpos);
        if(a3==1 || a3==3 || a3==5 || a3==7)
          T = (lbsy.nt>0)?lbrigt:lbsyst;
        else
          T = (lbsy.nt>0)?fGetTemperatureSite(rpos):lbsyst;
        fD3Q19PCESwift(lbrigp, uwall, &lbf[spos], &lbft[4*lbsy.nf*spos], T);
        break;
      case 34:
        a3=lbphi[tpos]/100;
        rpos = fNextStep(1, -1, 1, tpos);
        if(a3==1 || a3==3 || a3==5 || a3==7)
          T = (lbsy.nt>0)?lbleft:lbsyst;
        else
          T = (lbsy.nt>0)?fGetTemperatureSite(rpos):lbsyst;
        fD3Q19PCESwift(lblefp, uwall, &lbf[spos], &lbft[4*lbsy.nf*spos], T);
        break;
      case 43:
        a3=lbphi[tpos]/100;
        rpos = fNextStep(1, 1, 0, tpos);
        if(a3==1 || a3==3 || a3==5 || a3==7)
          T = (lbsy.nt>0)?lbleft:lbsyst;
        else
          T = (lbsy.nt>0)?fGetTemperatureSite(rpos):lbsyst;
        fD3Q19PCESwift(lblefp, uwall, &lbf[spos], &lbft[4*lbsy.nf*spos], T);
        break;
      case 44:
        a3=lbphi[tpos]/100;
        rpos = fNextStep(-1, 1, 0, tpos);
        if(a3==1 || a3==3 || a3==5 || a3==7)
          T = (lbsy.nt>0)?lbrigt:lbsyst;
        else
          T = (lbsy.nt>0)?fGetTemperatureSite(rpos):lbsyst;
        fD3Q19PCESwift(lbrigp, uwall, &lbf[spos], &lbft[4*lbsy.nf*spos], T);
        break;
      case 45:
        a3=lbphi[tpos]/100;
        rpos = fNextStep(-1, -1, 0, tpos);
        if(a3==1 || a3==3 || a3==5 || a3==7)
          T = (lbsy.nt>0)?lbrigt:lbsyst;
        else
          T = (lbsy.nt>0)?fGetTemperatureSite(rpos):lbsyst;
        fD3Q19PCESwift(lbrigp, uwall, &lbf[spos], &lbft[4*lbsy.nf*spos], T);
        break;
      case 46:
        a3=lbphi[tpos]/100;
        rpos = fNextStep(1, -1, 0, tpos);
        if(a3==1 || a3==3 || a3==5 || a3==7)
          T = (lbsy.nt>0)?lbleft:lbsyst;
        else
          T = (lbsy.nt>0)?fGetTemperatureSite(rpos):lbsyst;
        fD3Q19PCESwift(lblefp, uwall, &lbf[spos], &lbft[4*lbsy.nf*spos], T);
        break;
      case 47:
        a3=lbphi[tpos]/100;
        rpos = fNextStep(0, 1, 1, tpos);
        if(a3==1 || a3==3 || a3==5 || a3==7)
          T = (lbsy.nt>0)?lbbott:lbsyst;
        else
          T = (lbsy.nt>0)?fGetTemperatureSite(rpos):lbsyst;
        fD3Q19PCESwift(lbbotp, uwall, &lbf[spos], &lbft[4*lbsy.nf*spos], T);
        break;
      case 48:
        a3=lbphi[tpos]/100;
        rpos = fNextStep(-1, 0, 1, tpos);
        if(a3==1 || a3==3 || a3==5 || a3==7)
          T = (lbsy.nt>0)?lbrigt:lbsyst;
        else
          T = (lbsy.nt>0)?fGetTemperatureSite(rpos):lbsyst;
        fD3Q19PCESwift(lbrigp, uwall, &lbf[spos], &lbft[4*lbsy.nf*spos], T);
        break;
      case 49:
        a3=lbphi[tpos]/100;
        rpos = fNextStep(0, -1, 1, tpos);
        if(a3==1 || a3==3 || a3==5 || a3==7)
          T = (lbsy.nt>0)?lbtopt:lbsyst;
        else
          T = (lbsy.nt>0)?fGetTemperatureSite(rpos):lbsyst;
        fD3Q19PCESwift(lbtopp, uwall, &lbf[spos], &lbft[4*lbsy.nf*spos], T);
        break;
      case 50:
        a3=lbphi[tpos]/100;
        rpos = fNextStep(1, 0, 1, tpos);
        if(a3==1 || a3==3 || a3==5 || a3==7)
          T = (lbsy.nt>0)?lbleft:lbsyst;
        else
          T = (lbsy.nt>0)?fGetTemperatureSite(rpos):lbsyst;
        fD3Q19PCESwift(lblefp, uwall, &lbf[spos], &lbft[4*lbsy.nf*spos], T);
        break;
      case 51:
        a3=lbphi[tpos]/100;
        rpos = fNextStep(0, 1, -1, tpos);
        if(a3==1 || a3==3 || a3==5 || a3==7)
          T = (lbsy.nt>0)?lbbott:lbsyst;
        else
          T = (lbsy.nt>0)?fGetTemperatureSite(rpos):lbsyst;
        fD3Q19PCESwift(lbbotp, uwall, &lbf[spos], &lbft[4*lbsy.nf*spos], T);
        break;
      case 52:
        a3=lbphi[tpos]/100;
        rpos = fNextStep(-1, 0, -1, tpos);
        if(a3==1 || a3==3 || a3==5 || a3==7)
          T = (lbsy.nt>0)?lbrigt:lbsyst;
        else
          T = (lbsy.nt>0)?fGetTemperatureSite(rpos):lbsyst;
        fD3Q19PCESwift(lbrigp, uwall, &lbf[spos], &lbft[4*lbsy.nf*spos], T);
        break;
      case 53:
        a3=lbphi[tpos]/100;
        rpos = fNextStep(0, -1, -1, tpos);
        if(a3==1 || a3==3 || a3==5 || a3==7)
          T = (lbsy.nt>0)?lbtopt:lbsyst;
        else
          T = (lbsy.nt>0)?fGetTemperatureSite(rpos):lbsyst;
        fD3Q19PCESwift(lbtopp, uwall, &lbf[spos], &lbft[4*lbsy.nf*spos], T);
        break;
      case 54:
        a3=lbphi[tpos]/100;
        rpos = fNextStep(1, 0, -1, tpos);
        if(a3==1 || a3==3 || a3==5 || a3==7)
          T = (lbsy.nt>0)?lbleft:lbsyst;
        else
          T = (lbsy.nt>0)?fGetTemperatureSite(rpos):lbsyst;
        fD3Q19PCESwift(lblefp, uwall, &lbf[spos], &lbft[4*lbsy.nf*spos], T);
        break;
    }
  }
  else {
    switch (prop) {
      case 22:
        fD3Q19PPS(lbtopp, &lbf[spos], &lbf[spos+1*qdim],
                  &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim],
                  &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+8*qdim], &lbf[spos+9*qdim],
                  &lbf[spos+10*qdim], &lbf[spos+11*qdim], &lbf[spos+12*qdim], &lbf[spos+13*qdim],
                  &lbf[spos+14*qdim], &lbf[spos+15*qdim], &lbf[spos+16*qdim], &lbf[spos+17*qdim],
                  &lbf[spos+18*qdim], moment);
        uwall[1] += moment;
        break;
      case 21:
        fD3Q19PPS(lbbotp, &lbf[spos], &lbf[spos+10*qdim],
                  &lbf[spos+11*qdim], &lbf[spos+3*qdim], &lbf[spos+13*qdim], &lbf[spos+14*qdim],
                  &lbf[spos+16*qdim], &lbf[spos+15*qdim], &lbf[spos+18*qdim], &lbf[spos+17*qdim],
                  &lbf[spos+1*qdim], &lbf[spos+2*qdim], &lbf[spos+12*qdim], &lbf[spos+4*qdim],
                  &lbf[spos+5*qdim], &lbf[spos+7*qdim], &lbf[spos+6*qdim], &lbf[spos+9*qdim],
                  &lbf[spos+8*qdim], moment);
        uwall[1] -= moment;
        break;
      case 23:
        fD3Q19PPS(lbrigp, &lbf[spos], &lbf[spos+11*qdim],
                  &lbf[spos+1*qdim], &lbf[spos+3*qdim], &lbf[spos+5*qdim], &lbf[spos+13*qdim],
                  &lbf[spos+18*qdim], &lbf[spos+17*qdim], &lbf[spos+6*qdim], &lbf[spos+7*qdim],
                  &lbf[spos+2*qdim], &lbf[spos+10*qdim], &lbf[spos+12*qdim], &lbf[spos+14*qdim],
                  &lbf[spos+4*qdim], &lbf[spos+9*qdim], &lbf[spos+8*qdim], &lbf[spos+15*qdim],
                  &lbf[spos+16*qdim], moment);
        uwall[0] += moment;
        break;
      case 24:
        fD3Q19PPS(lblefp, &lbf[spos], &lbf[spos+2*qdim],
                  &lbf[spos+10*qdim], &lbf[spos+3*qdim], &lbf[spos+14*qdim], &lbf[spos+4*qdim],
                  &lbf[spos+8*qdim], &lbf[spos+9*qdim], &lbf[spos+16*qdim], &lbf[spos+15*qdim],
                  &lbf[spos+11*qdim], &lbf[spos+1*qdim], &lbf[spos+12*qdim], &lbf[spos+5*qdim],
                  &lbf[spos+13*qdim], &lbf[spos+17*qdim], &lbf[spos+18*qdim], &lbf[spos+7*qdim],
                  &lbf[spos+6*qdim], moment);
        uwall[0] -= moment;
        break;
      case 25:
        fD3Q19PPS(lbbacp, &lbf[spos], &lbf[spos+1*qdim],
                  &lbf[spos+12*qdim], &lbf[spos+2*qdim], &lbf[spos+7*qdim], &lbf[spos+6*qdim],
                  &lbf[spos+4*qdim], &lbf[spos+5*qdim], &lbf[spos+9*qdim], &lbf[spos+17*qdim],
                  &lbf[spos+10*qdim], &lbf[spos+3*qdim], &lbf[spos+11*qdim], &lbf[spos+16*qdim],
                  &lbf[spos+15*qdim], &lbf[spos+13*qdim], &lbf[spos+14*qdim], &lbf[spos+18*qdim],
                  &lbf[spos+8*qdim], moment);
        uwall[2] -= moment;
        break;
      case 26:
        fD3Q19PPS(lbfrop, &lbf[spos], &lbf[spos+1*qdim],
                  &lbf[spos+3*qdim], &lbf[spos+11*qdim], &lbf[spos+6*qdim], &lbf[spos+7*qdim],
                  &lbf[spos+5*qdim], &lbf[spos+4*qdim], &lbf[spos+18*qdim], &lbf[spos+8*qdim],
                  &lbf[spos+10*qdim], &lbf[spos+12*qdim], &lbf[spos+2*qdim], &lbf[spos+15*qdim],
                  &lbf[spos+16*qdim], &lbf[spos+14*qdim], &lbf[spos+13*qdim], &lbf[spos+9*qdim],
                  &lbf[spos+17*qdim], moment);
        uwall[2] += moment;
        break;
      case 27:
        fD3Q19PCE(lblefp, uwall, &lbf[spos]);
        break;
      case 28:
        fD3Q19PCE(lbrigp, uwall, &lbf[spos]);
        break;
      case 29:
        fD3Q19PCE(lbrigp, uwall, &lbf[spos]);
        break;
      case 30:
        fD3Q19PCE(lblefp, uwall, &lbf[spos]);
        break;
      case 31:
        fD3Q19PCE(lblefp, uwall, &lbf[spos]);
        break;
      case 32:
        fD3Q19PCE(lbrigp, uwall, &lbf[spos]);
        break;
      case 33:
        fD3Q19PCE(lbrigp, uwall, &lbf[spos]);
        break;
      case 34:
        fD3Q19PCE(lblefp, uwall, &lbf[spos]);
        break;
      case 43:
        fD3Q19PCE(lblefp, uwall, &lbf[spos]);
        break;
      case 44:
        fD3Q19PCE(lbrigp, uwall, &lbf[spos]);
        break;
      case 45:
        fD3Q19PCE(lbrigp, uwall, &lbf[spos]);
        break;
      case 46:
        fD3Q19PCE(lblefp, uwall, &lbf[spos]);
        break;
     case 47:
        fD3Q19PCE(lbbotp, uwall, &lbf[spos]);
        break;
      case 48:
        fD3Q19PCE(lbrigp, uwall, &lbf[spos]);
        break;
      case 49:
        fD3Q19PCE(lbtopp, uwall, &lbf[spos]);
        break;
      case 50:
        fD3Q19PCE(lblefp, uwall, &lbf[spos]);
        break;
      case 51:
        fD3Q19PCE(lbbotp, uwall, &lbf[spos]);
        break;
      case 52:
        fD3Q19PCE(lbrigp, uwall, &lbf[spos]);
        break;
      case 53:
        fD3Q19PCE(lbtopp, uwall, &lbf[spos]);
        break;
      case 54:
        fD3Q19PCE(lblefp, uwall, &lbf[spos]);
        break;
    }
  }
  return 0;
}


int fD3Q19CPS(double *p, double v0, double v1, double v2, double *f0, double *f1,
	          double *f2, double *f3, double *f4, double *f5, double *f6,
              double *f7, double *f8, double *f9, double *f10, double *f11,
              double *f12, double *f13, double *f14, double *f15, double *f16,
              double *f17, double *f18)
{

  // produce fixed concentration at planar surface: expressed for top wall

  double rho;
  double c1=1.0/18.0,c2=1.0/36.0;
  for(int i=0; i<lbsy.nc; i++) {
    rho=6.0*(p[i]-f0[i]-f1[i]-f3[i]-f5[i]-f6[i]-f7[i]-f10[i]-f11[i]-f12[i]-f13[i]-f15[i]-f16[i]-f17[i]-f18[i])/(1.0-3.0*v1);
    f2[i]=c1*rho*(1.0-3.0*v1);
    f4[i]=c2*rho*(1.0-3.0*v0-3.0*v1);
    f8[i]=c2*rho*(1.0-3.0*v1-3.0*v2);
    f9[i]=c2*rho*(1.0-3.0*v1+3.0*v2);
    f14[i]=c2*rho*(1.0+3.0*v0-3.0*v1);
  }
  return 0;
}


int fD3Q19CCE(double *p, double *v, double * startpos)
{

  // produce fixed solute concentration at convex or concave corner:
  // expressed for left-bottom edge (against velocity 7)

  double *pt1=startpos;
  int qdim=lbsy.nf+lbsy.nc+lbsy.nt;
  for(int j=0; j<lbsy.nc; j++) {
    fGetEquilibriumC(lbfeq, v, p[j]);
    for(int i=0; i<lbsy.nq; i++){
      pt1[i*qdim+j] =lbfeq[i];
    }
  }
  pt1 = NULL;
  return 0;
}

int fD3Q19PC(long tpos, int prop, double *uwall)
{
  long spos=tpos * lbsitelength + lbsy.nf;
  int qdim=lbsy.nf+lbsy.nc+lbsy.nt;
    
  if(lbsy.nc>0) {
    switch (prop) {
      case 22:
        fD3Q19CPS(lbtopc, uwall[0], uwall[1], uwall[2], &lbf[spos], &lbf[spos+1*qdim],
                  &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim], &lbf[spos+6*qdim],
                  &lbf[spos+7*qdim], &lbf[spos+8*qdim], &lbf[spos+9*qdim], &lbf[spos+10*qdim], &lbf[spos+11*qdim],
                  &lbf[spos+12*qdim], &lbf[spos+13*qdim], &lbf[spos+14*qdim], &lbf[spos+15*qdim], &lbf[spos+16*qdim],
                  &lbf[spos+17*qdim], &lbf[spos+18*qdim]);
        break;
      case 21:
        fD3Q19CPS(lbbotc, -uwall[0], -uwall[1], uwall[2], &lbf[spos], &lbf[spos+10*qdim],
                  &lbf[spos+11*qdim], &lbf[spos+3*qdim], &lbf[spos+13*qdim], &lbf[spos+14*qdim], &lbf[spos+16*qdim],
                  &lbf[spos+15*qdim], &lbf[spos+18*qdim], &lbf[spos+17*qdim], &lbf[spos+1*qdim], &lbf[spos+2*qdim],
                  &lbf[spos+12*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim], &lbf[spos+7*qdim], &lbf[spos+6*qdim],
                  &lbf[spos+9*qdim], &lbf[spos+8*qdim]);
        break;
      case 23:
        fD3Q19CPS(lbrigc, -uwall[1], uwall[0], uwall[2], &lbf[spos], &lbf[spos+11*qdim],
                  &lbf[spos+1*qdim], &lbf[spos+3*qdim], &lbf[spos+5*qdim], &lbf[spos+13*qdim], &lbf[spos+18*qdim],
                  &lbf[spos+17*qdim], &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+2*qdim], &lbf[spos+10*qdim],
                  &lbf[spos+12*qdim], &lbf[spos+14*qdim], &lbf[spos+4*qdim], &lbf[spos+9*qdim], &lbf[spos+8*qdim],
                  &lbf[spos+15*qdim], &lbf[spos+16*qdim]);
        break;
      case 24:
        fD3Q19CPS(lblefc, uwall[1], -uwall[0], uwall[2], &lbf[spos], &lbf[spos+2*qdim],
                  &lbf[spos+10*qdim], &lbf[spos+3*qdim], &lbf[spos+14*qdim], &lbf[spos+4*qdim], &lbf[spos+8*qdim],
                  &lbf[spos+9*qdim], &lbf[spos+16*qdim], &lbf[spos+15*qdim], &lbf[spos+11*qdim], &lbf[spos+1*qdim],
                  &lbf[spos+12*qdim], &lbf[spos+5*qdim], &lbf[spos+13*qdim], &lbf[spos+17*qdim], &lbf[spos+18*qdim],
                  &lbf[spos+7*qdim], &lbf[spos+6*qdim]);
        break;
      case 25:
        fD3Q19CPS(lbbacc, uwall[0], -uwall[2], uwall[1], &lbf[spos], &lbf[spos+1*qdim],
                  &lbf[spos+12*qdim], &lbf[spos+2*qdim], &lbf[spos+7*qdim], &lbf[spos+6*qdim], &lbf[spos+4*qdim],
                  &lbf[spos+5*qdim], &lbf[spos+9*qdim], &lbf[spos+17*qdim], &lbf[spos+10*qdim], &lbf[spos+3*qdim],
                  &lbf[spos+11*qdim], &lbf[spos+16*qdim], &lbf[spos+15*qdim], &lbf[spos+13*qdim], &lbf[spos+14*qdim],
                  &lbf[spos+18*qdim], &lbf[spos+8*qdim]);
        break;
      case 26:
        fD3Q19CPS(lbfroc, uwall[0], uwall[2], -uwall[1], &lbf[spos], &lbf[spos+1*qdim],
                  &lbf[spos+3*qdim], &lbf[spos+11*qdim], &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+5*qdim],
                  &lbf[spos+4*qdim], &lbf[spos+18*qdim], &lbf[spos+8*qdim], &lbf[spos+10*qdim], &lbf[spos+12*qdim],
                  &lbf[spos+2*qdim], &lbf[spos+15*qdim], &lbf[spos+16*qdim], &lbf[spos+14*qdim], &lbf[spos+13*qdim],
                  &lbf[spos+9*qdim], &lbf[spos+17*qdim]);
        break;
      case 27:
        fD3Q19CCE(lbbotc, uwall, &lbf[spos]);
        break;
      case 28:
        fD3Q19CCE(lbbotc, uwall, &lbf[spos]);
        break;
      case 29:
        fD3Q19CCE(lbtopc, uwall, &lbf[spos]);
        break;
      case 30:
        fD3Q19CCE(lbtopc, uwall, &lbf[spos]);
        break;
      case 31:
        fD3Q19CCE(lbbotc, uwall, &lbf[spos]);
        break;
      case 32:
        fD3Q19CCE(lbbotc, uwall, &lbf[spos]);
        break;
      case 33:
        fD3Q19CCE(lbtopc, uwall, &lbf[spos]);
        break;
      case 34:
        fD3Q19CCE(lbtopc, uwall, &lbf[spos]);
        break;
      case 43:
        fD3Q19CCE(lbbotc, uwall, &lbf[spos]);
        break;
      case 44:
        fD3Q19CCE(lbbotc, uwall, &lbf[spos]);
        break;
      case 45:
        fD3Q19CCE(lbtopc, uwall, &lbf[spos]);
        break;
      case 46:
        fD3Q19CCE(lbtopc, uwall, &lbf[spos]);
        break;
      case 47:
        fD3Q19CCE(lbbotc, uwall, &lbf[spos]);
        break;
      case 48:
        fD3Q19CCE(lbrigc, uwall, &lbf[spos]);
        break;
      case 49:
        fD3Q19CCE(lbtopc, uwall, &lbf[spos]);
        break;
      case 50:
        fD3Q19CCE(lblefc, uwall, &lbf[spos]);
        break;
      case 51:
        fD3Q19CCE(lbbotc, uwall, &lbf[spos]);
        break;
      case 52:
        fD3Q19CCE(lbrigc, uwall, &lbf[spos]);
        break;
      case 53:
        fD3Q19CCE(lbtopc, uwall, &lbf[spos]);
        break;
      case 54:
        fD3Q19CCE(lblefc, uwall, &lbf[spos]);
        break;
    }
  }
  return 0;
}

int fD3Q19TPS(double p, double v0, double v1, double v2, double *f0, double *f1,
	          double *f2, double *f3, double *f4, double *f5, double *f6,
              double *f7, double *f8, double *f9, double *f10, double *f11,
              double *f12, double *f13, double *f14, double *f15, double *f16,
              double *f17, double *f18)
{

  // produce fixed temperature at planar surface: expressed for top wall

  double rho;
  double c1=1.0/18.0,c2=1.0/36.0;
  rho=6.0*(p-f0[0]-f1[0]-f3[0]-f5[0]-f6[0]-f7[0]-f10[0]-f11[0]-f12[0]-f13[0]-f15[0]-f16[0]-f17[0]-f18[0])/(1.0-3.0*v1);
  f2[0]=c1*rho*(1.0-3.0*v1);
  f4[0]=c2*rho*(1.0-3.0*v0-3.0*v1);
  f8[0]=c2*rho*(1.0-3.0*v1-3.0*v2);
  f9[0]=c2*rho*(1.0-3.0*v1+3.0*v2);
  f14[0]=c2*rho*(1.0+3.0*v0-3.0*v1);
  return 0;
}


int fD3Q19TCE(double p, double *v, double * startpos)
{

  // produce fixed temperature at convex or concave corner:
  // expressed for left-bottom edge (against velocity 7)

  double *pt1=startpos;
  int qdim=lbsy.nf+lbsy.nc+lbsy.nt;
  fGetEquilibriumT(lbfeq, v, p);
  for(int i=0; i<lbsy.nq; i++){
    pt1[i*qdim] =lbfeq[i];
  }
  pt1 = NULL;
  return 0;
}

int fD3Q19PT(long tpos, int prop, double *uwall)
{
  long spos=tpos * lbsitelength + (lbsy.nf + lbsy.nc);
  int qdim=lbsy.nf+lbsy.nc+lbsy.nt;
  if(lbsy.nt==1) {
    switch (prop) {
      case 22:
        fD3Q19TPS(lbtopt, uwall[0], uwall[1], uwall[2], &lbf[spos], &lbf[spos+1*qdim],
                  &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim], &lbf[spos+6*qdim],
                  &lbf[spos+7*qdim], &lbf[spos+8*qdim], &lbf[spos+9*qdim], &lbf[spos+10*qdim], &lbf[spos+11*qdim],
                  &lbf[spos+12*qdim], &lbf[spos+13*qdim], &lbf[spos+14*qdim], &lbf[spos+15*qdim], &lbf[spos+16*qdim],
                  &lbf[spos+17*qdim], &lbf[spos+18*qdim]);
        break;
      case 21:
        fD3Q19TPS(lbbott, -uwall[0], -uwall[1], uwall[2], &lbf[spos], &lbf[spos+10*qdim],
                  &lbf[spos+11*qdim], &lbf[spos+3*qdim], &lbf[spos+13*qdim], &lbf[spos+14*qdim], &lbf[spos+16*qdim],
                  &lbf[spos+15*qdim], &lbf[spos+18*qdim], &lbf[spos+17*qdim], &lbf[spos+1*qdim], &lbf[spos+2*qdim],
                  &lbf[spos+12*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim], &lbf[spos+7*qdim], &lbf[spos+6*qdim],
                  &lbf[spos+9*qdim], &lbf[spos+8*qdim]);
        break;
      case 23:
        fD3Q19TPS(lbrigt, -uwall[1], uwall[0], uwall[2], &lbf[spos], &lbf[spos+11*qdim],
                  &lbf[spos+1*qdim], &lbf[spos+3*qdim], &lbf[spos+5*qdim], &lbf[spos+13*qdim], &lbf[spos+18*qdim],
                  &lbf[spos+17*qdim], &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+2*qdim], &lbf[spos+10*qdim],
                  &lbf[spos+12*qdim], &lbf[spos+14*qdim], &lbf[spos+4*qdim], &lbf[spos+9*qdim], &lbf[spos+8*qdim],
                  &lbf[spos+15*qdim], &lbf[spos+16*qdim]);
        break;
      case 24:
        fD3Q19TPS(lbleft, uwall[1], -uwall[0], uwall[2], &lbf[spos], &lbf[spos+2*qdim],
                  &lbf[spos+10*qdim], &lbf[spos+3*qdim], &lbf[spos+14*qdim], &lbf[spos+4*qdim], &lbf[spos+8*qdim],
                  &lbf[spos+9*qdim], &lbf[spos+16*qdim], &lbf[spos+15*qdim], &lbf[spos+11*qdim], &lbf[spos+1*qdim],
                  &lbf[spos+12*qdim], &lbf[spos+5*qdim], &lbf[spos+13*qdim], &lbf[spos+17*qdim], &lbf[spos+18*qdim],
                  &lbf[spos+7*qdim], &lbf[spos+6*qdim]);
        break;
      case 25:
        fD3Q19TPS(lbbact, uwall[0], -uwall[2], uwall[1], &lbf[spos], &lbf[spos+1*qdim],
                  &lbf[spos+12*qdim], &lbf[spos+2*qdim], &lbf[spos+7*qdim], &lbf[spos+6*qdim], &lbf[spos+4*qdim],
                  &lbf[spos+5*qdim], &lbf[spos+9*qdim], &lbf[spos+17*qdim], &lbf[spos+10*qdim], &lbf[spos+3*qdim],
                  &lbf[spos+11*qdim], &lbf[spos+16*qdim], &lbf[spos+15*qdim], &lbf[spos+13*qdim], &lbf[spos+14*qdim],
                  &lbf[spos+18*qdim], &lbf[spos+8*qdim]);
        break;
      case 26:
        fD3Q19TPS(lbfrot, uwall[0], uwall[2], -uwall[1], &lbf[spos], &lbf[spos+1*qdim],
                  &lbf[spos+3*qdim], &lbf[spos+11*qdim], &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+5*qdim],
                  &lbf[spos+4*qdim], &lbf[spos+18*qdim], &lbf[spos+8*qdim], &lbf[spos+10*qdim], &lbf[spos+12*qdim],
                  &lbf[spos+2*qdim], &lbf[spos+15*qdim], &lbf[spos+16*qdim], &lbf[spos+14*qdim], &lbf[spos+13*qdim],
                  &lbf[spos+9*qdim], &lbf[spos+17*qdim]);
        break;
      case 27:
        fD3Q19TCE(lbbott, uwall, &lbf[spos]);
        break;
      case 28:
        fD3Q19TCE(lbbott, uwall, &lbf[spos]);
        break;
      case 29:
        fD3Q19TCE(lbtopt, uwall, &lbf[spos]);
        break;
      case 30:
        fD3Q19TCE(lbtopt, uwall, &lbf[spos]);
        break;
      case 31:
        fD3Q19TCE(lbbott, uwall, &lbf[spos]);
        break;
      case 32:
        fD3Q19TCE(lbbott, uwall, &lbf[spos]);
        break;
      case 33:
        fD3Q19TCE(lbtopt, uwall, &lbf[spos]);
        break;
      case 34:
        fD3Q19TCE(lbtopt, uwall, &lbf[spos]);
        break;
      case 43:
        fD3Q19TCE(lbbott, uwall, &lbf[spos]);
        break;
      case 44:
        fD3Q19TCE(lbbott, uwall, &lbf[spos]);
        break;
      case 45:
        fD3Q19TCE(lbtopt, uwall, &lbf[spos]);
        break;
      case 46:
        fD3Q19TCE(lbtopt, uwall, &lbf[spos]);
        break;
      case 47:
        fD3Q19TCE(lbbott, uwall, &lbf[spos]);
        break;
      case 48:
        fD3Q19TCE(lbrigt, uwall, &lbf[spos]);
        break;
      case 49:
        fD3Q19TCE(lbtopt, uwall, &lbf[spos]);
        break;
      case 50:
        fD3Q19TCE(lbleft, uwall, &lbf[spos]);
        break;
      case 51:
        fD3Q19TCE(lbbott, uwall, &lbf[spos]);
        break;
      case 52:
        fD3Q19TCE(lbrigt, uwall, &lbf[spos]);
        break;
      case 53:
        fD3Q19TCE(lbtopt, uwall, &lbf[spos]);
        break;
      case 54:
        fD3Q19TCE(lbleft, uwall, &lbf[spos]);
        break;
    }
  }
  return 0;
}


// D3Q27

int fD3Q27VPS(double v0, double v1, double v2, double *f0, double *f1, double *f2,
              double *f3, double *f4, double *f5, double *f6, double *f7, double *f8,
              double *f9, double *f10, double *f11, double *f12, double *f13, double *f14,
              double *f15, double *f16, double *f17, double *f18, double *f19, double *f20,
              double *f21, double *f22, double *f23, double *f24, double *f25, double *f26)
{

  // produce fixed velocity for compressible/incompressible fluids at planar surface boundary:
  // expressed for top wall
  
  double rho, rho0, n1, n2;
  double c1=4.0/9.0,c2=1.0/9.0,c3=1.0/36.0,c4=1.0/6.0;
  if(!incompress) {
    for(int i=0; i<lbsy.nf; i++) {
      rho=(f0[i]+f1[i]+f3[i]+f6[i]+f7[i]+f14[i]+f16[i]+f19[i]+f20[i]+2.0*(f5[i]+f12[i]+f13[i]+f15[i]+f17[i]+f21[i]+f22[i]+f23[i]+f24[i]))/(1.0+v1);
      n1=c4*(f14[i]-f1[i]-f6[i]-f7[i]+f19[i]+f20[i])-c2*rho*v0;
      n2=c4*(f16[i]-f3[i]-f6[i]+f7[i]+f19[i]-f20[i])-c2*rho*v2;
      f2[i]=f15[i]-c1*rho*v1;
      f4[i]=f17[i]-c2*rho*(v0+v1)+n1;
      f8[i]=f21[i]-c2*rho*(v1+v2)+n2;
      f9[i]=f22[i]-c2*rho*(v1-v2)-n2;
      f18[i]=f5[i]+c2*rho*(v0-v1)-n1;
      f10[i]=f23[i]-c3*rho*(v0+v1+v2)+n1+n2;
      f11[i]=f24[i]-c3*rho*(v0+v1-v2)+n1-n2;
      f25[i]=f12[i]+c3*rho*(v0-v1+v2)-n1-n2;
      f26[i]=f13[i]+c3*rho*(v0-v1-v2)-n1+n2;
    }
  }
  else {
    for(int i=0; i<lbsy.nf; i++) {
//     rho=f0+f1+f3+f6+f7+f14+f16+f19+f20+2.0*(f5+f12+f13+f15+f17+f21+f22+f23+f24)-rho0*v1;
      rho0=lbincp[i];
      n1=c4*(f14[i]-f1[i]-f6[i]-f7[i]+f19[i]+f20[i])-c2*rho0*v0;
      n2=c4*(f16[i]-f3[i]-f6[i]+f7[i]+f19[i]-f20[i])-c2*rho0*v2;
      f2[i]=f15[i]-c1*rho0*v1;
      f4[i]=f17[i]-c2*rho0*(v0+v1)+n1;
      f8[i]=f21[i]-c2*rho0*(v1+v2)+n2;
      f9[i]=f22[i]-c2*rho0*(v1-v2)-n2;
      f18[i]=f5[i]+c2*rho0*(v0-v1)-n1;
      f10[i]=f23[i]-c3*rho0*(v0+v1+v2)+n1+n2;
      f11[i]=f24[i]-c3*rho0*(v0+v1-v2)+n1-n2;
      f25[i]=f12[i]+c3*rho0*(v0-v1+v2)-n1-n2;
      f26[i]=f13[i]+c3*rho0*(v0-v1-v2)-n1+n2;
    }      
  }
  return 0;
}

int fD3Q27VCE(double *v, double * startpos, long tpos)
{

  // produce fixed velocity at convex or concave corner for compressible/incompressible fluids

  double *pt1=startpos;
  double rho[lbsy.nf];
  double p,p0;
  int qdim=lbsy.nf+lbsy.nc+lbsy.nt;
  fGetAllMassSite(rho, &lbf[tpos*lbsitelength]);
  if(!incompress) {
    for(int j=0; j<lbsy.nf; j++) {
      p = fEvapLimit(rho[j]);
      fGetEquilibriumF(lbfeq, v, p);
      for(int i=0; i<lbsy.nq; i++){
        pt1[i*qdim+j] =lbfeq[i];
      }
    }
  }
  else {
    for(int j=0; j<lbsy.nf; j++) {
      p = fEvapLimit(rho[j]);
      p0 = lbincp[j];
      fGetEquilibriumFIncom(lbfeq, v, p, p0);
      for(int i=0; i<lbsy.nq; i++){
        pt1[i*qdim+j] =lbfeq[i];
      }
    }
  }
  pt1 = NULL;
  return 0;
}

int fD3Q27VF(long tpos, int prop, double *uwall)
{
  long spos=tpos * lbsitelength;
  long rpos;
  int qdim=lbsy.nf+lbsy.nc+lbsy.nt;
  switch (prop) {
    case 22:
      uwall[0] = lbtopv[0]; uwall[1] = lbtopv[1]; uwall[2] = lbtopv[2];
      fD3Q27VPS(uwall[0], uwall[1], uwall[2], &lbf[spos], &lbf[spos+1*qdim],
                &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim],
                &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+8*qdim], &lbf[spos+9*qdim],
                &lbf[spos+10*qdim], &lbf[spos+11*qdim], &lbf[spos+12*qdim], &lbf[spos+13*qdim],
                &lbf[spos+14*qdim], &lbf[spos+15*qdim], &lbf[spos+16*qdim], &lbf[spos+17*qdim],
                &lbf[spos+18*qdim], &lbf[spos+19*qdim], &lbf[spos+20*qdim], &lbf[spos+21*qdim],
                &lbf[spos+22*qdim], &lbf[spos+23*qdim], &lbf[spos+24*qdim], &lbf[spos+25*qdim],
                &lbf[spos+26*qdim]);
      break;
    case 21:
      uwall[0] = lbbotv[0]; uwall[1] = lbbotv[1]; uwall[2] = lbbotv[2];
      fD3Q27VPS(uwall[0], -uwall[1], uwall[2], &lbf[spos], &lbf[spos+1*qdim],
                &lbf[spos+15*qdim], &lbf[spos+3*qdim], &lbf[spos+5*qdim], &lbf[spos+4*qdim],
                &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+22*qdim], &lbf[spos+21*qdim],
                &lbf[spos+12*qdim], &lbf[spos+13*qdim], &lbf[spos+10*qdim], &lbf[spos+11*qdim],
                &lbf[spos+14*qdim], &lbf[spos+2*qdim], &lbf[spos+16*qdim], &lbf[spos+18*qdim],
                &lbf[spos+17*qdim], &lbf[spos+19*qdim], &lbf[spos+20*qdim], &lbf[spos+9*qdim],
                &lbf[spos+8*qdim], &lbf[spos+25*qdim], &lbf[spos+26*qdim], &lbf[spos+23*qdim],
                &lbf[spos+24*qdim]);
      break;
    case 23:
      uwall[0] = lbrigv[0]; uwall[1] = lbrigv[1]; uwall[2] = lbrigv[2];
      fD3Q27VPS(uwall[1], uwall[0], uwall[2], &lbf[spos], &lbf[spos+2*qdim],
                &lbf[spos+1*qdim], &lbf[spos+3*qdim], &lbf[spos+4*qdim], &lbf[spos+18*qdim],
                &lbf[spos+8*qdim], &lbf[spos+9*qdim], &lbf[spos+6*qdim], &lbf[spos+7*qdim],
                &lbf[spos+10*qdim], &lbf[spos+11*qdim], &lbf[spos+26*qdim], &lbf[spos+25*qdim],
                &lbf[spos+15*qdim], &lbf[spos+14*qdim], &lbf[spos+16*qdim], &lbf[spos+17*qdim],
                &lbf[spos+5*qdim], &lbf[spos+21*qdim], &lbf[spos+22*qdim], &lbf[spos+19*qdim],
                &lbf[spos+20*qdim], &lbf[spos+23*qdim], &lbf[spos+24*qdim], &lbf[spos+13*qdim],
                &lbf[spos+12*qdim]);
      break;
    case 24:
      uwall[0] = lblefv[0]; uwall[1] = lblefv[1]; uwall[2] = lblefv[2];
      fD3Q27VPS(uwall[1], -uwall[0], uwall[2], &lbf[spos], &lbf[spos+2*qdim],
                &lbf[spos+14*qdim], &lbf[spos+3*qdim], &lbf[spos+18*qdim], &lbf[spos+4*qdim],
                &lbf[spos+8*qdim], &lbf[spos+9*qdim], &lbf[spos+20*qdim], &lbf[spos+19*qdim],
                &lbf[spos+26*qdim], &lbf[spos+25*qdim], &lbf[spos+10*qdim], &lbf[spos+11*qdim],
                &lbf[spos+15*qdim], &lbf[spos+1*qdim], &lbf[spos+16*qdim], &lbf[spos+5*qdim],
                &lbf[spos+17*qdim], &lbf[spos+21*qdim], &lbf[spos+22*qdim], &lbf[spos+7*qdim],
                &lbf[spos+6*qdim], &lbf[spos+13*qdim], &lbf[spos+12*qdim], &lbf[spos+23*qdim],
                &lbf[spos+24*qdim]);
      break;
    case 25:
      uwall[0] = lbbacv[0]; uwall[1] = lbbacv[1]; uwall[2] = lbbacv[2];
      fD3Q27VPS(uwall[0], -uwall[2], uwall[1], &lbf[spos], &lbf[spos+1*qdim],
                &lbf[spos+16*qdim], &lbf[spos+2*qdim], &lbf[spos+7*qdim], &lbf[spos+6*qdim],
                &lbf[spos+4*qdim], &lbf[spos+5*qdim], &lbf[spos+9*qdim], &lbf[spos+21*qdim],
                &lbf[spos+11*qdim], &lbf[spos+13*qdim], &lbf[spos+10*qdim], &lbf[spos+12*qdim],
                &lbf[spos+14*qdim], &lbf[spos+3*qdim], &lbf[spos+15*qdim], &lbf[spos+20*qdim],
                &lbf[spos+19*qdim], &lbf[spos+17*qdim], &lbf[spos+18*qdim], &lbf[spos+22*qdim],
                &lbf[spos+8*qdim], &lbf[spos+24*qdim], &lbf[spos+26*qdim], &lbf[spos+23*qdim],
                &lbf[spos+25*qdim]);
      break;
    case 26:
      uwall[0] = lbfrov[0]; uwall[1] = lbfrov[1]; uwall[2] = lbfrov[2];
      fD3Q27VPS(uwall[0], uwall[2], uwall[1], &lbf[spos], &lbf[spos+1*qdim],
                &lbf[spos+3*qdim], &lbf[spos+2*qdim], &lbf[spos+6*qdim], &lbf[spos+7*qdim],
                &lbf[spos+4*qdim], &lbf[spos+5*qdim], &lbf[spos+8*qdim], &lbf[spos+22*qdim],
                &lbf[spos+10*qdim], &lbf[spos+12*qdim], &lbf[spos+11*qdim], &lbf[spos+13*qdim],
                &lbf[spos+14*qdim], &lbf[spos+16*qdim], &lbf[spos+15*qdim], &lbf[spos+19*qdim],
                &lbf[spos+20*qdim], &lbf[spos+17*qdim], &lbf[spos+18*qdim], &lbf[spos+21*qdim],
                &lbf[spos+9*qdim], &lbf[spos+23*qdim], &lbf[spos+25*qdim], &lbf[spos+24*qdim],
                &lbf[spos+26*qdim]);
      break;
    case 27:
      rpos = fNextStep(1, 1, -1, tpos);
      uwall[0] = lbbotv[0]; uwall[1] = lbbotv[1]; uwall[2] = lbbotv[2];
      fD3Q27VCE(uwall, &lbf[spos], rpos);
      break;
    case 28:
      rpos = fNextStep(-1, 1, -1, tpos);
      uwall[0] = lbbotv[0]; uwall[1] = lbbotv[1]; uwall[2] = lbbotv[2];
      fD3Q27VCE(uwall, &lbf[spos], rpos);
      break;
    case 29:
      rpos = fNextStep(-1, -1, -1, tpos);
      uwall[0] = lbtopv[0]; uwall[1] = lbtopv[1]; uwall[2] = lbtopv[2];
      fD3Q27VCE(uwall, &lbf[spos], rpos);
      break;
    case 30:
      rpos = fNextStep(1, -1, -1, tpos);
      uwall[0] = lbtopv[0]; uwall[1] = lbtopv[1]; uwall[2] = lbtopv[2];
      fD3Q27VCE(uwall, &lbf[spos], rpos);
      break;
    case 31:
      rpos = fNextStep(1, 1, 1, tpos);
      uwall[0] = lbbotv[0]; uwall[1] = lbbotv[1]; uwall[2] = lbbotv[2];
      fD3Q27VCE(uwall, &lbf[spos], rpos);
      break;
    case 32:
      rpos = fNextStep(-1, 1, 1, tpos);
      uwall[0] = lbbotv[0]; uwall[1] = lbbotv[1]; uwall[2] = lbbotv[2];
      fD3Q27VCE(uwall, &lbf[spos], rpos);
      break;
    case 33:
      rpos = fNextStep(-1, -1, 1, tpos);
      uwall[0] = lbtopv[0]; uwall[1] = lbtopv[1]; uwall[2] = lbtopv[2];
      fD3Q27VCE(uwall, &lbf[spos], rpos);
      break;
    case 34:
      rpos = fNextStep(1, -1, 1, tpos);
      uwall[0] = lbtopv[0]; uwall[1] = lbtopv[1]; uwall[2] = lbtopv[2];
      fD3Q27VCE(uwall, &lbf[spos], rpos);
      break;
    case 43:
      rpos = fNextStep(1, 1, 0, tpos);
      uwall[0] = lbbotv[0]; uwall[1] = lbbotv[1]; uwall[2] = lbbotv[2];
      fD3Q27VCE(uwall, &lbf[spos], rpos);
      break;
    case 44:
      rpos = fNextStep(-1, 1, 0, tpos);
      uwall[0] = lbbotv[0]; uwall[1] = lbbotv[1]; uwall[2] = lbbotv[2];
      fD3Q27VCE(uwall, &lbf[spos], rpos);
      break;
    case 45:
      rpos = fNextStep(-1, -1, 0, tpos);
      uwall[0] = lbtopv[0]; uwall[1] = lbtopv[1]; uwall[2] = lbtopv[2];
      fD3Q27VCE(uwall, &lbf[spos], rpos);
      break;
    case 46:
      rpos = fNextStep(1, -1, 0, tpos);
      uwall[0] = lbtopv[0]; uwall[1] = lbtopv[1]; uwall[2] = lbtopv[2];
      fD3Q27VCE(uwall, &lbf[spos], rpos);
      break;
    case 47:
      rpos = fNextStep(0, 1, 1, tpos);
      uwall[0] = lbbotv[0]; uwall[1] = lbbotv[1]; uwall[2] = lbbotv[2];
      fD3Q27VCE(uwall, &lbf[spos], rpos);
      break;
    case 48:
      rpos = fNextStep(-1, 0, 1, tpos);
      uwall[0] = lbrigv[0]; uwall[1] = lbrigv[1]; uwall[2] = lbrigv[2];
      fD3Q27VCE(uwall, &lbf[spos], rpos);
      break;
    case 49:
      rpos = fNextStep(0, -1, 1, tpos);
      uwall[0] = lbtopv[0]; uwall[1] = lbtopv[1]; uwall[2] = lbtopv[2];
      fD3Q27VCE(uwall, &lbf[spos], rpos);
      break;
    case 50:
      rpos = fNextStep(1, 0, 1, tpos);
      uwall[0] = lblefv[0]; uwall[1] = lblefv[1]; uwall[2] = lblefv[2];
      fD3Q27VCE(uwall, &lbf[spos], rpos);
      break;
    case 51:
      rpos = fNextStep(0, 1, -1, tpos);
      uwall[0] = lbbotv[0]; uwall[1] = lbbotv[1]; uwall[2] = lbbotv[2];
      fD3Q27VCE(uwall, &lbf[spos], rpos);
      break;
    case 52:
      rpos = fNextStep(-1, 0, -1, tpos);
      uwall[0] = lbrigv[0]; uwall[1] = lbrigv[1]; uwall[2] = lbrigv[2];
      fD3Q27VCE(uwall, &lbf[spos], rpos);
      break;
    case 53:
      rpos = fNextStep(0, -1, -1, tpos);
      uwall[0] = lbtopv[0]; uwall[1] = lbtopv[1]; uwall[2] = lbtopv[2];
      fD3Q27VCE(uwall, &lbf[spos], rpos);
      break;
    case 54:
      rpos = fNextStep(1, 0, -1, tpos);
      uwall[0] = lblefv[0]; uwall[1] = lblefv[1]; uwall[2] = lblefv[2];
      fD3Q27VCE(uwall, &lbf[spos], rpos);
      break;
  }

  return 0;
  
}


int fD3Q27PPS(double *p, double *f0, double *f1,
              double *f2, double *f3, double *f4, double *f5,
              double *f6, double *f7, double *f8, double *f9,
              double *f10, double *f11, double *f12, double *f13,
              double *f14, double *f15, double *f16, double *f17,
              double *f18, double *f19, double *f20, double *f21,
              double *f22, double *f23, double *f24, double *f25,
              double *f26, double &vel)
{

  // produce fixed pressure/density at planar surface: expressed for top wall

  double rx, rz, v, mass=0.0;
  double c1=4.0/9.0,c2=1.0/9.0,c3=1.0/36.0,c4=1.0/6.0;
  vel=0.0;
  if(!incompress) {
    for(int i=0; i<lbsy.nf; i++) {
      v=(f0[i]+f1[i]+f3[i]+f6[i]+f7[i]+f14[i]+f16[i]+f19[i]+f20[i]+2.0*(f5[i]+f12[i]+f13[i]+f15[i]+f17[i]+f21[i]+f22[i]+f23[i]+f24[i]))-p[i];
      vel += v;
      mass += p[i];
      rx=c4*(f14[i]-f1[i]-f6[i]-f7[i]+f19[i]+f20[i]);
      rz=c4*(f16[i]-f3[i]-f6[i]+f7[i]+f19[i]-f20[i]);
      f2[i]=f15[i]-c1*v;
      f4[i]=f17[i]-c2*v+rx;
      f8[i]=f21[i]-c2*v+rz;
      f9[i]=f22[i]-c2*v-rz;
      f18[i]=f5[i]-c2*v-rx;
      f10[i]=f23[i]-c3*v+rx+rz;
      f11[i]=f24[i]-c3*v+rx-rz;
      f25[i]=f12[i]-c3*v-rx-rz;
      f26[i]=f13[i]-c3*v-rx+rz;
    }
  }
  else {
    for(int i=0; i<lbsy.nf; i++) {
      v=(f0[i]+f1[i]+f3[i]+f6[i]+f7[i]+f14[i]+f16[i]+f19[i]+f20[i]+2.0*(f5[i]+f12[i]+f13[i]+f15[i]+f17[i]+f21[i]+f22[i]+f23[i]+f24[i]))-p[i];
      vel += v;
      mass += lbincp[i];
      rx=c4*(f14[i]-f1[i]-f6[i]-f7[i]+f19[i]+f20[i]);
      rz=c4*(f16[i]-f3[i]-f6[i]+f7[i]+f19[i]-f20[i]);
      f2[i]=f15[i]-c1*v;
      f4[i]=f17[i]-c2*v+rx;
      f8[i]=f21[i]-c2*v+rz;
      f9[i]=f22[i]-c2*v-rz;
      f18[i]=f5[i]-c2*v-rx;
      f10[i]=f23[i]-c3*v+rx+rz;
      f11[i]=f24[i]-c3*v+rx-rz;
      f25[i]=f12[i]-c3*v-rx-rz;
      f26[i]=f13[i]-c3*v-rx+rz;
    }
  }
  vel *= fReciprocal(mass);
  return 0;
}


int fD3Q27PCE(double *p, double *v, double * startpos)
{

  // produce fixed pressure/density at convex or concave corner for compressible/incompressible fluids

  double *pt1=startpos;
  int qdim=lbsy.nf+lbsy.nc+lbsy.nt;
    
  if(!incompress) {
    for(int j=0; j<lbsy.nf; j++) {
      fGetEquilibriumF(lbfeq, v, p[j]);
      for(int i=0; i<lbsy.nq; i++){
        pt1[i*qdim+j] =lbfeq[i];
      }
    }
  }
  else {
    for(int j=0; j<lbsy.nf; j++) {
      fGetEquilibriumFIncom(lbfeq, v, p[j], lbincp[j]);
      for(int i=0; i<lbsy.nq; i++){
        pt1[i*qdim+j] =lbfeq[i];
      }
    }
  }
  pt1 = NULL;
  return 0;
}


int fD3Q27PF(long tpos, int prop, double *uwall)
{
  double moment;
  long spos=tpos * lbsitelength;
  uwall[0]=0.0; uwall[1]=0.0; uwall[2]=0.0;
  int qdim=lbsy.nf+lbsy.nc+lbsy.nt;
  switch (prop) {
    case 22:
      fD3Q27PPS(lbtopp, &lbf[spos], &lbf[spos+1*qdim],
                &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim],
                &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+8*qdim], &lbf[spos+9*qdim],
                &lbf[spos+10*qdim], &lbf[spos+11*qdim], &lbf[spos+12*qdim], &lbf[spos+13*qdim],
                &lbf[spos+14*qdim], &lbf[spos+15*qdim], &lbf[spos+16*qdim], &lbf[spos+17*qdim],
                &lbf[spos+18*qdim], &lbf[spos+19*qdim], &lbf[spos+20*qdim], &lbf[spos+21*qdim],
                &lbf[spos+22*qdim], &lbf[spos+23*qdim], &lbf[spos+24*qdim], &lbf[spos+25*qdim],
                &lbf[spos+26*qdim], moment);
      uwall[1] += moment;
      break;
    case 21:
      fD3Q27PPS(lbbotp, &lbf[spos], &lbf[spos+1*qdim],
                &lbf[spos+15*qdim], &lbf[spos+3*qdim], &lbf[spos+5*qdim], &lbf[spos+4*qdim],
                &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+22*qdim], &lbf[spos+21*qdim],
                &lbf[spos+12*qdim], &lbf[spos+13*qdim], &lbf[spos+10*qdim], &lbf[spos+11*qdim],
                &lbf[spos+14*qdim], &lbf[spos+2*qdim], &lbf[spos+16*qdim], &lbf[spos+18*qdim],
                &lbf[spos+17*qdim], &lbf[spos+19*qdim], &lbf[spos+20*qdim], &lbf[spos+9*qdim],
                &lbf[spos+8*qdim], &lbf[spos+25*qdim], &lbf[spos+26*qdim], &lbf[spos+23*qdim],
                &lbf[spos+24*qdim], moment);
      uwall[1] -= moment;
      break;
    case 23:
      fD3Q27PPS(lbrigp, &lbf[spos], &lbf[spos+2*qdim],
                &lbf[spos+1*qdim], &lbf[spos+3*qdim], &lbf[spos+4*qdim], &lbf[spos+18*qdim],
                &lbf[spos+8*qdim], &lbf[spos+9*qdim], &lbf[spos+6*qdim], &lbf[spos+7*qdim],
                &lbf[spos+10*qdim], &lbf[spos+11*qdim], &lbf[spos+26*qdim], &lbf[spos+25*qdim],
                &lbf[spos+15*qdim], &lbf[spos+14*qdim], &lbf[spos+16*qdim], &lbf[spos+17*qdim],
                &lbf[spos+5*qdim], &lbf[spos+21*qdim], &lbf[spos+22*qdim], &lbf[spos+19*qdim],
                &lbf[spos+20*qdim], &lbf[spos+23*qdim], &lbf[spos+24*qdim], &lbf[spos+13*qdim],
                &lbf[spos+12*qdim], moment);
      uwall[0] += moment;
      break;
    case 24:
      fD3Q27PPS(lblefp, &lbf[spos], &lbf[spos+2*qdim],
                &lbf[spos+14*qdim], &lbf[spos+3*qdim], &lbf[spos+18*qdim], &lbf[spos+4*qdim],
                &lbf[spos+8*qdim], &lbf[spos+9*qdim], &lbf[spos+20*qdim], &lbf[spos+19*qdim],
                &lbf[spos+26*qdim], &lbf[spos+25*qdim], &lbf[spos+10*qdim], &lbf[spos+11*qdim],
                &lbf[spos+15*qdim], &lbf[spos+1*qdim], &lbf[spos+16*qdim], &lbf[spos+5*qdim],
                &lbf[spos+17*qdim], &lbf[spos+21*qdim], &lbf[spos+22*qdim], &lbf[spos+7*qdim],
                &lbf[spos+6*qdim], &lbf[spos+13*qdim], &lbf[spos+12*qdim], &lbf[spos+23*qdim],
                &lbf[spos+24*qdim], moment);
      uwall[0] -= moment;
      break;
    case 25:
      fD3Q27PPS(lbbacp, &lbf[spos], &lbf[spos+1*qdim],
                &lbf[spos+16*qdim], &lbf[spos+2*qdim], &lbf[spos+7*qdim], &lbf[spos+6*qdim],
                &lbf[spos+4*qdim], &lbf[spos+5*qdim], &lbf[spos+9*qdim], &lbf[spos+21*qdim],
                &lbf[spos+11*qdim], &lbf[spos+13*qdim], &lbf[spos+10*qdim], &lbf[spos+12*qdim],
                &lbf[spos+14*qdim], &lbf[spos+3*qdim], &lbf[spos+15*qdim], &lbf[spos+20*qdim],
                &lbf[spos+19*qdim], &lbf[spos+17*qdim], &lbf[spos+18*qdim], &lbf[spos+22*qdim],
                &lbf[spos+8*qdim], &lbf[spos+24*qdim], &lbf[spos+26*qdim], &lbf[spos+23*qdim],
                &lbf[spos+25*qdim], moment);
      uwall[2] -= moment;
      break;
    case 26:
      fD3Q27PPS(lbfrop, &lbf[spos], &lbf[spos+1*qdim],
                &lbf[spos+3*qdim], &lbf[spos+2*qdim], &lbf[spos+6*qdim], &lbf[spos+7*qdim],
                &lbf[spos+4*qdim], &lbf[spos+5*qdim], &lbf[spos+8*qdim], &lbf[spos+22*qdim],
                &lbf[spos+10*qdim], &lbf[spos+12*qdim], &lbf[spos+11*qdim], &lbf[spos+13*qdim],
                &lbf[spos+14*qdim], &lbf[spos+16*qdim], &lbf[spos+15*qdim], &lbf[spos+19*qdim],
                &lbf[spos+20*qdim], &lbf[spos+17*qdim], &lbf[spos+18*qdim], &lbf[spos+21*qdim],
                &lbf[spos+9*qdim], &lbf[spos+23*qdim], &lbf[spos+25*qdim], &lbf[spos+24*qdim],
                &lbf[spos+26*qdim], moment);
      uwall[2] += moment;
      break;
    case 27:
      fD3Q27PCE(lblefp, uwall, &lbf[spos]);
      break;
    case 28:
      fD3Q27PCE(lbrigp, uwall, &lbf[spos]);
      break;
    case 29:
      fD3Q27PCE(lbrigp, uwall, &lbf[spos]);
      break;
    case 30:
      fD3Q27PCE(lblefp, uwall, &lbf[spos]);
      break;
    case 31:
      fD3Q27PCE(lblefp, uwall, &lbf[spos]);
      break;
    case 32:
      fD3Q27PCE(lbrigp, uwall, &lbf[spos]);
      break;
    case 33:
      fD3Q27PCE(lbrigp, uwall, &lbf[spos]);
      break;
    case 34:
      fD3Q27PCE(lblefp, uwall, &lbf[spos]);
      break;
    case 43:
      fD3Q27PCE(lblefp, uwall, &lbf[spos]);
      break;
    case 44:
      fD3Q27PCE(lbrigp, uwall, &lbf[spos]);
      break;
    case 45:
      fD3Q27PCE(lbrigp, uwall, &lbf[spos]);
      break;
    case 46:
      fD3Q27PCE(lblefp, uwall, &lbf[spos]);
      break;
    case 47:
      fD3Q27PCE(lbbotp, uwall, &lbf[spos]);
      break;
    case 48:
      fD3Q27PCE(lbrigp, uwall, &lbf[spos]);
      break;
    case 49:
      fD3Q27PCE(lbtopp, uwall, &lbf[spos]);
      break;
    case 50:
      fD3Q27PCE(lblefp, uwall, &lbf[spos]);
      break;
    case 51:
      fD3Q27PCE(lbbotp, uwall, &lbf[spos]);
      break;
    case 52:
      fD3Q27PCE(lbrigp, uwall, &lbf[spos]);
      break;
    case 53:
      fD3Q27PCE(lbtopp, uwall, &lbf[spos]);
      break;
    case 54:
      fD3Q27PCE(lblefp, uwall, &lbf[spos]);
      break;
  }
  return 0;
}


int fD3Q27CPS(double *p, double v0, double v1, double v2, double *f0, double *f1,
              double *f2, double *f3, double *f4, double *f5, double *f6,
              double *f7, double *f8, double *f9, double *f10, double *f11,
              double *f12, double *f13, double *f14, double *f15, double *f16,
              double *f17, double *f18, double *f19, double *f20, double *f21,
              double *f22, double *f23, double *f24, double *f25, double *f26)
{

  // produce fixed concentration at planar surface: expressed for top wall

  double rho;
  double c1=2.0/27.0,c2=1.0/54.0,c3=1.0/216.0;
  for(int i=0; i<lbsy.nc; i++) {
    rho=6.0*(p[i]-f0[i]-f1[i]-f3[i]-f5[i]-f6[i]-f7[i]-f12[i]-f13[i]-f14[i]-f15[i]-f16[i]-f17[i]-f19[i]-f20[i]-f21[i]-f22[i]-f23[i]-f24[i])/(1.0-3.0*v1);
    f2[i]=c1*rho*(1.0-3.0*v1);
    f4[i]=c2*rho*(1.0-3.0*v0-3.0*v1);
    f8[i]=c2*rho*(1.0-3.0*v1-3.0*v2);
    f9[i]=c2*rho*(1.0-3.0*v1+3.0*v2);
    f10[i]=c3*rho*(1.0-3.0*v0-3.0*v1-3.0*v2);
    f11[i]=c3*rho*(1.0-3.0*v0-3.0*v1+3.0*v2);
    f18[i]=c2*rho*(1.0+3.0*v0-3.0*v1);
    f25[i]=c3*rho*(1.0+3.0*v0-3.0*v1+3.0*v2);
    f26[i]=c3*rho*(1.0+3.0*v0-3.0*v1-3.0*v2);
  }
  return 0;
}


int fD3Q27CCE(double *p, double *v, double * startpos)
{

  // produce fixed solute concentration at convex or concave corner:
  // expressed for left-bottom edge (against velocity 7)

  double *pt1=startpos;
  int qdim=lbsy.nf+lbsy.nc+lbsy.nt;
  for(int j=0; j<lbsy.nc; j++) {
    fGetEquilibriumC(lbfeq, v, p[j]);
    for(int i=0; i<lbsy.nq; i++){
      pt1[i*qdim+j] =lbfeq[i];
    }
  }
  pt1 = NULL;
  return 0;
}

int fD3Q27PC(long tpos, int prop, double *uwall)
{
  long spos=tpos * lbsitelength + lbsy.nf;
  int qdim=lbsy.nf+lbsy.nc+lbsy.nt;
    
  if(lbsy.nc>0) {
    switch (prop) {
      case 22:
        fD3Q27CPS(lbtopc, uwall[0], uwall[1], uwall[2], &lbf[spos], &lbf[spos+1*qdim],
                  &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim], &lbf[spos+6*qdim],
                  &lbf[spos+7*qdim], &lbf[spos+8*qdim], &lbf[spos+9*qdim], &lbf[spos+10*qdim], &lbf[spos+11*qdim],
                  &lbf[spos+12*qdim], &lbf[spos+13*qdim], &lbf[spos+14*qdim], &lbf[spos+15*qdim], &lbf[spos+16*qdim],
                  &lbf[spos+17*qdim], &lbf[spos+18*qdim], &lbf[spos+19*qdim], &lbf[spos+20*qdim], &lbf[spos+21*qdim],
                  &lbf[spos+22*qdim], &lbf[spos+23*qdim], &lbf[spos+24*qdim], &lbf[spos+25*qdim], &lbf[spos+26*qdim]);
        break;
      case 21:
        fD3Q27CPS(lbbotc, uwall[0], -uwall[1], uwall[2], &lbf[spos], &lbf[spos+1*qdim],
                  &lbf[spos+15*qdim], &lbf[spos+3*qdim], &lbf[spos+5*qdim], &lbf[spos+4*qdim], &lbf[spos+6*qdim],
                  &lbf[spos+7*qdim], &lbf[spos+22*qdim], &lbf[spos+21*qdim], &lbf[spos+12*qdim], &lbf[spos+13*qdim],
                  &lbf[spos+10*qdim], &lbf[spos+11*qdim], &lbf[spos+14*qdim], &lbf[spos+2*qdim], &lbf[spos+16*qdim],
                  &lbf[spos+18*qdim], &lbf[spos+17*qdim], &lbf[spos+19*qdim], &lbf[spos+20*qdim], &lbf[spos+9*qdim],
                  &lbf[spos+8*qdim], &lbf[spos+25*qdim], &lbf[spos+26*qdim], &lbf[spos+23*qdim], &lbf[spos+24*qdim]);
        break;
      case 23:
        fD3Q27CPS(lbrigc, uwall[1], uwall[0], uwall[2], &lbf[spos], &lbf[spos+2*qdim],
                  &lbf[spos+1*qdim], &lbf[spos+3*qdim], &lbf[spos+4*qdim], &lbf[spos+18*qdim], &lbf[spos+8*qdim],
                  &lbf[spos+9*qdim], &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+10*qdim], &lbf[spos+11*qdim],
                  &lbf[spos+26*qdim], &lbf[spos+25*qdim], &lbf[spos+15*qdim], &lbf[spos+14*qdim], &lbf[spos+16*qdim],
                  &lbf[spos+17*qdim], &lbf[spos+5*qdim], &lbf[spos+21*qdim], &lbf[spos+22*qdim], &lbf[spos+19*qdim],
                  &lbf[spos+20*qdim], &lbf[spos+23*qdim], &lbf[spos+24*qdim], &lbf[spos+13*qdim], &lbf[spos+12*qdim]);
        break;
      case 24:
        fD3Q27CPS(lblefc, uwall[1], -uwall[0], uwall[2], &lbf[spos], &lbf[spos+2*qdim],
                  &lbf[spos+14*qdim], &lbf[spos+3*qdim], &lbf[spos+18*qdim], &lbf[spos+4*qdim], &lbf[spos+8*qdim],
                  &lbf[spos+9*qdim], &lbf[spos+20*qdim], &lbf[spos+19*qdim], &lbf[spos+26*qdim], &lbf[spos+25*qdim],
                  &lbf[spos+10*qdim], &lbf[spos+11*qdim], &lbf[spos+15*qdim], &lbf[spos+1*qdim], &lbf[spos+16*qdim],
                  &lbf[spos+5*qdim], &lbf[spos+17*qdim], &lbf[spos+21*qdim], &lbf[spos+22*qdim], &lbf[spos+7*qdim],
                  &lbf[spos+6*qdim], &lbf[spos+13*qdim], &lbf[spos+12*qdim], &lbf[spos+23*qdim], &lbf[spos+24*qdim]);
        break;
      case 25:
        fD3Q27CPS(lbbacc, uwall[0], -uwall[2], uwall[2], &lbf[spos], &lbf[spos+1*qdim],
                  &lbf[spos+16*qdim], &lbf[spos+2*qdim], &lbf[spos+7*qdim], &lbf[spos+6*qdim], &lbf[spos+4*qdim],
                  &lbf[spos+5*qdim], &lbf[spos+9*qdim], &lbf[spos+21*qdim], &lbf[spos+11*qdim], &lbf[spos+13*qdim],
                  &lbf[spos+10*qdim], &lbf[spos+12*qdim], &lbf[spos+14*qdim], &lbf[spos+3*qdim], &lbf[spos+15*qdim],
                  &lbf[spos+20*qdim], &lbf[spos+19*qdim], &lbf[spos+17*qdim], &lbf[spos+18*qdim], &lbf[spos+22*qdim],
                  &lbf[spos+8*qdim], &lbf[spos+24*qdim], &lbf[spos+26*qdim], &lbf[spos+23*qdim], &lbf[spos+25*qdim]);
        break;
      case 26:
        fD3Q27CPS(lbfroc, uwall[0], uwall[2], uwall[1], &lbf[spos], &lbf[spos+1*qdim],
                  &lbf[spos+3*qdim], &lbf[spos+2*qdim], &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+4*qdim],
                  &lbf[spos+5*qdim], &lbf[spos+8*qdim], &lbf[spos+22*qdim], &lbf[spos+10*qdim], &lbf[spos+12*qdim],
                  &lbf[spos+11*qdim], &lbf[spos+13*qdim], &lbf[spos+14*qdim], &lbf[spos+16*qdim], &lbf[spos+15*qdim],
                  &lbf[spos+19*qdim], &lbf[spos+20*qdim], &lbf[spos+17*qdim], &lbf[spos+18*qdim], &lbf[spos+21*qdim],
                  &lbf[spos+9*qdim], &lbf[spos+23*qdim], &lbf[spos+25*qdim], &lbf[spos+24*qdim], &lbf[spos+26*qdim]);
        break;
      case 27:
        fD3Q27CCE(lbbotc, uwall, &lbf[spos]);
        break;
      case 28:
        fD3Q27CCE(lbbotc, uwall, &lbf[spos]);
        break;
      case 29:
        fD3Q27CCE(lbtopc, uwall, &lbf[spos]);
        break;
      case 30:
        fD3Q27CCE(lbtopc, uwall, &lbf[spos]);
        break;
      case 31:
        fD3Q27CCE(lbbotc, uwall, &lbf[spos]);
        break;
      case 32:
        fD3Q27CCE(lbbotc, uwall, &lbf[spos]);
        break;
      case 33:
        fD3Q27CCE(lbtopc, uwall, &lbf[spos]);
        break;
      case 34:
        fD3Q27CCE(lbtopc, uwall, &lbf[spos]);
        break;
      case 43:
        fD3Q27CCE(lbbotc, uwall, &lbf[spos]);
        break;
      case 44:
        fD3Q27CCE(lbbotc, uwall, &lbf[spos]);
        break;
      case 45:
        fD3Q27CCE(lbtopc, uwall, &lbf[spos]);
        break;
      case 46:
        fD3Q27CCE(lbtopc, uwall, &lbf[spos]);
        break;
      case 47:
        fD3Q27CCE(lbbotc, uwall, &lbf[spos]);
        break;
      case 48:
        fD3Q27CCE(lbrigc, uwall, &lbf[spos]);
        break;
      case 49:
        fD3Q27CCE(lbtopc, uwall, &lbf[spos]);
        break;
      case 50:
        fD3Q27CCE(lblefc, uwall, &lbf[spos]);
        break;
      case 51:
        fD3Q27CCE(lbbotc, uwall, &lbf[spos]);
        break;
      case 52:
        fD3Q27CCE(lbrigc, uwall, &lbf[spos]);
        break;
      case 53:
        fD3Q27CCE(lbtopc, uwall, &lbf[spos]);
        break;
      case 54:
        fD3Q27CCE(lblefc, uwall, &lbf[spos]);
        break;
    }
  }
  return 0;
}



int fD3Q27TPS(double p, double v0, double v1, double v2, double *f0, double *f1,
              double *f2, double *f3, double *f4, double *f5, double *f6,
              double *f7, double *f8, double *f9, double *f10, double *f11,
              double *f12, double *f13, double *f14, double *f15, double *f16,
              double *f17, double *f18, double *f19, double *f20, double *f21,
              double *f22, double *f23, double *f24, double *f25, double *f26)
{

  // produce fixed temperature at planar surface: expressed for top wall

  double rho;
  double c1=2.0/27.0,c2=1.0/54.0,c3=1.0/216.0;
  rho=6.0*(p-f0[0]-f1[0]-f3[0]-f5[0]-f6[0]-f7[0]-f12[0]-f13[0]-f14[0]-f15[0]-f16[0]-f17[0]-f19[0]-f20[0]-f21[0]-f22[0]-f23[0]-f24[0])/(1.0-3.0*v1);
  f2[0]=c1*rho*(1.0-3.0*v1);
  f4[0]=c2*rho*(1.0-3.0*v0-3.0*v1);
  f8[0]=c2*rho*(1.0-3.0*v1-3.0*v2);
  f9[0]=c2*rho*(1.0-3.0*v1+3.0*v2);
  f10[0]=c3*rho*(1.0-3.0*v0-3.0*v1-3.0*v2);
  f11[0]=c3*rho*(1.0-3.0*v0-3.0*v1+3.0*v2);
  f18[0]=c2*rho*(1.0+3.0*v0-3.0*v1);
  f25[0]=c3*rho*(1.0+3.0*v0-3.0*v1+3.0*v2);
  f26[0]=c3*rho*(1.0+3.0*v0-3.0*v1-3.0*v2);
  return 0;
}


int fD3Q27TCE(double p, double *v, double * startpos)
{

  // produce fixed temperature at convex or concave corner

  double *pt1=startpos;
  int qdim=lbsy.nf+lbsy.nc+lbsy.nt;
  fGetEquilibriumT(lbfeq, v, p);
  for(int i=0; i<lbsy.nq; i++){
    pt1[i*qdim] =lbfeq[i];
  }
  pt1 = NULL;
  return 0;
}


int fD3Q27PT(long tpos, int prop, double *uwall)
{
  long spos=tpos * lbsitelength + (lbsy.nf + lbsy.nc);
  int qdim=lbsy.nf+lbsy.nc+lbsy.nt;
    
  if(lbsy.nt==1) {
    switch (prop) {
      case 22:
        fD3Q27TPS(lbtopt, uwall[0], uwall[1], uwall[2], &lbf[spos], &lbf[spos+1*qdim],
                  &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim], &lbf[spos+6*qdim],
                  &lbf[spos+7*qdim], &lbf[spos+8*qdim], &lbf[spos+9*qdim], &lbf[spos+10*qdim], &lbf[spos+11*qdim],
                  &lbf[spos+12*qdim], &lbf[spos+13*qdim], &lbf[spos+14*qdim], &lbf[spos+15*qdim], &lbf[spos+16*qdim],
                  &lbf[spos+17*qdim], &lbf[spos+18*qdim], &lbf[spos+19*qdim], &lbf[spos+20*qdim], &lbf[spos+21*qdim],
                  &lbf[spos+22*qdim], &lbf[spos+23*qdim], &lbf[spos+24*qdim], &lbf[spos+25*qdim], &lbf[spos+26*qdim]);
        break;
      case 21:
        fD3Q27TPS(lbbott, uwall[0], -uwall[1], uwall[2], &lbf[spos], &lbf[spos+1*qdim],
                  &lbf[spos+15*qdim], &lbf[spos+3*qdim], &lbf[spos+5*qdim], &lbf[spos+4*qdim], &lbf[spos+6*qdim],
                  &lbf[spos+7*qdim], &lbf[spos+22*qdim], &lbf[spos+21*qdim], &lbf[spos+12*qdim], &lbf[spos+13*qdim],
                  &lbf[spos+10*qdim], &lbf[spos+11*qdim], &lbf[spos+14*qdim], &lbf[spos+2*qdim], &lbf[spos+16*qdim],
                  &lbf[spos+18*qdim], &lbf[spos+17*qdim], &lbf[spos+19*qdim], &lbf[spos+20*qdim], &lbf[spos+9*qdim],
                  &lbf[spos+8*qdim], &lbf[spos+25*qdim], &lbf[spos+26*qdim], &lbf[spos+23*qdim], &lbf[spos+24*qdim]);
        break;
      case 23:
        fD3Q27TPS(lbrigt, uwall[1], uwall[0], uwall[2], &lbf[spos], &lbf[spos+2*qdim],
                  &lbf[spos+1*qdim], &lbf[spos+3*qdim], &lbf[spos+4*qdim], &lbf[spos+18*qdim], &lbf[spos+8*qdim],
                  &lbf[spos+9*qdim], &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+10*qdim], &lbf[spos+11*qdim],
                  &lbf[spos+26*qdim], &lbf[spos+25*qdim], &lbf[spos+15*qdim], &lbf[spos+14*qdim], &lbf[spos+16*qdim],
                  &lbf[spos+17*qdim], &lbf[spos+5*qdim], &lbf[spos+21*qdim], &lbf[spos+22*qdim], &lbf[spos+19*qdim],
                  &lbf[spos+20*qdim], &lbf[spos+23*qdim], &lbf[spos+24*qdim], &lbf[spos+13*qdim], &lbf[spos+12*qdim]);
        break;
      case 24:
        fD3Q27TPS(lbleft, uwall[1], -uwall[0], uwall[2], &lbf[spos], &lbf[spos+2*qdim],
                  &lbf[spos+14*qdim], &lbf[spos+3*qdim], &lbf[spos+18*qdim], &lbf[spos+4*qdim], &lbf[spos+8*qdim],
                  &lbf[spos+9*qdim], &lbf[spos+20*qdim], &lbf[spos+19*qdim], &lbf[spos+26*qdim], &lbf[spos+25*qdim],
                  &lbf[spos+10*qdim], &lbf[spos+11*qdim], &lbf[spos+15*qdim], &lbf[spos+1*qdim], &lbf[spos+16*qdim],
                  &lbf[spos+5*qdim], &lbf[spos+17*qdim], &lbf[spos+21*qdim], &lbf[spos+22*qdim], &lbf[spos+7*qdim],
                  &lbf[spos+6*qdim], &lbf[spos+13*qdim], &lbf[spos+12*qdim], &lbf[spos+23*qdim], &lbf[spos+24*qdim]);
        break;
      case 25:
        fD3Q27TPS(lbbact, uwall[0], -uwall[2], uwall[2], &lbf[spos], &lbf[spos+1*qdim],
                  &lbf[spos+16*qdim], &lbf[spos+2*qdim], &lbf[spos+7*qdim], &lbf[spos+6*qdim], &lbf[spos+4*qdim],
                  &lbf[spos+5*qdim], &lbf[spos+9*qdim], &lbf[spos+21*qdim], &lbf[spos+11*qdim], &lbf[spos+13*qdim],
                  &lbf[spos+10*qdim], &lbf[spos+12*qdim], &lbf[spos+14*qdim], &lbf[spos+3*qdim], &lbf[spos+15*qdim],
                  &lbf[spos+20*qdim], &lbf[spos+19*qdim], &lbf[spos+17*qdim], &lbf[spos+18*qdim], &lbf[spos+22*qdim],
                  &lbf[spos+8*qdim], &lbf[spos+24*qdim], &lbf[spos+26*qdim], &lbf[spos+23*qdim], &lbf[spos+25*qdim]);
        break;
      case 26:
        fD3Q27TPS(lbfrot, uwall[0], uwall[2], uwall[1], &lbf[spos], &lbf[spos+1*qdim],
                  &lbf[spos+3*qdim], &lbf[spos+2*qdim], &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+4*qdim],
                  &lbf[spos+5*qdim], &lbf[spos+8*qdim], &lbf[spos+22*qdim], &lbf[spos+10*qdim], &lbf[spos+12*qdim],
                  &lbf[spos+11*qdim], &lbf[spos+13*qdim], &lbf[spos+14*qdim], &lbf[spos+16*qdim], &lbf[spos+15*qdim],
                  &lbf[spos+19*qdim], &lbf[spos+20*qdim], &lbf[spos+17*qdim], &lbf[spos+18*qdim], &lbf[spos+21*qdim],
                  &lbf[spos+9*qdim], &lbf[spos+23*qdim], &lbf[spos+25*qdim], &lbf[spos+24*qdim], &lbf[spos+26*qdim]);
        break;
      case 27:
        fD3Q27TCE(lbbott, uwall, &lbf[spos]);
        break;
      case 28:
        fD3Q27TCE(lbbott, uwall, &lbf[spos]);
        break;
      case 29:
        fD3Q27TCE(lbtopt, uwall, &lbf[spos]);
        break;
      case 30:
        fD3Q27TCE(lbtopt, uwall, &lbf[spos]);
        break;
      case 31:
        fD3Q27TCE(lbbott, uwall, &lbf[spos]);
        break;
      case 32:
        fD3Q27TCE(lbbott, uwall, &lbf[spos]);
        break;
      case 33:
        fD3Q27TCE(lbtopt, uwall, &lbf[spos]);
        break;
      case 34:
        fD3Q27TCE(lbtopt, uwall, &lbf[spos]);
        break;
      case 43:
        fD3Q27TCE(lbbott, uwall, &lbf[spos]);
        break;
      case 44:
        fD3Q27TCE(lbbott, uwall, &lbf[spos]);
        break;
      case 45:
        fD3Q27TCE(lbtopt, uwall, &lbf[spos]);
        break;
      case 46:
        fD3Q27TCE(lbtopt, uwall, &lbf[spos]);
        break;
      case 47:
        fD3Q27TCE(lbbott, uwall, &lbf[spos]);
        break;
      case 48:
        fD3Q27TCE(lbrigt, uwall, &lbf[spos]);
        break;
      case 49:
        fD3Q27TCE(lbtopt, uwall, &lbf[spos]);
        break;
      case 50:
        fD3Q27TCE(lbleft, uwall, &lbf[spos]);
        break;
      case 51:
        fD3Q27TCE(lbbott, uwall, &lbf[spos]);
        break;
      case 52:
        fD3Q27TCE(lbrigt, uwall, &lbf[spos]);
        break;
      case 53:
        fD3Q27TCE(lbtopt, uwall, &lbf[spos]);
        break;
      case 54:
        fD3Q27TCE(lbleft, uwall, &lbf[spos]);
        break;
    }
  }
  return 0;  
}


int fFixedSpeedFluid(long tpos, int prop, double *uwall)
{

  // produce boundary with fixed speed

  if(lbsy.nq == 9)
    fD2Q9VF(tpos, prop, uwall); 
  else if(lbsy.nq == 15)
    fD3Q15VF(tpos, prop, uwall);
  else if(lbsy.nq == 19)
    fD3Q19VF(tpos, prop, uwall);
  else if(lbsy.nq == 27)
    fD3Q27VF(tpos, prop, uwall);
  else if(lbdm.rank ==0) {
    cout << "the boundary condition for D" << lbsy.nd << "Q" << lbsy.nq
         << " model has not been defined" << endl;
    if(lbsy.nd == 2)
      cout << "the D2Q9 model can be used" << endl;
    else
      cout << "the D3Q15, D3Q19 or D3Q27 models can be used" << endl;
    exit(1);
  }
  
  return 0;
}

int fFixedDensityFluid(long tpos, int prop, double *uwall)
{

  // produce boundary with fixed density/pressure
  
  if(lbsy.nq == 9)
    fD2Q9PF(tpos, prop, uwall);
  else if(lbsy.nq == 15)
    fD3Q15PF(tpos, prop, uwall);
  else if(lbsy.nq == 19)
    fD3Q19PF(tpos, prop, uwall);
  else if(lbsy.nq == 27)
    fD3Q27PF(tpos, prop, uwall);
  else if(lbdm.rank ==0) {
    cout << "the boundary condition for D" << lbsy.nd << "Q" << lbsy.nq
         << " model has not been defined" << endl;
    if(lbsy.nd == 2)
      cout << "the D2Q9 model can be used" << endl;
    else
      cout << "the D3Q15, D3Q19 or D3Q27 models can be used" << endl;
    exit(1);
  }
  
  return 0;
}

int fFixedSoluteConcen(long tpos, int prop, double *uwall)
{

  // produce boundary with fixed solute concentration
  
  if(lbsy.nq == 9)
    fD2Q9PC(tpos, prop, uwall);
  else if(lbsy.nq == 15)
    fD3Q15PC(tpos, prop, uwall);
  else if(lbsy.nq == 19)
    fD3Q19PC(tpos, prop, uwall);
  else if(lbsy.nq == 27)
    fD3Q27PC(tpos, prop, uwall);
  else if(lbdm.rank ==0) {
    cout << "the boundary condition for D" << lbsy.nd << "Q" << lbsy.nq
         << " model has not been defined" << endl;
    if(lbsy.nd == 2)
      cout << "the D2Q9 model can be used" << endl;
    else
      cout << "the D3Q15, D3Q19 or D3Q27 models can be used" << endl;
    exit(1);
  }
  return 0;
}

int fFixedTemperature(long tpos, int prop, double *uwall)
{

  // produce boundary with fixed temperature
  
  if(lbsy.nq == 9)
    fD2Q9PT(tpos, prop, uwall);
  else if(lbsy.nq == 15)
    fD3Q15PT(tpos, prop, uwall);
  else if(lbsy.nq == 19)
    fD3Q19PT(tpos, prop, uwall);
  else if(lbsy.nq == 27)
    fD3Q27PT(tpos, prop, uwall);
  else if(lbdm.rank ==0) {
    cout << "the boundary condition for D" << lbsy.nd << "Q" << lbsy.nq
         << " model has not been defined" << endl;
    if(lbsy.nd == 2)
      cout << "the D2Q9 model can be used" << endl;
    else
      cout << "the D3Q15, D3Q19 or D3Q27 models can be used" << endl;
    exit(1);
  }
  return 0;
}

int fPostCollBoundary()
{
  for(long il=0; il<lbdm.touter; il++){
    if(lbphi[il] == 13) {
      fMidBounceBackF(il);
      fMidBounceBackC(il);
      fMidBounceBackT(il);
    }
  }    
  return 0;
}

int fPostPropBoundary()
{
  int a3, a12;
  double uw[3];
  if(lbsy.nt == 1) {
    lbinit += lbsysdt * lbdt;
    lbtopt += lbtopdt * lbdt;
    lbbott += lbbotdt * lbdt;
    lbfrot += lbfrodt * lbdt;
    lbbact += lbbacdt * lbdt;
    lbleft += lblefdt * lbdt;
    lbrigt += lbrigdt * lbdt;
  }
  for(long il=0; il<lbdm.touter; il++){
    if(lbphi[il] == 0) ;
    else if(lbphi[il] == 10);
    else if(lbphi[il] == 11) {
      fSiteBlankF(il);
      fSiteBlankC(il);
      fSiteBlankT(il); 
    }
    else if(lbphi[il] == 12) {
      fBounceBackF(il);
      fBounceBackC(il);
      fBounceBackT(il);
    }
    else if(lbphi[il] == 13);
    else if (lbphi[il]>110 && lbphi[il]<890) {
      a12 = lbphi[il] % 100;
      a3=lbphi[il]/100;
      if(a3 == 1) {
        fFixedSpeedFluid(il, a12, uw);
	    fFixedSoluteConcen(il, a12, uw);
	    fFixedTemperature(il, a12, uw);
      }
      else if(a3 == 2) {
	    fFixedSpeedFluid(il, a12, uw);
	    fFixedSoluteConcen(il, a12, uw);
	    fBounceBackT(il);
      }
      else if(a3 == 3) {
	    fFixedSpeedFluid(il, a12, uw);
	    fBounceBackC(il);
	    fFixedTemperature(il, a12, uw);
      }
      else if(a3 == 4) {
	    fFixedSpeedFluid(il, a12, uw);
	    fBounceBackC(il);
	    fBounceBackT(il);
      }
      else if(a3 == 5) {
	    fFixedDensityFluid(il, a12, uw);
	    fFixedSoluteConcen(il, a12, uw);
	    fFixedTemperature(il, a12, uw);
      } 
      else if(a3 == 6) {
	    fFixedDensityFluid(il, a12, uw);
	    fFixedSoluteConcen(il, a12, uw);
	    fBounceBackT(il);
      }
      else if(a3 == 7) {
	    fFixedDensityFluid(il, a12, uw);
	    fBounceBackC(il);
	    fFixedTemperature(il, a12, uw);
      }
      else if(a3 == 8) {
	    fFixedDensityFluid(il, a12, uw);
	    fBounceBackC(il);
	    fBounceBackT(il);
      }
    }
    else {
      if(lbdm.rank == 0)
	cout << "error: boundary condition not recognised" << endl;
      exit(1);
    }
  }
  return 0;
}

int fNeighbourBoundary()
{
  int test, testphi, xpos, ypos, zpos, xneigh, yneigh, zneigh, xm, xp, ym, yp, zm, zp;
    
  for(long il=0; il<lbdm.touter; il++) {
    fGetCoord(il, xpos, ypos, zpos);
    lbneigh[il] = 0;
    xneigh = 0;
    yneigh = 0;
    zneigh = 0;
    if(lbphi[il]>100) {
      testphi = lbphi[il] % 100;
      if((testphi>34 && testphi<43) || (testphi>54 && testphi<67)) {
        xneigh = 1; yneigh = 1; zneigh = 1;
      }
      else {
        if(lbsy.nd==3) {
          switch (testphi) {
            case 21:
              yp = lbphi[fNextStep(0, 2, 0, il)];
              xneigh = 1;
              yneigh = (yp>10 || lbgradord==1)?2:3;
              zneigh = 1;
              break;
            case 22:
              ym = lbphi[fNextStep(0, -2, 0, il)];
              xneigh = 1;
              yneigh = (ym>10 || lbgradord==1)?4:5;
              zneigh = 1;
              break;
            case 23:
              xm = lbphi[fNextStep(0, -2, 0, il)];
              xneigh = (xm>10 || lbgradord==1)?2:3;
              yneigh = 1;
              zneigh = 1;
              break;
            case 24:
              xp = lbphi[fNextStep(0, 2, 0, il)];
              xneigh = (xp>10 || lbgradord==1)?4:5;
              yneigh = 1;
              zneigh = 1;
              break;
            case 25:
              zm = lbphi[fNextStep(0, 0, -2, il)];
              xneigh = 1;
              yneigh = 1;
              zneigh = (zm>10 || lbgradord==1)?2:3;
              break;
            case 26:
              zp = lbphi[fNextStep(0, 0, 2, il)];
              xneigh = 1;
              yneigh = 1;
              zneigh = (zp>10 || lbgradord==1)?4:5;
              break;
            case 27:
              xp = lbphi[fNextStep(2, 0, 0, il)];
              yp = lbphi[fNextStep(0, 2, 0, il)];
              zm = lbphi[fNextStep(0, 0, -2, il)];
              xneigh = (xp>10 || lbgradord==1)?2:3;
              yneigh = (yp>10 || lbgradord==1)?2:3;
              zneigh = (zm>10 || lbgradord==1)?4:5;
              break;
            case 28:
              xm = lbphi[fNextStep(-2, 0, 0, il)];
              yp = lbphi[fNextStep(0, 2, 0, il)];
              zm = lbphi[fNextStep(0, 0, -2, il)];
              xneigh = (xm>10 || lbgradord==1)?4:5;
              yneigh = (yp>10 || lbgradord==1)?2:3;
              zneigh = (zm>10 || lbgradord==1)?4:5;
              break;
            case 29:
              xm = lbphi[fNextStep(-2, 0, 0, il)];
              ym = lbphi[fNextStep(0, -2, 0, il)];
              zm = lbphi[fNextStep(0, 0, -2, il)];
              xneigh = (xm>10 || lbgradord==1)?4:5;
              yneigh = (ym>10 || lbgradord==1)?4:5;
              zneigh = (zm>10 || lbgradord==1)?4:5;
              break;
            case 30:
              xp = lbphi[fNextStep(2, 0, 0, il)];
              ym = lbphi[fNextStep(0, -2, 0, il)];
              zm = lbphi[fNextStep(0, 0, -2, il)];
              xneigh = (xp>10 || lbgradord==1)?2:3;
              yneigh = (ym>10 || lbgradord==1)?4:5;
              zneigh = (zm>10 || lbgradord==1)?4:5;
              break;
            case 31:
              xp = lbphi[fNextStep(2, 0, 0, il)];
              yp = lbphi[fNextStep(0, 2, 0, il)];
              zp = lbphi[fNextStep(0, 0, 2, il)];
              xneigh = (xp>10 || lbgradord==1)?2:3;
              yneigh = (yp>10 || lbgradord==1)?2:3;
              zneigh = (zp>10 || lbgradord==1)?2:3;
              break;
            case 32:
              xm = lbphi[fNextStep(-2, 0, 0, il)];
              yp = lbphi[fNextStep(0, 2, 0, il)];
              zp = lbphi[fNextStep(0, 0, 2, il)];
              xneigh = (xm>10 || lbgradord==1)?4:5;
              yneigh = (yp>10 || lbgradord==1)?2:3;
              zneigh = (zp>10 || lbgradord==1)?2:3;
              break;
            case 33:
              xm = lbphi[fNextStep(-2, 0, 0, il)];
              ym = lbphi[fNextStep(0, -2, 0, il)];
              zp = lbphi[fNextStep(0, 0, 2, il)];
              xneigh = (xm>10 || lbgradord==1)?4:5;
              yneigh = (ym>10 || lbgradord==1)?4:5;
              zneigh = (zp>10 || lbgradord==1)?2:3;
              break;
            case 34:
              xp = lbphi[fNextStep(2, 0, 0, il)];
              ym = lbphi[fNextStep(0, -2, 0, il)];
              zp = lbphi[fNextStep(0, 0, 2, il)];
              xneigh = (xp>10 || lbgradord==1)?2:3;
              yneigh = (ym>10 || lbgradord==1)?4:5;
              zneigh = (zp>10 || lbgradord==1)?2:3;
              break;
            case 43:
              xp = lbphi[fNextStep(2, 0, 0, il)];
              yp = lbphi[fNextStep(0, 2, 0, il)];
              xneigh = (xp>10 || lbgradord==1)?2:3;
              yneigh = (yp>10 || lbgradord==1)?2:3;
              zneigh = 1;
              break;
            case 44:
              xm = lbphi[fNextStep(-2, 0, 0, il)];
              yp = lbphi[fNextStep(0, 2, 0, il)];
              xneigh = (xm>10 || lbgradord==1)?4:5;
              yneigh = (yp>10 || lbgradord==1)?2:3;
              zneigh = 1;
              break;
            case 45:
              xm = lbphi[fNextStep(-2, 0, 0, il)];
              ym = lbphi[fNextStep(0, -2, 0, il)];
              xneigh = (xm>10 || lbgradord==1)?4:5;
              yneigh = (ym>10 || lbgradord==1)?4:5;
              zneigh = 1;
              break;
            case 46:
              xp = lbphi[fNextStep(2, 0, 0, il)];
              ym = lbphi[fNextStep(0, -2, 0, il)];
              xneigh = (xp>10 || lbgradord==1)?2:3;
              yneigh = (ym>10 || lbgradord==1)?4:5;
              zneigh = 1;
              break;
            case 47:
              yp = lbphi[fNextStep(0, 2, 0, il)];
              zp = lbphi[fNextStep(0, 0, 2, il)];
              xneigh = 1;
              yneigh = (yp>10 || lbgradord==1)?2:3;
              zneigh = (zp>10 || lbgradord==1)?2:3;
              break;
            case 48:
              xm = lbphi[fNextStep(-2, 0, 0, il)];
              zp = lbphi[fNextStep(0, 0, 2, il)];
              xneigh = (xm>10 || lbgradord==1)?4:5;
              yneigh = 1;
              zneigh = (zp>10 || lbgradord==1)?2:3;
              break;
            case 49:
              ym = lbphi[fNextStep(0, -2, 0, il)];
              zp = lbphi[fNextStep(0, 0, 2, il)];
              xneigh = 1;
              yneigh = (ym>10 || lbgradord==1)?4:5;
              zneigh = (zp>10 || lbgradord==1)?2:3;
              break;
            case 50:
              xp = lbphi[fNextStep(2, 0, 0, il)];
              zp = lbphi[fNextStep(0, 0, 2, il)];
              xneigh = (xp>10 || lbgradord==1)?2:3;
              yneigh = 1;
              zneigh = (zp>10 || lbgradord==1)?2:3;
              break;
            case 51:
              yp = lbphi[fNextStep(0, 2, 0, il)];
              zm = lbphi[fNextStep(0, 0, -2, il)];
              xneigh = 1;
              yneigh = (yp>10 || lbgradord==1)?2:3;
              zneigh = (zm>10 || lbgradord==1)?4:5;
              break;
            case 52:
              xm = lbphi[fNextStep(-2, 0, 0, il)];
              zm = lbphi[fNextStep(0, 0, -2, il)];
              xneigh = (xm>10 || lbgradord==1)?4:5;
              yneigh = 1;
              zneigh = (zm>10 || lbgradord==1)?4:5;
              break;
            case 53:
              ym = lbphi[fNextStep(0, -2, 0, il)];
              zm = lbphi[fNextStep(0, 0, -2, il)];
              xneigh = 1;
              yneigh = (ym>10 || lbgradord==1)?4:5;
              zneigh = (zm>10 || lbgradord==1)?4:5;
              break;
            case 54:
              xp = lbphi[fNextStep(2, 0, 0, il)];
              zm = lbphi[fNextStep(0, 0, -2, il)];
              xneigh = (xp>10 || lbgradord==1)?2:3;
              yneigh = 1;
              zneigh = (zm>10 || lbgradord==1)?4:5;
              break;
          }
        }
        else {
          switch (testphi) {
            case 31:
              xp = lbphi[fNextStep(2, 0, 0, il)];
              yp = lbphi[fNextStep(0, 2, 0, il)];
              xneigh = (xp>10 || lbgradord==1)?2:3;
              yneigh = (yp>10 || lbgradord==1)?2:3;
              zneigh = 1;
              break;
            case 32:
              xm = lbphi[fNextStep(-2, 0, 0, il)];
              yp = lbphi[fNextStep(0, 2, 0, il)];
              xneigh = (xm>10 || lbgradord==1)?4:5;
              yneigh = (yp>10 || lbgradord==1)?2:3;
              zneigh = 1;
              break;
            case 33:
              xm = lbphi[fNextStep(-2, 0, 0, il)];
              ym = lbphi[fNextStep(0, -2, 0, il)];
              xneigh = (xm>10 || lbgradord==1)?4:5;
              yneigh = (ym>10 || lbgradord==1)?4:5;
              zneigh = 1;
              break;
            case 34:
              xp = lbphi[fNextStep(2, 0, 0, il)];
              ym = lbphi[fNextStep(0, -2, 0, il)];
              xneigh = (xp>10 || lbgradord==1)?2:3;
              yneigh = (ym>10 || lbgradord==1)?4:5;
              zneigh = 1;
              break;
            case 47:
              yp = lbphi[fNextStep(0, 2, 0, il)];
              xneigh = 1;
              yneigh = (yp>10 || lbgradord==1)?2:3;
              zneigh = 1;
              break;
            case 48:
              xm = lbphi[fNextStep(-2, 0, 0, il)];
              xneigh = (xm>10 || lbgradord==1)?4:5;
              yneigh = 1;
              zneigh = 1;
              break;
            case 49:
              ym = lbphi[fNextStep(0, -2, 0, il)];
              xneigh = 1;
              yneigh = (ym>10 || lbgradord==1)?4:5;
              zneigh = 1;
              break;
            case 50:
              xp = lbphi[fNextStep(2, 0, 0, il)];
              xneigh = (xp>10 || lbgradord==1)?2:3;
              yneigh = 1;
              zneigh = 1;
              break;
          }
        }
      }
    }
    else {
      if(interact==5) {
        testphi = 0;
        xm = lbphi[fNextStep(-1, -1, -1, il)];
        testphi += (xm>10 && xm<100);
        xm = lbphi[fNextStep(-1, -1,  1, il)];
        testphi += (xm>10 && xm<100);
        xm = lbphi[fNextStep(-1,  1,  1, il)];
        testphi += (xm>10 && xm<100);
        xm = lbphi[fNextStep(-1,  1, -1, il)];
        testphi += (xm>10 && xm<100);
        xm = lbphi[fNextStep( 1, -1, -1, il)];
        testphi += (xm>10 && xm<100);
        xm = lbphi[fNextStep( 1, -1,  1, il)];
        testphi += (xm>10 && xm<100);
        xm = lbphi[fNextStep( 1,  1,  1, il)];
        testphi += (xm>10 && xm<100);
        xm = lbphi[fNextStep( 1,  1, -1, il)];
        testphi += (xm>10 && xm<100);
        xm = lbphi[fNextStep(-1, -1,  0, il)];
        testphi += (xm>10 && xm<100);
        xm = lbphi[fNextStep(-1,  1,  0, il)];
        testphi += (xm>10 && xm<100);
        xm = lbphi[fNextStep( 1, -1,  0, il)];
        testphi += (xm>10 && xm<100);
        xm = lbphi[fNextStep( 1,  1,  0, il)];
        testphi += (xm>10 && xm<100);
        xm = lbphi[fNextStep(-1,  0, -1, il)];
        testphi += (xm>10 && xm<100);
        xm = lbphi[fNextStep(-1,  0,  1, il)];
        testphi += (xm>10 && xm<100);
        xm = lbphi[fNextStep( 1,  0, -1, il)];
        testphi += (xm>10 && xm<100);
        xm = lbphi[fNextStep( 1,  0,  1, il)];
        testphi += (xm>10 && xm<100);
        xm = lbphi[fNextStep( 0, -1, -1, il)];
        testphi += (xm>10 && xm<100);
        xm = lbphi[fNextStep( 0, -1,  1, il)];
        testphi += (xm>10 && xm<100);
        xm = lbphi[fNextStep( 0,  1, -1, il)];
        testphi += (xm>10 && xm<100);
        xm = lbphi[fNextStep( 0,  1,  1, il)];
        testphi += (xm>10 && xm<100);
        if(testphi>0) {
          xneigh = 1; yneigh = 1; zneigh = 1;
        }
        xm = lbphi[fNextStep(-1,  0,  0, il)];
        xp = lbphi[fNextStep( 1,  0,  0, il)];
        ym = lbphi[fNextStep( 0, -1,  0, il)];
        yp = lbphi[fNextStep( 0,  1,  0, il)];
        zm = lbphi[fNextStep( 0,  0, -1, il)];
        zp = lbphi[fNextStep( 0,  0,  1, il)];
        if(xm>10 && xm<100 && xp>10 && xp<100)
          xneigh = 6;
        else if(xm>10 && xm<100) {
          testphi = lbphi[fNextStep(2, 0, 0, il)];
          xneigh = (testphi>10 && testphi<100 || lbgradord==1)?2:3;
        }
        else if(xp>10 && xp<100) {
          testphi = lbphi[fNextStep(-2, 0, 0, il)];
          xneigh = (testphi>10 && testphi<100 || lbgradord==1)?4:5;
        }
        if(ym>10 && ym<100 && yp>10 && yp<100)
          yneigh = 6;
        else if(ym>10 && ym<100) {
          testphi = lbphi[fNextStep(0, 2, 0, il)];
          yneigh = (testphi>10 && testphi<100 || lbgradord==1)?2:3;
        }
        else if(yp>10 && yp<100) {
          testphi = lbphi[fNextStep(0, -2, 0, il)];
          yneigh = (testphi>10 && testphi<100 || lbgradord==1)?4:5;
        }
        if(lbsy.nd>2) {
          if(zm>10 && zm<100 && zp>10 && zp<100)
            zneigh = 6;
          else if(zm>10 && zm<100) {
            testphi = lbphi[fNextStep(0, 0, 2, il)];
            zneigh = (testphi>10 && testphi<100  || lbgradord==1)?2:3;
          }
          else if(zp>10 && zp<100) {
            testphi = lbphi[fNextStep(0, 0, -2, il)];
            zneigh = (testphi>10 && testphi<100 || lbgradord==1)?4:5;
          }
        }
      }
      else {
        testphi = 0;
        xm = lbphi[fNextStep(-1, -1, -1, il)];
        testphi += (xm>10);
        xm = lbphi[fNextStep(-1, -1,  1, il)];
        testphi += (xm>10);
        xm = lbphi[fNextStep(-1,  1,  1, il)];
        testphi += (xm>10);
        xm = lbphi[fNextStep(-1,  1, -1, il)];
        testphi += (xm>10);
        xm = lbphi[fNextStep( 1, -1, -1, il)];
        testphi += (xm>10);
        xm = lbphi[fNextStep( 1, -1,  1, il)];
        testphi += (xm>10);
        xm = lbphi[fNextStep( 1,  1,  1, il)];
        testphi += (xm>10);
        xm = lbphi[fNextStep( 1,  1, -1, il)];
        testphi += (xm>10);
        xm = lbphi[fNextStep(-1, -1,  0, il)];
        testphi += (xm>10);
        xm = lbphi[fNextStep(-1,  1,  0, il)];
        testphi += (xm>10);
        xm = lbphi[fNextStep( 1, -1,  0, il)];
        testphi += (xm>10);
        xm = lbphi[fNextStep( 1,  1,  0, il)];
        testphi += (xm>10);
        xm = lbphi[fNextStep(-1,  0, -1, il)];
        testphi += (xm>10);
        xm = lbphi[fNextStep(-1,  0,  1, il)];
        testphi += (xm>10);
        xm = lbphi[fNextStep( 1,  0, -1, il)];
        testphi += (xm>10);
        xm = lbphi[fNextStep( 1,  0,  1, il)];
        testphi += (xm>10);
        xm = lbphi[fNextStep( 0, -1, -1, il)];
        testphi += (xm>10);
        xm = lbphi[fNextStep( 0, -1,  1, il)];
        testphi += (xm>10);
        xm = lbphi[fNextStep( 0,  1, -1, il)];
        testphi += (xm>10);
        xm = lbphi[fNextStep( 0,  1,  1, il)];
        testphi += (xm>10);
        if(testphi>0) {
          xneigh = 1; yneigh = 1; zneigh = 1;
        }
        xm = lbphi[fNextStep(-1,  0,  0, il)];
        xp = lbphi[fNextStep( 1,  0,  0, il)];
        ym = lbphi[fNextStep( 0, -1,  0, il)];
        yp = lbphi[fNextStep( 0,  1,  0, il)];
        zm = lbphi[fNextStep( 0,  0, -1, il)];
        zp = lbphi[fNextStep( 0,  0,  1, il)];
        if(xm>10 && xp>10)
          xneigh = 6;
        else if(xm>10) {
          testphi = lbphi[fNextStep(2, 0, 0, il)];
          xneigh = (testphi>10 || lbgradord==1)?2:3;
        }
        else if(xp>10) {
          testphi = lbphi[fNextStep(-2, 0, 0, il)];
          xneigh = (testphi>10 || lbgradord==1)?4:5;
        }
        if(ym>10 && yp>10)
          yneigh = 6;
        else if(ym>10) {
          testphi = lbphi[fNextStep(0, 2, 0, il)];
          yneigh = (testphi>10 || lbgradord==1)?2:3;
        }
        else if(yp>10) {
          testphi = lbphi[fNextStep(0, -2, 0, il)];
          yneigh = (testphi>10 || lbgradord==1)?4:5;
        }
        if(lbsy.nd>2) {
          if(zm>10 && zp>10)
            zneigh = 6;
          else if(zm>10) {
            testphi = lbphi[fNextStep(0, 0, 2, il)];
            zneigh = (testphi>10 || lbgradord==1)?2:3;
          }
          else if(zp>10) {
            testphi = lbphi[fNextStep(0, 0, -2, il)];
            zneigh = (testphi>10 || lbgradord==1)?4:5;
          }
        }
      }
      if(xneigh>0) {
        if(yneigh==0)
          yneigh = 1;
        if(zneigh==0)
          zneigh = 1;
      }
      if(yneigh>0) {
        if(xneigh==0)
          xneigh = 1;
        if(zneigh==0)
          zneigh = 1;
      }
      if(zneigh>0) {
        if(xneigh==0)
          xneigh = 1;
        if(yneigh==0)
          yneigh = 1;
      }
    }
    lbneigh[il] = 100 * xneigh + 10 * yneigh + zneigh;
  }
  return 0;
}

int fsPeriodic()
{
  // apply periodic boundary condition on distribution functions for either 2D or 3D system

  if(lbsy.nd == 2)
    fsPeriodic2D();
  else
    fsPeriodic3D();
  return 0;
}

int fsBoundPeriodic()
{
  // apply periodic boundary condition on space properties for either 2D or 3D system

  if(lbsy.nd == 2)
    fsBoundPeriodic2D();
  else
    fsBoundPeriodic3D();
  return 0;
}

int fsForcePeriodic()
{
  // apply periodic boundary condition on forces for either 2D or 3D system

  if(lbsy.nd == 2)
    fsForcePeriodic2D();
  else
    fsForcePeriodic3D();
  return 0;
}

int fsIndexPeriodic()
{
  // apply periodic boundary condition on phase indices for either 2D or 3D system

  if(lbsy.nd == 2)
    fsIndexPeriodic2D();
  else
    fsIndexPeriodic3D();
  return 0;
}

int fsPeriodic2D()
{
  // apply periodic boundary condition for 2D systems with boundary layer points
  unsigned long i, j, ipos, jpos;

  for (i=0; i<lbdm.bwid; i++) {
    ipos = (i*lbdm.youter+lbdm.bwid) * lbsitelength;
    jpos = ((lbdm.xouter - 2*lbdm.bwid + i) * lbdm.youter + lbdm.bwid) * lbsitelength;
    for (j=0; j<(lbdm.yinner*lbsitelength); j++) {
      lbf[ipos+j] = lbf[jpos+j];
    }
  }

  for (i=0; i<lbdm.bwid; i++) {
    ipos = ((lbdm.xouter - lbdm.bwid + i) * lbdm.youter + lbdm.bwid) * lbsitelength;
    jpos = ((lbdm.bwid + i) * lbdm.youter + lbdm.bwid) * lbsitelength;
    for (j=0; j<(lbdm.yinner*lbsitelength); j++) {
      lbf[ipos+j] = lbf[jpos+j];
    }
  }

  for (i=0; i<lbdm.xouter; i++) {
    ipos = ((i+1)*lbdm.youter - lbdm.bwid) * lbsitelength;
    jpos = (i * lbdm.youter + lbdm.bwid) * lbsitelength;
    for (j=0; j<(lbdm.bwid*lbsitelength); j++) {
      lbf[ipos+j] = lbf[jpos+j];
    }
  }

  for (i=0; i<lbdm.xouter; i++) {
    ipos = i * lbdm.youter * lbsitelength;
    jpos = ((i+1) * lbdm.youter - 2 * lbdm.bwid) * lbsitelength;
    for (j=0; j<(lbdm.bwid*lbsitelength); j++) {
      lbf[ipos+j] = lbf[jpos+j];
    }
  }

  return 0;
}

int fsPeriodic3D()
{
  // apply periodic boundary condition for 3D systems with boundary layer points

  unsigned long i, j, k, ipos, jpos;

  for (i=0; i<lbdm.bwid; i++) 
    for (j=0; j<lbdm.yinner; j++) {
      ipos = ((i * lbdm.youter + lbdm.bwid + j) * lbdm.zouter + lbdm.bwid) * lbsitelength;
      jpos = (((lbdm.xouter - 2*lbdm.bwid + i) * lbdm.youter + lbdm.bwid + j) * lbdm.zouter + lbdm.bwid) * lbsitelength;
      for (k=0; k<(lbdm.zinner*lbsitelength); k++) {
        lbf[ipos+k] = lbf[jpos+k];
      }
    }

  for (i=0; i<lbdm.bwid; i++) 
    for (j=0; j<lbdm.yinner; j++) {
      ipos = (((lbdm.xouter - lbdm.bwid + i) * lbdm.youter + lbdm.bwid + j) * lbdm.zouter + lbdm.bwid) * lbsitelength;
      jpos = (((lbdm.bwid + i) * lbdm.youter + lbdm.bwid + j) * lbdm.zouter + lbdm.bwid) * lbsitelength;
      for (k=0; k<(lbdm.zinner*lbsitelength); k++) {
        lbf[ipos+k] = lbf[jpos+k];
      }
    }

  for (i=0; i<lbdm.xouter; i++) 
    for (j=0; j<lbdm.bwid; j++) {
      ipos = (((i+1) * lbdm.youter - lbdm.bwid + j) * lbdm.zouter + lbdm.bwid) * lbsitelength;
      jpos = ((i * lbdm.youter + lbdm.bwid + j) * lbdm.zouter + lbdm.bwid) * lbsitelength;
      for (k=0; k<(lbdm.zinner*lbsitelength); k++) {
        lbf[ipos+k] = lbf[jpos+k];
      }
    }

  for (i=0; i<lbdm.xouter; i++) 
    for (j=0; j<lbdm.bwid; j++) {
      ipos = ((i * lbdm.youter + j) * lbdm.zouter + lbdm.bwid) * lbsitelength;
      jpos = (((i+1) * lbdm.youter - 2 * lbdm.bwid + j) * lbdm.zouter + lbdm.bwid) * lbsitelength;
      for (k=0; k<(lbdm.zinner*lbsitelength); k++) {
        lbf[ipos+k] = lbf[jpos+k];
      }
    }

  for (i=0; i<lbdm.xouter; i++) 
    for (j=0; j<lbdm.youter; j++) {
      ipos = ((i * lbdm.youter + j) * lbdm.zouter) * lbsitelength;
      jpos = ((i * lbdm.youter + j + 1) * lbdm.zouter - 2 * lbdm.bwid) * lbsitelength;
      for (k=0; k<(lbdm.bwid*lbsitelength); k++) {
        lbf[ipos+k] = lbf[jpos+k];
      }
    }

  for (i=0; i<lbdm.xouter; i++) 
    for (j=0; j<lbdm.youter; j++) {
      ipos = ((i * lbdm.youter + j + 1) * lbdm.zouter - lbdm.bwid) * lbsitelength;
      jpos = ((i * lbdm.youter + j) * lbdm.zouter + lbdm.bwid) * lbsitelength;
      for (k=0; k<(lbdm.bwid*lbsitelength); k++) {
        lbf[ipos+k] = lbf[jpos+k];
      }
    }

  return 0;
}

int fsBoundPeriodic2D()
{
  // apply periodic boundary condition for 2D systems with boundary layer points
  unsigned long i, j, ipos, jpos;

  for (i=0; i<lbdm.bwid; i++) {
    ipos = i * lbdm.youter + lbdm.bwid;
    jpos = (lbdm.xouter - 2*lbdm.bwid + i) * lbdm.youter + lbdm.bwid;
    for (j=0; j<lbdm.yinner; j++) {
      lbphi[ipos+j] = lbphi[jpos+j];
    }
  }

  for (i=0; i<lbdm.bwid; i++) {
    ipos = (lbdm.xouter - lbdm.bwid + i) * lbdm.youter + lbdm.bwid;
    jpos = (lbdm.bwid + i) * lbdm.youter + lbdm.bwid;
    for (j=0; j<lbdm.yinner; j++) {
      lbphi[ipos+j] = lbphi[jpos+j];
    }
  }

  for (i=0; i<lbdm.xouter; i++) {
    ipos = (i+1)*lbdm.youter - lbdm.bwid;
    jpos = i * lbdm.youter + lbdm.bwid;
    for (j=0; j<lbdm.bwid; j++) {
      lbphi[ipos+j] = lbphi[jpos+j];
    }
  }

  for (i=0; i<lbdm.xouter; i++) {
    ipos = i * lbdm.youter;
    jpos = (i+1) * lbdm.youter - 2 * lbdm.bwid;
    for (j=0; j<lbdm.bwid; j++) {
      lbphi[ipos+j] = lbphi[jpos+j];
    }
  }

  return 0;
}

int fsBoundPeriodic3D()
{
  // apply periodic boundary condition for 3D systems with boundary layer points

  unsigned long i, j, k, ipos, jpos;

  for (i=0; i<lbdm.bwid; i++) 
    for (j=0; j<lbdm.yinner; j++) {
      ipos = (i * lbdm.youter + lbdm.bwid + j) * lbdm.zouter + lbdm.bwid;
      jpos = ((lbdm.xouter - 2*lbdm.bwid + i) * lbdm.youter + lbdm.bwid + j) * lbdm.zouter + lbdm.bwid;
      for (k=0; k<lbdm.zinner; k++) {
        lbphi[ipos+k] = lbphi[jpos+k];
      }
    }

  for (i=0; i<lbdm.bwid; i++) 
    for (j=0; j<lbdm.yinner; j++) {
      ipos = ((lbdm.xouter - lbdm.bwid + i) * lbdm.youter + lbdm.bwid + j) * lbdm.zouter + lbdm.bwid;
      jpos = ((lbdm.bwid + i) * lbdm.youter + lbdm.bwid + j) * lbdm.zouter + lbdm.bwid;
      for (k=0; k<lbdm.zinner; k++) {
        lbphi[ipos+k] = lbphi[jpos+k];
      }
    }

  for (i=0; i<lbdm.xouter; i++) 
    for (j=0; j<lbdm.bwid; j++) {
      ipos = ((i+1) * lbdm.youter - lbdm.bwid + j) * lbdm.zouter + lbdm.bwid;
      jpos = (i * lbdm.youter + lbdm.bwid + j) * lbdm.zouter + lbdm.bwid;
      for (k=0; k<lbdm.zinner; k++) {
        lbphi[ipos+k] = lbphi[jpos+k];
      }
    }

  for (i=0; i<lbdm.xouter; i++) 
    for (j=0; j<lbdm.bwid; j++) {
      ipos = (i * lbdm.youter + j) * lbdm.zouter + lbdm.bwid;
      jpos = ((i+1) * lbdm.youter - 2 * lbdm.bwid + j) * lbdm.zouter + lbdm.bwid;
      for (k=0; k<lbdm.zinner; k++) {
        lbphi[ipos+k] = lbphi[jpos+k];
      }
    }

  for (i=0; i<lbdm.xouter; i++) 
    for (j=0; j<lbdm.youter; j++) {
      ipos = (i * lbdm.youter + j) * lbdm.zouter;
      jpos = (i * lbdm.youter + j + 1) * lbdm.zouter - 2 * lbdm.bwid;
      for (k=0; k<lbdm.bwid; k++) {
        lbphi[ipos+k] = lbphi[jpos+k];
      }
    }

  for (i=0; i<lbdm.xouter; i++) 
    for (j=0; j<lbdm.youter; j++) {
      ipos = (i * lbdm.youter + j + 1) * lbdm.zouter - lbdm.bwid;
      jpos = (i * lbdm.youter + j) * lbdm.zouter + lbdm.bwid;
      for (k=0; k<lbdm.bwid; k++) {
        lbphi[ipos+k] = lbphi[jpos+k];
      }
    }

  return 0;
}

int fsForcePeriodic2D()
{
  // apply periodic boundary condition for 2D systems with boundary layer points
  unsigned long i, j, ipos, jpos;

  for (i=0; i<lbdm.bwid; i++) {
    ipos = (i*lbdm.youter+lbdm.bwid) * 3;
    jpos = ((lbdm.xouter - 2*lbdm.bwid + i) * lbdm.youter + lbdm.bwid) * 3;
    for (j=0; j<(lbdm.yinner*3); j++) {
      lbinterforce[ipos+j] = lbinterforce[jpos+j];
    }
  }

  for (i=0; i<lbdm.bwid; i++) {
    ipos = ((lbdm.xouter - lbdm.bwid + i) * lbdm.youter + lbdm.bwid) * 3;
    jpos = ((lbdm.bwid + i) * lbdm.youter + lbdm.bwid) * 3;
    for (j=0; j<(lbdm.yinner*3); j++) {
      lbinterforce[ipos+j] = lbinterforce[jpos+j];
    }
  }

  for (i=0; i<lbdm.xouter; i++) {
    ipos = ((i+1)*lbdm.youter - lbdm.bwid) * 3;
    jpos = (i * lbdm.youter + lbdm.bwid) * 3;
    for (j=0; j<(lbdm.bwid*3); j++) {
      lbinterforce[ipos+j] = lbinterforce[jpos+j];
    }
  }

  for (i=0; i<lbdm.xouter; i++) {
    ipos = i * lbdm.youter * 3;
    jpos = ((i+1) * lbdm.youter - 2 * lbdm.bwid) * 3;
    for (j=0; j<(lbdm.bwid*3); j++) {
      lbinterforce[ipos+j] = lbinterforce[jpos+j];
    }
  }

  return 0;
}

int fsForcePeriodic3D()
{
  // apply periodic boundary condition for 3D systems with boundary layer points

  unsigned long i, j, k, ipos, jpos;

  for (i=0; i<lbdm.bwid; i++) 
    for (j=0; j<lbdm.yinner; j++) {
      ipos = ((i * lbdm.youter + lbdm.bwid + j) * lbdm.zouter + lbdm.bwid) * 3;
      jpos = (((lbdm.xouter - 2*lbdm.bwid + i) * lbdm.youter + lbdm.bwid + j) * lbdm.zouter + lbdm.bwid) * 3;
      for (k=0; k<(lbdm.zinner*3); k++) {
        lbinterforce[ipos+k] = lbinterforce[jpos+k];
      }
    }

  for (i=0; i<lbdm.bwid; i++) 
    for (j=0; j<lbdm.yinner; j++) {
      ipos = (((lbdm.xouter - lbdm.bwid + i) * lbdm.youter + lbdm.bwid + j) * lbdm.zouter + lbdm.bwid) * 3;
      jpos = (((lbdm.bwid + i) * lbdm.youter + lbdm.bwid + j) * lbdm.zouter + lbdm.bwid) * 3;
      for (k=0; k<(lbdm.zinner*3); k++) {
        lbinterforce[ipos+k] = lbinterforce[jpos+k];
      }
    }

  for (i=0; i<lbdm.xouter; i++) 
    for (j=0; j<lbdm.bwid; j++) {
      ipos = (((i+1) * lbdm.youter - lbdm.bwid + j) * lbdm.zouter + lbdm.bwid) * 3;
      jpos = ((i * lbdm.youter + lbdm.bwid + j) * lbdm.zouter + lbdm.bwid) * 3;
      for (k=0; k<(lbdm.zinner*3); k++) {
        lbinterforce[ipos+k] = lbinterforce[jpos+k];
      }
    }

  for (i=0; i<lbdm.xouter; i++) 
    for (j=0; j<lbdm.bwid; j++) {
      ipos = ((i * lbdm.youter + j) * lbdm.zouter + lbdm.bwid) * 3;
      jpos = (((i+1) * lbdm.youter - 2 * lbdm.bwid + j) * lbdm.zouter + lbdm.bwid) * 3;
      for (k=0; k<(lbdm.zinner*3); k++) {
        lbinterforce[ipos+k] = lbinterforce[jpos+k];
      }
    }

  for (i=0; i<lbdm.xouter; i++) 
    for (j=0; j<lbdm.youter; j++) {
      ipos = ((i * lbdm.youter + j) * lbdm.zouter) * 3;
      jpos = ((i * lbdm.youter + j + 1) * lbdm.zouter - 2 * lbdm.bwid) * 3;
      for (k=0; k<(lbdm.bwid*3); k++) {
        lbinterforce[ipos+k] = lbinterforce[jpos+k];
      }
    }

  for (i=0; i<lbdm.xouter; i++) 
    for (j=0; j<lbdm.youter; j++) {
      ipos = ((i * lbdm.youter + j + 1) * lbdm.zouter - lbdm.bwid) * 3;
      jpos = ((i * lbdm.youter + j) * lbdm.zouter + lbdm.bwid) * 3;
      for (k=0; k<(lbdm.bwid*3); k++) {
        lbinterforce[ipos+k] = lbinterforce[jpos+k];
      }
    }

  return 0;
}

int fsIndexPeriodic2D()
{
  // apply periodic boundary condition for 2D systems with boundary layer points
  unsigned long i, j, ipos, jpos;
  int numpair = 3 * lbsy.nf * (lbsy.nf-1) / 2;

  for (i=0; i<lbdm.bwid; i++) {
    ipos = (i * lbdm.youter + lbdm.bwid) * numpair;
    jpos = ((lbdm.xouter - 2*lbdm.bwid + i) * lbdm.youter + lbdm.bwid) * numpair;
    for (j=0; j<(lbdm.yinner*numpair); j++) {
      lbft[ipos+j] = lbft[jpos+j];
    }
  }

  for (i=0; i<lbdm.bwid; i++) {
    ipos = ((lbdm.xouter - lbdm.bwid + i) * lbdm.youter + lbdm.bwid) * numpair;
    jpos = ((lbdm.bwid + i) * lbdm.youter + lbdm.bwid) * numpair;
    for (j=0; j<(lbdm.yinner*numpair); j++) {
      lbft[ipos+j] = lbft[jpos+j];
    }
  }

  for (i=0; i<lbdm.xouter; i++) {
    ipos = ((i+1)*lbdm.youter - lbdm.bwid) * numpair;
    jpos = (i * lbdm.youter + lbdm.bwid) * numpair;
    for (j=0; j<(lbdm.bwid*numpair); j++) {
      lbft[ipos+j] = lbft[jpos+j];
    }
  }

  for (i=0; i<lbdm.xouter; i++) {
    ipos = i * lbdm.youter * numpair;
    jpos = ((i+1) * lbdm.youter - 2 * lbdm.bwid) * numpair;
    for (j=0; j<(lbdm.bwid*numpair); j++) {
      lbft[ipos+j] = lbft[jpos+j];
    }
  }

  return 0;
}

int fsIndexPeriodic3D()
{
  // apply periodic boundary condition for 3D systems with boundary layer points

  unsigned long i, j, k, ipos, jpos;
  int numpair = 3 * lbsy.nf * (lbsy.nf-1) / 2;

  for (i=0; i<lbdm.bwid; i++) 
    for (j=0; j<lbdm.yinner; j++) {
      ipos = ((i * lbdm.youter + lbdm.bwid + j) * lbdm.zouter + lbdm.bwid) * numpair;
      jpos = (((lbdm.xouter - 2*lbdm.bwid + i) * lbdm.youter + lbdm.bwid + j) * lbdm.zouter + lbdm.bwid) * numpair;
      for (k=0; k<(lbdm.zinner*numpair); k++) {
        lbft[ipos+k] = lbft[jpos+k];
      }
    }

  for (i=0; i<lbdm.bwid; i++) 
    for (j=0; j<lbdm.yinner; j++) {
      ipos = (((lbdm.xouter - lbdm.bwid + i) * lbdm.youter + lbdm.bwid + j) * lbdm.zouter + lbdm.bwid) * numpair;
      jpos = (((lbdm.bwid + i) * lbdm.youter + lbdm.bwid + j) * lbdm.zouter + lbdm.bwid) * numpair;
      for (k=0; k<(lbdm.zinner*numpair); k++) {
        lbft[ipos+k] = lbft[jpos+k];
      }
    }

  for (i=0; i<lbdm.xouter; i++) 
    for (j=0; j<lbdm.bwid; j++) {
      ipos = (((i+1) * lbdm.youter - lbdm.bwid + j) * lbdm.zouter + lbdm.bwid) * numpair;
      jpos = ((i * lbdm.youter + lbdm.bwid + j) * lbdm.zouter + lbdm.bwid) * numpair;
      for (k=0; k<(lbdm.zinner*numpair); k++) {
        lbft[ipos+k] = lbft[jpos+k];
      }
    }

  for (i=0; i<lbdm.xouter; i++) 
    for (j=0; j<lbdm.bwid; j++) {
      ipos = ((i * lbdm.youter + j) * lbdm.zouter + lbdm.bwid) * numpair;
      jpos = (((i+1) * lbdm.youter - 2 * lbdm.bwid + j) * lbdm.zouter + lbdm.bwid) * numpair;
      for (k=0; k<(lbdm.zinner*numpair); k++) {
        lbft[ipos+k] = lbft[jpos+k];
      }
    }

  for (i=0; i<lbdm.xouter; i++) 
    for (j=0; j<lbdm.youter; j++) {
      ipos = ((i * lbdm.youter + j) * lbdm.zouter) * numpair;
      jpos = ((i * lbdm.youter + j + 1) * lbdm.zouter - 2 * lbdm.bwid) * numpair;
      for (k=0; k<(lbdm.bwid*numpair); k++) {
        lbft[ipos+k] = lbft[jpos+k];
      }
    }

  for (i=0; i<lbdm.xouter; i++) 
    for (j=0; j<lbdm.youter; j++) {
      ipos = ((i * lbdm.youter + j + 1) * lbdm.zouter - lbdm.bwid) * numpair;
      jpos = ((i * lbdm.youter + j) * lbdm.zouter + lbdm.bwid) * numpair;
      for (k=0; k<(lbdm.bwid*numpair); k++) {
        lbft[ipos+k] = lbft[jpos+k];
      }
    }

  return 0;
}


