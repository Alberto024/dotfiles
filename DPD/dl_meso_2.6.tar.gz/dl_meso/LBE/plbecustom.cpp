#include "plbe.hpp"

int main(int argc, char** argv)
{
  bigend = fBigEndian();
  fStartMPI(argc, argv);
  fDefineSystem("lbin.sys");
  fDefineDomain();
  fStartDLMESO();
  fMemoryAllocation();
  fDefineNeighbours();
  fDefineMessage();
  fPrintSystemInfo();
  fAllReady();
  fPrintDomainInfo();
  fAllReady();
  fInputParameters("lbin.sys");
  fReadSpaceParameter("lbin.spa");
  fNeighbourBoundary();
  fGetModel();
  fBoundNonBlockCommunication();
  fMarkBoundArea();
  fInitializeSystem();
  fReadInitialState("lbin.init");
  fAllReady();
  fOutputInfo();
  if(outformat==2)                   // Grid for Plot3D output files
    fOutputGrid();  
  timetotal=fCheckTimeMPI();
  for(int i=0; i<= lbtotstep; i++) { 
    fNonBlockCommunication();
    if(i%lbsave  == 0) {
      fOutputVTKP();                 // Substitute with required file type and/or output
      qVersion++;
      if(lbdm.rank == 0)
        cout << i << " \t ";
      fPrintSystemMass();
      fPrintSystemMomentum();
    }
    fInteractionForceZero();         // Remove if no additional forces or mesophase interactions used
    fCalcPotential_ShanChen();       // Substitute with required potential/phase index/density/concentration gradients
                                     // (or remove if no mesophase interactions required)
//  fIndexNonBlockCommunication();   // Required for Lishchuk continuum-based interactions and Swift free-energy interactions
    fInteractionForceShanChen();     // Substitute with required mesophase interactions and/or add additional forces
    fForceNonBlockCommunication();   // Remove if no additional forces or mesophase interactions used
    fCollisionBGK();                 // Substitute with required collision and forcing algorithm
    fPostCollBoundary();
    fPropagationCombinedSwap();
    fPostPropBoundary();
  }
  timetotal=fCheckTimeMPI();
  fFreeMemory();
  fFinishDLMESO();
  fCloseMPI();
  return 0;
}

