/***********************************************
 *   DL_MESO       Version 2.6                 *
 *   Authors   :   R. S. Qin, M. A. Seaton     *
 *   Copyright :   STFC Daresbury Laboratory   *
 *             :   22/10/2015                  *
 ***********************************************/

int fDefineSystem(const char* filename = "lbin.sys")
{
  
  // read calculation parameters from system data file (default: lbin.sys)

  int numb=0;
  int ansi=0;
  string line,issue,value;
  ifstream myfile;

  myfile.open(filename, ios::in);

  if(!myfile)
    {
      cout << "error opening system file" << endl;
      exit(1);
    }

//  lbrestart = 0;
  incompress = 0;
  collide = 0;
  interact = 0;
  outformat = 0;

  while (!myfile.eof())
    {

      getline(myfile,line);
      issue = fReadString(line, 0);
      value = fReadString(line, 1);

      if(issue.compare(0,15,"space_dimension")==0) { 
	    lbsy.nd = fStringToNumber <int> (value); numb++; }

      else if(issue.compare(0,14,"discrete_speed")==0) { 
	    lbsy.nq = fStringToNumber <int> (value); numb++; }

      else if(issue.compare(0,15,"number_of_fluid")==0) { 
	    lbsy.nf = fStringToNumber <int> (value); numb++; }

      else if(issue.compare(0,16,"number_of_solute")==0) {
	    lbsy.nc = fStringToNumber <int> (value); numb++; }

      else if(issue.compare(0,18,"temperature_scalar")==0) {
	    lbsy.nt = fStringToNumber <int> (value); numb++; }

      else if(issue.compare(0,11,"phase_field")==0) {
	    lbsy.pf = fStringToNumber <int> (value); numb++; }

      else if(issue.compare(0,13,"grid_number_x")==0) {
	    lbsy.nx = fStringToNumber <int> (value); numb++; }

      else if(issue.compare(0,13,"grid_number_y")==0) {
	    lbsy.ny = fStringToNumber <int> (value); numb++; }

      else if(issue.compare(0,13,"grid_number_z")==0) {
	    lbsy.nz = fStringToNumber <int> (value); numb++; }

      else if(issue.compare(0,21,"domain_boundary_width")==0) { 
	    lbdm.bwid = fStringToNumber <int> (value); numb++; }

      else if(issue.compare(0,21,"incompressible_fluids")==0) { 
	    incompress = fStringToNumber <int> (value); }

//      else if(issue.compare(0,18,"restart_simulation")==0) {
//	    lbrestart = fStringToNumber <int> (value); }

      else if(issue.compare(0,14,"collision_type")==0) { 
        if(value.compare("BGK")==0) {
          collide = 0;
        }
        else if(value.compare("BGKEDM")==0) {
          collide = 1;
        }
        else if(value.compare("BGKGuo")==0) {
          collide = 2;
        }
        else if(value.compare("TRT")==0) {
          collide = 3;
        }
        else if(value.compare("TRTEDM")==0) {
          collide = 4;
        }
        else if(value.compare("TRTGuo")==0) {
          collide = 5;
        }
        else if(value.compare("MRT")==0) {
          collide = 6;
        }
        else if(value.compare("MRTEDM")==0) {
          collide = 7;
        }
        else if(value.compare("MRTGuo")==0) {
          collide = 8;
        }
        else {
          collide = fStringToNumber <int> (value);
        }
      }

      else if(issue.compare(0,16,"interaction_type")==0) { 
        if(value.compare("ShanChen")==0) {
          interact = 1;
        }
        else if(value.compare("ShanChenWetting")==0) {
          interact = 1;
        }
        else if(value.compare("ShanChenQuadratic")==0) {
          interact = 2;
        }
        else if(value.compare("Lishchuk")==0) {
          interact = 3;
        }
        else if(value.compare("LishchukLocal")==0) {
          interact = 4;
        }
        else if(value.compare("Swift")==0) {
          interact = 5;
        }
        else {
          interact = fStringToNumber <int> (value);
        }
      }

      else if(issue.compare(0,13,"output_format")==0) {
	    if(value.compare("VTK")==0) {
          outformat = 0;
        }
        else if(value.compare("LegacyVTK")==0) {
          outformat = 1;
        }
        else if(value.compare("Plot3D")==0) {
          outformat = 2;
        }
        else {
          outformat = fStringToNumber <int> (value);
        }
      }

      else if(issue.compare(0,13,"output_type")==0) {
	    if(value.compare("Binary")==0) {
          ansi = 0;
        }
        else if(value.compare("Text")==0 || value.compare("ANSI")==0) {
          ansi = 1;
        }
        else {
          ansi = fStringToNumber <int> (value);
        }
      }
    }

  if(numb != 10) {
    cout << "error: insufficient system information" << endl;
    exit(1); }
  
  if((lbsy.nd == 2) && (lbsy.nz != 1)) {
    lbsy.nz = 1;
    cout << "warning: lbsy.nz is reset to 1" << endl; }

  outformat += 3*ansi;
    
  lbsitelength = (lbsy.nf + lbsy.nc + lbsy.nt) * lbsy.nq + lbsy.pf;

  myfile.close();
  
  return 0;
  
}


int fInputParameters(const char* filename="lbin.sys")
{
  
  // reads system parameters from system data file (default: lbin.sys)
  
  string line,issue,value,str1;
  stringstream sstm;
  ifstream myfile;
  double Tr, alpha;
  
  myfile.open(filename, ios::in);
  
  if(!myfile)
    {
      cout << "error: cannot open system file" << endl;
      exit(1);
    }

  // default values for equilibration steps, evaporation limit,
  // gradient order and gas constant

  lbequstep = 0;
  lbevaplim = 1e-8;
  lbgradord = 1;
  lbgasconst = 1.0;
//  lbdump = 10000;

  while (!myfile.eof())
    {
      getline(myfile,line);
      issue = fReadString(line, 0);
      value = fReadString(line, 1);
      if(issue.compare(0,10,"total_step")==0)
 	    lbtotstep = fStringToNumber <int> (value);
      else if(issue.compare(0,18,"equilibration_step")==0)
        lbequstep = fStringToNumber <int> (value);
      else if(issue.compare(0,9,"save_span")==0)
	    lbsave = fStringToNumber <int> (value);
/*      else if(issue.compare(0,9,"dump_span")==0)
	    lbdump = fStringToNumber <int> (value);
      else if(issue.compare(0,16,"calculation_time")==0)
        lbcalctime = fStringToNumber <double> (value);
      else if(issue.compare(0,16,"closedown_time")==0)
        lbendtime = fStringToNumber <double> (value); */
      else if(issue.compare(0,15,"noise_intensity")==0)
	    lbnoise = fStringToNumber <double> (value);
      else if(issue.compare(0,11,"sound_speed")==0)
	    lbsoundv = fStringToNumber <double> (value);
      else if(issue.compare(0,17,"kinetic_viscosity")==0)
	    lbkinetic = fStringToNumber <double> (value);
      else if(issue.compare(0,17,"evaporation_limit")==0)
	    lbevaplim = fStringToNumber <double> (value);
      else if(issue.compare(0,16,"trt_magic_number")==0)
        lbtrtmagic = fStringToNumber <double> (value);
      else if(issue.compare(0,12,"gas_constant")==0)
        lbgasconst = fStringToNumber <double> (value);
      else if(issue.compare(0,14,"gradient_order")==0)
        lbgradord = fStringToNumber <int> (value);
      
      else if(issue.compare(0,18,"temperature_system")==0)
	    lbsyst = fStringToNumber <double> (value);
      else if(issue.compare(0,15,"temperature_ini")==0)
	    lbinit = fStringToNumber <double> (value);
      else if(issue.compare(0,15,"temperature_top")==0)
	    lbtopt = fStringToNumber <double> (value);
      else if(issue.compare(0,18,"temperature_bottom")==0)
	    lbbott = fStringToNumber <double> (value);
      else if(issue.compare(0,17,"temperature_front")==0)
	    lbfrot = fStringToNumber <double> (value);
      else if(issue.compare(0,16,"temperature_back")==0)
	    lbbact = fStringToNumber <double> (value);
      else if(issue.compare(0,16,"temperature_left")==0)
	    lbleft = fStringToNumber <double> (value);
      else if(issue.compare(0,17,"temperature_right")==0)
	    lbrigt = fStringToNumber <double> (value);
      else if(issue.compare(0,27,"temperature_boussinesq_high")==0)
	    lbbousth = fStringToNumber <double> (value);
      else if(issue.compare(0,26,"temperature_boussinesq_low")==0)
	    lbboustl = fStringToNumber <double> (value);
      
      else if(issue.compare(0,16,"heating_rate_sys")==0)
	    lbsysdt = fStringToNumber <double> (value);
      else if(issue.compare(0,16,"heating_rate_top")==0)
	    lbtopdt = fStringToNumber <double> (value);
      else if(issue.compare(0,19,"heating_rate_bottom")==0)
	    lbbotdt = fStringToNumber <double> (value);
      else if(issue.compare(0,18,"heating_rate_front")==0)
	    lbfrodt = fStringToNumber <double> (value);
      else if(issue.compare(0,17,"heating_rate_back")==0)
	    lbbacdt = fStringToNumber <double> (value);
      else if(issue.compare(0,17,"heating_rate_left")==0)
	    lblefdt = fStringToNumber <double> (value);
      else if(issue.compare(0,18,"heating_rate_right")==0)
	    lbrigdt = fStringToNumber <double> (value);

      else if(issue.compare(0,14,"relax_mobility")==0)
        lbtmob = 1.0 / fStringToNumber <double> (value);
      else if(issue.compare(0,19,"relax_freq_mobility")==0)
        lbtmob = fStringToNumber <double> (value);
      else if(issue.compare(0,18,"mobility_parameter")==0)
        lbfemob = fStringToNumber <double> (value);
      else if(issue.compare(0,25,"surface_tension_parameter")==0)
        lbkappa = fStringToNumber <double> (value);
      else if(interact==5 && issue.compare(0,15,"eos_parameter_a")==0)
        lbeosa[0] = fStringToNumber <double> (value);
      else if(interact==5 && issue.compare(0,15,"eos_parameter_b")==0)
        lbeosb[0] = fStringToNumber <double> (value);
      else if(interact==5 && lbsy.nf>1 && issue.compare(0,21,"potential_parameter_a")==0)
        lbeosa[1] = fStringToNumber <double> (value);
      else if(interact==5 && lbsy.nf>1 && issue.compare(0,21,"potential_parameter_b")==0)
        lbeosb[1] = fStringToNumber <double> (value);
        
      else if(issue.compare(0,11,"segregation")==0) {
        for(int i=0; i<lbsy.nf*lbsy.nf; i++) {
	      lbseg[i]=fStringToNumber <double> (value);
        }
      }

      else if(issue.compare(0,14,"quadratic_weight")==0) {
        for(int i=0; i<lbsy.nf; i++) {
	      lbscquad[i*lbsy.nf+i]=fStringToNumber <double> (value);
        }
      }
        
	  else if(issue.compare(0,14,"potential_type")==0) {
        if((interact==1 || interact==2) && value.compare("IdealLattice")==0) {
          for(int i=0; i<lbsy.nf; i++) {
            lbscpot[i] = 0;
          }
        }
        else if((interact==1 || interact==2) && value.compare("ShanChen1993")==0) {
          for(int i=0; i<lbsy.nf; i++) {
            lbscpot[i] = 1;
          }
        }
        else if((interact==1 || interact==2) && value.compare("ShanChen1994")==0) {
          for(int i=0; i<lbsy.nf; i++) {
            lbscpot[i] = 2;
          }
        }
        else if((interact==1 || interact==2) && value.compare("Rho")==0) {
          for(int i=0; i<lbsy.nf; i++) {
            lbscpot[i] = 3;
          }
        }
        else if((interact==1 || interact==2) && value.compare("Ideal")==0) {
          for(int i=0; i<lbsy.nf; i++) {
            lbscpot[i] = 4;
          }
        }
        else if((interact==1 || interact==2) && value.compare("vanderWaals")==0 || value.compare("vdW")==0) {
          for(int i=0; i<lbsy.nf; i++) {
            lbscpot[i] = 5;
          }
        }
        else if((interact==1 || interact==2) && value.compare("CarnahanStarlingvanderWaals")==0 || value.compare("CSvdW")==0) {
          for(int i=0; i<lbsy.nf; i++) {
            lbscpot[i] = 6;
          }
        }
        else if((interact==1 || interact==2) && value.compare("RedlichKwong")==0 || value.compare("RK")==0) {
          for(int i=0; i<lbsy.nf; i++) {
            lbscpot[i] = 7;
          }
        }
        else if((interact==1 || interact==2) && value.compare("SoaveRedlichKwong")==0 || value.compare("SRK")==0) {
          for(int i=0; i<lbsy.nf; i++) {
            lbscpot[i] = 9;
          }
        }
        else if((interact==1 || interact==2) && value.compare("PengRobinson")==0 || value.compare("PR")==0) {
          for(int i=0; i<lbsy.nf; i++) {
            lbscpot[i] = 11;
          }
        }
        else if((interact==1 || interact==2) && value.compare("CarnahanStarlingRedlichKwong")==0 || value.compare("CSRK")==0) {
          for(int i=0; i<lbsy.nf; i++) {
            lbscpot[i] = 13;
          }
        }
        else {
          for(int i=0; i<lbsy.nf; i++) {
            lbscpot[i] = fStringToNumber <double> (value);
          }
        }
	  }
	  else if(issue.compare(0,17,"equation_of_state")==0) {
        if(interact==5 && value.compare("IdealLattice")==0)
          lbfeeos = 0;
        else if(interact==5 && value.compare("ShanChen1993")==0)
          lbfeeos = 1;
        else if(interact==5 && value.compare("ShanChen1994")==0)
          lbfeeos = 2;
        else if(interact==5 && value.compare("Rho")==0)
          lbfeeos = 3;
        else if(interact==5 && value.compare("Ideal")==0)
          lbfeeos = 4;
        else if(interact==5 && value.compare("vanderWaals")==0 || value.compare("vdW")==0)
          lbfeeos = 5;
        else if(interact==5 && value.compare("CarnahanStarlingvanderWaals")==0 || value.compare("CSvdW")==0)
          lbfeeos = 6;
        else if(interact==5 && value.compare("RedlichKwong")==0 || value.compare("RK")==0)
          lbfeeos = 7;
        else if(interact==5 && value.compare("SoaveRedlichKwong")==0 || value.compare("SRK")==0)
          lbfeeos = 9;
        else if(interact==5 && value.compare("PengRobinson")==0 || value.compare("PR")==0)
          lbfeeos = 11;
        else if(interact==5 && value.compare("CarnahanStarlingRedlichKwong")==0 || value.compare("CSRK")==0)
          lbfeeos = 13;
        else
          lbfeeos = fStringToNumber <double> (value);
	  }
      else if(issue.compare(0,14,"potential_type")==0) {
        if(interact==5 && value.compare("None")==0) {
          lbfepot = 0;
        }
        else if(interact==5 && value.compare("Quartic")==0) {
          lbfepot = 1;
        }
      }

	  else if(issue.compare(0,14,"wetting_type")==0) {
        if((interact==1 || interact==2) && value.compare("Density")==0) {
          for(int i=0; i<lbsy.nf; i++) {
            lbwet[i] = 0;
          }
        }
        else if((interact==1 || interact==2) && value.compare("Potential")==0) {
          for(int i=0; i<lbsy.nf; i++) {
            lbwet[i] = 1;
          }
        }
        else if((interact==1 || interact==2) && value.compare("ScreenedPotential")==0) {
          for(int i=0; i<lbsy.nf; i++) {
            lbwet[i] = 2;
          }
        }
        else if(interact==5 && value.compare("None")==0) {
          for(int i=0; i<lbsy.nf; i++) {
            lbwet[i] = 0;
          }
        }
        else if(interact==5 && value.compare("Quadratic")==0) {
          for(int i=0; i<lbsy.nf; i++) {
            lbwet[i] = 1;
          }
        }
        else {
          for(int i=0; i<lbsy.nf; i++) {
            lbwet[i] = fStringToNumber <double> (value);
          }
        }
	  }

      else {
        for(int i=0; i<2; i++) {
          sstm.str(string());
          sstm << "wetting_parameter_rho_" << i;
          str1 = sstm.str();
          if(issue.compare(str1)==0) {
            lbfewet[i] = fStringToNumber <double> (value); goto Found; }
            
          sstm.str(string());
          sstm << "wetting_parameter_phi_" << i;
          str1 = sstm.str();
          if(issue.compare(str1)==0) {
            lbfewet[2+i] = fStringToNumber <double> (value); goto Found; }
            
        }

        for(int i=0; i<3; i++) {
          sstm.str(string());
          sstm << "speed_ini_" << i;
	      str1 = sstm.str();
	      if(issue.compare(str1)==0) {
	        lbiniv[i] = fStringToNumber <double> (value); goto Found;}
	  
          sstm.str(string());
          sstm << "speed_top_" << i;
	      str1 = sstm.str();
	      if(issue.compare(str1)==0) {
	        lbtopv[i] = fStringToNumber <double> (value);  goto Found;}
	  
          sstm.str(string());
          sstm << "speed_bot_" << i;
	      str1 = sstm.str();
	      if(issue.compare(str1)==0) {
	        lbbotv[i] = fStringToNumber <double> (value); goto Found;}
	  
          sstm.str(string());
          sstm << "speed_fro_" << i;
	      str1 = sstm.str();
	      if(issue.compare(str1)==0) {
	        lbfrov[i] = fStringToNumber <double> (value); goto Found;}
	  
          sstm.str(string());
          sstm << "speed_bac_" << i;
	      str1 = sstm.str();
	      if(issue.compare(str1)==0) {
	        lbbacv[i] = fStringToNumber <double> (value); goto Found;}
	  
          sstm.str(string());
          sstm << "speed_lef_" << i;
	      str1 = sstm.str();
    	  if(issue.compare(str1)==0) {
	        lblefv[i] = fStringToNumber <double> (value); goto Found;}
	  
          sstm.str(string());
          sstm << "speed_rig_" << i;
	      str1 = sstm.str();
	      if(issue.compare(str1)==0) {
	        lbrigv[i] = fStringToNumber <double> (value); goto Found;}
	  
	    }
	    for(int i=0; i<lbsy.nf; i++) {

/*
          sstm.str(string());
          sstm << "embryo_radius_" << i;
	      str1 = sstm.str();
	      if(issue.compare(str1)==0) {
	        lbemradius[i] = fStringToNumber <double> (value);  goto Found;}
	  
          sstm.str(string());
          sstm << "embryo_number_" << i;
	      str1 = sstm.str();
	      if(issue.compare(str1)==0) {
	        lbemnumber[i] = fStringToNumber <int> (value); goto Found;}
*/

          sstm.str(string());
          sstm << "density_inc_" << i;
	      str1 = sstm.str();
	      if(issue.compare(str1)==0) {
	        lbincp[i] = fStringToNumber <double> (value);  goto Found;}
	  
          sstm.str(string());
          sstm << "density_ini_" << i;
	      str1 = sstm.str();
	      if(issue.compare(str1)==0) {
	        lbinip[i] = fStringToNumber <double> (value);
            if(!incompress && lbincp[i]==0.0)
              lbincp[i] = fStringToNumber <double> (value);
            goto Found;}
	  
          sstm.str(string());
          sstm << "density_top_" << i;
	      str1 = sstm.str();
	      if(issue.compare(str1)==0) {
	        lbtopp[i] = fStringToNumber <double> (value);  goto Found;}
	  
          sstm.str(string());
          sstm << "density_bot_" << i;
	      str1 = sstm.str();
	      if(issue.compare(str1)==0) {
	        lbbotp[i] = fStringToNumber <double> (value);  goto Found;}
	  
          sstm.str(string());
          sstm << "density_fro_" << i;
  	      str1 = sstm.str();
	      if(issue.compare(str1)==0) {
	        lbfrop[i] = fStringToNumber <double> (value);  goto Found;}
	  
          sstm.str(string());
          sstm << "density_bac_" << i;
	      str1 = sstm.str();
	      if(issue.compare(str1)==0) {
	        lbbacp[i] = fStringToNumber <double> (value);  goto Found;}
	  
          sstm.str(string());
          sstm << "density_lef_" << i;
	      str1 = sstm.str();
	      if(issue.compare(str1)==0) {
	        lblefp[i] = fStringToNumber <double> (value);  goto Found;}
	  
          sstm.str(string());
          sstm << "density_rig_" << i;
	      str1 = sstm.str();
	      if(issue.compare(str1)==0) {
	        lbrigp[i] = fStringToNumber <double> (value);  goto Found;}
	  
          sstm.str(string());
          sstm << "relaxation_fluid_" << i;
	      str1 = sstm.str();
	      if(issue.compare(str1)==0) {
	        lbtf[i] = 1.0 / fStringToNumber <double> (value);  goto Found;}
	  
          sstm.str(string());
          sstm << "relax_freq_fluid_" << i;
	      str1 = sstm.str();
	      if(issue.compare(str1)==0) {
	        lbtf[i] = fStringToNumber <double> (value);  goto Found;}

          sstm.str(string());
          sstm << "bulk_relaxation_fluid_" << i;
	      str1 = sstm.str();
	      if(issue.compare(str1)==0) {
	        lbtfbulk[i] = 1.0 / fStringToNumber <double> (value);  goto Found;}
	  
          sstm.str(string());
          sstm << "bulk_relax_freq_fluid_" << i;
	      str1 = sstm.str();
	      if(issue.compare(str1)==0) {
	        lbtfbulk[i] = fStringToNumber <double> (value);  goto Found;}
	  
          sstm.str(string());
          sstm << "shanchen_psi0_" << i;
	      str1 = sstm.str();
	      if(issue.compare(str1)==0) {
	        lbpsi0[i] = fStringToNumber <double> (value);  goto Found;}
	  
          sstm.str(string());
          sstm << "critical_temperature_" << i;
	      str1 = sstm.str();
	      if(issue.compare(str1)==0) {
	        lbcritt[i] = fStringToNumber <double> (value);  goto Found;}
	  
          sstm.str(string());
          sstm << "critical_pressure_" << i;
	      str1 = sstm.str();
	      if(issue.compare(str1)==0) {
	        lbcritp[i] = fStringToNumber <double> (value);  goto Found;}
	  
          sstm.str(string());
          sstm << "eos_parameter_a_" << i;
	      str1 = sstm.str();
	      if(issue.compare(str1)==0) {
	        lbeosa[i] = fStringToNumber <double> (value);  goto Found;}
	  
          sstm.str(string());
          sstm << "eos_parameter_b_" << i;
	      str1 = sstm.str();
	      if(issue.compare(str1)==0) {
	        lbeosb[i] = fStringToNumber <double> (value);  goto Found;}
	  
          sstm.str(string());
          sstm << "acentric_factor_" << i;
	      str1 = sstm.str();
	      if(issue.compare(str1)==0) {
	        lbacentric[i] = fStringToNumber <double> (value);  goto Found;}
	  
          sstm.str(string());
          sstm << "potential_type_" << i;
	      str1 = sstm.str();
	      if(issue.compare(str1)==0) {
            if(value.compare("IdealLattice")==0) {
              lbscpot[i] = 0;
            }
            else if(value.compare("ShanChen1993")==0) {
              lbscpot[i] = 1;
            }
            else if(value.compare("ShanChen1994")==0) {
              lbscpot[i] = 2;
            }
            else if(value.compare("Rho")==0) {
              lbscpot[i] = 3;
            }
            else if(value.compare("Ideal")==0) {
              lbscpot[i] = 4;
            }
            else if(value.compare("vanderWaals")==0 || value.compare("vdW")==0) {
              lbscpot[i] = 5;
            }
            else if(value.compare("CarnahanStarlingvanderWaals")==0 || value.compare("CSvdW")==0) {
              lbscpot[i] = 6;
            }
            else if(value.compare("RedlichKwong")==0 || value.compare("RK")==0) {
              lbscpot[i] = 7;
            }
            else if(value.compare("SoaveRedlichKwong")==0 || value.compare("SRK")==0) {
              lbscpot[i] = 9;
            }
            else if(value.compare("PengRobinson")==0 || value.compare("PR")==0) {
              lbscpot[i] = 11;
            }
            else if(value.compare("CarnahanStarlingRedlichKwong")==0 || value.compare("CSRK")==0) {
              lbscpot[i] = 13;
            }
            else {
	          lbscpot[i] = fStringToNumber <double> (value);
            }
            goto Found;}
	  
          sstm.str(string());
          sstm << "wetting_type_" << i;
	      str1 = sstm.str();
	      if(issue.compare(str1)==0) {
            if(value.compare("Density")==0) {
              lbwet[i] = 0;
            }
            else if(value.compare("Potential")==0) {
              lbwet[i] = 1;
            }
            else if(value.compare("ScreenedPotential")==0) {
              lbwet[i] = 2;
            }
            else {
	          lbwet[i] = fStringToNumber <double> (value);
            }
            goto Found;}
	  
	      for(int j=0; j<lbsy.nf; j++) {
            sstm.str(string());
            sstm << "interaction_" << (i*lbsy.nf+j);
	        str1 = sstm.str();
	        if(issue.compare(str1)==0) {
	          lbg[i*lbsy.nf+j]=fStringToNumber <double> (value);  goto Found;}

            sstm.str(string());
            sstm << "interaction_" << i << "_" << j;
	        str1 = sstm.str();
	        if(issue.compare(str1)==0) {
	          lbg[i*lbsy.nf+j]=fStringToNumber <double> (value);
	          lbg[j*lbsy.nf+i]=fStringToNumber <double> (value);  goto Found;}

            sstm.str(string());
            sstm << "segregation_" << (i*lbsy.nf+j);
	        str1 = sstm.str();
	        if(issue.compare(str1)==0) {
	          lbseg[i*lbsy.nf+j]=fStringToNumber <double> (value);  goto Found;}

            sstm.str(string());
            sstm << "segregation_" << i << "_" << j;
	        str1 = sstm.str();
	        if(issue.compare(str1)==0) {
	          lbseg[i*lbsy.nf+j]=fStringToNumber <double> (value);
	          lbseg[j*lbsy.nf+i]=fStringToNumber <double> (value);  goto Found;}

            sstm.str(string());
            sstm << "quadratic_weight_" << (i*lbsy.nf+j);
	        str1 = sstm.str();
	        if(issue.compare(str1)==0) {
	          lbscquad[i*lbsy.nf+j]=fStringToNumber <double> (value);  goto Found;}

            sstm.str(string());
            sstm << "quadratic_weight_" << i << "_" << j;
	        str1 = sstm.str();
	        if(issue.compare(str1)==0) {
	          lbscquad[i*lbsy.nf+j]=fStringToNumber <double> (value);
	          lbscquad[j*lbsy.nf+i]=fStringToNumber <double> (value);  goto Found;}

          }

          sstm.str(string());
          sstm << "wall_interaction_" << i;
	      str1 = sstm.str();
	      if(issue.compare(str1)==0) {
	        lbgwall[i] = fStringToNumber <double> (value);  goto Found;}


          for(int j=0; j<3; j++) {
            sstm.str(string());
            sstm << "body_force_" << (i*3+j);
	        str1 = sstm.str();
	        if(issue.compare(str1)==0) {
	          lbbdforce[i*3+j] = fStringToNumber <double> (value);  goto Found;}

            sstm.str(string());
            sstm << "boussinesq_force_" << (i*3+j);
	        str1 = sstm.str();
	        if(issue.compare(str1)==0) {
	          lbbousforce[i*3+j] = fStringToNumber <double> (value);  goto Found;}
	      }

          sstm.str(string());
          sstm << "body_force_x_" << i;
	      str1 = sstm.str();
	      if(issue.compare(str1)==0) {
	        lbbdforce[i*3] = fStringToNumber <double> (value);  goto Found;}
          sstm.str(string());
          sstm << "body_force_y_" << i;
	      str1 = sstm.str();
	      if(issue.compare(str1)==0) {
	        lbbdforce[i*3+1] = fStringToNumber <double> (value);  goto Found;}
          sstm.str(string());
          sstm << "body_force_z_" << i;
	      str1 = sstm.str();
	      if(issue.compare(str1)==0) {
	        lbbdforce[i*3+2] = fStringToNumber <double> (value);  goto Found;}
          sstm.str(string());
          sstm << "boussinesq_force_x_" << i;
	      str1 = sstm.str();
	      if(issue.compare(str1)==0) {
	        lbbousforce[i*3] = fStringToNumber <double> (value);  goto Found;}
          sstm.str(string());
          sstm << "boussinesq_force_y_" << i;
	      str1 = sstm.str();
	      if(issue.compare(str1)==0) {
	        lbbousforce[i*3+1] = fStringToNumber <double> (value);  goto Found;}
          sstm.str(string());
          sstm << "boussinesq_force_z_" << i;
	      str1 = sstm.str();
	      if(issue.compare(str1)==0) {
	        lbbousforce[i*3+2] = fStringToNumber <double> (value);  goto Found;}
	  
	    }

  	    for(int j=0; j<lbsy.nc; j++) {
          sstm.str(string());
          sstm << "relax_solute_" << j;
	      str1 = sstm.str();
	      if(issue.compare(str1)==0) {
	        lbtc[j]= 1.0 / fStringToNumber <double> (value);  goto Found;}
          sstm.str(string());
          sstm << "relax_freq_solute_" << j;
	      str1 = sstm.str();
	      if(issue.compare(str1)==0) {
	        lbtc[j]= fStringToNumber <double> (value);  goto Found;}
	    }
	  
	    for(int j=0; j<lbsy.nt; j++) {
	      if(issue.compare(0,13,"relax_thermal")==0) {
	        lbtt[j]= 1.0 / fStringToNumber <double> (value); goto Found;}
	      if(issue.compare(0,18,"relax_freq_thermal")==0) {
	        lbtt[j]= fStringToNumber <double> (value); goto Found;}
	    }

/*
	    for(int i=0; i<(lbsy.nf * (lbsy.nf-1))/2; i++) {
          sstm.str(string());
          sstm << "interface_fold_" << i;
	      str1 = sstm.str();
	      if(issue.compare(str1)==0) {
	        lbanifold[i] = fStringToNumber <int> (value);  goto Found;}
	  
          sstm.str(string());
          sstm << "anisotropy_intensity_" << i;
	      str1 = sstm.str();
	      if(issue.compare(str1)==0) {
	        lbanitens[i] = fStringToNumber <double> (value);  goto Found;}
	    }
*/	
	
	    for(int i=0; i<lbsy.nc; i++) {
          sstm.str(string());
          sstm << "solute_ini_" << i;
	      str1 = sstm.str();
	      if(issue.compare(str1)==0) {
	        lbinic[i] = fStringToNumber <double> (value); goto Found;}
	  
          sstm.str(string());
          sstm << "solute_top_" << i;
  	      str1 = sstm.str();
	      if(issue.compare(str1)==0) {
	        lbtopc[i] = fStringToNumber <double> (value); goto Found;}
	  
          sstm.str(string());
          sstm << "solute_bot_" << i;
	      str1 = sstm.str();
	      if(issue.compare(str1)==0) {
	        lbbotc[i] = fStringToNumber <double> (value); goto Found;}
	  
          sstm.str(string());
          sstm << "solute_fro_" << i;
	      str1 = sstm.str();
	      if(issue.compare(str1)==0) {
	        lbfroc[i] = fStringToNumber <double> (value); goto Found;}
	  
          sstm.str(string());
          sstm << "solute_bac_" << i;
	      str1 = sstm.str();
	      if(issue.compare(str1)==0) {
	        lbbacc[i] = fStringToNumber <double> (value); goto Found;}
	  
          sstm.str(string());
          sstm << "solute_lef_" << i;
	      str1 = sstm.str();
	      if(issue.compare(str1)==0) {
	        lblefc[i] = fStringToNumber <double> (value); goto Found;}
	  
          sstm.str(string());
          sstm << "solute_rig_" << i;
	      str1 = sstm.str();
	      if(issue.compare(str1)==0) {
	        lbrigc[i] = fStringToNumber <double> (value); goto Found;}
	    }
      }
    Found: ;
    }

  lbdt = lbkinetic / (lbsoundv * lbsoundv * (1.0/lbtf[0] -0.5));

  if(lbdt <= 0) {
    cout << "The given relaxation time is not suitable for LBE calculation!" << endl;
    cout << "error: program terminated" << endl;
    exit(1);
  }

  postequil = (lbequstep==0);
  
  if(lbgradord<1)
    lbgradord=1;
  else if(lbgradord>2)
    lbgradord=2;

  // determine if EOS-based Shan-Chen pseudopotentials use constant or
  // variable temperatures and reset interaction parameters

  if(interact>0 && interact<3) {
    for(int i=0; i<lbsy.nf; i++) {
      if(lbscpot[i]>3) {
        lbscpot[i] += (lbsy.nt>0 && lbscpot[i]>6)?1:0;
        if(lbsy.nt==0 && lbsyst<=0.0) {
          cout << "The given pseudopotential for fluid species "<<i<<" requires a specified temperature!" << endl;
          cout << "error: program terminated" << endl;
          exit(1);
        }
        lbg[i*lbsy.nf+i] = 1.0;
        int pottyp = lbscpot[i];
        switch (pottyp) {
          case 5:
            // van der Waals
            if(lbcritt[i]==0.0)
              lbcritt[i] = 8.0 * lbeosa[i] * fReciprocal(27.0 * lbgasconst * lbeosb[i]);
            if(lbcritp[i]==0.0)
              lbcritp[i] = lbeosa[i] * fReciprocal(27.0 * lbeosb[i] * lbeosb[i]);
            if(lbeosa[i]==0.0)
              lbeosa[i] = 27.0 * lbgasconst * lbgasconst * lbcritt[i] * lbcritt[i] * fReciprocal(64.0*lbcritp[i]);
            if(lbeosb[i]==0.0)
              lbeosb[i] = lbgasconst * lbcritt[i] * fReciprocal(8.0*lbcritp[i]);
            break;
          case 6:
            // Carnahan-Starling-van der Waals
            if(lbcritt[i]==0.0)
              lbcritt[i] = 0.37731481253489 * lbeosa[i] * fReciprocal(lbgasconst * lbeosb[i]);
            if(lbcritp[i]==0.0)
              lbcritp[i] = 0.07066901441631 * lbeosa[i] * fReciprocal(lbeosb[i] * lbeosb[i]);
            if(lbeosa[i]==0.0)
              lbeosa[i] = 0.49638805772941 * lbgasconst * lbgasconst * lbcritt[i] * lbcritt[i] * fReciprocal(lbcritp[i]);
            if(lbeosb[i]==0.0)
              lbeosb[i] = 0.18729456694673 * lbgasconst * lbcritt[i] * fReciprocal(lbcritp[i]);
            break;
          case 7:
            // Redlich-Kwong (constant temperature)
            if(lbcritt[i]==0.0)
              lbcritt[i] = pow(0.20267685653536*lbeosa[i]*fReciprocal(lbgasconst*lbeosb[i]), 2.0/3.0);
            if(lbcritp[i]==0.0)
              lbcritp[i] = 0.01755999378002*lbeosa[i]*fReciprocal(sqrt(lbcritt[i])*lbeosb[i]*lbeosb[i]);
            if(lbeosa[i]==0.0)
              lbeosa[i] = 0.42748023354034 * lbgasconst * lbgasconst * lbcritt[i] * lbcritt[i] * sqrt(lbcritt[i]/lbsyst) * fReciprocal(lbcritp[i]);
            if(lbeosb[i]==0.0)
              lbeosb[i] = 0.08664034996496 * lbgasconst * lbcritt[i] * fReciprocal(lbcritp[i]);
            break;
          case 8:
            // Redlich-Kwong (variable temperature)
            if(lbcritt[i]==0.0)
              lbcritt[i] = pow(0.20267685653536*lbeosa[i]*fReciprocal(lbgasconst*lbeosb[i]), 2.0/3.0);
            if(lbcritp[i]==0.0)
              lbcritp[i] = 0.01755999378002*lbeosa[i]*fReciprocal(sqrt(lbcritt[i])*lbeosb[i]*lbeosb[i]);
            if(lbeosa[i]==0.0)
              lbeosa[i] = 0.42748023354034 * lbgasconst * lbgasconst * lbcritt[i] * lbcritt[i] * sqrt(lbcritt[i]) * fReciprocal(lbcritp[i]);
            if(lbeosb[i]==0.0)
              lbeosb[i] = 0.08664034996496 * lbgasconst * lbcritt[i] * fReciprocal(lbcritp[i]);
            break;
          case 9:
            // Soave-Redlich-Kwong (constant temperature)
            if(lbcritt[i]==0.0)
              lbcritt[i] = 0.20267685653536 * lbeosa[i] * fReciprocal(lbgasconst*lbeosb[i]);
            if(lbcritp[i]==0.0)
              lbcritp[i] = 0.01755999378002 * lbeosa[i] * fReciprocal(lbeosb[i]*lbeosb[i]);
            if(lbeosa[i]==0.0)
              lbeosa[i] = 0.42748023354034 * lbgasconst * lbgasconst * lbcritt[i] * lbcritt[i] * fReciprocal(lbcritp[i]);
            if(lbeosb[i]==0.0)
              lbeosb[i] = 0.08664034996496 * lbgasconst * lbcritt[i] * fReciprocal(lbcritp[i]);
            if(lbcritt[i]==0.0)
              lbcritt[i] = 0.20267685653536 * lbeosa[i] * fReciprocal(lbgasconst*lbeosb[i]);
            Tr = lbsyst * fReciprocal(lbcritt[i]);
            alpha = (1.0 + (0.480 + lbacentric[i] * (1.574  - 0.176 * lbacentric[i])) * (1.0 - sqrt(Tr)));
            lbeosa[i] *= alpha * alpha;
            break;
          case 10:
            // Soave-Redlich-Kwong (variable temperature)
            if(lbcritt[i]==0.0)
              lbcritt[i] = 0.20267685653536 * lbeosa[i] * fReciprocal(lbgasconst*lbeosb[i]);
            if(lbcritp[i]==0.0)
              lbcritp[i] = 0.01755999378002 * lbeosa[i] * fReciprocal(lbeosb[i]*lbeosb[i]);
            if(lbeosa[i]==0.0)
              lbeosa[i] = 0.42748023354034 * lbgasconst * lbgasconst * lbcritt[i] * lbcritt[i] * fReciprocal(lbcritp[i]);
            if(lbeosb[i]==0.0)
              lbeosb[i] = 0.08664034996496 * lbgasconst * lbcritt[i] * fReciprocal(lbcritp[i]);
            if(lbcritt[i]==0.0)
              lbcritt[i] = 0.20267685653536 * lbeosa[i] * fReciprocal(lbgasconst*lbeosb[i]);
            break;
          case 11:
            // Peng-Robinson (constant temperature)
            if(lbcritt[i]==0.0)
              lbcritt[i] = 0.17014442007035 * lbeosa[i] * fReciprocal(lbgasconst*lbeosb[i]);
            if(lbcritp[i]==0.0)
              lbcritp[i] = 0.01323656787813 * lbeosa[i] * fReciprocal(lbeosb[i]*lbeosb[i]);
            if(lbeosa[i]==0.0)
              lbeosa[i] = 0.45723552892138 * lbgasconst * lbgasconst * lbcritt[i] * lbcritt[i] * fReciprocal(lbcritp[i]);
            if(lbeosb[i]==0.0)
              lbeosb[i] = 0.07779607390389 * lbgasconst * lbcritt[i] * fReciprocal(lbcritp[i]);
            if(lbcritt[i]==0.0)
              lbcritt[i] = 0.17014442007035 * lbeosa[i] * fReciprocal(lbgasconst*lbeosb[i]);
            Tr = lbsyst * fReciprocal(lbcritt[i]);
            alpha = (1.0 + (0.37464 + lbacentric[i] * (1.54226  - 0.26992 * lbacentric[i])) * (1.0 - sqrt(Tr)));
            lbeosa[i] *= alpha * alpha;
            break;
          case 12:
            // Peng-Robinson (variable temperature)
            if(lbcritt[i]==0.0)
              lbcritt[i] = 0.17014442007035 * lbeosa[i] * fReciprocal(lbgasconst*lbeosb[i]);
            if(lbcritp[i]==0.0)
              lbcritp[i] = 0.01323656787813 * lbeosa[i] * fReciprocal(lbeosb[i]*lbeosb[i]);
            if(lbeosa[i]==0.0)
              lbeosa[i] = 0.45723552892138 * lbgasconst * lbgasconst * lbcritt[i] * lbcritt[i] * fReciprocal(lbcritp[i]);
            if(lbeosb[i]==0.0)
              lbeosb[i] = 0.07779607390389 * lbgasconst * lbcritt[i] * fReciprocal(lbcritp[i]);
            if(lbcritt[i]==0.0)
              lbcritt[i] = 0.17014442007035 * lbeosa[i] * fReciprocal(lbgasconst*lbeosb[i]);
            break;
          case 13:
            // Carnahan-Starling-Redlich-Kwong (constant temperature)
            if(lbcritt[i]==0.0)
              lbcritt[i] = pow(0.2273290998908*lbeosa[i]*fReciprocal(lbgasconst*lbeosb[i]), 2.0/3.0);
            if(lbcritp[i]==0.0)
              lbcritp[i] = 0.02382998820259*lbeosa[i]*fReciprocal(sqrt(lbcritt[i])*lbeosb[i]*lbeosb[i]);
            if(lbeosa[i]==0.0)
              lbeosa[i] = 0.46111979136946 * lbgasconst * lbgasconst * lbcritt[i] * lbcritt[i] * sqrt(lbcritt[i]/lbsyst) * fReciprocal(lbcritp[i]);
            if(lbeosb[i]==0.0)
              lbeosb[i] = 0.10482594711385 * lbgasconst * lbcritt[i] * fReciprocal(lbcritp[i]);
            break;
          case 14:
            // Carnahan-Starling-Redlich-Kwong (variable temperature)
            if(lbcritt[i]==0.0)
              lbcritt[i] = pow(0.2273290998908*lbeosa[i]*fReciprocal(lbgasconst*lbeosb[i]), 2.0/3.0);
            if(lbcritp[i]==0.0)
              lbcritp[i] = 0.02382998820259*lbeosa[i]*fReciprocal(sqrt(lbcritt[i])*lbeosb[i]*lbeosb[i]);
            if(lbeosa[i]==0.0)
              lbeosa[i] = 0.46111979136946 * lbgasconst * lbgasconst * lbcritt[i] * lbcritt[i] * sqrt(lbcritt[i]) * fReciprocal(lbcritp[i]);
            if(lbeosb[i]==0.0)
              lbeosb[i] = 0.10482594711385 * lbgasconst * lbcritt[i] * fReciprocal(lbcritp[i]);
            break;
        }
      }
    }
  }

  // determine if EOS for Swift free-energy interactions use constant or
  // variable temperatures and reset interaction parameters

  if(interact==5) {
    if(lbsy.nf>2) {
      cout << "Swift free-energy interactions cannot model more than 2 fluids!" << endl;
      cout << "error: program terminated" << endl;
      exit(1);
    }
    lbfeeos += (lbsy.nt>0 && lbfeeos>6)?1:0;
    if(lbsy.nt==0 && lbsyst<=0.0) {
      cout << "The given equation of state requires a specified temperature!" << endl;
      cout << "error: program terminated" << endl;
      exit(1);
    }
    switch (lbfeeos) {
      case 1:
        // Shan-Chen model (1993)
        if(lbeosa[0]==0.0)
          lbeosa[0] = lbg[0];
      case 2:
        // Shan-Chen model (1994)
        if(lbeosa[0]==0.0)
          lbeosa[0] = lbg[0];
        if(lbeosb[0]==0.0)
          lbeosb[0] = lbpsi0[0];
      case 3:
        // Quadratic equation of state (psi = rho)
        if(lbeosa[0]==0.0)
          lbeosa[0] = lbg[0];
      case 5:
        // van der Waals
        if(lbcritt[0]==0.0)
          lbcritt[0] = 8.0 * lbeosa[0] * fReciprocal(27.0 * lbgasconst * lbeosb[0]);
        if(lbcritp[0]==0.0)
          lbcritp[0] = lbeosa[0] * fReciprocal(27.0 * lbeosb[0] * lbeosb[0]);
        if(lbeosa[0]==0.0)
          lbeosa[0] = 27.0 * lbgasconst * lbgasconst * lbcritt[0] * lbcritt[0] * fReciprocal(64.0*lbcritp[0]);
        if(lbeosb[0]==0.0)
          lbeosb[0] = lbgasconst * lbcritt[0] * fReciprocal(8.0*lbcritp[0]);
        break;
      case 6:
        // Carnahan-Starling-van der Waals
        if(lbcritt[0]==0.0)
          lbcritt[0] = 0.37731481253489 * lbeosa[0] * fReciprocal(lbgasconst * lbeosb[0]);
        if(lbcritp[0]==0.0)
          lbcritp[0] = 0.07066901441631 * lbeosa[0] * fReciprocal(lbeosb[0] * lbeosb[0]);
        if(lbeosa[0]==0.0)
          lbeosa[0] = 0.49638805772941 * lbgasconst * lbgasconst * lbcritt[0] * lbcritt[0] * fReciprocal(lbcritp[0]);
        if(lbeosb[0]==0.0)
          lbeosb[0] = 0.18729456694673 * lbgasconst * lbcritt[0] * fReciprocal(lbcritp[0]);
        break;
      case 7:
        // Redlich-Kwong (constant temperature)
        if(lbcritt[0]==0.0)
          lbcritt[0] = pow(0.20267685653536*lbeosa[0]*fReciprocal(lbgasconst*lbeosb[0]), 2.0/3.0);
        if(lbcritp[0]==0.0)
          lbcritp[0] = 0.01755999378002*lbeosa[0]*fReciprocal(sqrt(lbcritt[0])*lbeosb[0]*lbeosb[0]);
        if(lbeosa[0]==0.0)
          lbeosa[0] = 0.42748023354034 * lbgasconst * lbgasconst * lbcritt[0] * lbcritt[0] * sqrt(lbcritt[0]/lbsyst) * fReciprocal(lbcritp[0]);
        if(lbeosb[0]==0.0)
          lbeosb[0] = 0.08664034996496 * lbgasconst * lbcritt[0] * fReciprocal(lbcritp[0]);
        break;
      case 8:
        // Redlich-Kwong (variable temperature)
        if(lbcritt[0]==0.0)
          lbcritt[0] = pow(0.20267685653536*lbeosa[0]*fReciprocal(lbgasconst*lbeosb[0]), 2.0/3.0);
        if(lbcritp[0]==0.0)
          lbcritp[0] = 0.01755999378002*lbeosa[0]*fReciprocal(sqrt(lbcritt[0])*lbeosb[0]*lbeosb[0]);
        if(lbeosa[0]==0.0)
          lbeosa[0] = 0.42748023354034 * lbgasconst * lbgasconst * lbcritt[0] * lbcritt[0] * sqrt(lbcritt[0]) * fReciprocal(lbcritp[0]);
        if(lbeosb[0]==0.0)
          lbeosb[0] = 0.08664034996496 * lbgasconst * lbcritt[0] * fReciprocal(lbcritp[0]);
        break;
      case 9:
        // Soave-Redlich-Kwong (constant temperature)
        if(lbcritt[0]==0.0)
          lbcritt[0] = 0.20267685653536 * lbeosa[0] * fReciprocal(lbgasconst*lbeosb[0]);
        if(lbcritp[0]==0.0)
          lbcritp[0] = 0.01755999378002 * lbeosa[0] * fReciprocal(lbeosb[0]*lbeosb[0]);
        if(lbeosa[0]==0.0)
          lbeosa[0] = 0.42748023354034 * lbgasconst * lbgasconst * lbcritt[0] * lbcritt[0] * fReciprocal(lbcritp[0]);
        if(lbeosb[0]==0.0)
          lbeosb[0] = 0.08664034996496 * lbgasconst * lbcritt[0] * fReciprocal(lbcritp[0]);
        if(lbcritt[0]==0.0)
          lbcritt[0] = 0.20267685653536 * lbeosa[0] * fReciprocal(lbgasconst*lbeosb[0]);
        Tr = lbsyst * fReciprocal(lbcritt[0]);
        alpha = (1.0 + (0.480 + lbacentric[0] * (1.574  - 0.176 * lbacentric[0])) * (1.0 - sqrt(Tr)));
        lbeosa[0] *= alpha * alpha;
        break;
      case 10:
        // Soave-Redlich-Kwong (variable temperature)
        if(lbcritt[0]==0.0)
          lbcritt[0] = 0.20267685653536 * lbeosa[0] * fReciprocal(lbgasconst*lbeosb[0]);
        if(lbcritp[0]==0.0)
          lbcritp[0] = 0.01755999378002 * lbeosa[0] * fReciprocal(lbeosb[0]*lbeosb[0]);
        if(lbeosa[0]==0.0)
          lbeosa[0] = 0.42748023354034 * lbgasconst * lbgasconst * lbcritt[0] * lbcritt[0] * fReciprocal(lbcritp[0]);
        if(lbeosb[0]==0.0)
          lbeosb[0] = 0.08664034996496 * lbgasconst * lbcritt[0] * fReciprocal(lbcritp[0]);
        if(lbcritt[0]==0.0)
          lbcritt[0] = 0.20267685653536 * lbeosa[0] * fReciprocal(lbgasconst*lbeosb[0]);
        break;
      case 11:
        // Peng-Robinson (constant temperature)
        if(lbcritt[0]==0.0)
          lbcritt[0] = 0.17014442007035 * lbeosa[0] * fReciprocal(lbgasconst*lbeosb[0]);
        if(lbcritp[0]==0.0)
          lbcritp[0] = 0.01323656787813 * lbeosa[0] * fReciprocal(lbeosb[0]*lbeosb[0]);
        if(lbeosa[0]==0.0)
          lbeosa[0] = 0.45723552892138 * lbgasconst * lbgasconst * lbcritt[0] * lbcritt[0] * fReciprocal(lbcritp[0]);
        if(lbeosb[0]==0.0)
          lbeosb[0] = 0.07779607390389 * lbgasconst * lbcritt[0] * fReciprocal(lbcritp[0]);
        if(lbcritt[0]==0.0)
          lbcritt[0] = 0.17014442007035 * lbeosa[0] * fReciprocal(lbgasconst*lbeosb[0]);
        Tr = lbsyst * fReciprocal(lbcritt[0]);
        alpha = (1.0 + (0.37464 + lbacentric[0] * (1.54226  - 0.26992 * lbacentric[0])) * (1.0 - sqrt(Tr)));
        lbeosa[0] *= alpha * alpha;
        break;
      case 12:
        // Peng-Robinson (variable temperature)
        if(lbcritt[0]==0.0)
          lbcritt[0] = 0.17014442007035 * lbeosa[0] * fReciprocal(lbgasconst*lbeosb[0]);
        if(lbcritp[0]==0.0)
          lbcritp[0] = 0.01323656787813 * lbeosa[0] * fReciprocal(lbeosb[0]*lbeosb[0]);
        if(lbeosa[0]==0.0)
          lbeosa[0] = 0.45723552892138 * lbgasconst * lbgasconst * lbcritt[0] * lbcritt[0] * fReciprocal(lbcritp[0]);
        if(lbeosb[0]==0.0)
          lbeosb[0] = 0.07779607390389 * lbgasconst * lbcritt[0] * fReciprocal(lbcritp[0]);
        if(lbcritt[0]==0.0)
          lbcritt[0] = 0.17014442007035 * lbeosa[0] * fReciprocal(lbgasconst*lbeosb[0]);
        break;
      case 13:
       // Carnahan-Starling-Redlich-Kwong (constant temperature)
        if(lbcritt[0]==0.0)
          lbcritt[0] = pow(0.2273290998908*lbeosa[0]*fReciprocal(lbgasconst*lbeosb[0]), 2.0/3.0);
        if(lbcritp[0]==0.0)
          lbcritp[0] = 0.02382998820259*lbeosa[0]*fReciprocal(sqrt(lbcritt[0])*lbeosb[0]*lbeosb[0]);
        if(lbeosa[0]==0.0)
          lbeosa[0] = 0.46111979136946 * lbgasconst * lbgasconst * lbcritt[0] * lbcritt[0] * sqrt(lbcritt[0]/lbsyst) * fReciprocal(lbcritp[0]);
        if(lbeosb[0]==0.0)
          lbeosb[0] = 0.10482594711385 * lbgasconst * lbcritt[0] * fReciprocal(lbcritp[0]);
        break;
      case 14:
        // Carnahan-Starling-Redlich-Kwong (variable temperature)
        if(lbcritt[0]==0.0)
          lbcritt[0] = pow(0.2273290998908*lbeosa[0]*fReciprocal(lbgasconst*lbeosb[0]), 2.0/3.0);
        if(lbcritp[0]==0.0)
          lbcritp[0] = 0.02382998820259*lbeosa[0]*fReciprocal(sqrt(lbcritt[0])*lbeosb[0]*lbeosb[0]);
        if(lbeosa[0]==0.0)
          lbeosa[0] = 0.46111979136946 * lbgasconst * lbgasconst * lbcritt[0] * lbcritt[0] * sqrt(lbcritt[0]) * fReciprocal(lbcritp[0]);
        if(lbeosb[0]==0.0)
          lbeosb[0] = 0.10482594711385 * lbgasconst * lbcritt[0] * fReciprocal(lbcritp[0]);
        break;
    }
  }

  // calculate antisymmetric relaxation frequencies if using TRT and not
  // using Lishchuk interactions or two-fluid Swift free-energy interactions
    
  if(collide>2 && collide<6 && interact<3 || (interact==5 && lbsy.nf==1)) {
    for(int i=0; i<lbsy.nf; i++)
      lbtfbulk[i] = fTRTOmegaAntisymmetric(lbtf[i], lbtrtmagic);
  }

  myfile.close();
  
  return 0;
}

int fReadSpace2D(const char* filename="lbin.spa")
{

  // read 2D space parameters from data file (default: lbin.spa)
   
  int xpos, ypos, zpos, value;
  unsigned long rpos;

  ifstream myfile;
  myfile.open(filename, ios::in);
  if(!myfile)
    {
      cout << "error: cannot open input file" << endl;
      exit(1);
    }
  while (!myfile.eof())
    {
      myfile >> xpos >> ypos >> zpos >> value;
      if(!(postequil) && value>110 && value<890)
        value = 0;
      if((xpos >= lbdm.xs) && (xpos < lbdm.xe) && 
	 (ypos >= lbdm.ys) && (ypos < lbdm.ye) &&
	 (zpos == 0))
	{
	  rpos = (xpos - lbdm.xs + lbdm.bwid) * lbdm.youter 
	    + ypos - lbdm.ys + lbdm.bwid; 
	  lbphi[rpos] = value;
	}
    }
  myfile.close();
  return 0;
}


int fReadSpace3D(const char* filename="lbin.spa")
{
  
  // read 3D space parameters from data file (default: lbin.spa)
  
  int xpos, ypos, zpos, value;
  unsigned long rpos;
  
  ifstream myfile;
  myfile.open(filename, ios::in);
  if(!myfile)
    {
      cout << "Error opening input file" << endl;
      exit(1);
    }
  while (!myfile.eof())
    {
      myfile >> xpos >> ypos >> zpos >> value;
      if((xpos >= lbdm.xs) && (xpos <lbdm.xe) && 
	 (ypos >= lbdm.ys) && (ypos <lbdm.ye) &&
	 (zpos >= lbdm.zs) && (zpos <lbdm.ze))
	{
	  rpos = ((xpos - lbdm.xs + lbdm.bwid) * lbdm.youter 
		  + (ypos - lbdm.ys + lbdm.bwid)) * lbdm.zouter
	    + zpos - lbdm.zs + lbdm.bwid; 
	  lbphi[rpos] = value;
	}
    }
  myfile.close();
  return 0;
}


int fReadSpaceParameter(const char* filename="lbin.spa")
{

  if(lbsy.nd == 2)
    fReadSpace2D(filename);
  else
    fReadSpace3D(filename);
  return 0;
}


int fReadInitialState2D(const char* filename="lbin.init")
{
  
  // read initial velocities, densities, concentrations, temperature
  // from data file to replace default values (default file: lbin.init)

  int xpos, ypos, zpos;
  unsigned long rpos;
  double vel[3];
  double dens[lbsy.nf];
  double conc[lbsy.nc];
  double delta[4*lbsy.nf];
  double temp, T, rho, phi, omega, pb, lambda, mu;
  double * pt2;
  int qdim=lbsy.nf+lbsy.nc+lbsy.nt;

  for(int i=0; i<4*lbsy.nf; i++)
    delta[i] = 0.0;
    
  ifstream myfile;
  myfile.open(filename, ios::in);
  if(myfile)
    {
    while (!myfile.eof())
      {
        myfile >> xpos >> ypos >> zpos;
        myfile >> vel[0] >> vel[1] >> vel[2];
        for (int m=0; m<lbsy.nf; m++) {
          myfile >> dens[m];
        }
        if (lbsy.nc>0) {
          for (int m=0; m<lbsy.nc; m++) {
            myfile >> conc[m];
          }
        }
        if (lbsy.nt==1) {
          myfile >> temp;
        }
  //  replace populations for points inside domain

        if((xpos >= lbdm.xs) && (xpos <lbdm.xe) && 
           (ypos >= lbdm.ys) && (ypos <lbdm.ye) &&
           (zpos == 0))
  	      {
	        rpos = (xpos - lbdm.xs + lbdm.bwid) * lbdm.youter
		         + (ypos - lbdm.ys + lbdm.bwid);
	        pt2 = &lbf[lbsitelength*rpos];
            T = (lbsy.nt>0)?temp:lbsyst;
            if(interact==5 && lbsy.nf>1) {
              rho = dens[0]+dens[1];
              phi = (dens[0]-dens[1])*fReciprocal(rho);
              omega = 2.0*lbtf[0]*lbtf[1]/(2.0*lbtf[0]+(1.0+phi)*(lbtf[1]-lbtf[0]));
              pb = fGetBulkPressureSwift(rho, phi, T);
              lambda = fGetLambdaSwift(rho, omega, T);
              mu = fGetPotentialSwift(phi, 0.0);
              fGetEquilibriumFSwiftTwoFluid(lbfeq, vel, rho, phi, pb, mu, lambda, delta);
              for (int n=0; n<lbsy.nq; n++) {
                pt2[n*qdim  ] = lbfeq[2*n  ];
                pt2[n*qdim+1] = lbfeq[2*n+1];
              }
            }
            else if(interact==5 && lbsy.nf==1) {
              pb = fGetBulkPressureSwift(dens[0], 0.0, T);
              lambda = fGetLambdaSwift(dens[0], lbtf[0], T);
              fGetEquilibriumFSwiftOneFluid(lbfeq, vel, dens[0], pb, lambda, delta);
              for (int n=0; n<lbsy.nq; n++) {
                pt2[n*qdim] = lbfeq[n];
              }
            }
            else if(!incompress) {
              for (int m=0; m<lbsy.nf; m++) {
                fGetEquilibriumF(lbfeq, vel, dens[m]);
                for (int n=0; n<lbsy.nq; n++) {
                  pt2[n*qdim+m] = lbfeq[n];
                }
              }
            }
            else {
              for (int m=0; m<lbsy.nf; m++) {
                fGetEquilibriumFIncom(lbfeq, vel, dens[m], lbinip[m]);
                for (int n=0; n<lbsy.nq; n++) {
                  pt2[n*qdim+m] = lbfeq[n];
                }
              }
            }
            for (int m=0; m<lbsy.nc; m++) {
              fGetEquilibriumC(lbfeq, vel, conc[m]);
              for (int n=0; n<lbsy.nq; n++) {
                pt2[n*qdim+lbsy.nf+m] = lbfeq[n];
              }
            }
            if (lbsy.nt==1) {
              fGetEquilibriumT(lbfeq, vel, temp);
              for (int n=0; n<lbsy.nq; n++) {
                pt2[n*qdim+lbsy.nf+lbsy.nc] = lbfeq[n];
              }
            }
     	  }

      }
    }
  myfile.close();
  pt2=NULL;

  return 0;
}


int fReadInitialState3D(const char* filename="lbin.init")
{
  
  // read initial velocities, densities, concentrations, temperature
  // from data file to replace default values (default file: lbin.init)

  int xpos, ypos, zpos;
  unsigned long rpos;
  double vel[3];
  double dens[lbsy.nf];
  double conc[lbsy.nc];
  double delta[4*lbsy.nf];
  double temp, T, rho, phi, omega, pb, lambda, mu;
  double * pt2;
  int qdim=lbsy.nf+lbsy.nc+lbsy.nt;

  for(int i=0; i<4*lbsy.nf; i++)
    delta[i] = 0.0;

  ifstream myfile;
  myfile.open(filename, ios::in);
  if(myfile)
    {
    while (!myfile.eof())
      {
        myfile >> xpos >> ypos >> zpos;
        myfile >> vel[0] >> vel[1] >> vel[2];
        for (int m=0; m<lbsy.nf; m++) {
          myfile >> dens[m];
        }
        if (lbsy.nc>0) {
          for (int m=0; m<lbsy.nc; m++) {
            myfile >> conc[m];
          }
        }
        if (lbsy.nt==1) {
          myfile >> temp;
        }
  //  replace populations for points inside domain

        if((xpos >= lbdm.xs) && (xpos <lbdm.xe) && 
	       (ypos >= lbdm.ys) && (ypos <lbdm.ye) &&
  	       (zpos >= lbdm.zs) && (zpos <lbdm.ze))
  	      {
	        rpos = ((xpos - lbdm.xs + lbdm.bwid) * lbdm.youter
		         + (ypos - lbdm.ys + lbdm.bwid)) * lbdm.zouter
	             + zpos - lbdm.zs + lbdm.bwid;
            pt2 = &lbf[lbsitelength*rpos];
            T = (lbsy.nt>0)?temp:lbsyst;
            if(interact==5 && lbsy.nf>1) {
              rho = dens[0]+dens[1];
              phi = (dens[0]-dens[1])*fReciprocal(rho);
              omega = 2.0*lbtf[0]*lbtf[1]/(2.0*lbtf[0]+(1.0+phi)*(lbtf[1]-lbtf[0]));
              pb = fGetBulkPressureSwift(rho, phi, T);
              lambda = fGetLambdaSwift(rho, omega, T);
              mu = fGetPotentialSwift(phi, 0.0);
              fGetEquilibriumFSwiftTwoFluid(lbfeq, vel, rho, phi, pb, mu, lambda, delta);
              for (int n=0; n<lbsy.nq; n++) {
                pt2[n*qdim  ] = lbfeq[2*n  ];
                pt2[n*qdim+1] = lbfeq[2*n+1];
              }
            }
            else if(interact==5 && lbsy.nf==1) {
              pb = fGetBulkPressureSwift(dens[0], 0.0, T);
              lambda = fGetLambdaSwift(dens[0], lbtf[0], T);
              fGetEquilibriumFSwiftOneFluid(lbfeq, vel, dens[0], pb, lambda, delta);
              for (int n=0; n<lbsy.nq; n++) {
                pt2[n*qdim] = lbfeq[n];
              }
            }
            else if(!incompress) {
              for (int m=0; m<lbsy.nf; m++) {
                fGetEquilibriumF(lbfeq, vel, dens[m]);
                for (int n=0; n<lbsy.nq; n++) {
                  pt2[n*qdim+m] = lbfeq[n];
                }
              }
            }
            else {
              for (int m=0; m<lbsy.nf; m++) {
                fGetEquilibriumFIncom(lbfeq, vel, dens[m], lbinip[m]);
                for (int n=0; n<lbsy.nq; n++) {
                  pt2[n*qdim+m] = lbfeq[n];
                }
              }
            }
            for (int m=0; m<lbsy.nc; m++) {
              fGetEquilibriumC(lbfeq, vel, conc[m]);
              for (int n=0; n<lbsy.nq; n++) {
                pt2[n*qdim+lbsy.nf+m] = lbfeq[n];
              }
            }
            if (lbsy.nt==1) {
              fGetEquilibriumT(lbfeq, vel, temp);
              for (int n=0; n<lbsy.nq; n++) {
                pt2[n*qdim+lbsy.nf+lbsy.nc] = lbfeq[n];
              }
            }
  	      }

      }
    }
  myfile.close();
  pt2=NULL;

  return 0;
}

int fReadInitialState(const char* filename="lbin.init")
{

  if(lbsy.nd == 2)
    fReadInitialState2D(filename);
  else
    fReadInitialState3D(filename);
  return 0;
}


int fSetoffSteer()
{
  // create notsteer file to prevent DL_MESO_LBE creating new system and space
  // files

  ofstream file("notsteer");
  file << "delete this file before steering\n";
  file.close();
  
  return 0;
}


int fCheckSteer()
{

  // check for existence of notsteer file: if not found, read system and space 
  // files
  
  ifstream file("notsteer");
  if(!file){
    fInputParameters("lbin.sys");
    fReadSpaceParameter("lbin.spa");	
  }
  fSetoffSteer();
  
  return 0;
}


int fPrintSystemInfo()
{

  // print system information

  string buff, bufc, buft, bufcoll, bufforc, bufmeso, bufwet;
//  char buff[30], bufc[20], buft[30], bufcoll[20], bufforc[20], bufmeso[20], bufwet[20];
  int coll=collide/3;
  int forc=collide%3;

  if(!incompress)
    buff.assign((lbsy.nf>1)?"compressible phases":"compressible phase");
  else
    buff.assign((lbsy.nf>1)?"incompressible phases":"incompressible phase");

  bufc.assign((lbsy.nc>1)?"solutes":"solute");
  buft.assign((lbsy.nt==1)?"temperature scalar":"no temperature scalar");
  switch (coll) {
    case 0:
      bufcoll.assign("BGK");
      break;
    case 1:
      bufcoll.assign("TRT");
      break;
    case 2:
      bufcoll.assign("MRT");
      break;
  }
  switch (forc) {
    case 0:
      bufforc.assign("standard");
      break;
    case 1:
      bufforc.assign("EDM");
      break;
    case 2:
      bufforc.assign("Guo");
      break;
  }
  switch (interact) {
    case 0:
      bufmeso.assign("no");
      bufwet.assign(" ");
      break;
    case 1:
      bufmeso.assign("Shan-Chen");
      bufwet.assign(" ");
      break;
    case 2:
      bufmeso.assign("Shan-Chen");
      bufwet.assign("with quadratic terms");
      break;
    case 3:
      bufmeso.assign("Lishchuk");
      bufwet.assign(" ");
      break;
    case 4:
      bufmeso.assign("Lishchuk");
      bufwet.assign("determined locally");
      break;
    case 5:
      bufmeso.assign("Swift");
      bufwet.assign(" ");
      break;

  }
  if(lbdm.rank == 0) {
    fPrintDoubleLine();
    cout << lbsy.nd << "-dimensional system with grid size: nx=" << lbsy.nx << ", ny=" << lbsy.ny;
    if(lbsy.nd == 3)
      cout << ", nz=" << lbsy.nz; 
    cout << endl;
    cout << "boundary width = " << lbdm.bwid << endl;
    cout << "system includes " << lbsy.nf << " " << buff << ", " << lbsy.nc 
         << " " << bufc << " and " << buft << endl;
    cout << "D" << lbsy.nd << "Q" << lbsy.nq << " lattice Boltzmann model is defined using " 
         << bufcoll << " collisions" << endl;
    cout << "with " << bufforc << " forcing and " << bufmeso << " interactions " << bufwet << endl;
    fPrintLine();
  }
  
  return 0;
}


int fPrintEndEquilibration()
{
  if(lbdm.rank == 0) {
    fPrintDoubleLine();
    cout << "EQUILIBRATION PERIOD NOW COMPLETE" << endl;
    fPrintDoubleLine();   
  }
  return 0;
}


int fPrintDomainMass()
{

  // display masses of individual and all fluids in domain

  if(interact==5) {
    cout<<"MASS: "<<"total = "<<fGetOneMassDomain(0);
    for(int i=0; i<lbsy.nf; i++)
      cout<<", fluid "<<i+1<<" = "<<fGetOneMassSwiftDomain(i);
    cout<<endl;
  }
  else {
    cout<<"MASS: "<<"total = "<<fGetTotMassDomain();
    for(int i=0; i<lbsy.nf; i++)
      cout<<", fluid "<<i+1<<" = "<<fGetOneMassDomain(i);
    cout<<endl;
  }
  return 0;
}


int fPrintDomainMomentum()
{

  // display total fluid momentum in domain

  double mome[3];
    
  if(interact==5)
    fGetTotMomentSwiftDomain(mome);
  else
    fGetTotMomentDomain(mome);
    
  cout<<"MOMENTUM: "<<"x: "<<mome[0]<<", y: "<<mome[1];
  if(lbsy.nd == 3)
    cout<<", z: "<<mome[2];
  cout<<endl;
  return 0;  
}

int fOutput(const char* filename="lbout")
{

  // output all properties at current timestep according to required format

  switch (outformat) {
    case 0:
      // XML-based VTK in big-endian binary
      fOutputVTK(filename);
      break;
    case 1:
      // Legacy VTK in big-endian binary
      fOutputLegacyVTK(filename);
      break;
    case 2:
      // Plot3D in binary
      fOutputQ(filename);
      break;
    case 3:
      // XML-based VTK in ANSI/text
      fsOutputVTK(filename);
      break;
    case 4:
      // Legacy VTK in ANSI/text
      fsOutputLegacyVTK(filename);
      break;
    case 5:
      // Plot3D in ANSI/text
      fsOutputQ(filename);
      break;
  }
  qVersion++;
  return 0;
}

