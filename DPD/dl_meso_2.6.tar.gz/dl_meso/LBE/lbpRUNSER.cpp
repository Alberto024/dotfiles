/***********************************************
 *   DL_MESO       Version 2.6                 *
 *   Authors   :   R. S. Qin, M. A. Seaton     *
 *   Copyright :   STFC Daresbury Laboratory   *
 *             :   22/10/2015                  *
 ***********************************************/

// No mesoscopic interactions

// option 0: BGK with standard forcing

int fsBGK()
{
  do {
    if(lbcurstep%lbsave == 0 || lbcurstep==lbequstep) {
      if(lbequstep>0 && lbcurstep==lbequstep) {
        fPrintEndEquilibration();
        postequil = 1;
        fReadSpaceParameter();
        fNeighbourBoundary();
      }
      if(lbcurstep>=lbequstep)
        fOutput();
      cout << left << setw(12) << lbcurstep << " ";
      fPrintDomainMass();
      double timeelapsed = fCheckTimeSerial();
      cout << left << setw(12) << timeelapsed << " ";
      fPrintDomainMomentum();
    }
    if(lbsy.nt==1) {
      fInteractionForceZero();
      fConvectionForceBoussinesq(lbbousth, lbboustl);
    }
    fCollisionBGK();
    fPostCollBoundary();
    fPropagationSwap();
    fPostPropBoundary();
    lbcurstep++;
  }
  while(lbcurstep<=lbtotstep);
  return 0;
}

// option 1: BGK with EDM forcing

int fsBGKEDM()
{
  do {
    if(lbcurstep%lbsave == 0 || lbcurstep==lbequstep) {
      if(lbequstep>0 && lbcurstep==lbequstep) {
        fPrintEndEquilibration();
        postequil = 1;
        fReadSpaceParameter();
        fNeighbourBoundary();
      }
      if(lbcurstep>=lbequstep)
        fOutput();
      cout << left << setw(12) << lbcurstep << " ";
      fPrintDomainMass();
      double timeelapsed = fCheckTimeSerial();
      cout << left << setw(12) << timeelapsed << " ";
      fPrintDomainMomentum();
    }
    if(lbsy.nt==1) {
      fInteractionForceZero();
      fConvectionForceBoussinesq(lbbousth, lbboustl);
    }
    fCollisionBGKEDM();
    fPostCollBoundary();
    fPropagationSwap();
    fPostPropBoundary();
    lbcurstep++;
  }
  while(lbcurstep<=lbtotstep);
  return 0;
}

// option 2: BGK with Guo forcing

int fsBGKGuo()
{
  do {
    if(lbcurstep%lbsave == 0 || lbcurstep==lbequstep) {
      if(lbequstep>0 && lbcurstep==lbequstep) {
        fPrintEndEquilibration();
        postequil = 1;
        fReadSpaceParameter();
        fNeighbourBoundary();
      }
      if(lbcurstep>=lbequstep)
        fOutput();
      cout << left << setw(12) << lbcurstep << " ";
      fPrintDomainMass();
      double timeelapsed = fCheckTimeSerial();
      cout << left << setw(12) << timeelapsed << " ";
      fPrintDomainMomentum();
    }
    if(lbsy.nt==1) {
      fInteractionForceZero();
      fConvectionForceBoussinesq(lbbousth, lbboustl);
    }
    fCollisionBGKGuo();
    fPostCollBoundary();
    fPropagationSwap();
    fPostPropBoundary();
    lbcurstep++;
  }
  while(lbcurstep<=lbtotstep);
  return 0;
}

// option 3: TRT with standard forcing

int fsTRT()
{
  do {
    if(lbcurstep%lbsave == 0 || lbcurstep==lbequstep) {
      if(lbequstep>0 && lbcurstep==lbequstep) {
        fPrintEndEquilibration();
        postequil = 1;
        fReadSpaceParameter();
        fNeighbourBoundary();
      }
      if(lbcurstep>=lbequstep)
        fOutput();
      cout << left << setw(12) << lbcurstep << " ";
      fPrintDomainMass();
      double timeelapsed = fCheckTimeSerial();
      cout << left << setw(12) << timeelapsed << " ";
      fPrintDomainMomentum();
    }
    if(lbsy.nt==1) {
      fInteractionForceZero();
      fConvectionForceBoussinesq(lbbousth, lbboustl);
    }
    fCollisionTRT();
    fPostCollBoundary();
    fPropagationSwap();
    fPostPropBoundary();
    lbcurstep++;
  }
  while(lbcurstep<=lbtotstep);
  return 0;
}

// option 4: TRT with EDM forcing

int fsTRTEDM()
{
  do {
    if(lbcurstep%lbsave == 0 || lbcurstep==lbequstep) {
      if(lbequstep>0 && lbcurstep==lbequstep) {
        fPrintEndEquilibration();
        postequil = 1;
        fReadSpaceParameter();
        fNeighbourBoundary();
      }
      if(lbcurstep>=lbequstep)
        fOutput();
      cout << left << setw(12) << lbcurstep << " ";
      fPrintDomainMass();
      double timeelapsed = fCheckTimeSerial();
      cout << left << setw(12) << timeelapsed << " ";
      fPrintDomainMomentum();
    }
    if(lbsy.nt==1) {
      fInteractionForceZero();
      fConvectionForceBoussinesq(lbbousth, lbboustl);
    }
    fCollisionTRTEDM();
    fPostCollBoundary();
    fPropagationSwap();
    fPostPropBoundary();
    lbcurstep++;
  }
  while(lbcurstep<=lbtotstep);
  return 0;
}

// option 5: TRT with Guo-like forcing

int fsTRTGuo()
{
  do {
    if(lbcurstep%lbsave == 0 || lbcurstep==lbequstep) {
      if(lbequstep>0 && lbcurstep==lbequstep) {
        fPrintEndEquilibration();
        postequil = 1;
        fReadSpaceParameter();
        fNeighbourBoundary();
      }
      if(lbcurstep>=lbequstep)
        fOutput();
      cout << left << setw(12) << lbcurstep << " ";
      fPrintDomainMass();
      double timeelapsed = fCheckTimeSerial();
      cout << left << setw(12) << timeelapsed << " ";
      fPrintDomainMomentum();
    }
    if(lbsy.nt==1) {
      fInteractionForceZero();
      fConvectionForceBoussinesq(lbbousth, lbboustl);
    }
    fCollisionTRTGuo();
    fPostCollBoundary();
    fPropagationSwap();
    fPostPropBoundary();
    lbcurstep++;
  }
  while(lbcurstep<=lbtotstep);
  return 0;
}

// option 6: MRT with standard forcing

int fsMRT()
{
  do {
    if(lbcurstep%lbsave == 0 || lbcurstep==lbequstep) {
      if(lbequstep>0 && lbcurstep==lbequstep) {
        fPrintEndEquilibration();
        postequil = 1;
        fReadSpaceParameter();
        fNeighbourBoundary();
      }
      if(lbcurstep>=lbequstep)
        fOutput();
      cout << left << setw(12) << lbcurstep << " ";
      fPrintDomainMass();
      double timeelapsed = fCheckTimeSerial();
      cout << left << setw(12) << timeelapsed << " ";
      fPrintDomainMomentum();
    }
    if(lbsy.nt==1) {
      fInteractionForceZero();
      fConvectionForceBoussinesq(lbbousth, lbboustl);
    }
    fCollisionMRT();
    fPostCollBoundary();
    fPropagationSwap();
    fPostPropBoundary();
    lbcurstep++;
  }
  while(lbcurstep<=lbtotstep);
  return 0;
}

// option 7: MRT with EDM forcing

int fsMRTEDM()
{
  do {
    if(lbcurstep%lbsave == 0 || lbcurstep==lbequstep) {
      if(lbequstep>0 && lbcurstep==lbequstep) {
        fPrintEndEquilibration();
        postequil = 1;
        fReadSpaceParameter();
        fNeighbourBoundary();
      }
      if(lbcurstep>=lbequstep)
        fOutput();
      cout << left << setw(12) << lbcurstep << " ";
      fPrintDomainMass();
      double timeelapsed = fCheckTimeSerial();
      cout << left << setw(12) << timeelapsed << " ";
      fPrintDomainMomentum();
    }
    if(lbsy.nt==1) {
      fInteractionForceZero();
      fConvectionForceBoussinesq(lbbousth, lbboustl);
    }
    fCollisionMRTEDM();
    fPostCollBoundary();
    fPropagationSwap();
    fPostPropBoundary();
    lbcurstep++;
  }
  while(lbcurstep<=lbtotstep);
  return 0;
}

// option 8: MRT with Guo-like forcing

int fsMRTGuo()
{
  do {
    if(lbcurstep%lbsave == 0 || lbcurstep==lbequstep) {
      if(lbequstep>0 && lbcurstep==lbequstep) {
        fPrintEndEquilibration();
        postequil = 1;
        fReadSpaceParameter();
        fNeighbourBoundary();
      }
      if(lbcurstep>=lbequstep)
        fOutput();
      cout << left << setw(12) << lbcurstep << " ";
      fPrintDomainMass();
      double timeelapsed = fCheckTimeSerial();
      cout << left << setw(12) << timeelapsed << " ";
      fPrintDomainMomentum();
    }
    if(lbsy.nt==1) {
      fInteractionForceZero();
      fConvectionForceBoussinesq(lbbousth, lbboustl);
    }
    fCollisionMRTGuo();
    fPostCollBoundary();
    fPropagationSwap();
    fPostPropBoundary();
    lbcurstep++;
  }
  while(lbcurstep<=lbtotstep);
  return 0;
}

// Shan-Chen pseudopotential interactions

// option 0: BGK with standard forcing

int fsBGKShanChen()
{
  do {
    if(lbcurstep%lbsave == 0 || lbcurstep==lbequstep) {
      if(lbequstep>0 && lbcurstep==lbequstep) {
        fPrintEndEquilibration();
        postequil = 1;
        fReadSpaceParameter();
        fNeighbourBoundary();
      }
      if(lbcurstep>=lbequstep)
        fOutput();
      cout << left << setw(12) << lbcurstep << " ";
      fPrintDomainMass();
      double timeelapsed = fCheckTimeSerial();
      cout << left << setw(12) << timeelapsed << " ";
      fPrintDomainMomentum();
    }
    fInteractionForceZero();
    fConvectionForceBoussinesq(lbbousth, lbboustl);
    fCalcPotential_ShanChen();
    fsInteractionForceShanChen();
    fCollisionBGKShanChen();
    fPostCollBoundary();
    fPropagationSwap();
    fPostPropBoundary();
    lbcurstep++;
  }
  while(lbcurstep<=lbtotstep);
  return 0;
}

// option 1: BGK with EDM forcing

int fsBGKEDMShanChen()
{
  do {
    if(lbcurstep%lbsave == 0 || lbcurstep==lbequstep) {
      if(lbequstep>0 && lbcurstep==lbequstep) {
        fPrintEndEquilibration();
        postequil = 1;
        fReadSpaceParameter();
        fNeighbourBoundary();
      }
      if(lbcurstep>=lbequstep)
        fOutput();
      cout << left << setw(12) << lbcurstep << " ";
      fPrintDomainMass();
      double timeelapsed = fCheckTimeSerial();
      cout << left << setw(12) << timeelapsed << " ";
      fPrintDomainMomentum();
    }
    fInteractionForceZero();
    fConvectionForceBoussinesq(lbbousth, lbboustl);
    fCalcPotential_ShanChen();
    fsInteractionForceShanChen();
    fCollisionBGKEDMShanChen();
    fPostCollBoundary();
    fPropagationSwap();
    fPostPropBoundary();
    lbcurstep++;
  }
  while(lbcurstep<=lbtotstep);
  return 0;
}

// option 2: BGK with Guo forcing

int fsBGKGuoShanChen()
{
  do {
    if(lbcurstep%lbsave == 0 || lbcurstep==lbequstep) {
      if(lbequstep>0 && lbcurstep==lbequstep) {
        fPrintEndEquilibration();
        postequil = 1;
        fReadSpaceParameter();
        fNeighbourBoundary();
      }
      if(lbcurstep>=lbequstep)
        fOutput();
      cout << left << setw(12) << lbcurstep << " ";
      fPrintDomainMass();
      double timeelapsed = fCheckTimeSerial();
      cout << left << setw(12) << timeelapsed << " ";
      fPrintDomainMomentum();
    }
    fInteractionForceZero();
    fConvectionForceBoussinesq(lbbousth, lbboustl);
    fCalcPotential_ShanChen();
    fsInteractionForceShanChen();
    fCollisionBGKGuoShanChen();
    fPostCollBoundary();
    fPropagationSwap();
    fPostPropBoundary();
    lbcurstep++;
  }
  while(lbcurstep<=lbtotstep);
  return 0;
}

// option 3: TRT with standard forcing

int fsTRTShanChen()
{
  do {
    if(lbcurstep%lbsave == 0 || lbcurstep==lbequstep) {
      if(lbequstep>0 && lbcurstep==lbequstep) {
        fPrintEndEquilibration();
        postequil = 1;
        fReadSpaceParameter();
        fNeighbourBoundary();
      }
      if(lbcurstep>=lbequstep)
        fOutput();
      cout << left << setw(12) << lbcurstep << " ";
      fPrintDomainMass();
      double timeelapsed = fCheckTimeSerial();
      cout << left << setw(12) << timeelapsed << " ";
      fPrintDomainMomentum();
    }
    fInteractionForceZero();
    fConvectionForceBoussinesq(lbbousth, lbboustl);
    fCalcPotential_ShanChen();
    fsInteractionForceShanChen();
    fCollisionTRTShanChen();
    fPostCollBoundary();
    fPropagationSwap();
    fPostPropBoundary();
    lbcurstep++;
  }
  while(lbcurstep<=lbtotstep);
  return 0;
}

// option 4: TRT with EDM forcing

int fsTRTEDMShanChen()
{
  do {
    if(lbcurstep%lbsave == 0 || lbcurstep==lbequstep) {
      if(lbequstep>0 && lbcurstep==lbequstep) {
        fPrintEndEquilibration();
        postequil = 1;
        fReadSpaceParameter();
        fNeighbourBoundary();
      }
      if(lbcurstep>=lbequstep)
        fOutput();
      cout << left << setw(12) << lbcurstep << " ";
      fPrintDomainMass();
      double timeelapsed = fCheckTimeSerial();
      cout << left << setw(12) << timeelapsed << " ";
      fPrintDomainMomentum();
    }
    fInteractionForceZero();
    fConvectionForceBoussinesq(lbbousth, lbboustl);
    fCalcPotential_ShanChen();
    fsInteractionForceShanChen();
    fCollisionTRTEDMShanChen();
    fPostCollBoundary();
    fPropagationSwap();
    fPostPropBoundary();
    lbcurstep++;
  }
  while(lbcurstep<=lbtotstep);
  return 0;
}

// option 5: TRT with Guo forcing

int fsTRTGuoShanChen()
{
  do {
    if(lbcurstep%lbsave == 0 || lbcurstep==lbequstep) {
      if(lbequstep>0 && lbcurstep==lbequstep) {
        fPrintEndEquilibration();
        postequil = 1;
        fReadSpaceParameter();
        fNeighbourBoundary();
      }
      if(lbcurstep>=lbequstep)
        fOutput();
      cout << left << setw(12) << lbcurstep << " ";
      fPrintDomainMass();
      double timeelapsed = fCheckTimeSerial();
      cout << left << setw(12) << timeelapsed << " ";
      fPrintDomainMomentum();
    }
    fInteractionForceZero();
    fConvectionForceBoussinesq(lbbousth, lbboustl);
    fCalcPotential_ShanChen();
    fsInteractionForceShanChen();
    fCollisionTRTGuoShanChen();
    fPostCollBoundary();
    fPropagationSwap();
    fPostPropBoundary();
    lbcurstep++;
  }
  while(lbcurstep<=lbtotstep);
  return 0;
}

// option 6: MRT with standard forcing

int fsMRTShanChen()
{
  do {
    if(lbcurstep%lbsave == 0 || lbcurstep==lbequstep) {
      if(lbequstep>0 && lbcurstep==lbequstep) {
        fPrintEndEquilibration();
        postequil = 1;
        fReadSpaceParameter();
        fNeighbourBoundary();
      }
      if(lbcurstep>=lbequstep)
        fOutput();
      cout << left << setw(12) << lbcurstep << " ";
      fPrintDomainMass();
      double timeelapsed = fCheckTimeSerial();
      cout << left << setw(12) << timeelapsed << " ";
      fPrintDomainMomentum();
    }
    fInteractionForceZero();
    fConvectionForceBoussinesq(lbbousth, lbboustl);
    fCalcPotential_ShanChen();
    fsInteractionForceShanChen();
    fCollisionMRTShanChen();
    fPostCollBoundary();
    fPropagationSwap();
    fPostPropBoundary();
    lbcurstep++;
  }
  while(lbcurstep<=lbtotstep);
  return 0;
}

// option 7: MRT with EDM forcing

int fsMRTEDMShanChen()
{
  do {
    if(lbcurstep%lbsave == 0 || lbcurstep==lbequstep) {
      if(lbequstep>0 && lbcurstep==lbequstep) {
        fPrintEndEquilibration();
        postequil = 1;
        fReadSpaceParameter();
        fNeighbourBoundary();
      }
      if(lbcurstep>=lbequstep)
        fOutput();
      cout << left << setw(12) << lbcurstep << " ";
      fPrintDomainMass();
      double timeelapsed = fCheckTimeSerial();
      cout << left << setw(12) << timeelapsed << " ";
      fPrintDomainMomentum();
    }
    fInteractionForceZero();
    fConvectionForceBoussinesq(lbbousth, lbboustl);
    fCalcPotential_ShanChen();
    fsInteractionForceShanChen();
    fCollisionMRTEDMShanChen();
    fPostCollBoundary();
    fPropagationSwap();
    fPostPropBoundary();
    lbcurstep++;
  }
  while(lbcurstep<=lbtotstep);
  return 0;
}

// option 8: MRT with Guo-like forcing

int fsMRTGuoShanChen()
{
  do {
    if(lbcurstep%lbsave == 0 || lbcurstep==lbequstep) {
      if(lbequstep>0 && lbcurstep==lbequstep) {
        fPrintEndEquilibration();
        postequil = 1;
        fReadSpaceParameter();
        fNeighbourBoundary();
      }
      if(lbcurstep>=lbequstep)
        fOutput();
      cout << left << setw(12) << lbcurstep << " ";
      fPrintDomainMass();
      double timeelapsed = fCheckTimeSerial();
      cout << left << setw(12) << timeelapsed << " ";
      fPrintDomainMomentum();
    }
    fInteractionForceZero();
    fConvectionForceBoussinesq(lbbousth, lbboustl);
    fCalcPotential_ShanChen();
    fsInteractionForceShanChen();
    fCollisionMRTGuoShanChen();
    fPostCollBoundary();
    fPropagationSwap();
    fPostPropBoundary();
    lbcurstep++;
  }
  while(lbcurstep<=lbtotstep);
  return 0;
}

// Shan/Chen pseudopotential interactions with quadratic pseudopotential term

// option 0: BGK with standard forcing

int fsBGKShanChenQuadratic()
{
  do {
    if(lbcurstep%lbsave == 0 || lbcurstep==lbequstep) {
      if(lbequstep>0 && lbcurstep==lbequstep) {
        fPrintEndEquilibration();
        postequil = 1;
        fReadSpaceParameter();
        fNeighbourBoundary();
      }
      if(lbcurstep>=lbequstep)
        fOutput();
      cout << left << setw(12) << lbcurstep << " ";
      fPrintDomainMass();
      double timeelapsed = fCheckTimeSerial();
      cout << left << setw(12) << timeelapsed << " ";
      fPrintDomainMomentum();
    }
    fInteractionForceZero();
    fConvectionForceBoussinesq(lbbousth, lbboustl);
    fCalcPotential_ShanChen();
    fsInteractionForceShanChenQuadratic();
    fCollisionBGKShanChen();
    fPostCollBoundary();
    fPropagationSwap();
    fPostPropBoundary();
    lbcurstep++;
  }
  while(lbcurstep<=lbtotstep);
  return 0;
}

// option 1: BGK with EDM forcing

int fsBGKEDMShanChenQuadratic()
{
  do {
    if(lbcurstep%lbsave == 0 || lbcurstep==lbequstep) {
      if(lbequstep>0 && lbcurstep==lbequstep) {
        fPrintEndEquilibration();
        postequil = 1;
        fReadSpaceParameter();
        fNeighbourBoundary();
      }
      if(lbcurstep>=lbequstep)
        fOutput();
      cout << left << setw(12) << lbcurstep << " ";
      fPrintDomainMass();
      double timeelapsed = fCheckTimeSerial();
      cout << left << setw(12) << timeelapsed << " ";
      fPrintDomainMomentum();
    }
    fInteractionForceZero();
    fConvectionForceBoussinesq(lbbousth, lbboustl);
    fCalcPotential_ShanChen();
    fsInteractionForceShanChenQuadratic();
    fCollisionBGKEDMShanChen();
    fPostCollBoundary();
    fPropagationSwap();
    fPostPropBoundary();
    lbcurstep++;
  }
  while(lbcurstep<=lbtotstep);
  return 0;
}

// option 2: BGK with Guo forcing

int fsBGKGuoShanChenQuadratic()
{
  do {
    if(lbcurstep%lbsave == 0 || lbcurstep==lbequstep) {
      if(lbequstep>0 && lbcurstep==lbequstep) {
        fPrintEndEquilibration();
        postequil = 1;
        fReadSpaceParameter();
        fNeighbourBoundary();
      }
      if(lbcurstep>=lbequstep)
        fOutput();
      cout << left << setw(12) << lbcurstep << " ";
      fPrintDomainMass();
      double timeelapsed = fCheckTimeSerial();
      cout << left << setw(12) << timeelapsed << " ";
      fPrintDomainMomentum();
    }
    fInteractionForceZero();
    fConvectionForceBoussinesq(lbbousth, lbboustl);
    fCalcPotential_ShanChen();
    fsInteractionForceShanChenQuadratic();
    fCollisionBGKGuoShanChen();
    fPostCollBoundary();
    fPropagationSwap();
    fPostPropBoundary();
    lbcurstep++;
  }
  while(lbcurstep<=lbtotstep);
  return 0;
}

// option 3: TRT with standard forcing

int fsTRTShanChenQuadratic()
{
  do {
    if(lbcurstep%lbsave == 0 || lbcurstep==lbequstep) {
      if(lbequstep>0 && lbcurstep==lbequstep) {
        fPrintEndEquilibration();
        postequil = 1;
        fReadSpaceParameter();
        fNeighbourBoundary();
      }
      if(lbcurstep>=lbequstep)
        fOutput();
      cout << left << setw(12) << lbcurstep << " ";
      fPrintDomainMass();
      double timeelapsed = fCheckTimeSerial();
      cout << left << setw(12) << timeelapsed << " ";
      fPrintDomainMomentum();
    }
    fInteractionForceZero();
    fConvectionForceBoussinesq(lbbousth, lbboustl);
    fCalcPotential_ShanChen();
    fsInteractionForceShanChenQuadratic();
    fCollisionTRTShanChen();
    fPostCollBoundary();
    fPropagationSwap();
    fPostPropBoundary();
    lbcurstep++;
  }
  while(lbcurstep<=lbtotstep);
  return 0;
}

// option 4: TRT with EDM forcing

int fsTRTEDMShanChenQuadratic()
{
  do {
    if(lbcurstep%lbsave == 0 || lbcurstep==lbequstep) {
      if(lbequstep>0 && lbcurstep==lbequstep) {
        fPrintEndEquilibration();
        postequil = 1;
        fReadSpaceParameter();
        fNeighbourBoundary();
      }
      if(lbcurstep>=lbequstep)
        fOutput();
      cout << left << setw(12) << lbcurstep << " ";
      fPrintDomainMass();
      double timeelapsed = fCheckTimeSerial();
      cout << left << setw(12) << timeelapsed << " ";
      fPrintDomainMomentum();
    }
    fInteractionForceZero();
    fConvectionForceBoussinesq(lbbousth, lbboustl);
    fCalcPotential_ShanChen();
    fsInteractionForceShanChenQuadratic();
    fCollisionTRTEDMShanChen();
    fPostCollBoundary();
    fPropagationSwap();
    fPostPropBoundary();
    lbcurstep++;
  }
  while(lbcurstep<=lbtotstep);
  return 0;
}

// option 5: TRT with Guo forcing

int fsTRTGuoShanChenQuadratic()
{
  do {
    if(lbcurstep%lbsave == 0 || lbcurstep==lbequstep) {
      if(lbequstep>0 && lbcurstep==lbequstep) {
        fPrintEndEquilibration();
        postequil = 1;
        fReadSpaceParameter();
        fNeighbourBoundary();
      }
      if(lbcurstep>=lbequstep)
        fOutput();
      cout << left << setw(12) << lbcurstep << " ";
      fPrintDomainMass();
      double timeelapsed = fCheckTimeSerial();
      cout << left << setw(12) << timeelapsed << " ";
      fPrintDomainMomentum();
    }
    fInteractionForceZero();
    fConvectionForceBoussinesq(lbbousth, lbboustl);
    fCalcPotential_ShanChen();
    fsInteractionForceShanChenQuadratic();
    fCollisionTRTGuoShanChen();
    fPostCollBoundary();
    fPropagationSwap();
    fPostPropBoundary();
    lbcurstep++;
  }
  while(lbcurstep<=lbtotstep);
  return 0;
}

// option 6: MRT with standard forcing

int fsMRTShanChenQuadratic()
{
  do {
    if(lbcurstep%lbsave == 0 || lbcurstep==lbequstep) {
      if(lbequstep>0 && lbcurstep==lbequstep) {
        fPrintEndEquilibration();
        postequil = 1;
        fReadSpaceParameter();
        fNeighbourBoundary();
      }
      if(lbcurstep>=lbequstep)
        fOutput();
      cout << left << setw(12) << lbcurstep << " ";
      fPrintDomainMass();
      double timeelapsed = fCheckTimeSerial();
      cout << left << setw(12) << timeelapsed << " ";
      fPrintDomainMomentum();
    }
    fInteractionForceZero();
    fConvectionForceBoussinesq(lbbousth, lbboustl);
    fCalcPotential_ShanChen();
    fsInteractionForceShanChenQuadratic();
    fCollisionMRTShanChen();
    fPostCollBoundary();
    fPropagationSwap();
    fPostPropBoundary();
    lbcurstep++;
  }
  while(lbcurstep<=lbtotstep);
  return 0;
}

// option 7: MRT with EDM forcing

int fsMRTEDMShanChenQuadratic()
{
  do {
    if(lbcurstep%lbsave == 0 || lbcurstep==lbequstep) {
      if(lbequstep>0 && lbcurstep==lbequstep) {
        fPrintEndEquilibration();
        postequil = 1;
        fReadSpaceParameter();
        fNeighbourBoundary();
      }
      if(lbcurstep>=lbequstep)
        fOutput();
      cout << left << setw(12) << lbcurstep << " ";
      fPrintDomainMass();
      double timeelapsed = fCheckTimeSerial();
      cout << left << setw(12) << timeelapsed << " ";
      fPrintDomainMomentum();
    }
    fInteractionForceZero();
    fConvectionForceBoussinesq(lbbousth, lbboustl);
    fCalcPotential_ShanChen();
    fsInteractionForceShanChenQuadratic();
    fCollisionMRTEDMShanChen();
    fPostCollBoundary();
    fPropagationSwap();
    fPostPropBoundary();
    lbcurstep++;
  }
  while(lbcurstep<=lbtotstep);
  return 0;
}

// option 8: MRT with Guo-like forcing

int fsMRTGuoShanChenQuadratic()
{
  do {
    if(lbcurstep%lbsave == 0 || lbcurstep==lbequstep) {
      if(lbequstep>0 && lbcurstep==lbequstep) {
        fPrintEndEquilibration();
        postequil = 1;
        fReadSpaceParameter();
        fNeighbourBoundary();
      }
      if(lbcurstep>=lbequstep)
        fOutput();
      cout << left << setw(12) << lbcurstep << " ";
      fPrintDomainMass();
      double timeelapsed = fCheckTimeSerial();
      cout << left << setw(12) << timeelapsed << " ";
      fPrintDomainMomentum();
    }
    fInteractionForceZero();
    fConvectionForceBoussinesq(lbbousth, lbboustl);
    fCalcPotential_ShanChen();
    fsInteractionForceShanChenQuadratic();
    fCollisionMRTGuoShanChen();
    fPostCollBoundary();
    fPropagationSwap();
    fPostPropBoundary();
    lbcurstep++;
  }
  while(lbcurstep<=lbtotstep);
  return 0;
}

// Lishchuk continuum-based interactions (with interfacial normals calculated non-locally)

// option 0: BGK with standard forcing

int fsBGKLishchuk()
{
  do {
    if(lbcurstep%lbsave == 0 || lbcurstep==lbequstep) {
      if(lbequstep>0 && lbcurstep==lbequstep) {
        fPrintEndEquilibration();
        postequil = 1;
        fReadSpaceParameter();
        fNeighbourBoundary();
      }
      if(lbcurstep>=lbequstep)
        fOutput();
      cout << left << setw(12) << lbcurstep << " ";
      fPrintDomainMass();
      double timeelapsed = fCheckTimeSerial();
      cout << left << setw(12) << timeelapsed << " ";
      fPrintDomainMomentum();
    }
    fInteractionForceZero();
    fConvectionForceBoussinesq(lbbousth, lbboustl);
    fsCalcPhaseIndex_Lishchuk();
    fsInteractionForceLishchuk();
    fCollisionBGKLishchuk();
    fPostCollBoundary();
    fPropagationSwap();
    fPostPropBoundary();
    lbcurstep++;
  }
  while(lbcurstep<=lbtotstep);
  return 0;
}

// option 1: BGK with EDM forcing

int fsBGKEDMLishchuk()
{
  do {
    if(lbcurstep%lbsave == 0 || lbcurstep==lbequstep) {
      if(lbequstep>0 && lbcurstep==lbequstep) {
        fPrintEndEquilibration();
        postequil = 1;
        fReadSpaceParameter();
        fNeighbourBoundary();
      }
      if(lbcurstep>=lbequstep)
        fOutput();
      cout << left << setw(12) << lbcurstep << " ";
      fPrintDomainMass();
      double timeelapsed = fCheckTimeSerial();
      cout << left << setw(12) << timeelapsed << " ";
      fPrintDomainMomentum();
    }
    fInteractionForceZero();
    fConvectionForceBoussinesq(lbbousth, lbboustl);
    fsCalcPhaseIndex_Lishchuk();
    fsInteractionForceLishchuk();
    fCollisionBGKEDMLishchuk();
    fPostCollBoundary();
    fPropagationSwap();
    fPostPropBoundary();
    lbcurstep++;
  }
  while(lbcurstep<=lbtotstep);
  return 0;
}

// option 2: BGK with Guo forcing

int fsBGKGuoLishchuk()
{
  do {
    if(lbcurstep%lbsave == 0 || lbcurstep==lbequstep) {
      if(lbequstep>0 && lbcurstep==lbequstep) {
        fPrintEndEquilibration();
        postequil = 1;
        fReadSpaceParameter();
        fNeighbourBoundary();
      }
      if(lbcurstep>=lbequstep)
        fOutput();
      cout << left << setw(12) << lbcurstep << " ";
      fPrintDomainMass();
      double timeelapsed = fCheckTimeSerial();
      cout << left << setw(12) << timeelapsed << " ";
      fPrintDomainMomentum();
    }
    fInteractionForceZero();
    fConvectionForceBoussinesq(lbbousth, lbboustl);
    fsCalcPhaseIndex_Lishchuk();
    fsInteractionForceLishchuk();
    fCollisionBGKGuoLishchuk();
    fPostCollBoundary();
    fPropagationSwap();
    fPostPropBoundary();
    lbcurstep++;
  }
  while(lbcurstep<=lbtotstep);
  return 0;
}

// option 3: TRT with standard forcing

int fsTRTLishchuk()
{
  do {
    if(lbcurstep%lbsave == 0 || lbcurstep==lbequstep) {
      if(lbequstep>0 && lbcurstep==lbequstep) {
        fPrintEndEquilibration();
        postequil = 1;
        fReadSpaceParameter();
        fNeighbourBoundary();
      }
      if(lbcurstep>=lbequstep)
        fOutput();
      cout << left << setw(12) << lbcurstep << " ";
      fPrintDomainMass();
      double timeelapsed = fCheckTimeSerial();
      cout << left << setw(12) << timeelapsed << " ";
      fPrintDomainMomentum();
    }
    fInteractionForceZero();
    fConvectionForceBoussinesq(lbbousth, lbboustl);
    fsCalcPhaseIndex_Lishchuk();
    fsInteractionForceLishchuk();
    fCollisionTRTLishchuk();
    fPostCollBoundary();
    fPropagationSwap();
    fPostPropBoundary();
    lbcurstep++;
  }
  while(lbcurstep<=lbtotstep);
  return 0;
}

// option 4: TRT with EDM forcing

int fsTRTEDMLishchuk()
{
  do {
    if(lbcurstep%lbsave == 0 || lbcurstep==lbequstep) {
      if(lbequstep>0 && lbcurstep==lbequstep) {
        fPrintEndEquilibration();
        postequil = 1;
        fReadSpaceParameter();
        fNeighbourBoundary();
      }
      if(lbcurstep>=lbequstep)
        fOutput();
      cout << left << setw(12) << lbcurstep << " ";
      fPrintDomainMass();
      double timeelapsed = fCheckTimeSerial();
      cout << left << setw(12) << timeelapsed << " ";
      fPrintDomainMomentum();
    }
    fInteractionForceZero();
    fConvectionForceBoussinesq(lbbousth, lbboustl);
    fsCalcPhaseIndex_Lishchuk();
    fsInteractionForceLishchuk();
    fCollisionTRTEDMLishchuk();
    fPostCollBoundary();
    fPropagationSwap();
    fPostPropBoundary();
    lbcurstep++;
  }
  while(lbcurstep<=lbtotstep);
  return 0;
}

// option 5: TRT with Guo forcing

int fsTRTGuoLishchuk()
{
  do {
    if(lbcurstep%lbsave == 0 || lbcurstep==lbequstep) {
      if(lbequstep>0 && lbcurstep==lbequstep) {
        fPrintEndEquilibration();
        postequil = 1;
        fReadSpaceParameter();
        fNeighbourBoundary();
      }
      if(lbcurstep>=lbequstep)
        fOutput();
      cout << left << setw(12) << lbcurstep << " ";
      fPrintDomainMass();
      double timeelapsed = fCheckTimeSerial();
      cout << left << setw(12) << timeelapsed << " ";
      fPrintDomainMomentum();
    }
    fInteractionForceZero();
    fConvectionForceBoussinesq(lbbousth, lbboustl);
    fsCalcPhaseIndex_Lishchuk();
    fsInteractionForceLishchuk();
    fCollisionTRTGuoLishchuk();
    fPostCollBoundary();
    fPropagationSwap();
    fPostPropBoundary();
    lbcurstep++;
  }
  while(lbcurstep<=lbtotstep);
  return 0;
}

// option 6: MRT with standard forcing

int fsMRTLishchuk()
{
  do {
    if(lbcurstep%lbsave == 0 || lbcurstep==lbequstep) {
      if(lbequstep>0 && lbcurstep==lbequstep) {
        fPrintEndEquilibration();
        postequil = 1;
        fReadSpaceParameter();
        fNeighbourBoundary();
      }
      if(lbcurstep>=lbequstep)
        fOutput();
      cout << left << setw(12) << lbcurstep << " ";
      fPrintDomainMass();
      double timeelapsed = fCheckTimeSerial();
      cout << left << setw(12) << timeelapsed << " ";
      fPrintDomainMomentum();
    }
    fInteractionForceZero();
    fConvectionForceBoussinesq(lbbousth, lbboustl);
    fsCalcPhaseIndex_Lishchuk();
    fsInteractionForceLishchuk();
    fCollisionMRTLishchuk();
    fPostCollBoundary();
    fPropagationSwap();
    fPostPropBoundary();
    lbcurstep++;
  }
  while(lbcurstep<=lbtotstep);
  return 0;
}

// option 7: MRT with EDM forcing

int fsMRTEDMLishchuk()
{
  do {
    if(lbcurstep%lbsave == 0 || lbcurstep==lbequstep) {
      if(lbequstep>0 && lbcurstep==lbequstep) {
        fPrintEndEquilibration();
        postequil = 1;
        fReadSpaceParameter();
        fNeighbourBoundary();
      }
      if(lbcurstep>=lbequstep)
        fOutput();
      cout << left << setw(12) << lbcurstep << " ";
      fPrintDomainMass();
      double timeelapsed = fCheckTimeSerial();
      cout << left << setw(12) << timeelapsed << " ";
      fPrintDomainMomentum();
    }
    fInteractionForceZero();
    fConvectionForceBoussinesq(lbbousth, lbboustl);
    fsCalcPhaseIndex_Lishchuk();
    fsInteractionForceLishchuk();
    fCollisionMRTEDMLishchuk();
    fPostCollBoundary();
    fPropagationSwap();
    fPostPropBoundary();
    lbcurstep++;
  }
  while(lbcurstep<=lbtotstep);
  return 0;
}

// option 8: MRT with Guo-like forcing

int fsMRTGuoLishchuk()
{
  do {
    if(lbcurstep%lbsave == 0 || lbcurstep==lbequstep) {
      if(lbequstep>0 && lbcurstep==lbequstep) {
        fPrintEndEquilibration();
        postequil = 1;
        fReadSpaceParameter();
        fNeighbourBoundary();
      }
      if(lbcurstep>=lbequstep)
        fOutput();
      cout << left << setw(12) << lbcurstep << " ";
      fPrintDomainMass();
      double timeelapsed = fCheckTimeSerial();
      cout << left << setw(12) << timeelapsed << " ";
      fPrintDomainMomentum();
    }
    fInteractionForceZero();
    fConvectionForceBoussinesq(lbbousth, lbboustl);
    fsCalcPhaseIndex_Lishchuk();
    fsInteractionForceLishchuk();
    fCollisionMRTGuoLishchuk();
    fPostCollBoundary();
    fPropagationSwap();
    fPostPropBoundary();
    lbcurstep++;
  }
  while(lbcurstep<=lbtotstep);
  return 0;
}

// Lishchuk continuum-based interactions (with interfacial normals calculated locally)

// option 0: BGK with standard forcing

int fsBGKLishchukLocal()
{
  do {
    if(lbcurstep%lbsave == 0 || lbcurstep==lbequstep) {
      if(lbequstep>0 && lbcurstep==lbequstep) {
        fPrintEndEquilibration();
        postequil = 1;
        fReadSpaceParameter();
        fNeighbourBoundary();
      }
      if(lbcurstep>=lbequstep)
        fOutput();
      cout << left << setw(12) << lbcurstep << " ";
      fPrintDomainMass();
      double timeelapsed = fCheckTimeSerial();
      cout << left << setw(12) << timeelapsed << " ";
      fPrintDomainMomentum();
    }
    fInteractionForceZero();
    fConvectionForceBoussinesq(lbbousth, lbboustl);
    fCalcPhaseIndex_LishchukLocal();
    fCollisionBGKLishchukLocal();
    fPostCollBoundary();
    fPropagationSwap();
    fPostPropBoundary();
    lbcurstep++;
  }
  while(lbcurstep<=lbtotstep);
  return 0;
}

// option 1: BGK with EDM forcing

int fsBGKEDMLishchukLocal()
{
  do {
    if(lbcurstep%lbsave == 0 || lbcurstep==lbequstep) {
      if(lbequstep>0 && lbcurstep==lbequstep) {
        fPrintEndEquilibration();
        postequil = 1;
        fReadSpaceParameter();
        fNeighbourBoundary();
      }
      if(lbcurstep>=lbequstep)
        fOutput();
      cout << left << setw(12) << lbcurstep << " ";
      fPrintDomainMass();
      double timeelapsed = fCheckTimeSerial();
      cout << left << setw(12) << timeelapsed << " ";
      fPrintDomainMomentum();
    }
    fInteractionForceZero();
    fConvectionForceBoussinesq(lbbousth, lbboustl);
    fCalcPhaseIndex_LishchukLocal();
    fCollisionBGKEDMLishchukLocal();
    fPostCollBoundary();
    fPropagationSwap();
    fPostPropBoundary();
    lbcurstep++;
  }
  while(lbcurstep<=lbtotstep);
  return 0;
}

// option 2: BGK with Guo forcing

int fsBGKGuoLishchukLocal()
{
  do {
    if(lbcurstep%lbsave == 0 || lbcurstep==lbequstep) {
      if(lbequstep>0 && lbcurstep==lbequstep) {
        fPrintEndEquilibration();
        postequil = 1;
        fReadSpaceParameter();
        fNeighbourBoundary();
      }
      if(lbcurstep>=lbequstep)
        fOutput();
      cout << left << setw(12) << lbcurstep << " ";
      fPrintDomainMass();
      double timeelapsed = fCheckTimeSerial();
      cout << left << setw(12) << timeelapsed << " ";
      fPrintDomainMomentum();
    }
    fInteractionForceZero();
    fConvectionForceBoussinesq(lbbousth, lbboustl);
    fCalcPhaseIndex_LishchukLocal();
    fCollisionBGKGuoLishchukLocal();
    fPostCollBoundary();
    fPropagationSwap();
    fPostPropBoundary();
    lbcurstep++;
  }
  while(lbcurstep<=lbtotstep);
  return 0;
}

// option 3: TRT with standard forcing

int fsTRTLishchukLocal()
{
  do {
    if(lbcurstep%lbsave == 0 || lbcurstep==lbequstep) {
      if(lbequstep>0 && lbcurstep==lbequstep) {
        fPrintEndEquilibration();
        postequil = 1;
        fReadSpaceParameter();
        fNeighbourBoundary();
      }
      if(lbcurstep>=lbequstep)
        fOutput();
      cout << left << setw(12) << lbcurstep << " ";
      fPrintDomainMass();
      double timeelapsed = fCheckTimeSerial();
      cout << left << setw(12) << timeelapsed << " ";
      fPrintDomainMomentum();
    }
    fInteractionForceZero();
    fConvectionForceBoussinesq(lbbousth, lbboustl);
    fCalcPhaseIndex_LishchukLocal();
    fCollisionTRTLishchukLocal();
    fPostCollBoundary();
    fPropagationSwap();
    fPostPropBoundary();
    lbcurstep++;
  }
  while(lbcurstep<=lbtotstep);
  return 0;
}

// option 4: TRT with EDM forcing

int fsTRTEDMLishchukLocal()
{
  do {
    if(lbcurstep%lbsave == 0 || lbcurstep==lbequstep) {
      if(lbequstep>0 && lbcurstep==lbequstep) {
        fPrintEndEquilibration();
        postequil = 1;
        fReadSpaceParameter();
        fNeighbourBoundary();
      }
      if(lbcurstep>=lbequstep)
        fOutput();
      cout << left << setw(12) << lbcurstep << " ";
      fPrintDomainMass();
      double timeelapsed = fCheckTimeSerial();
      cout << left << setw(12) << timeelapsed << " ";
      fPrintDomainMomentum();
    }
    fInteractionForceZero();
    fConvectionForceBoussinesq(lbbousth, lbboustl);
    fCalcPhaseIndex_LishchukLocal();
    fCollisionTRTEDMLishchukLocal();
    fPostCollBoundary();
    fPropagationSwap();
    fPostPropBoundary();
    lbcurstep++;
  }
  while(lbcurstep<=lbtotstep);
  return 0;
}

// option 5: TRT with Guo forcing

int fsTRTGuoLishchukLocal()
{
  do {
    if(lbcurstep%lbsave == 0 || lbcurstep==lbequstep) {
      if(lbequstep>0 && lbcurstep==lbequstep) {
        fPrintEndEquilibration();
        postequil = 1;
        fReadSpaceParameter();
        fNeighbourBoundary();
      }
      if(lbcurstep>=lbequstep)
        fOutput();
      cout << left << setw(12) << lbcurstep << " ";
      fPrintDomainMass();
      double timeelapsed = fCheckTimeSerial();
      cout << left << setw(12) << timeelapsed << " ";
      fPrintDomainMomentum();
    }
    fInteractionForceZero();
    fConvectionForceBoussinesq(lbbousth, lbboustl);
    fCalcPhaseIndex_LishchukLocal();
    fCollisionTRTGuoLishchukLocal();
    fPostCollBoundary();
    fPropagationSwap();
    fPostPropBoundary();
    lbcurstep++;
  }
  while(lbcurstep<=lbtotstep);
  return 0;
}

// option 6: MRT with standard forcing

int fsMRTLishchukLocal()
{
  do {
    if(lbcurstep%lbsave == 0 || lbcurstep==lbequstep) {
      if(lbequstep>0 && lbcurstep==lbequstep) {
        fPrintEndEquilibration();
        postequil = 1;
        fReadSpaceParameter();
        fNeighbourBoundary();
      }
      if(lbcurstep>=lbequstep)
        fOutput();
      cout << left << setw(12) << lbcurstep << " ";
      fPrintDomainMass();
      double timeelapsed = fCheckTimeSerial();
      cout << left << setw(12) << timeelapsed << " ";
      fPrintDomainMomentum();
    }
    fInteractionForceZero();
    fConvectionForceBoussinesq(lbbousth, lbboustl);
    fCalcPhaseIndex_LishchukLocal();
    fCollisionMRTLishchukLocal();
    fPostCollBoundary();
    fPropagationSwap();
    fPostPropBoundary();
    lbcurstep++;
  }
  while(lbcurstep<=lbtotstep);
  return 0;
}

// option 7: MRT with EDM forcing

int fsMRTEDMLishchukLocal()
{
  do {
    if(lbcurstep%lbsave == 0 || lbcurstep==lbequstep) {
      if(lbequstep>0 && lbcurstep==lbequstep) {
        fPrintEndEquilibration();
        postequil = 1;
        fReadSpaceParameter();
        fNeighbourBoundary();
      }
      if(lbcurstep>=lbequstep)
        fOutput();
      cout << left << setw(12) << lbcurstep << " ";
      fPrintDomainMass();
      double timeelapsed = fCheckTimeSerial();
      cout << left << setw(12) << timeelapsed << " ";
      fPrintDomainMomentum();
    }
    fInteractionForceZero();
    fConvectionForceBoussinesq(lbbousth, lbboustl);
    fCalcPhaseIndex_LishchukLocal();
    fCollisionMRTEDMLishchukLocal();
    fPostCollBoundary();
    fPropagationSwap();
    fPostPropBoundary();
    lbcurstep++;
  }
  while(lbcurstep<=lbtotstep);
  return 0;
}

// option 8: MRT with Guo-like forcing

int fsMRTGuoLishchukLocal()
{
  do {
    if(lbcurstep%lbsave == 0 || lbcurstep==lbequstep) {
      if(lbequstep>0 && lbcurstep==lbequstep) {
        fPrintEndEquilibration();
        postequil = 1;
        fReadSpaceParameter();
        fNeighbourBoundary();
      }
      if(lbcurstep>=lbequstep)
        fOutput();
      cout << left << setw(12) << lbcurstep << " ";
      fPrintDomainMass();
      double timeelapsed = fCheckTimeSerial();
      cout << left << setw(12) << timeelapsed << " ";
      fPrintDomainMomentum();
    }
    fInteractionForceZero();
    fConvectionForceBoussinesq(lbbousth, lbboustl);
    fCalcPhaseIndex_LishchukLocal();
    fCollisionMRTGuoLishchukLocal();
    fPostCollBoundary();
    fPropagationSwap();
    fPostPropBoundary();
    lbcurstep++;
  }
  while(lbcurstep<=lbtotstep);
  return 0;
}

// Swift free-energy interactions

// option 0: BGK with standard forcing

int fsBGKSwift()
{
  do {
    if(lbcurstep%lbsave == 0 || lbcurstep==lbequstep) {
      if(lbequstep>0 && lbcurstep==lbequstep) {
        fPrintEndEquilibration();
        postequil = 1;
        fReadSpaceParameter();
        fNeighbourBoundary();
      }
      if(lbcurstep>=lbequstep)
        fOutput();
      cout << left << setw(12) << lbcurstep << " ";
      fPrintDomainMass();
      double timeelapsed = fCheckTimeSerial();
      cout << left << setw(12) << timeelapsed << " ";
      fPrintDomainMomentum();
    }
    fInteractionForceZero();
    fConvectionForceBoussinesq(lbbousth, lbboustl);
    fsCalcGradient_Swift();
    fCollisionBGKSwift();
    fPostCollBoundary();
    fPropagationSwap();
    fPostPropBoundary();
    lbcurstep++;
  }
  while(lbcurstep<=lbtotstep);
  return 0;
}

// option 1: BGK with EDM forcing

int fsBGKEDMSwift()
{
  do {
    if(lbcurstep%lbsave == 0 || lbcurstep==lbequstep) {
      if(lbequstep>0 && lbcurstep==lbequstep) {
        fPrintEndEquilibration();
        postequil = 1;
        fReadSpaceParameter();
        fNeighbourBoundary();
      }
      if(lbcurstep>=lbequstep)
        fOutput();
      cout << left << setw(12) << lbcurstep << " ";
      fPrintDomainMass();
      double timeelapsed = fCheckTimeSerial();
      cout << left << setw(12) << timeelapsed << " ";
      fPrintDomainMomentum();
    }
    fInteractionForceZero();
    fConvectionForceBoussinesq(lbbousth, lbboustl);
    fsCalcGradient_Swift();
    fCollisionBGKEDMSwift();
    fPostCollBoundary();
    fPropagationSwap();
    fPostPropBoundary();
    lbcurstep++;
  }
  while(lbcurstep<=lbtotstep);
  return 0;
}

// option 2: BGK with Guo forcing

int fsBGKGuoSwift()
{
  do {
    if(lbcurstep%lbsave == 0 || lbcurstep==lbequstep) {
      if(lbequstep>0 && lbcurstep==lbequstep) {
        fPrintEndEquilibration();
        postequil = 1;
        fReadSpaceParameter();
        fNeighbourBoundary();
      }
      if(lbcurstep>=lbequstep)
        fOutput();
      cout << left << setw(12) << lbcurstep << " ";
      fPrintDomainMass();
      double timeelapsed = fCheckTimeSerial();
      cout << left << setw(12) << timeelapsed << " ";
      fPrintDomainMomentum();
    }
    fInteractionForceZero();
    fConvectionForceBoussinesq(lbbousth, lbboustl);
    fsCalcGradient_Swift();
    fCollisionBGKGuoSwift();
    fPostCollBoundary();
    fPropagationSwap();
    fPostPropBoundary();
    lbcurstep++;
  }
  while(lbcurstep<=lbtotstep);
  return 0;
}

// option 3: TRT with standard forcing

int fsTRTSwift()
{
  do {
    if(lbcurstep%lbsave == 0 || lbcurstep==lbequstep) {
      if(lbequstep>0 && lbcurstep==lbequstep) {
        fPrintEndEquilibration();
        postequil = 1;
        fReadSpaceParameter();
        fNeighbourBoundary();
      }
      if(lbcurstep>=lbequstep)
        fOutput();
      cout << left << setw(12) << lbcurstep << " ";
      fPrintDomainMass();
      double timeelapsed = fCheckTimeSerial();
      cout << left << setw(12) << timeelapsed << " ";
      fPrintDomainMomentum();
    }
    fInteractionForceZero();
    fConvectionForceBoussinesq(lbbousth, lbboustl);
    fsCalcGradient_Swift();
    fCollisionTRTSwift();
    fPostCollBoundary();
    fPropagationSwap();
    fPostPropBoundary();
    lbcurstep++;
  }
  while(lbcurstep<=lbtotstep);
  return 0;
}

// option 4: TRT with EDM forcing

int fsTRTEDMSwift()
{
  do {
    if(lbcurstep%lbsave == 0 || lbcurstep==lbequstep) {
      if(lbequstep>0 && lbcurstep==lbequstep) {
        fPrintEndEquilibration();
        postequil = 1;
        fReadSpaceParameter();
        fNeighbourBoundary();
      }
      if(lbcurstep>=lbequstep)
        fOutput();
      cout << left << setw(12) << lbcurstep << " ";
      fPrintDomainMass();
      double timeelapsed = fCheckTimeSerial();
      cout << left << setw(12) << timeelapsed << " ";
      fPrintDomainMomentum();
    }
    fInteractionForceZero();
    fConvectionForceBoussinesq(lbbousth, lbboustl);
    fsCalcGradient_Swift();
    fCollisionTRTEDMSwift();
    fPostCollBoundary();
    fPropagationSwap();
    fPostPropBoundary();
    lbcurstep++;
  }
  while(lbcurstep<=lbtotstep);
  return 0;
}

// option 5: TRT with Guo forcing

int fsTRTGuoSwift()
{
  do {
    if(lbcurstep%lbsave == 0 || lbcurstep==lbequstep) {
      if(lbequstep>0 && lbcurstep==lbequstep) {
        fPrintEndEquilibration();
        postequil = 1;
        fReadSpaceParameter();
        fNeighbourBoundary();
      }
      if(lbcurstep>=lbequstep)
        fOutput();
      cout << left << setw(12) << lbcurstep << " ";
      fPrintDomainMass();
      double timeelapsed = fCheckTimeSerial();
      cout << left << setw(12) << timeelapsed << " ";
      fPrintDomainMomentum();
    }
    fInteractionForceZero();
    fConvectionForceBoussinesq(lbbousth, lbboustl);
    fsCalcGradient_Swift();
    fCollisionTRTGuoSwift();
    fPostCollBoundary();
    fPropagationSwap();
    fPostPropBoundary();
    lbcurstep++;
  }
  while(lbcurstep<=lbtotstep);
  return 0;
}

// option 6: MRT with standard forcing

int fsMRTSwift()
{
  do {
    if(lbcurstep%lbsave == 0 || lbcurstep==lbequstep) {
      if(lbequstep>0 && lbcurstep==lbequstep) {
        fPrintEndEquilibration();
        postequil = 1;
        fReadSpaceParameter();
        fNeighbourBoundary();
      }
      if(lbcurstep>=lbequstep)
        fOutput();
      cout << left << setw(12) << lbcurstep << " ";
      fPrintDomainMass();
      double timeelapsed = fCheckTimeSerial();
      cout << left << setw(12) << timeelapsed << " ";
      fPrintDomainMomentum();
    }
    fInteractionForceZero();
    fConvectionForceBoussinesq(lbbousth, lbboustl);
    fsCalcGradient_Swift();
    fCollisionMRTSwift();
    fPostCollBoundary();
    fPropagationSwap();
    fPostPropBoundary();
    lbcurstep++;
  }
  while(lbcurstep<=lbtotstep);
  return 0;
}

// option 7: MRT with EDM forcing

int fsMRTEDMSwift()
{
  do {
    if(lbcurstep%lbsave == 0 || lbcurstep==lbequstep) {
      if(lbequstep>0 && lbcurstep==lbequstep) {
        fPrintEndEquilibration();
        postequil = 1;
        fReadSpaceParameter();
        fNeighbourBoundary();
      }
      if(lbcurstep>=lbequstep)
        fOutput();
      cout << left << setw(12) << lbcurstep << " ";
      fPrintDomainMass();
      double timeelapsed = fCheckTimeSerial();
      cout << left << setw(12) << timeelapsed << " ";
      fPrintDomainMomentum();
    }
    fInteractionForceZero();
    fConvectionForceBoussinesq(lbbousth, lbboustl);
    fsCalcGradient_Swift();
    fCollisionMRTEDMSwift();
    fPostCollBoundary();
    fPropagationSwap();
    fPostPropBoundary();
    lbcurstep++;
  }
  while(lbcurstep<=lbtotstep);
  return 0;
}

// option 8: MRT with Guo-like forcing

int fsMRTGuoSwift()
{
  do {
    if(lbcurstep%lbsave == 0 || lbcurstep==lbequstep) {
      if(lbequstep>0 && lbcurstep==lbequstep) {
        fPrintEndEquilibration();
        postequil = 1;
        fReadSpaceParameter();
        fNeighbourBoundary();
      }
      if(lbcurstep>=lbequstep)
        fOutput();
      cout << left << setw(12) << lbcurstep << " ";
      fPrintDomainMass();
      double timeelapsed = fCheckTimeSerial();
      cout << left << setw(12) << timeelapsed << " ";
      fPrintDomainMomentum();
    }
    fInteractionForceZero();
    fConvectionForceBoussinesq(lbbousth, lbboustl);
    fsCalcGradient_Swift();
    fCollisionMRTGuoSwift();
    fPostCollBoundary();
    fPropagationSwap();
    fPostPropBoundary();
    lbcurstep++;
  }
  while(lbcurstep<=lbtotstep);
  return 0;
}


