/***********************************************
 *   DL_MESO       Version 2.6                 *
 *   Authors   :   R. S. Qin, M. A. Seaton     *
 *   Copyright :   STFC Daresbury Laboratory   *
 *             :   22/10/2015                  *
 ***********************************************/

// Plot3D format output

int fOutputGrid(const char* filename="lbout")
{
  if(lbsy.nd == 3)
    fOutputGrid3D(filename);
  else
    fOutputGrid2D(filename);
  return 0;
}

int fsOutputGrid(const char* filename="lbout")
{
  if(lbsy.nd == 3)
    fsOutputGrid3D(filename);
  else
    fsOutputGrid2D(filename);
  return 0;
}

int fOutputQ(const char* filename="lbout")
{
  char namebuf[80];
  if(lbsy.nd==3) {
    for(int iprop=0; iprop<lbsy.nf; iprop++) {
      sprintf(namebuf, "%s%.2ddens", filename, iprop);
      fOutputQP3D(namebuf, iprop);
      sprintf(namebuf, "%s%.2dfrac", filename, iprop);
      fOutputQCA3D(namebuf, iprop);
    }
    for(int iprop=0; iprop<lbsy.nc; iprop++) {
      sprintf(namebuf, "%s%.2dconc", filename, iprop);
      fOutputQCB3D(namebuf, iprop);
    }
    if(lbsy.nt==1) {
      sprintf(namebuf, "%stemp", filename);
      fOutputQT3D(namebuf);
    }
  }
  else {
    for(int iprop=0; iprop<lbsy.nf; iprop++) {
      sprintf(namebuf, "%s%.2ddens", filename, iprop);
      fOutputQP2D(namebuf, iprop);
      sprintf(namebuf, "%s%.2dfrac", filename, iprop);
      fOutputQCA2D(namebuf, iprop);
    }
    for(int iprop=0; iprop<lbsy.nc; iprop++) {
      sprintf(namebuf, "%s%.2dconc", filename, iprop);
      fOutputQCB2D(namebuf, iprop);
    }
    if(lbsy.nt==1) {
      sprintf(namebuf, "%stemp", filename);
      fOutputQT2D(namebuf);
    }
  }
  return 0;
}

int fsOutputQ(const char* filename="lbout")
{
  char namebuf[80];
  if(lbsy.nd==3) {
    for(int iprop=0; iprop<lbsy.nf; iprop++) {
      sprintf(namebuf, "%s%.2ddens", filename, iprop);
      fsOutputQP3D(namebuf, iprop);
      sprintf(namebuf, "%s%.2dfrac", filename, iprop);
      fsOutputQCA3D(namebuf, iprop);
    }
    for(int iprop=0; iprop<lbsy.nc; iprop++) {
      sprintf(namebuf, "%s%.2dconc", filename, iprop);
      fsOutputQCB3D(namebuf, iprop);
    }
    if(lbsy.nt==1) {
      sprintf(namebuf, "%stemp", filename);
      fsOutputQT3D(namebuf);
    }
  }
  else {
    for(int iprop=0; iprop<lbsy.nf; iprop++) {
      sprintf(namebuf, "%s%.2ddens", filename, iprop);
      fsOutputQP2D(namebuf, iprop);
      sprintf(namebuf, "%s%.2dfrac", filename, iprop);
      fsOutputQCA2D(namebuf, iprop);
    }
    for(int iprop=0; iprop<lbsy.nc; iprop++) {
      sprintf(namebuf, "%s%.2dconc", filename, iprop);
      fsOutputQCB2D(namebuf, iprop);
    }
    if(lbsy.nt==1) {
      sprintf(namebuf, "%stemp", filename);
      fsOutputQT2D(namebuf);
    }
  }
  return 0;
}

int fOutputQP(const char* filename="lbout", int iprop=0)
{
  if(lbsy.nd ==3)
    fOutputQP3D(filename, iprop);
  else
    fOutputQP2D(filename, iprop);
  return 0;
}


int fsOutputQP(const char* filename="lbout", int iprop=0)
{
  if(lbsy.nd ==3)
    fsOutputQP3D(filename, iprop);
  else
    fsOutputQP2D(filename, iprop);
  return 0;
}


int fOutputQCA(const char* filename="lbout", int iprop=0)
{
  if(lbsy.nd ==3)
    fOutputQCA3D(filename, iprop);
  else
    fOutputQCA2D(filename, iprop);
  return 0;
}


int fsOutputQCA(const char* filename="lbout", int iprop=0)
{
  if(lbsy.nd ==3)
    fsOutputQCA3D(filename, iprop);
  else
    fsOutputQCA2D(filename, iprop);
  return 0;
}


int fOutputQCB(const char* filename="lbout", int iprop=0)
{
  if(lbsy.nd ==3)
    fOutputQCB3D(filename, iprop);
  else
    fOutputQCB2D(filename, iprop);
  return 0;
}


int fsOutputQCB(const char* filename="lbout", int iprop=0)
{
  if(lbsy.nd ==3)
    fsOutputQCB3D(filename, iprop);
  else
    fsOutputQCB2D(filename, iprop);
  return 0;
}


int fOutputQT(const char* filename="lbout")
{
  if(lbsy.nd ==3)
    fOutputQT3D(filename);
  else
    fOutputQT2D(filename);
  return 0;
}


int fsOutputQT(const char* filename="lbout")
{
  if(lbsy.nd ==3)
    fsOutputQT3D(filename);
  else
    fsOutputQT2D(filename);
  return 0;
}


int fOutputGrid3D(const char* filename="lbout")
{
  int i, j, k, istart, iend, jstart, jend, kstart, kend;
  float ipos=0.0;
  int ilen=0;
  char buf[80];
  if(lbdm.size>1)
    sprintf(buf, "%s%.6d.xyz", filename, lbdm.rank);
  else
    sprintf(buf, "%s.xyz", filename);
    
  ofstream file(buf, ios::binary);

  ilen=lbdm.xouter;
  if(lbdm.xcor == 0)
    ilen -= lbdm.bwid;
  if(lbdm.xcor == lbdm.xdim-1)
    ilen -= lbdm.bwid;
  file.write((char*)&ilen, sizeof(int));

  ilen=lbdm.youter;
  if(lbdm.ycor == 0)
    ilen -= lbdm.bwid;
  if(lbdm.ycor == lbdm.ydim-1)
    ilen -= lbdm.bwid;
  file.write((char*)&ilen, sizeof(int));

  ilen=lbdm.zouter;
  if(lbdm.zcor == 0)
    ilen -= lbdm.bwid;
  if(lbdm.zcor == lbdm.zdim-1)
    ilen -= lbdm.bwid;
  file.write((char*)&ilen, sizeof(int));

  istart = 0; iend = lbdm.xouter; 
  if(lbdm.xcor == 0)
    istart = lbdm.bwid;
  if(lbdm.xcor == lbdm.xdim-1)
    iend = lbdm.xouter - lbdm.bwid;

  jstart = 0; jend = lbdm.youter; 
  if(lbdm.ycor == 0)
    jstart = lbdm.bwid;
  if(lbdm.ycor == lbdm.ydim-1)
    jend = lbdm.youter - lbdm.bwid;

  kstart = 0; kend = lbdm.zouter; 
  if(lbdm.zcor == 0)
    kstart = lbdm.bwid;
  if(lbdm.zcor == lbdm.zdim-1)
    kend = lbdm.zouter - lbdm.bwid;

  for(k=kstart; k<kend; k++)
    for(j=jstart; j<jend; j++) {
      for(i=istart; i<iend; i++) {
	ipos=(lbdm.xs + i - lbdm.bwid)*float(lbdx);
	file.write((char*)&ipos, sizeof(float));
      }
    }
  
  for(k=kstart; k<kend; k++)
    for(j=jstart; j<jend; j++) {
      for(i=istart; i<iend; i++) {
	ipos=(lbdm.ys + j - lbdm.bwid)*float(lbdx);
	file.write((char*)&ipos, sizeof(float));
      }
    }
  
  for(k=kstart; k<kend; k++)
    for(j=jstart; j<jend; j++) {
      for(i=istart; i<iend; i++) {
	ipos=(lbdm.zs + k - lbdm.bwid)*float(lbdx);
	file.write((char*)&ipos, sizeof(float));
      }
    }
  
  file.close();
  
  return 0;
}


int fOutputGrid2D(const char* filename="lbout")
{
  int i, j, istart, iend, jstart, jend;
  float ipos=0.0;
  int ilen=0;
  char buf[80];
  if(lbdm.size>1)
    sprintf(buf, "%s%.6d.xy", filename, lbdm.rank);
  else
    sprintf(buf, "%s.xy", filename);

  ofstream file(buf, ios::binary);

  ilen=lbdm.xouter;
  if(lbdm.xcor == 0)
    ilen -= lbdm.bwid;
  if(lbdm.xcor == lbdm.xdim-1)
    ilen -= lbdm.bwid;
  file.write((char*)&ilen, sizeof(int));

  ilen=lbdm.youter;
  if(lbdm.ycor == 0)
    ilen -= lbdm.bwid;
  if(lbdm.ycor == lbdm.ydim-1)
    ilen -= lbdm.bwid;
  file.write((char*)&ilen, sizeof(int));

  istart = 0; iend = lbdm.xouter; 
  if(lbdm.xcor == 0)
    istart = lbdm.bwid;
  if(lbdm.xcor == lbdm.xdim-1)
    iend = lbdm.xouter - lbdm.bwid;

  jstart = 0; jend = lbdm.youter; 
  if(lbdm.ycor == 0)
    jstart = lbdm.bwid;
  if(lbdm.ycor == lbdm.ydim-1)
    jend = lbdm.youter - lbdm.bwid;

  for(j=jstart; j<jend; j++)
    for(i=istart; i<iend; i++) {
      ipos=(lbdm.xs + i - lbdm.bwid)*float(lbdx);
      file.write((char*)&ipos, sizeof(float));
    }
  
  for(j=jstart; j<jend; j++) 
    for(i=istart; i<iend; i++) {
      ipos=(lbdm.ys + j - lbdm.bwid)*float(lbdx);
      file.write((char*)&ipos, sizeof(float));
    }
    
  file.close();
  
  return 0;
}


int fsOutputGrid3D(const char* filename="lbout")
{
  int i, j, k, istart, iend, jstart, jend, kstart, kend;
  char buf[80];
  if(lbdm.size>1)
    sprintf(buf, "%s%.6d.xyz", filename, lbdm.rank);
  else
    sprintf(buf, "%s.xyz", filename);

  ofstream file(buf);

  istart = 0; iend = lbdm.xouter; 
  if(lbdm.xcor == 0)
    istart = lbdm.bwid;
  if(lbdm.xcor == lbdm.xdim-1)
    iend = lbdm.xouter - lbdm.bwid;

  jstart = 0; jend = lbdm.youter; 
  if(lbdm.ycor == 0)
    jstart = lbdm.bwid;
  if(lbdm.ycor == lbdm.ydim-1)
    jend = lbdm.youter - lbdm.bwid;

  kstart = 0; kend = lbdm.zouter; 
  if(lbdm.zcor == 0)
    kstart = lbdm.bwid;
  if(lbdm.zcor == lbdm.zdim-1)
    kend = lbdm.zouter - lbdm.bwid;

  file<<(iend-istart)<<" "<<(jend-jstart)<<" "<<(kend-kstart)<<" "<<endl;
    
  for(k=kstart; k<kend; k++)
    for(j=jstart; j<jend; j++)
      for(i=istart; i<iend; i++)
	    file<<(lbdm.xs+i-lbdm.bwid)*float(lbdx)<<" ";
  file<<endl;
  for(k=kstart; k<kend; k++)
    for(j=jstart; j<jend; j++)
      for(i=istart; i<iend; i++)
	    file<<(lbdm.ys+j-lbdm.bwid)*float(lbdx)<<" ";
  file<<endl;
  for(k=kstart; k<kend; k++)
    for(j=jstart; j<jend; j++)
      for(i=istart; i<iend; i++)
	    file<<(lbdm.zs+k-lbdm.bwid)*float(lbdx)<<" ";
  file<<endl;
  file.close();
  return 0;
}


int fsOutputGrid2D(const char* filename="lbout")
{
  int i, j, istart, iend, jstart, jend;
  char buf[80];
  if(lbdm.size>1)
    sprintf(buf, "%s%.6d.xy", filename, lbdm.rank);
  else
    sprintf(buf, "%s.xy", filename);
    
  ofstream file(buf);

  istart = 0; iend = lbdm.xouter; 
  if(lbdm.xcor == 0)
    istart = lbdm.bwid;
  if(lbdm.xcor == lbdm.xdim-1)
    iend = lbdm.xouter - lbdm.bwid;

  jstart = 0; jend = lbdm.youter; 
  if(lbdm.ycor == 0)
    jstart = lbdm.bwid;
  if(lbdm.ycor == lbdm.ydim-1)
    jend = lbdm.youter - lbdm.bwid;

  file<<(iend-istart)<<" "<<(jend-jstart)<<" "<<endl;
    
  for(j=jstart; j<jend; j++)
    for(i=istart; i<iend; i++)
      file<<(lbdm.xs+i-lbdm.bwid)*float(lbdx)<<" ";
  file<<endl;
  for(j=jstart; j<jend; j++)
    for(i=istart; i<iend; i++)
      file<<(lbdm.ys+j-lbdm.bwid)*float(lbdx)<<" ";
  file<<endl;
  file.close();
  return 0;
}



int fOutputQP3D(const char* filename="lbout", int iprop=0)
{
  
  // output .q file with macroscopic mass density and velocity for fluid iprop

  int i, j, k, istart, iend, jstart, jend, kstart, kend;
  float ipos=0.0;
  int ilen=0;
  char buf[80];
  double rho, frac;
    
  if(lbdm.size>1)
    sprintf(buf, "%s%.6dat%.6d.q", filename, lbdm.rank, qVersion);
  else
    sprintf(buf, "%s%.6d.q", filename, qVersion);
    
  ofstream file(buf, ios::binary);

  ilen=lbdm.xouter;
  if(lbdm.xcor == 0)
    ilen -= lbdm.bwid;
  if(lbdm.xcor == lbdm.xdim-1)
    ilen -= lbdm.bwid;
  file.write((char*)&ilen, sizeof(int));

  ilen=lbdm.youter;
  if(lbdm.ycor == 0)
    ilen -= lbdm.bwid;
  if(lbdm.ycor == lbdm.ydim-1)
    ilen -= lbdm.bwid;
  file.write((char*)&ilen, sizeof(int));

  ilen=lbdm.zouter;
  if(lbdm.zcor == 0)
    ilen -= lbdm.bwid;
  if(lbdm.zcor == lbdm.zdim-1)
    ilen -= lbdm.bwid;
  file.write((char*)&ilen, sizeof(int));

  // write velocity scale (speed of sound)  
  ipos=float(lbsoundv);
  file.write((char*)&ipos, sizeof(float));
  // write freestream angle-of-attack
  ipos=1.0;
  file.write((char*)&ipos, sizeof(float));  
  // write Reynolds number
  ipos=lbreynolds;
  file.write((char*)&ipos, sizeof(float));
  // write time (in time steps)
  ipos=qVersion * lbsave*1.0;
  file.write((char*)&ipos, sizeof(float));

  istart = 0; iend = lbdm.xouter; 
  if(lbdm.xcor == 0)
    istart = lbdm.bwid;
  if(lbdm.xcor == lbdm.xdim-1)
    iend = lbdm.xouter - lbdm.bwid;

  jstart = 0; jend = lbdm.youter; 
  if(lbdm.ycor == 0)
    jstart = lbdm.bwid;
  if(lbdm.ycor == lbdm.ydim-1)
    jend = lbdm.youter - lbdm.bwid;

  kstart = 0; kend = lbdm.zouter; 
  if(lbdm.zcor == 0)
    kstart = lbdm.bwid;
  if(lbdm.zcor == lbdm.zdim-1)
    kend = lbdm.zouter - lbdm.bwid;

  // write density
  if(interact==5 && lbsy.nf>1) {
    for(k=kstart; k<kend; k++) {
      for(j=jstart; j<jend; j++) {
        for(i=istart; i<iend; i++) {
 	      ilen = (i * lbdm.youter + j) * lbdm.zouter + k;
          rho = fGetOneMassSite(&lbf[ilen*lbsitelength]);
          frac = fGetFracSwiftSite(iprop, &lbf[ilen*lbsitelength]);
	      ipos = float(rho*frac);
	      file.write((char*)&ipos, sizeof(float));
        }
      }
    }
  }
  else {
    for(k=kstart; k<kend; k++) {
      for(j=jstart; j<jend; j++) {
        for(i=istart; i<iend; i++) {
  	      ilen = (i * lbdm.youter + j) * lbdm.zouter + k;
	      ipos = float(fGetOneMassSite(&lbf[ilen*lbsitelength+iprop]));
	      file.write((char*)&ipos, sizeof(float));
        }
      }
    }
  }
    
  if(interact==5) {
  // write x-component of velocity (v_x)
    for(k=kstart; k<kend; k++) {
      for(j=jstart; j<jend; j++) {
        for(i=istart; i<iend; i++) {
	      ilen = (i * lbdm.youter + j) * lbdm.zouter + k;
	      if(lbphi[ilen] == 12 || lbphi[ilen] == 13)
	        ipos = 0;
	      else
	        ipos=fGetOneDirecSpeedSwiftSite(0, &lbf[ilen*lbsitelength]);
	      file.write((char*)&ipos, sizeof(float));
        }
      }
    }
  // write y-component of velocity (v_y)
    for(k=kstart; k<kend; k++) {
      for(j=jstart; j<jend; j++) {
        for(i=istart; i<iend; i++) {
 	      ilen = (i * lbdm.youter + j) * lbdm.zouter + k;
	      if(lbphi[ilen] == 12 || lbphi[ilen] == 13)
	        ipos = 0;
	      else
	        ipos=fGetOneDirecSpeedSwiftSite(1, &lbf[ilen*lbsitelength]);
	      file.write((char*)&ipos, sizeof(float));
        }
      }
    }
  // write z-component of velocity (v_z)
    for(k=kstart; k<kend; k++) {
      for(j=jstart; j<jend; j++) {
        for(i=istart; i<iend; i++) {
	      ilen = (i * lbdm.youter + j) * lbdm.zouter + k;
  	      if(lbphi[ilen] == 12 || lbphi[ilen] == 13)
	        ipos = 0;
 	      else
	        ipos=fGetOneDirecSpeedSwiftSite(2, &lbf[ilen*lbsitelength]);
	      file.write((char*)&ipos, sizeof(float));
        }
      }
    }
  }
  else if(!incompress) {
  // write x-component of velocity (v_x)
    for(k=kstart; k<kend; k++) {
      for(j=jstart; j<jend; j++) {
        for(i=istart; i<iend; i++) {
	      ilen = (i * lbdm.youter + j) * lbdm.zouter + k;
	      if(lbphi[ilen] == 12 || lbphi[ilen] == 13)
	        ipos = 0;
	      else
	        ipos=fGetOneDirecSpeedSite(0, &lbf[ilen*lbsitelength]);
	      file.write((char*)&ipos, sizeof(float));
        }
      }
    }
  // write y-component of velocity (v_y)
    for(k=kstart; k<kend; k++) {
      for(j=jstart; j<jend; j++) {
        for(i=istart; i<iend; i++) {
 	      ilen = (i * lbdm.youter + j) * lbdm.zouter + k;
	      if(lbphi[ilen] == 12 || lbphi[ilen] == 13)
	        ipos = 0;
	      else
	        ipos=fGetOneDirecSpeedSite(1, &lbf[ilen*lbsitelength]);
	      file.write((char*)&ipos, sizeof(float));
        }
      }
    }
  // write z-component of velocity (v_z)
    for(k=kstart; k<kend; k++) {
      for(j=jstart; j<jend; j++) {
        for(i=istart; i<iend; i++) {
	      ilen = (i * lbdm.youter + j) * lbdm.zouter + k;
  	      if(lbphi[ilen] == 12 || lbphi[ilen] == 13)
	        ipos = 0;
 	      else
	        ipos=fGetOneDirecSpeedSite(2, &lbf[ilen*lbsitelength]);
	      file.write((char*)&ipos, sizeof(float));
        }
      }
    }
  }
  else {
  // write x-component of velocity (v_x)
    for(k=kstart; k<kend; k++) {
      for(j=jstart; j<jend; j++) {
        for(i=istart; i<iend; i++) {
	      ilen = (i * lbdm.youter + j) * lbdm.zouter + k;
	      if(lbphi[ilen] == 12 || lbphi[ilen] == 13)
	        ipos = 0;
	      else
	        ipos=fGetOneDirecSpeedIncomSite(0, &lbf[ilen*lbsitelength]);
	      file.write((char*)&ipos, sizeof(float));
        }
      }
    }
  // write y-component of velocity (v_y)
    for(k=kstart; k<kend; k++) {
      for(j=jstart; j<jend; j++) {
        for(i=istart; i<iend; i++) {
 	      ilen = (i * lbdm.youter + j) * lbdm.zouter + k;
	      if(lbphi[ilen] == 12 || lbphi[ilen] == 13)
	        ipos = 0;
	      else
	        ipos=fGetOneDirecSpeedIncomSite(1, &lbf[ilen*lbsitelength]);
	      file.write((char*)&ipos, sizeof(float));
        }
      }
    }
  // write z-component of velocity (v_z)
    for(k=kstart; k<kend; k++) {
      for(j=jstart; j<jend; j++) {
        for(i=istart; i<iend; i++) {
	      ilen = (i * lbdm.youter + j) * lbdm.zouter + k;
  	      if(lbphi[ilen] == 12 || lbphi[ilen] == 13)
	        ipos = 0;
 	      else
	        ipos=fGetOneDirecSpeedIncomSite(2, &lbf[ilen*lbsitelength]);
	      file.write((char*)&ipos, sizeof(float));
        }
      }
    }
  }
  // write phase field/space property
  for(k=kstart; k<kend; k++)
    for(j=jstart; j<jend; j++) {
      for(i=istart; i<iend; i++) {
	    ilen = (i * lbdm.youter + j) * lbdm.zouter + k;
	    ipos=(float)lbphi[ilen];
	    file.write((char*)&ipos, sizeof(float));
      }
    }	
  file.close();
  
  return 0;
}

int fsOutputQP3D(const char* filename="lbout", int iprop=0)
{
  int i, j, k, istart, iend, jstart, jend, kstart, kend;
  float ipos=0.0;
  long ilen=0,ilenend;
  char buf[80];
  double rho, frac;
    
  if(lbdm.size>1)
    sprintf(buf, "%s%.6dat%.6d.q", filename, lbdm.rank, qVersion);
  else
    sprintf(buf, "%s%.6d.q", filename, qVersion);
    
  ofstream file(buf);
    
  istart = 0; iend = lbdm.xouter; 
  if(lbdm.xcor == 0)
    istart = lbdm.bwid;
  if(lbdm.xcor == lbdm.xdim-1)
    iend = lbdm.xouter - lbdm.bwid;

  jstart = 0; jend = lbdm.youter; 
  if(lbdm.ycor == 0)
    jstart = lbdm.bwid;
  if(lbdm.ycor == lbdm.ydim-1)
    jend = lbdm.youter - lbdm.bwid;

  kstart = 0; kend = lbdm.zouter; 
  if(lbdm.zcor == 0)
    kstart = lbdm.bwid;
  if(lbdm.zcor == lbdm.zdim-1)
    kend = lbdm.zouter - lbdm.bwid;

  ilenend = ((iend-1) * lbdm.youter + jend-1) * lbdm.zouter + k-1;
  file<<(iend-istart)<<" "<<(jend-jstart)<<" "<<(kend-kstart)<<" "<<endl;
  file<<lbsoundv<<" "<<1.0<<" "<<lbreynolds<<" "<<qVersion<<" "<<endl;
  // write density
  if(interact==5 && lbsy.nf>1) {
    for(k=kstart; k<kend; k++) {
      for(j=jstart; j<jend; j++) {
        for(i=istart; i<iend; i++) {
	      ilen = (i * lbdm.youter + j) * lbdm.zouter + k;
          rho = fGetOneMassSite(&lbf[ilen*lbsitelength]);
          frac = fGetFracSwiftSite(iprop,&lbf[ilen*lbsitelength]);
          ipos = float(rho*frac);
  	      file<<ipos<<" ";
        }
      }
    }
  }
  else {
    for(k=kstart; k<kend; k++) {
      for(j=jstart; j<jend; j++) {
        for(i=istart; i<iend; i++) {
	      ilen = (i * lbdm.youter + j) * lbdm.zouter + k;
          ipos = float(fGetOneMassSite(&lbf[ilen*lbsitelength+iprop]));
  	      file<<ipos<<" ";
        }
      }
    }
  }

  if(interact==5) {
  // write x-component of velocity (v_x)
    for(k=kstart; k<kend; k++) {
      for(j=jstart; j<jend; j++) {
        for(i=istart; i<iend; i++) {
	      ilen = (i * lbdm.youter + j) * lbdm.zouter + k;
  	      if(lbphi[ilen] == 12 || lbphi[ilen] == 13)
	        ipos = 0;
 	      else
	        ipos=fGetOneDirecSpeedSwiftSite(0, &lbf[ilen*lbsitelength]);
	      file<<ipos<<" ";
	    }
      }
    }
  // write y-component of velocity (v_y)
    for(k=kstart; k<kend; k++) {
      for(j=jstart; j<jend; j++) {
        for(i=istart; i<iend; i++) {
	      ilen = (i * lbdm.youter + j) * lbdm.zouter + k;
  	      if(lbphi[ilen] == 12 || lbphi[ilen] == 13)
	        ipos = 0;
 	      else
  	        ipos=fGetOneDirecSpeedSwiftSite(1, &lbf[ilen*lbsitelength]);
	      file<<ipos<<" ";
        }
      }
    }
  // write z-component of velocity (v_z)
    for(k=kstart; k<kend; k++) {
      for(j=jstart; j<jend; j++) {
        for(i=istart; i<iend; i++) {
	      ilen = (i * lbdm.youter + j) * lbdm.zouter + k;
  	      if(lbphi[ilen] == 12 || lbphi[ilen] == 13)
	        ipos = 0;
 	      else
	        ipos=fGetOneDirecSpeedSwiftSite(2, &lbf[ilen*lbsitelength]);
	      file<<ipos<<" ";
	    }
      }
    }
  }
  else if(!incompress) {
  // write x-component of velocity (v_x)
    for(k=kstart; k<kend; k++) {
      for(j=jstart; j<jend; j++) {
        for(i=istart; i<iend; i++) {
	      ilen = (i * lbdm.youter + j) * lbdm.zouter + k;
  	      if(lbphi[ilen] == 12 || lbphi[ilen] == 13)
	        ipos = 0;
 	      else
	        ipos=fGetOneDirecSpeedSite(0, &lbf[ilen*lbsitelength]);
	      file<<ipos<<" ";
	    }
      }
    }
  // write y-component of velocity (v_y)
    for(k=kstart; k<kend; k++) {
      for(j=jstart; j<jend; j++) {
        for(i=istart; i<iend; i++) {
	      ilen = (i * lbdm.youter + j) * lbdm.zouter + k;
  	      if(lbphi[ilen] == 12 || lbphi[ilen] == 13)
	        ipos = 0;
 	      else
  	        ipos=fGetOneDirecSpeedSite(1, &lbf[ilen*lbsitelength]);
	      file<<ipos<<" ";
        }
      }
    }
  // write z-component of velocity (v_z)
    for(k=kstart; k<kend; k++) {
      for(j=jstart; j<jend; j++) {
        for(i=istart; i<iend; i++) {
	      ilen = (i * lbdm.youter + j) * lbdm.zouter + k;
  	      if(lbphi[ilen] == 12 || lbphi[ilen] == 13)
	        ipos = 0;
 	      else
	        ipos=fGetOneDirecSpeedSite(2, &lbf[ilen*lbsitelength]);
	      file<<ipos<<" ";
	    }
      }
    }
  }
  else {
  // write x-component of velocity (v_x)
    for(k=kstart; k<kend; k++) {
      for(j=jstart; j<jend; j++) {
        for(i=istart; i<iend; i++) {
	      ilen = (i * lbdm.youter + j) * lbdm.zouter + k;
  	      if(lbphi[ilen] == 12 || lbphi[ilen] == 13)
	        ipos = 0;
 	      else
	        ipos=fGetOneDirecSpeedIncomSite(0, &lbf[ilen*lbsitelength]);
	      file<<ipos<<" ";
	    }
      }
    }
  // write y-component of velocity (v_y)
    for(k=kstart; k<kend; k++) {
      for(j=jstart; j<jend; j++) {
        for(i=istart; i<iend; i++) {
	      ilen = (i * lbdm.youter + j) * lbdm.zouter + k;
  	      if(lbphi[ilen] == 12 || lbphi[ilen] == 13)
	        ipos = 0;
 	      else
	        ipos=fGetOneDirecSpeedIncomSite(1, &lbf[ilen*lbsitelength]);
	      file<<ipos<<" ";
	    }
      }
    }
  // write z-component of velocity (v_z)
    for(k=kstart; k<kend; k++) {
      for(j=jstart; j<jend; j++) {
        for(i=istart; i<iend; i++) {
	      ilen = (i * lbdm.youter + j) * lbdm.zouter + k;
  	      if(lbphi[ilen] == 12 || lbphi[ilen] == 13)
	        ipos = 0;
 	      else
	        ipos=fGetOneDirecSpeedIncomSite(2, &lbf[ilen*lbsitelength]);
	      file<<ipos<<" ";
	    }
      }
    }
  }

  // write phase field/space property
  for(k=kstart; k<kend; k++)
    for(j=jstart; j<jend; j++)
      for(i=istart; i<iend; i++)
	    {
	      ilen = (i * lbdm.youter + j) * lbdm.zouter + k;
  	      ipos=(float)lbphi[ilen];
	      file<<ipos;
          if(ilen<ilenend)
            file<<" ";
	    }
  file<<endl;
  file.close();
  return 0;
}


int fOutputQP2D(const char* filename="lbout", int iprop=0)
{

  // output .q file with macroscopic mass density and velocity for fluid iprop

  int i, j, istart, iend, jstart, jend;
  float ipos=0.0;
  int ilen=0;
  char buf[80];
  double rho, frac;
    
  if(lbdm.size>1)
    sprintf(buf, "%s%.6dat%.6d.q", filename, lbdm.rank, qVersion);
  else
    sprintf(buf, "%s%.6d.q", filename, qVersion);
    
  ofstream file(buf, ios::binary);

  ilen=lbdm.xouter;
  if(lbdm.xcor == 0)
    ilen -= lbdm.bwid;
  if(lbdm.xcor == lbdm.xdim-1)
    ilen -= lbdm.bwid;
  file.write((char*)&ilen, sizeof(int));

  ilen=lbdm.youter;
  if(lbdm.ycor == 0)
    ilen -= lbdm.bwid;
  if(lbdm.ycor == lbdm.ydim-1)
    ilen -= lbdm.bwid;
  file.write((char*)&ilen, sizeof(int));

  // write velocity scale (speed of sound)
  ipos=float(lbsoundv);
  file.write((char*)&ipos, sizeof(float));
  // write freestreaming angle-of-attack
  ipos=1.0;
  file.write((char*)&ipos, sizeof(float));  
  // write Reynolds number
  ipos=lbreynolds;
  file.write((char*)&ipos, sizeof(float));
  // write time (in time steps)
  ipos=qVersion * lbsave*1.0;
  file.write((char*)&ipos, sizeof(float));

  istart = 0; iend = lbdm.xouter; 
  if(lbdm.xcor == 0)
    istart = lbdm.bwid;
  if(lbdm.xcor == lbdm.xdim-1)
    iend = lbdm.xouter - lbdm.bwid;

  jstart = 0; jend = lbdm.youter; 
  if(lbdm.ycor == 0)
    jstart = lbdm.bwid;
  if(lbdm.ycor == lbdm.ydim-1)
    jend = lbdm.youter - lbdm.bwid;

  // write density
  if(interact==5 && lbsy.nf>1) {
    for(j=jstart; j<jend; j++) {
      for(i=istart; i<iend; i++) {
        ilen = i * lbdm.youter + j;
        rho = fGetOneMassSite(&lbf[ilen*lbsitelength]);
        frac = fGetFracSwiftSite(iprop, &lbf[ilen*lbsitelength]);
        ipos = float(rho*frac);
        file.write((char*)&ipos, sizeof(float));
      }
    }
  }
  else {
    for(j=jstart; j<jend; j++) {
      for(i=istart; i<iend; i++) {
        ilen = i * lbdm.youter + j;
        ipos = float(fGetOneMassSite(&lbf[ilen*lbsitelength+iprop]));
        file.write((char*)&ipos, sizeof(float));
      }
    }
  }
    
  if(interact==5) {
  // write x-component of velocity (v_x)
    for(j=jstart; j<jend; j++) {
      for(i=istart; i<iend; i++) {
	    ilen = i * lbdm.youter + j;
	    if(lbphi[ilen] == 12 || lbphi[ilen] == 13)
	      ipos = 0;
 	    else
	      ipos=fGetOneDirecSpeedSite(0, &lbf[ilen*lbsitelength]);
        file.write((char*)&ipos, sizeof(float));
      }
    }
  // write y-component of velocity (v_y)
    for(j=jstart; j<jend; j++) {
      for(i=istart; i<iend; i++) {
 	    ilen = i * lbdm.youter + j;
	    if(lbphi[ilen] == 12 || lbphi[ilen] == 13)
	      ipos = 0;
	    else
	      ipos=fGetOneDirecSpeedSite(1, &lbf[ilen*lbsitelength]);
        file.write((char*)&ipos, sizeof(float));
      }
    }
  }
  else if(!incompress) {
  // write x-component of velocity (v_x)
    for(j=jstart; j<jend; j++) {
      for(i=istart; i<iend; i++) {
	    ilen = i * lbdm.youter + j;
	    if(lbphi[ilen] == 12 || lbphi[ilen] == 13)
	      ipos = 0;
 	    else
	      ipos=fGetOneDirecSpeedSite(0, &lbf[ilen*lbsitelength]);
        file.write((char*)&ipos, sizeof(float));
      }
    }
  // write y-component of velocity (v_y)
    for(j=jstart; j<jend; j++) {
      for(i=istart; i<iend; i++) {
 	    ilen = i * lbdm.youter + j;
	    if(lbphi[ilen] == 12 || lbphi[ilen] == 13)
	      ipos = 0;
	    else
	      ipos=fGetOneDirecSpeedSite(1, &lbf[ilen*lbsitelength]);
        file.write((char*)&ipos, sizeof(float));
      }
    }
  }
  else {
  // write x-component of velocity (v_x)
    for(j=jstart; j<jend; j++) {
      for(i=istart; i<iend; i++) {
	    ilen = i * lbdm.youter + j;
	    if(lbphi[ilen] == 12 || lbphi[ilen] == 13)
	      ipos = 0;
	    else
	      ipos=fGetOneDirecSpeedIncomSite(0, &lbf[ilen*lbsitelength]);
	    file.write((char*)&ipos, sizeof(float));
      }
    }
  // write y-component of velocity (v_y)
    for(j=jstart; j<jend; j++) {
      for(i=istart; i<iend; i++) {
 	    ilen = i * lbdm.youter + j;
	    if(lbphi[ilen] == 12 || lbphi[ilen] == 13)
	      ipos = 0;
	    else
	      ipos=fGetOneDirecSpeedIncomSite(1, &lbf[ilen*lbsitelength]);
	    file.write((char*)&ipos, sizeof(float));
      }
    }
  }
  
  // write phase field/space property
  for(j=jstart; j<jend; j++) 
    for(i=istart; i<iend; i++) {
      ilen = i * lbdm.youter + j;
      ipos=(float)lbphi[ilen];
      file.write((char*)&ipos, sizeof(float));
    }
	
  file.close();
  return 0;
}


int fsOutputQP2D(const char* filename="lbout", int iprop=0)
{
  int i, j, istart, iend, jstart, jend;
  float ipos=0.0;
  long ilen=0,ilenend;
  char buf[80];
  double rho, frac;
    
  if(lbdm.size>1)
    sprintf(buf, "%s%.6dat%.6d.q", filename, lbdm.rank, qVersion);
  else
    sprintf(buf, "%s%.6d.q", filename, qVersion);

  ofstream file(buf);
    
  istart = 0; iend = lbdm.xouter; 
  if(lbdm.xcor == 0)
    istart = lbdm.bwid;
  if(lbdm.xcor == lbdm.xdim-1)
    iend = lbdm.xouter - lbdm.bwid;

  jstart = 0; jend = lbdm.youter; 
  if(lbdm.ycor == 0)
    jstart = lbdm.bwid;
  if(lbdm.ycor == lbdm.ydim-1)
    jend = lbdm.youter - lbdm.bwid;

  ilenend = (iend-1) * lbdm.youter + jend-1;
  file<<(iend-istart)<<" "<<(jend-jstart)<<" "<<endl;
    
  file<<lbsoundv<<" "<<1.0<<" "<<lbreynolds<<" "<<qVersion<<" "<<endl;
  // write density
  if(interact==5 && lbsy.nf>1) {
    for(j=jstart; j<jend; j++) {
      for(i=istart; i<iend; i++) {
        ilen = i * lbdm.youter + j;
        rho = fGetOneMassSite(&lbf[ilen*lbsitelength]);
        frac = fGetFracSwiftSite(iprop, &lbf[ilen*lbsitelength]);
	    ipos = float(rho*frac);
	    file<<ipos<<" ";
      }
    }
  }
  else {
    for(j=jstart; j<jend; j++) {
      for(i=istart; i<iend; i++) {
        ilen = i * lbdm.youter + j;
	    ipos = float(fGetOneMassSite(&lbf[ilen*lbsitelength+iprop]));
	    file<<ipos<<" ";
      }
    }
  }

  if(interact==5) {
  // write x-component of velocity (v_x)
    for(j=jstart; j<jend; j++) {
      for(i=istart; i<iend; i++) {
	    ilen = i * lbdm.youter + j;
	    if(lbphi[ilen] == 12 || lbphi[ilen] == 13)
	      ipos = 0;
 	    else
	      ipos=fGetOneDirecSpeedSwiftSite(0, &lbf[ilen*lbsitelength]);
	    file<<ipos<<" ";
      }
    }
  // write y-component of velocity (v_y)
    for(j=jstart; j<jend; j++) {
      for(i=istart; i<iend; i++) {
	    ilen = i * lbdm.youter + j;
	    if(lbphi[ilen] == 12 || lbphi[ilen] == 13)
	      ipos = 0;
 	    else
	      ipos=fGetOneDirecSpeedSwiftSite(1, &lbf[ilen*lbsitelength]);
	    file<<ipos<<" ";
      }
    }
  }
  else if(!incompress) {
  // write x-component of velocity (v_x)
    for(j=jstart; j<jend; j++) {
      for(i=istart; i<iend; i++) {
	    ilen = i * lbdm.youter + j;
	    if(lbphi[ilen] == 12 || lbphi[ilen] == 13)
	      ipos = 0;
 	    else
	      ipos=fGetOneDirecSpeedSite(0, &lbf[ilen*lbsitelength]);
	    file<<ipos<<" ";
      }
    }
  // write y-component of velocity (v_y)
    for(j=jstart; j<jend; j++) {
      for(i=istart; i<iend; i++) {
	    ilen = i * lbdm.youter + j;
	    if(lbphi[ilen] == 12 || lbphi[ilen] == 13)
	      ipos = 0;
 	    else
	      ipos=fGetOneDirecSpeedSite(1, &lbf[ilen*lbsitelength]);
	    file<<ipos<<" ";
      }
    }
  }
  else {
  // write x-component of velocity (v_x)
    for(j=jstart; j<jend; j++) {
      for(i=istart; i<iend; i++) {
	    ilen = i * lbdm.youter + j;
	    if(lbphi[ilen] == 12 || lbphi[ilen] == 13)
	      ipos = 0;
 	    else
	      ipos=fGetOneDirecSpeedIncomSite(0, &lbf[ilen*lbsitelength]);
	    file<<ipos<<" ";
      }
    }
  // write y-component of velocity (v_y)
    for(j=jstart; j<jend; j++) {
      for(i=istart; i<iend; i++) {
	    ilen = i * lbdm.youter + j;
	    if(lbphi[ilen] == 12 || lbphi[ilen] == 13)
	      ipos = 0;
 	    else
	      ipos=fGetOneDirecSpeedIncomSite(1, &lbf[ilen*lbsitelength]);
	    file<<ipos<<" ";
      }
    }
  }

  // write phase field/space property
  for(j=jstart; j<jend; j++)
    for(i=istart; i<iend; i++)
      {
	    ilen = i * lbdm.youter + j;
	    ipos=(float)lbphi[ilen];
	    file<<ipos;
        if(ilen<ilenend)
          file<<" ";
      }
  file<<endl;
  file.close();
  return 0;
}


int fOutputQCA3D(const char* filename="lbout", int iprop=0)
{

  // output .q file with mass fraction and velocity for fluid iprop

  int i, j, k, istart, iend, jstart, jend, kstart, kend;
  float ipos=0.0;
  int ilen=0;
  char buf[80];
  if(lbdm.size>1)
    sprintf(buf, "%s%.6dat%.6d.q", filename, lbdm.rank, qVersion);
  else
    sprintf(buf, "%s%.6d.q", filename, qVersion);
    
  ofstream file(buf, ios::binary);

  ilen=lbdm.xouter;
  if(lbdm.xcor == 0)
    ilen -= lbdm.bwid;
  if(lbdm.xcor == lbdm.xdim-1)
    ilen -= lbdm.bwid;
  file.write((char*)&ilen, sizeof(int));

  ilen=lbdm.youter;
  if(lbdm.ycor == 0)
    ilen -= lbdm.bwid;
  if(lbdm.ycor == lbdm.ydim-1)
    ilen -= lbdm.bwid;
  file.write((char*)&ilen, sizeof(int));

  ilen=lbdm.zouter;
  if(lbdm.zcor == 0)
    ilen -= lbdm.bwid;
  if(lbdm.zcor == lbdm.zdim-1)
    ilen -= lbdm.bwid;
  file.write((char*)&ilen, sizeof(int));

  // write velocity scale (speed of sound)  
  ipos=float(lbsoundv);
  file.write((char*)&ipos, sizeof(float));
  // write freestream angle-of-attack
  ipos=1.0;
  file.write((char*)&ipos, sizeof(float));  
  // write Reynolds number
  ipos=lbreynolds;
  file.write((char*)&ipos, sizeof(float));
  // write time (in time steps)
  ipos=qVersion * lbsave*1.0;
  file.write((char*)&ipos, sizeof(float));

  istart = 0; iend = lbdm.xouter; 
  if(lbdm.xcor == 0)
    istart = lbdm.bwid;
  if(lbdm.xcor == lbdm.xdim-1)
    iend = lbdm.xouter - lbdm.bwid;

  jstart = 0; jend = lbdm.youter; 
  if(lbdm.ycor == 0)
    jstart = lbdm.bwid;
  if(lbdm.ycor == lbdm.ydim-1)
    jend = lbdm.youter - lbdm.bwid;

  kstart = 0; kend = lbdm.zouter; 
  if(lbdm.zcor == 0)
    kstart = lbdm.bwid;
  if(lbdm.zcor == lbdm.zdim-1)
    kend = lbdm.zouter - lbdm.bwid;

  // write mass fraction
  if(interact==5 && lbsy.nf>1) {
    for(k=kstart; k<kend; k++) {
      for(j=jstart; j<jend; j++) {
        for(i=istart; i<iend; i++) {
  	      ilen = (i * lbdm.youter + j) * lbdm.zouter + k;
	      ipos = float(fGetFracSwiftSite(iprop, &lbf[ilen*lbsitelength]));
	      file.write((char*)&ipos, sizeof(float));
        }
      }
    }
  }
  else {
    for(k=kstart; k<kend; k++) {
      for(j=jstart; j<jend; j++) {
        for(i=istart; i<iend; i++) {
  	      ilen = (i * lbdm.youter + j) * lbdm.zouter + k;
	      ipos = float(fGetFracSite(iprop, &lbf[ilen*lbsitelength]));
	      file.write((char*)&ipos, sizeof(float));
        }
      }
    }
  }

  if(interact==5) {
  // write x-component of velocity (v_x)
    for(k=kstart; k<kend; k++) {
      for(j=jstart; j<jend; j++) {
        for(i=istart; i<iend; i++) {
	      ilen = (i * lbdm.youter + j) * lbdm.zouter + k;
	      if(lbphi[ilen] == 12 || lbphi[ilen] == 13)
	        ipos = 0;
	      else
	        ipos=fGetOneDirecSpeedSwiftSite(0, &lbf[ilen*lbsitelength]);
	      file.write((char*)&ipos, sizeof(float));
        }
      }
    }
  // write y-component of velocity (v_y)
    for(k=kstart; k<kend; k++) {
      for(j=jstart; j<jend; j++) {
        for(i=istart; i<iend; i++) {
 	      ilen = (i * lbdm.youter + j) * lbdm.zouter + k;
	      if(lbphi[ilen] == 12 || lbphi[ilen] == 13)
	        ipos = 0;
	      else
	        ipos=fGetOneDirecSpeedSwiftSite(1, &lbf[ilen*lbsitelength]);
	      file.write((char*)&ipos, sizeof(float));
        }
      }
    }
  // write z-component of velocity (v_z)
    for(k=kstart; k<kend; k++) {
      for(j=jstart; j<jend; j++) {
        for(i=istart; i<iend; i++) {
	      ilen = (i * lbdm.youter + j) * lbdm.zouter + k;
  	      if(lbphi[ilen] == 12 || lbphi[ilen] == 13)
	        ipos = 0;
 	      else
	        ipos=fGetOneDirecSpeedSwiftSite(2, &lbf[ilen*lbsitelength]);
	      file.write((char*)&ipos, sizeof(float));
        }
      }
    }
  }
  else if(!incompress) {
  // write x-component of velocity (v_x)
    for(k=kstart; k<kend; k++) {
      for(j=jstart; j<jend; j++) {
        for(i=istart; i<iend; i++) {
	      ilen = (i * lbdm.youter + j) * lbdm.zouter + k;
	      if(lbphi[ilen] == 12 || lbphi[ilen] == 13)
	        ipos = 0;
	      else
	        ipos=fGetOneDirecSpeedSite(0, &lbf[ilen*lbsitelength]);
	      file.write((char*)&ipos, sizeof(float));
        }
      }
    }
  // write y-component of velocity (v_y)
    for(k=kstart; k<kend; k++) {
      for(j=jstart; j<jend; j++) {
        for(i=istart; i<iend; i++) {
 	      ilen = (i * lbdm.youter + j) * lbdm.zouter + k;
	      if(lbphi[ilen] == 12 || lbphi[ilen] == 13)
	        ipos = 0;
	      else
	        ipos=fGetOneDirecSpeedSite(1, &lbf[ilen*lbsitelength]);
	      file.write((char*)&ipos, sizeof(float));
        }
      }
    }
  // write z-component of velocity (v_z)
    for(k=kstart; k<kend; k++) {
      for(j=jstart; j<jend; j++) {
        for(i=istart; i<iend; i++) {
	      ilen = (i * lbdm.youter + j) * lbdm.zouter + k;
  	      if(lbphi[ilen] == 12 || lbphi[ilen] == 13)
	        ipos = 0;
 	      else
	        ipos=fGetOneDirecSpeedSite(2, &lbf[ilen*lbsitelength]);
	      file.write((char*)&ipos, sizeof(float));
        }
      }
    }
  }
  else {
  // write x-component of velocity (v_x)
    for(k=kstart; k<kend; k++) {
      for(j=jstart; j<jend; j++) {
        for(i=istart; i<iend; i++) {
	      ilen = (i * lbdm.youter + j) * lbdm.zouter + k;
	      if(lbphi[ilen] == 12 || lbphi[ilen] == 13)
	        ipos = 0;
	      else
	        ipos=fGetOneDirecSpeedIncomSite(0, &lbf[ilen*lbsitelength]);
	      file.write((char*)&ipos, sizeof(float));
        }
      }
    }
  // write y-component of velocity (v_y)
    for(k=kstart; k<kend; k++) {
      for(j=jstart; j<jend; j++) {
        for(i=istart; i<iend; i++) {
 	      ilen = (i * lbdm.youter + j) * lbdm.zouter + k;
	      if(lbphi[ilen] == 12 || lbphi[ilen] == 13)
	        ipos = 0;
	      else
	        ipos=fGetOneDirecSpeedIncomSite(1, &lbf[ilen*lbsitelength]);
	      file.write((char*)&ipos, sizeof(float));
        }
      }
    }
  // write z-component of velocity (v_z)
    for(k=kstart; k<kend; k++) {
      for(j=jstart; j<jend; j++) {
        for(i=istart; i<iend; i++) {
	      ilen = (i * lbdm.youter + j) * lbdm.zouter + k;
  	      if(lbphi[ilen] == 12 || lbphi[ilen] == 13)
	        ipos = 0;
 	      else
	        ipos=fGetOneDirecSpeedIncomSite(2, &lbf[ilen*lbsitelength]);
	      file.write((char*)&ipos, sizeof(float));
        }
      }
    }
  }
  
  // write phase field/space property
  for(k=kstart; k<kend; k++)
    for(j=jstart; j<jend; j++) {
      for(i=istart; i<iend; i++) {
	    ilen = (i * lbdm.youter + j) * lbdm.zouter + k;
	    ipos=(float)lbphi[ilen];
	    file.write((char*)&ipos, sizeof(float));
      }
    }	
  file.close();
    
  return 0;
}


int fsOutputQCA3D(const char* filename="lbout", int iprop=0)
{
  int i, j, k, istart, iend, jstart, jend, kstart, kend;
  float ipos=0.0;
  long ilen=0,ilenend;
  char buf[80];
  if(lbdm.size>1)
    sprintf(buf, "%s%.6dat%.6d.q", filename, lbdm.rank, qVersion);
  else
    sprintf(buf, "%s%.6d.q", filename, qVersion);
    
  ofstream file(buf);
    
  istart = 0; iend = lbdm.xouter; 
  if(lbdm.xcor == 0)
    istart = lbdm.bwid;
  if(lbdm.xcor == lbdm.xdim-1)
    iend = lbdm.xouter - lbdm.bwid;

  jstart = 0; jend = lbdm.youter; 
  if(lbdm.ycor == 0)
    jstart = lbdm.bwid;
  if(lbdm.ycor == lbdm.ydim-1)
    jend = lbdm.youter - lbdm.bwid;

  kstart = 0; kend = lbdm.zouter; 
  if(lbdm.zcor == 0)
    kstart = lbdm.bwid;
  if(lbdm.zcor == lbdm.zdim-1)
    kend = lbdm.zouter - lbdm.bwid;

  ilenend = ((iend-1) * lbdm.youter + jend-1) * lbdm.zouter + k-1;
  file<<(iend-istart)<<" "<<(jend-jstart)<<" "<<(kend-kstart)<<" "<<endl;
  file<<lbsoundv<<" "<<1.0<<" "<<lbreynolds<<" "<<qVersion<<" "<<endl;
  // write mass fraction
  if(interact==5 && lbsy.nf>1) {
    for(k=kstart; k<kend; k++) {
      for(j=jstart; j<jend; j++) {
        for(i=istart; i<iend; i++) {
  	      ilen = (i * lbdm.youter + j) * lbdm.zouter + k;
	      ipos = float(fGetFracSwiftSite(iprop, &lbf[ilen*lbsitelength]));
	      file<<ipos<<" ";
        }
      }
    }
  }
  else {
    for(k=kstart; k<kend; k++) {
      for(j=jstart; j<jend; j++) {
        for(i=istart; i<iend; i++) {
  	      ilen = (i * lbdm.youter + j) * lbdm.zouter + k;
	      ipos = float(fGetFracSite(iprop, &lbf[ilen*lbsitelength]));
	      file<<ipos<<" ";
        }
      }
    }
  }
    
  if(interact==5) {
  // write x-component of velocity (v_x)
    for(k=kstart; k<kend; k++) {
      for(j=jstart; j<jend; j++) {
        for(i=istart; i<iend; i++) {
	      ilen = (i * lbdm.youter + j) * lbdm.zouter + k;
	      if(lbphi[ilen] == 12 || lbphi[ilen] == 13)
	        ipos = 0;
 	      else
	        ipos=fGetOneDirecSpeedSite(0, &lbf[ilen*lbsitelength]);
	      file<<ipos<<" ";
	    }
      }
    }
  // write y-component of velocity (v_y)
    for(k=kstart; k<kend; k++) {
      for(j=jstart; j<jend; j++) {
        for(i=istart; i<iend; i++) {
	      ilen = (i * lbdm.youter + j) * lbdm.zouter + k;
	      if(lbphi[ilen] == 12 || lbphi[ilen] == 13)
	        ipos = 0;
 	      else
	        ipos=fGetOneDirecSpeedSite(1, &lbf[ilen*lbsitelength]);
	      file<<ipos<<" ";
	    }
      }
    }
  // write z-component of velocity (v_z)
    for(k=kstart; k<kend; k++) {
      for(j=jstart; j<jend; j++) {
        for(i=istart; i<iend; i++) {
	      ilen = (i * lbdm.youter + j) * lbdm.zouter + k;
	      if(lbphi[ilen] == 12 || lbphi[ilen] == 13)
	        ipos = 0;
 	      else
	        ipos=fGetOneDirecSpeedSite(2, &lbf[ilen*lbsitelength]);
	      file<<ipos<<" ";
	    }
      }
    }
  }
  else if(!incompress) {
  // write x-component of velocity (v_x)
    for(k=kstart; k<kend; k++) {
      for(j=jstart; j<jend; j++) {
        for(i=istart; i<iend; i++) {
	      ilen = (i * lbdm.youter + j) * lbdm.zouter + k;
	      if(lbphi[ilen] == 12 || lbphi[ilen] == 13)
	        ipos = 0;
 	      else
	        ipos=fGetOneDirecSpeedSite(0, &lbf[ilen*lbsitelength]);
	      file<<ipos<<" ";
	    }
      }
    }
  // write y-component of velocity (v_y)
    for(k=kstart; k<kend; k++) {
      for(j=jstart; j<jend; j++) {
        for(i=istart; i<iend; i++) {
	      ilen = (i * lbdm.youter + j) * lbdm.zouter + k;
	      if(lbphi[ilen] == 12 || lbphi[ilen] == 13)
	        ipos = 0;
 	      else
	        ipos=fGetOneDirecSpeedSite(1, &lbf[ilen*lbsitelength]);
	      file<<ipos<<" ";
	    }
      }
    }
  // write z-component of velocity (v_z)
    for(k=kstart; k<kend; k++) {
      for(j=jstart; j<jend; j++) {
        for(i=istart; i<iend; i++) {
	      ilen = (i * lbdm.youter + j) * lbdm.zouter + k;
	      if(lbphi[ilen] == 12 || lbphi[ilen] == 13)
	        ipos = 0;
 	      else
	        ipos=fGetOneDirecSpeedSite(2, &lbf[ilen*lbsitelength]);
	      file<<ipos<<" ";
	    }
      }
    }
  }
  else {
  // write x-component of velocity (v_x)
    for(k=kstart; k<kend; k++) {
      for(j=jstart; j<jend; j++) {
        for(i=istart; i<iend; i++) {
	      ilen = (i * lbdm.youter + j) * lbdm.zouter + k;
	      if(lbphi[ilen] == 12 || lbphi[ilen] == 13)
	        ipos = 0;
 	      else
	        ipos=fGetOneDirecSpeedIncomSite(0, &lbf[ilen*lbsitelength]);
	      file<<ipos<<" ";
	    }
      }
    }
  // write y-component of velocity (v_y)
    for(k=kstart; k<kend; k++) {
      for(j=jstart; j<jend; j++) {
        for(i=istart; i<iend; i++) {
	      ilen = (i * lbdm.youter + j) * lbdm.zouter + k;
	      if(lbphi[ilen] == 12 || lbphi[ilen] == 13)
	        ipos = 0;
 	      else
	        ipos=fGetOneDirecSpeedIncomSite(1, &lbf[ilen*lbsitelength]);
	      file<<ipos<<" ";
	    }
      }
    }
  // write z-component of velocity (v_z)
    for(k=kstart; k<kend; k++) {
      for(j=jstart; j<jend; j++) {
        for(i=istart; i<iend; i++) {
	      ilen = (i * lbdm.youter + j) * lbdm.zouter + k;
	      if(lbphi[ilen] == 12 || lbphi[ilen] == 13)
	        ipos = 0;
 	      else
	        ipos=fGetOneDirecSpeedIncomSite(2, &lbf[ilen*lbsitelength]);
	      file<<ipos<<" ";
	    }
      }
    }
  }

  // write phase-field/space property
  for(k=kstart; k<kend; k++)
    for(j=jstart; j<jend; j++)
      for(i=istart; i<iend; i++)
	    {
	      ilen = (i * lbdm.youter + j) * lbdm.zouter + k;
	      ipos=(float)lbphi[ilen];
	      file<<ipos;
          if(ilen<ilenend)
            file<<" ";
	    }
  file<<endl;
  file.close();
  return 0;
}


int fOutputQCA2D(const char* filename="lbout", int iprop=0)
{

  // output .q file with mass fraction and velocity for fluid iprop

  int i, j, istart, iend, jstart, jend;
  float ipos=0.0;
  int ilen=0;
  static int qVersion;
  char buf[80];
  if(lbdm.size>1)
    sprintf(buf, "%s%.6dat%.6d.q", filename, lbdm.rank, qVersion);
  else
    sprintf(buf, "%s%.6d.q", filename, qVersion);
    
  ofstream file(buf, ios::binary);

  ilen=lbdm.xouter;
  if(lbdm.xcor == 0)
    ilen -= lbdm.bwid;
  if(lbdm.xcor == lbdm.xdim-1)
    ilen -= lbdm.bwid;
  file.write((char*)&ilen, sizeof(int));

  ilen=lbdm.youter;
  if(lbdm.ycor == 0)
    ilen -= lbdm.bwid;
  if(lbdm.ycor == lbdm.ydim-1)
    ilen -= lbdm.bwid;
  file.write((char*)&ilen, sizeof(int));

  // write velocity scale (speed of sound)  
  ipos=float(lbsoundv);
  file.write((char*)&ipos, sizeof(float));
  // write freestreaming angle-of-attack
  ipos=1.0;
  file.write((char*)&ipos, sizeof(float));  
  // write Reynolds number
  ipos=lbreynolds;
  file.write((char*)&ipos, sizeof(float));
  // write time (in time steps)
  ipos=qVersion * lbsave*1.0;
  file.write((char*)&ipos, sizeof(float));

  istart = 0; iend = lbdm.xouter; 
  if(lbdm.xcor == 0)
    istart = lbdm.bwid;
  if(lbdm.xcor == lbdm.xdim-1)
    iend = lbdm.xouter - lbdm.bwid;

  jstart = 0; jend = lbdm.youter; 
  if(lbdm.ycor == 0)
    jstart = lbdm.bwid;
  if(lbdm.ycor == lbdm.ydim-1)
    jend = lbdm.youter - lbdm.bwid;

  // write mass fraction
  if(interact==5 && lbsy.nf>1) {
    for(j=jstart; j<jend; j++) {
      for(i=istart; i<iend; i++) {
        ilen = i * lbdm.youter + j;
        ipos = float(fGetFracSwiftSite(iprop, &lbf[ilen*lbsitelength]));
        file.write((char*)&ipos, sizeof(float));
      }
    }
  }
  else {
    for(j=jstart; j<jend; j++) {
      for(i=istart; i<iend; i++) {
        ilen = i * lbdm.youter + j;
        ipos = float(fGetFracSite(iprop, &lbf[ilen*lbsitelength]));
        file.write((char*)&ipos, sizeof(float));
      }
    }
  }

  if(interact==5) {
  // write x-component of velocity (v_x)
    for(j=jstart; j<jend; j++) {
      for(i=istart; i<iend; i++) {
	    ilen = i * lbdm.youter + j;
	    if(lbphi[ilen] == 12 || lbphi[ilen] == 13)
	      ipos = 0;
	    else
	      ipos=fGetOneDirecSpeedSwiftSite(0, &lbf[ilen*lbsitelength]);
	    file.write((char*)&ipos, sizeof(float));
      }
    }
  // write y-component of velocity (v_y)
    for(j=jstart; j<jend; j++) {
      for(i=istart; i<iend; i++) {
 	    ilen = i * lbdm.youter + j;
	    if(lbphi[ilen] == 12 || lbphi[ilen] == 13)
	      ipos = 0;
	    else
	      ipos=fGetOneDirecSpeedSwiftSite(1, &lbf[ilen*lbsitelength]);
	    file.write((char*)&ipos, sizeof(float));
      }
    }
  }
  else if(!incompress) {
  // write x-component of velocity (v_x)
    for(j=jstart; j<jend; j++) {
      for(i=istart; i<iend; i++) {
	    ilen = i * lbdm.youter + j;
	    if(lbphi[ilen] == 12 || lbphi[ilen] == 13)
	      ipos = 0;
	    else
	      ipos=fGetOneDirecSpeedSite(0, &lbf[ilen*lbsitelength]);
	    file.write((char*)&ipos, sizeof(float));
      }
    }
  // write y-component of velocity (v_y)
    for(j=jstart; j<jend; j++) {
      for(i=istart; i<iend; i++) {
 	    ilen = i * lbdm.youter + j;
	    if(lbphi[ilen] == 12 || lbphi[ilen] == 13)
	      ipos = 0;
	    else
	      ipos=fGetOneDirecSpeedSite(1, &lbf[ilen*lbsitelength]);
	    file.write((char*)&ipos, sizeof(float));
      }
    }
  }
  else {
  // write x-component of velocity (v_x)
    for(j=jstart; j<jend; j++) {
      for(i=istart; i<iend; i++) {
	    ilen = i * lbdm.youter + j;
	    if(lbphi[ilen] == 12 || lbphi[ilen] == 13)
	      ipos = 0;
	    else
	      ipos=fGetOneDirecSpeedIncomSite(0, &lbf[ilen*lbsitelength]);
	    file.write((char*)&ipos, sizeof(float));
      }
    }
  // write y-component of velocity (v_y)
    for(j=jstart; j<jend; j++) {
      for(i=istart; i<iend; i++) {
 	    ilen = i * lbdm.youter + j;
	    if(lbphi[ilen] == 12 || lbphi[ilen] == 13)
	      ipos = 0;
	    else
	      ipos=fGetOneDirecSpeedIncomSite(1, &lbf[ilen*lbsitelength]);
	    file.write((char*)&ipos, sizeof(float));
      }
    }
  }
  
  // write phase field/space property
  for(j=jstart; j<jend; j++) 
    for(i=istart; i<iend; i++) {
      ilen=i * lbdm.youter + j;
      ipos=(float)lbphi[ilen];
      file.write((char*)&ipos, sizeof(float));
    }
	
  file.close();
  return 0;
}


int fsOutputQCA2D(const char* filename="lbout", int iprop=0)
{
  int i, j, istart, iend, jstart, jend;
  float ipos=0.0;
  long ilen=0,ilenend;
  char buf[80];
  if(lbdm.size>1)
    sprintf(buf, "%s%.6dat%.6d.q", filename, lbdm.rank, qVersion);
  else
    sprintf(buf, "%s%.6d.q", filename, qVersion);
    
  ofstream file(buf);
    
  istart = 0; iend = lbdm.xouter; 
  if(lbdm.xcor == 0)
    istart = lbdm.bwid;
  if(lbdm.xcor == lbdm.xdim-1)
    iend = lbdm.xouter - lbdm.bwid;

  jstart = 0; jend = lbdm.youter; 
  if(lbdm.ycor == 0)
    jstart = lbdm.bwid;
  if(lbdm.ycor == lbdm.ydim-1)
    jend = lbdm.youter - lbdm.bwid;

  ilenend = (iend-1) * lbdm.youter + jend-1;
  file<<(iend-istart)<<" "<<(jend-jstart)<<" "<<endl;
  file<<lbsoundv<<" "<<1.0<<" "<<lbreynolds<<" "<<qVersion<<" "<<endl;
  // write mass fraction
  if(interact==5 && lbsy.nf>1) {
    for(j=jstart; j<jend; j++) {
      for(i=istart; i<iend; i++) {
        ilen = i * lbdm.youter + j;
  	    ipos = float(fGetFracSwiftSite(iprop, &lbf[ilen*lbsitelength]));
	    file<<ipos<<" ";
  	  }
    }
  }
  else {
    for(j=jstart; j<jend; j++) {
      for(i=istart; i<iend; i++) {
        ilen = i * lbdm.youter + j;
  	    ipos = float(fGetFracSite(iprop, &lbf[ilen*lbsitelength]));
	    file<<ipos<<" ";
  	  }
    }
  }
    
  if(interact==5) {
  // write x-component of velocity (v_x)
    for(j=jstart; j<jend; j++) {
      for(i=istart; i<iend; i++) {
	    ilen = i * lbdm.youter + j;
	    if(lbphi[ilen] == 12 || lbphi[ilen] == 13)
	      ipos = 0;
 	    else
	      ipos=fGetOneDirecSpeedSwiftSite(0, &lbf[ilen*lbsitelength]);
	    file<<ipos<<" ";
      }
    }
  // write y-component of velocity (v_y)
    for(j=jstart; j<jend; j++) {
      for(i=istart; i<iend; i++) {
	    ilen = i * lbdm.youter + j;
	    if(lbphi[ilen] == 12 || lbphi[ilen] == 13)
	      ipos = 0;
 	    else
	      ipos=fGetOneDirecSpeedSwiftSite(1, &lbf[ilen*lbsitelength]);
	    file<<ipos<<" ";
      }
    }
  }
  else if(!incompress) {
  // write x-component of velocity (v_x)
    for(j=jstart; j<jend; j++) {
      for(i=istart; i<iend; i++) {
	    ilen = i * lbdm.youter + j;
	    if(lbphi[ilen] == 12 || lbphi[ilen] == 13)
	      ipos = 0;
 	    else
	      ipos=fGetOneDirecSpeedSite(0, &lbf[ilen*lbsitelength]);
	    file<<ipos<<" ";
      }
    }
  // write y-component of velocity (v_y)
    for(j=jstart; j<jend; j++) {
      for(i=istart; i<iend; i++) {
	    ilen = i * lbdm.youter + j;
	    if(lbphi[ilen] == 12 || lbphi[ilen] == 13)
	      ipos = 0;
 	    else
	      ipos=fGetOneDirecSpeedSite(1, &lbf[ilen*lbsitelength]);
	    file<<ipos<<" ";
      }
    }
  }
  else {
  // write x-component of velocity (v_x)
    for(j=jstart; j<jend; j++) {
      for(i=istart; i<iend; i++) {
	    ilen = i * lbdm.youter + j;
	    if(lbphi[ilen] == 12 || lbphi[ilen] == 13)
	      ipos = 0;
 	    else
	      ipos=fGetOneDirecSpeedIncomSite(0, &lbf[ilen*lbsitelength]);
	    file<<ipos<<" ";
      }
    }
  // write y-component of velocity (v_y)
    for(j=jstart; j<jend; j++) {
      for(i=istart; i<iend; i++) {
	    ilen = i * lbdm.youter + j;
	    if(lbphi[ilen] == 12 || lbphi[ilen] == 13)
	      ipos = 0;
 	    else
	      ipos=fGetOneDirecSpeedIncomSite(1, &lbf[ilen*lbsitelength]);
	    file<<ipos<<" ";
      }
    }
  }

  // write phase field/space property
  for(j=jstart; j<jend; j++)
    for(i=istart; i<iend; i++)
      {
	    ilen = i * lbdm.youter + j;
	    ipos=(float)lbphi[ilen];
	    file<<ipos;
        if(ilen<ilenend)
          file<<" ";
      }
  file<<endl;
  file.close();
  return 0;
}


int fOutputQCB3D(const char* filename="lbout", int iprop=0)
{

  // output .q file with concentration and velocity for solute iprop

  int i, j, k, istart, iend, jstart, jend, kstart, kend;
  float ipos=0.0;
  int ilen=0;
  char buf[80];
  if(lbdm.size>1)
    sprintf(buf, "%s%.6dat%.6d.q", filename, lbdm.rank, qVersion);
  else
    sprintf(buf, "%s%.6d.q", filename, qVersion);
    
  ofstream file(buf, ios::binary);

  ilen=lbdm.xouter;
  if(lbdm.xcor == 0)
    ilen -= lbdm.bwid;
  if(lbdm.xcor == lbdm.xdim-1)
    ilen -= lbdm.bwid;
  file.write((char*)&ilen, sizeof(int));

  ilen=lbdm.youter;
  if(lbdm.ycor == 0)
    ilen -= lbdm.bwid;
  if(lbdm.ycor == lbdm.ydim-1)
    ilen -= lbdm.bwid;
  file.write((char*)&ilen, sizeof(int));

  ilen=lbdm.zouter;
  if(lbdm.zcor == 0)
    ilen -= lbdm.bwid;
  if(lbdm.zcor == lbdm.zdim-1)
    ilen -= lbdm.bwid;
  file.write((char*)&ilen, sizeof(int));

  // write velocity scale (speed of sound)
  ipos=float(lbsoundv);
  file.write((char*)&ipos, sizeof(float));
  // write freestreaming angle-of-attack
  ipos=1.0;
  file.write((char*)&ipos, sizeof(float));  
  // write Reynolds number
  ipos=lbreynolds;
  file.write((char*)&ipos, sizeof(float));
  // write time (in time steps)
  ipos=qVersion * lbsave*1.0;
  file.write((char*)&ipos, sizeof(float));

  istart = 0; iend = lbdm.xouter; 
  if(lbdm.xcor == 0)
    istart = lbdm.bwid;
  if(lbdm.xcor == lbdm.xdim-1)
    iend = lbdm.xouter - lbdm.bwid;

  jstart = 0; jend = lbdm.youter; 
  if(lbdm.ycor == 0)
    jstart = lbdm.bwid;
  if(lbdm.ycor == lbdm.ydim-1)
    jend = lbdm.youter - lbdm.bwid;

  kstart = 0; kend = lbdm.zouter; 
  if(lbdm.zcor == 0)
    kstart = lbdm.bwid;
  if(lbdm.zcor == lbdm.zdim-1)
    kend = lbdm.zouter - lbdm.bwid;

  // write solute concentration
  for(k=kstart; k<kend; k++)
    for(j=jstart; j<jend; j++) {
      for(i=istart; i<iend; i++) {
	    ilen = (i * lbdm.youter + j) * lbdm.zouter + k;
	    ipos = float(fGetOneConcSite(iprop, ilen));
	    file.write((char*)&ipos, sizeof(float));
      }
    }

  if(interact==5) {
  // write x-component of velocity (v_x)
    for(k=kstart; k<kend; k++) {
      for(j=jstart; j<jend; j++) {
        for(i=istart; i<iend; i++) {
	      ilen = (i * lbdm.youter + j) * lbdm.zouter + k;
	      if(lbphi[ilen] == 12 || lbphi[ilen] == 13)
	        ipos = 0;
	      else
	        ipos=fGetOneDirecSpeedSwiftSite(0, &lbf[ilen*lbsitelength]);
	      file.write((char*)&ipos, sizeof(float));
        }
      }
    }
  // write y-component of velocity (v_y)
    for(k=kstart; k<kend; k++) {
      for(j=jstart; j<jend; j++) {
        for(i=istart; i<iend; i++) {
 	      ilen = (i * lbdm.youter + j) * lbdm.zouter + k;
	      if(lbphi[ilen] == 12 || lbphi[ilen] == 13)
	        ipos = 0;
	      else
	        ipos=fGetOneDirecSpeedSwiftSite(1, &lbf[ilen*lbsitelength]);
	      file.write((char*)&ipos, sizeof(float));
        }
      }
    }
  // write z-component of velocity (v_z)
    for(k=kstart; k<kend; k++) {
      for(j=jstart; j<jend; j++) {
        for(i=istart; i<iend; i++) {
	      ilen = (i * lbdm.youter + j) * lbdm.zouter + k;
  	      if(lbphi[ilen] == 12 || lbphi[ilen] == 13)
	        ipos = 0;
 	      else
	        ipos=fGetOneDirecSpeedSwiftSite(2, &lbf[ilen*lbsitelength]);
	      file.write((char*)&ipos, sizeof(float));
        }
      }
    }
  }
  else if(!incompress) {
  // write x-component of velocity (v_x)
    for(k=kstart; k<kend; k++) {
      for(j=jstart; j<jend; j++) {
        for(i=istart; i<iend; i++) {
	      ilen = (i * lbdm.youter + j) * lbdm.zouter + k;
	      if(lbphi[ilen] == 12 || lbphi[ilen] == 13)
	        ipos = 0;
	      else
	        ipos=fGetOneDirecSpeedSite(0, &lbf[ilen*lbsitelength]);
	      file.write((char*)&ipos, sizeof(float));
        }
      }
    }
  // write y-component of velocity (v_y)
    for(k=kstart; k<kend; k++) {
      for(j=jstart; j<jend; j++) {
        for(i=istart; i<iend; i++) {
 	      ilen = (i * lbdm.youter + j) * lbdm.zouter + k;
	      if(lbphi[ilen] == 12 || lbphi[ilen] == 13)
	        ipos = 0;
	      else
	        ipos=fGetOneDirecSpeedSite(1, &lbf[ilen*lbsitelength]);
	      file.write((char*)&ipos, sizeof(float));
        }
      }
    }
  // write z-component of velocity (v_z)
    for(k=kstart; k<kend; k++) {
      for(j=jstart; j<jend; j++) {
        for(i=istart; i<iend; i++) {
	      ilen = (i * lbdm.youter + j) * lbdm.zouter + k;
  	      if(lbphi[ilen] == 12 || lbphi[ilen] == 13)
	        ipos = 0;
 	      else
	        ipos=fGetOneDirecSpeedSite(2, &lbf[ilen*lbsitelength]);
	      file.write((char*)&ipos, sizeof(float));
        }
      }
    }
  }
  else {
  // write x-component of velocity (v_x)
    for(k=kstart; k<kend; k++) {
      for(j=jstart; j<jend; j++) {
        for(i=istart; i<iend; i++) {
	      ilen = (i * lbdm.youter + j) * lbdm.zouter + k;
	      if(lbphi[ilen] == 12 || lbphi[ilen] == 13)
	        ipos = 0;
	      else
	        ipos=fGetOneDirecSpeedIncomSite(0, &lbf[ilen*lbsitelength]);
	      file.write((char*)&ipos, sizeof(float));
        }
      }
    }
  // write y-component of velocity (v_y)
    for(k=kstart; k<kend; k++) {
      for(j=jstart; j<jend; j++) {
        for(i=istart; i<iend; i++) {
	      ilen = (i * lbdm.youter + j) * lbdm.zouter + k;
	      if(lbphi[ilen] == 12 || lbphi[ilen] == 13)
	        ipos = 0;
	      else
	        ipos=fGetOneDirecSpeedIncomSite(1, &lbf[ilen*lbsitelength]);
	      file.write((char*)&ipos, sizeof(float));
        }
      }
    }
  // write z-component of velocity (v_z)
    for(k=kstart; k<kend; k++) {
      for(j=jstart; j<jend; j++) {
        for(i=istart; i<iend; i++) {
	      ilen = (i * lbdm.youter + j) * lbdm.zouter + k;
	      if(lbphi[ilen] == 12 || lbphi[ilen] == 13)
	        ipos = 0;
	      else
	        ipos=fGetOneDirecSpeedIncomSite(2, &lbf[ilen*lbsitelength]);
	      file.write((char*)&ipos, sizeof(float));
        }
      }
    }
  }
  
  // write phase field/space property
  for(k=kstart; k<kend; k++)
    for(j=jstart; j<jend; j++) {
      for(i=istart; i<iend; i++) {
	    ilen = (i * lbdm.youter + j) * lbdm.zouter + k;
	    ipos=(float)lbphi[ilen];
	    file.write((char*)&ipos, sizeof(float));
      }
    }	
  file.close();
    
  return 0;
}


int fsOutputQCB3D(const char* filename="lbout", int iprop=0)
{
  int i, j, k, istart, iend, jstart, jend, kstart, kend;
  float ipos=0.0;
  long ilen=0,ilenend;
  char buf[80];
  if(lbdm.size>1)
    sprintf(buf, "%s%.6dat%.6d.q", filename, lbdm.rank, qVersion);
  else
    sprintf(buf, "%s%.6d.q", filename, qVersion);
    
  ofstream file(buf);

  istart = 0; iend = lbdm.xouter; 
  if(lbdm.xcor == 0)
    istart = lbdm.bwid;
  if(lbdm.xcor == lbdm.xdim-1)
    iend = lbdm.xouter - lbdm.bwid;

  jstart = 0; jend = lbdm.youter; 
  if(lbdm.ycor == 0)
    jstart = lbdm.bwid;
  if(lbdm.ycor == lbdm.ydim-1)
    jend = lbdm.youter - lbdm.bwid;

  kstart = 0; kend = lbdm.zouter; 
  if(lbdm.zcor == 0)
    kstart = lbdm.bwid;
  if(lbdm.zcor == lbdm.zdim-1)
    kend = lbdm.zouter - lbdm.bwid;

  ilenend = ((iend-1) * lbdm.youter + jend-1) * lbdm.zouter + k-1;
  file<<(iend-istart)<<" "<<(jend-jstart)<<" "<<(kend-kstart)<<" "<<endl;
  file<<lbsoundv<<" "<<1.0<<" "<<lbreynolds<<" "<<qVersion<<" "<<endl;
  // write solute concentration
  for(k=kstart; k<kend; k++)
    for(j=jstart; j<jend; j++)
      for(i=istart; i<iend; i++)
	    {
	      ilen = (i * lbdm.youter + j) * lbdm.zouter + k;
          ipos = float(fGetOneConcSite(iprop, ilen));
	      file<<ipos<<" ";
	    }

  if(interact==5) {
  // write x-component of velocity (v_x)
    for(k=kstart; k<kend; k++) {
      for(j=jstart; j<jend; j++) {
        for(i=istart; i<iend; i++) {
	      ilen = (i * lbdm.youter + j) * lbdm.zouter + k;
	      if(lbphi[ilen] == 12 || lbphi[ilen] == 13)
	        ipos = 0;
 	      else
	        ipos=fGetOneDirecSpeedSwiftSite(0, &lbf[ilen*lbsitelength]);
	      file<<ipos<<" ";
	    }
      }
    }
  // write y-component of velocity (v_y)
    for(k=kstart; k<kend; k++) {
      for(j=jstart; j<jend; j++) {
        for(i=istart; i<iend; i++) {
	      ilen = (i * lbdm.youter + j) * lbdm.zouter + k;
	      if(lbphi[ilen] == 12 || lbphi[ilen] == 13)
	        ipos = 0;
 	      else
	        ipos=fGetOneDirecSpeedSwiftSite(1, &lbf[ilen*lbsitelength]);
	      file<<ipos<<" ";
	    }
      }
    }
  // write z-component of velocity (v_z)
    for(k=kstart; k<kend; k++) {
      for(j=jstart; j<jend; j++) {
        for(i=istart; i<iend; i++) {
	      ilen = (i * lbdm.youter + j) * lbdm.zouter + k;
	      if(lbphi[ilen] == 12 || lbphi[ilen] == 13)
	        ipos = 0;
 	      else
	        ipos=fGetOneDirecSpeedSwiftSite(2, &lbf[ilen*lbsitelength]);
	      file<<ipos<<" ";
	    }
      }
    }
  }
  else if(!incompress) {
  // write x-component of velocity (v_x)
    for(k=kstart; k<kend; k++) {
      for(j=jstart; j<jend; j++) {
        for(i=istart; i<iend; i++) {
	      ilen = (i * lbdm.youter + j) * lbdm.zouter + k;
	      if(lbphi[ilen] == 12 || lbphi[ilen] == 13)
	        ipos = 0;
 	      else
	        ipos=fGetOneDirecSpeedSite(0, &lbf[ilen*lbsitelength]);
	      file<<ipos<<" ";
	    }
      }
    }
  // write y-component of velocity (v_y)
    for(k=kstart; k<kend; k++) {
      for(j=jstart; j<jend; j++) {
        for(i=istart; i<iend; i++) {
	      ilen = (i * lbdm.youter + j) * lbdm.zouter + k;
	      if(lbphi[ilen] == 12 || lbphi[ilen] == 13)
	        ipos = 0;
 	      else
	        ipos=fGetOneDirecSpeedSite(1, &lbf[ilen*lbsitelength]);
	      file<<ipos<<" ";
	    }
      }
    }
  // write z-component of velocity (v_z)
    for(k=kstart; k<kend; k++) {
      for(j=jstart; j<jend; j++) {
        for(i=istart; i<iend; i++) {
	      ilen = (i * lbdm.youter + j) * lbdm.zouter + k;
	      if(lbphi[ilen] == 12 || lbphi[ilen] == 13)
	        ipos = 0;
 	      else
	        ipos=fGetOneDirecSpeedSite(2, &lbf[ilen*lbsitelength]);
	      file<<ipos<<" ";
	    }
      }
    }
  }
  else {
  // write x-component of velocity (v_x)
    for(k=kstart; k<kend; k++) {
      for(j=jstart; j<jend; j++) {
        for(i=istart; i<iend; i++) {
	      ilen = (i * lbdm.youter + j) * lbdm.zouter + k;
	      if(lbphi[ilen] == 12 || lbphi[ilen] == 13)
	        ipos = 0;
 	      else
	        ipos=fGetOneDirecSpeedIncomSite(0, &lbf[ilen*lbsitelength]);
	      file<<ipos<<" ";
	    }
      }
    }
  // write y-component of velocity (v_y)
    for(k=kstart; k<kend; k++) {
      for(j=jstart; j<jend; j++) {
        for(i=istart; i<iend; i++) {
	      ilen = (i * lbdm.youter + j) * lbdm.zouter + k;
	      if(lbphi[ilen] == 12 || lbphi[ilen] == 13)
	        ipos = 0;
 	      else
	        ipos=fGetOneDirecSpeedIncomSite(1, &lbf[ilen*lbsitelength]);
	      file<<ipos<<" ";
	    }
      }
    }
  // write z-component of velocity (v_z)
    for(k=kstart; k<kend; k++) {
      for(j=jstart; j<jend; j++) {
        for(i=istart; i<iend; i++) {
	      ilen = (i * lbdm.youter + j) * lbdm.zouter + k;
	      if(lbphi[ilen] == 12 || lbphi[ilen] == 13)
	        ipos = 0;
 	      else
	        ipos=fGetOneDirecSpeedIncomSite(2, &lbf[ilen*lbsitelength]);
	      file<<ipos<<" ";
	    }
      }
    }
  }

  // write phase field/space property
  for(k=kstart; k<kend; k++)
    for(j=jstart; j<jend; j++)
      for(i=istart; i<iend; i++)
	    {
          ilen = (i * lbdm.youter + j) * lbdm.zouter + k;
	      ipos=(float)lbphi[ilen];
	      file<<ipos;
          if(ilen<ilenend)
            file<<" ";
	    }
  file<<endl;
  file.close();
  return 0;
}


int fOutputQCB2D(const char* filename="lbout", int iprop=0)
{

  // output .q file with concentration and velocity for solute iprop

  int i, j, istart, iend, jstart, jend;
  float ipos=0.0;
  int ilen=0;
  static int qVersion;
  char buf[80];
  if(lbdm.size>1)
    sprintf(buf, "%s%.6dat%.6d.q", filename, lbdm.rank, qVersion);
  else
    sprintf(buf, "%s%.6d.q", filename, qVersion);
    
  ofstream file(buf, ios::binary);

  ilen=lbdm.xouter;
  if(lbdm.xcor == 0)
    ilen -= lbdm.bwid;
  if(lbdm.xcor == lbdm.xdim-1)
    ilen -= lbdm.bwid;
  file.write((char*)&ilen, sizeof(int));

  ilen=lbdm.youter;
  if(lbdm.ycor == 0)
    ilen -= lbdm.bwid;
  if(lbdm.ycor == lbdm.ydim-1)
    ilen -= lbdm.bwid;
  file.write((char*)&ilen, sizeof(int));

  // write velocity scale (speed of sound)
  ipos=float(lbsoundv);
  file.write((char*)&ipos, sizeof(float));
  // write freestreaming angle-of-attack
  ipos=1.0;
  file.write((char*)&ipos, sizeof(float));  
  // write Reynolds number
  ipos=lbreynolds;
  file.write((char*)&ipos, sizeof(float));
  // write time (in time steps)
  ipos=qVersion * lbsave*1.0;
  file.write((char*)&ipos, sizeof(float));

  istart = 0; iend = lbdm.xouter; 
  if(lbdm.xcor == 0)
    istart = lbdm.bwid;
  if(lbdm.xcor == lbdm.xdim-1)
    iend = lbdm.xouter - lbdm.bwid;

  jstart = 0; jend = lbdm.youter; 
  if(lbdm.ycor == 0)
    jstart = lbdm.bwid;
  if(lbdm.ycor == lbdm.ydim-1)
    jend = lbdm.youter - lbdm.bwid;

  // write solute concentration
  for(j=jstart; j<jend; j++) 
    for(i=istart; i<iend; i++) {
      ilen = i * lbdm.youter + j;
      ipos = float(fGetOneConcSite(iprop, ilen));
      file.write((char*)&ipos, sizeof(float));
    }

  if(interact==5) {
  // write x-component of velocity (v_x)
    for(j=jstart; j<jend; j++) {
      for(i=istart; i<iend; i++) {
	    ilen = i * lbdm.youter + j;
	    if(lbphi[ilen] == 12 || lbphi[ilen] == 13)
	      ipos = 0;
	    else
	      ipos=fGetOneDirecSpeedSwiftSite(0, &lbf[ilen*lbsitelength]);
	    file.write((char*)&ipos, sizeof(float));
      }
    }
  // write y-component of velocity (v_y)
    for(j=jstart; j<jend; j++) {
      for(i=istart; i<iend; i++) {
 	    ilen = i * lbdm.youter + j;
	    if(lbphi[ilen] == 12 || lbphi[ilen] == 13)
	      ipos = 0;
	    else
	      ipos=fGetOneDirecSpeedSwiftSite(1, &lbf[ilen*lbsitelength]);
	    file.write((char*)&ipos, sizeof(float));
      }
    }
  }
  else if(!incompress) {
  // write x-component of velocity (v_x)
    for(j=jstart; j<jend; j++) {
      for(i=istart; i<iend; i++) {
	    ilen = i * lbdm.youter + j;
	    if(lbphi[ilen] == 12 || lbphi[ilen] == 13)
	      ipos = 0;
	    else
	      ipos=fGetOneDirecSpeedSite(0, &lbf[ilen*lbsitelength]);
	    file.write((char*)&ipos, sizeof(float));
      }
    }
  // write y-component of velocity (v_y)
    for(j=jstart; j<jend; j++) {
      for(i=istart; i<iend; i++) {
 	    ilen = i * lbdm.youter + j;
	    if(lbphi[ilen] == 12 || lbphi[ilen] == 13)
	      ipos = 0;
	    else
	      ipos=fGetOneDirecSpeedSite(1, &lbf[ilen*lbsitelength]);
	    file.write((char*)&ipos, sizeof(float));
      }
    }
  }
  else {
  // write x-component of velocity (v_x)
    for(j=jstart; j<jend; j++) {
      for(i=istart; i<iend; i++) {
	    ilen = i * lbdm.youter + j;
	    if(lbphi[ilen] == 12 || lbphi[ilen] == 13)
	      ipos = 0;
	    else
	      ipos=fGetOneDirecSpeedIncomSite(0, &lbf[ilen*lbsitelength]);
	    file.write((char*)&ipos, sizeof(float));
      }
    }
  // write y-component of velocity (v_y)
    for(j=jstart; j<jend; j++) {
      for(i=istart; i<iend; i++) {
 	    ilen = i * lbdm.youter + j;
	    if(lbphi[ilen] == 12 || lbphi[ilen] == 13)
	      ipos = 0;
	    else
	      ipos=fGetOneDirecSpeedIncomSite(1, &lbf[ilen*lbsitelength]);
	    file.write((char*)&ipos, sizeof(float));
      }
    }
  }
  
  // write phase field/space property
  
  for(j=jstart; j<jend; j++) 
    for(i=istart; i<iend; i++) {
      ilen=i * lbdm.youter + j;
      ipos=(float)lbphi[ilen];
      file.write((char*)&ipos, sizeof(float));
    }
	
  file.close();
  return 0;
}


int fsOutputQCB2D(const char* filename="lbout", int iprop=0)
{
  int i, j, istart, iend, jstart, jend;
  float ipos=0.0;
  long ilen=0,ilenend;
  char buf[80];
  if(lbdm.size>1)
    sprintf(buf, "%s%.6dat%.6d.q", filename, lbdm.rank, qVersion);
  else
    sprintf(buf, "%s%.6d.q", filename, qVersion);
    
  ofstream file(buf);
    
  istart = 0; iend = lbdm.xouter; 
  if(lbdm.xcor == 0)
    istart = lbdm.bwid;
  if(lbdm.xcor == lbdm.xdim-1)
    iend = lbdm.xouter - lbdm.bwid;

  jstart = 0; jend = lbdm.youter; 
  if(lbdm.ycor == 0)
    jstart = lbdm.bwid;
  if(lbdm.ycor == lbdm.ydim-1)
    jend = lbdm.youter - lbdm.bwid;

  ilenend = (iend-1) * lbdm.youter + jend-1;
  file<<(iend-istart)<<" "<<(jend-jstart)<<" "<<endl;
    
  file<<lbsoundv<<" "<<1.0<<" "<<lbreynolds<<" "<<qVersion<<" "<<endl;
  // write solute concentration
  for(j=jstart; j<jend; j++)
    for(i=istart; i<iend; i++)
      {
	    ilen = i * lbdm.youter + j;
	    ipos = float(fGetOneConcSite(iprop, ilen));
	    file<<ipos<<" ";
  	  }

  if(interact==5) {
  // write x-component of velocity (v_x)
    for(j=jstart; j<jend; j++) {
      for(i=istart; i<iend; i++) {
	    ilen = i * lbdm.youter + j;
	    if(lbphi[ilen] == 12 || lbphi[ilen] == 13)
	      ipos = 0;
 	    else
	      ipos=fGetOneDirecSpeedSite(0, &lbf[ilen*lbsitelength]);
	    file<<ipos<<" ";
      }
    }
  // write y-component of velocity (v_y)
    for(j=jstart; j<jend; j++) {
      for(i=istart; i<iend; i++) {
	    ilen = i * lbdm.youter + j;
	    if(lbphi[ilen] == 12 || lbphi[ilen] == 13)
	      ipos = 0;
 	    else
	      ipos=fGetOneDirecSpeedSite(1, &lbf[ilen*lbsitelength]);
	    file<<ipos<<" ";
      }
    }
  }
  else if(!incompress) {
  // write x-component of velocity (v_x)
    for(j=jstart; j<jend; j++) {
      for(i=istart; i<iend; i++) {
	    ilen = i * lbdm.youter + j;
	    if(lbphi[ilen] == 12 || lbphi[ilen] == 13)
	      ipos = 0;
 	    else
	      ipos=fGetOneDirecSpeedSite(0, &lbf[ilen*lbsitelength]);
	    file<<ipos<<" ";
      }
    }
  // write y-component of velocity (v_y)
    for(j=jstart; j<jend; j++) {
      for(i=istart; i<iend; i++) {
	    ilen = i * lbdm.youter + j;
	    if(lbphi[ilen] == 12 || lbphi[ilen] == 13)
	      ipos = 0;
 	    else
	      ipos=fGetOneDirecSpeedSite(1, &lbf[ilen*lbsitelength]);
	    file<<ipos<<" ";
      }
    }
  }
  else {
  // write x-component of velocity (v_x)
    for(j=jstart; j<jend; j++) {
      for(i=istart; i<iend; i++) {
	    ilen = i * lbdm.youter + j;
	    if(lbphi[ilen] == 12 || lbphi[ilen] == 13)
	      ipos = 0;
 	    else
	      ipos=fGetOneDirecSpeedIncomSite(0, &lbf[ilen*lbsitelength]);
	    file<<ipos<<" ";
      }
    }
  // write y-component of velocity (v_y)
    for(j=jstart; j<jend; j++) {
      for(i=istart; i<iend; i++) {
	    ilen = i * lbdm.youter + j;
	    if(lbphi[ilen] == 12 || lbphi[ilen] == 13)
	      ipos = 0;
 	    else
	      ipos=fGetOneDirecSpeedIncomSite(1, &lbf[ilen*lbsitelength]);
	    file<<ipos<<" ";
      }
    }
  }

  // write phase field/space property
  for(j=0; j<lbsy.ny; j++)
    for(i=0; i<lbsy.nx; i++) 
      {
	    ilen = i * lbdm.youter + j;
	    ipos=(float)lbphi[ilen];
	    file<<ipos;
        if(ilen<ilenend)
          file<<" ";
      }
  file<<endl;
  file.close();
  return 0;
}


int fOutputQT3D(const char* filename="lbout")
{

  // output .q file with scalar temperature and velocity

  int i, j, k, istart, iend, jstart, jend, kstart, kend;
  float ipos=0.0;
  int ilen=0;
  char buf[80];
  if(lbdm.size>1)
    sprintf(buf, "%s%.6dat%.6d.q", filename, lbdm.rank, qVersion);
  else
    sprintf(buf, "%s%.6d.q", filename, qVersion);
    
  ofstream file(buf, ios::binary);

  ilen=lbdm.xouter;
  if(lbdm.xcor == 0)
    ilen -= lbdm.bwid;
  if(lbdm.xcor == lbdm.xdim-1)
    ilen -= lbdm.bwid;
  file.write((char*)&ilen, sizeof(int));

  ilen=lbdm.youter;
  if(lbdm.ycor == 0)
    ilen -= lbdm.bwid;
  if(lbdm.ycor == lbdm.ydim-1)
    ilen -= lbdm.bwid;
  file.write((char*)&ilen, sizeof(int));

  ilen=lbdm.zouter;
  if(lbdm.zcor == 0)
    ilen -= lbdm.bwid;
  if(lbdm.zcor == lbdm.zdim-1)
    ilen -= lbdm.bwid;
  file.write((char*)&ilen, sizeof(int));

  // write velocity scale (speed of sound) 
  ipos=float(lbsoundv);
  file.write((char*)&ipos, sizeof(float));
  // write freestreaming angle-of-attack
  ipos=1.0;
  file.write((char*)&ipos, sizeof(float));  
  // write Reynolds number
  ipos=lbreynolds;
  file.write((char*)&ipos, sizeof(float));
  // write time (in time steps)
  ipos=qVersion * lbsave*1.0;
  file.write((char*)&ipos, sizeof(float));

  istart = 0; iend = lbdm.xouter; 
  if(lbdm.xcor == 0)
    istart = lbdm.bwid;
  if(lbdm.xcor == lbdm.xdim-1)
    iend = lbdm.xouter - lbdm.bwid;

  jstart = 0; jend = lbdm.youter; 
  if(lbdm.ycor == 0)
    jstart = lbdm.bwid;
  if(lbdm.ycor == lbdm.ydim-1)
    jend = lbdm.youter - lbdm.bwid;

  kstart = 0; kend = lbdm.zouter; 
  if(lbdm.zcor == 0)
    kstart = lbdm.bwid;
  if(lbdm.zcor == lbdm.zdim-1)
    kend = lbdm.zouter - lbdm.bwid;

  // write temperature
  for(k=kstart; k<kend; k++)
    for(j=jstart; j<jend; j++) {
      for(i=istart; i<iend; i++) {
	    ilen = (i * lbdm.youter + j) * lbdm.zouter + k;
	    ipos = float(fGetTemperatureSite(ilen));
	    file.write((char*)&ipos, sizeof(float));
      }
    }

  if(interact==5) {
  // write x-component of velocity (v_x)
    for(k=kstart; k<kend; k++) {
      for(j=jstart; j<jend; j++) {
        for(i=istart; i<iend; i++) {
	      ilen = (i * lbdm.youter + j) * lbdm.zouter + k;
	      if(lbphi[ilen] == 12 || lbphi[ilen] == 13)
	        ipos = 0;
	      else
	        ipos=fGetOneDirecSpeedSwiftSite(0, &lbf[ilen*lbsitelength]);
	      file.write((char*)&ipos, sizeof(float));
        }
      }
    }
  // write y-component of velocity (v_y)
    for(k=kstart; k<kend; k++) {
      for(j=jstart; j<jend; j++) {
        for(i=istart; i<iend; i++) {
	      ilen = (i * lbdm.youter + j) * lbdm.zouter + k;
	      if(lbphi[ilen] == 12 || lbphi[ilen] == 13)
	        ipos = 0;
	      else
	        ipos=fGetOneDirecSpeedSwiftSite(1, &lbf[ilen*lbsitelength]);
	      file.write((char*)&ipos, sizeof(float));
        }
      }
    }
  // write z-component of velocity (v_z)
    for(k=kstart; k<kend; k++) {
      for(j=jstart; j<jend; j++) {
        for(i=istart; i<iend; i++) {
	      ilen = (i * lbdm.youter + j) * lbdm.zouter + k;
	      if(lbphi[ilen] == 12 || lbphi[ilen] == 13)
	        ipos = 0;
	      else
	        ipos=fGetOneDirecSpeedSwiftSite(2, &lbf[ilen*lbsitelength]);
	      file.write((char*)&ipos, sizeof(float));
        }
      }
    }
  }
  else if(!incompress) {
  // write x-component of velocity (v_x)
    for(k=kstart; k<kend; k++) {
      for(j=jstart; j<jend; j++) {
        for(i=istart; i<iend; i++) {
	      ilen = (i * lbdm.youter + j) * lbdm.zouter + k;
	      if(lbphi[ilen] == 12 || lbphi[ilen] == 13)
	        ipos = 0;
	      else
	        ipos=fGetOneDirecSpeedSite(0, &lbf[ilen*lbsitelength]);
	      file.write((char*)&ipos, sizeof(float));
        }
      }
    }
  // write y-component of velocity (v_y)
    for(k=kstart; k<kend; k++) {
      for(j=jstart; j<jend; j++) {
        for(i=istart; i<iend; i++) {
	      ilen = (i * lbdm.youter + j) * lbdm.zouter + k;
	      if(lbphi[ilen] == 12 || lbphi[ilen] == 13)
	        ipos = 0;
	      else
	        ipos=fGetOneDirecSpeedSite(1, &lbf[ilen*lbsitelength]);
	      file.write((char*)&ipos, sizeof(float));
        }
      }
    }
  // write z-component of velocity (v_z)
    for(k=kstart; k<kend; k++) {
      for(j=jstart; j<jend; j++) {
        for(i=istart; i<iend; i++) {
	      ilen = (i * lbdm.youter + j) * lbdm.zouter + k;
	      if(lbphi[ilen] == 12 || lbphi[ilen] == 13)
	        ipos = 0;
	      else
	        ipos=fGetOneDirecSpeedSite(2, &lbf[ilen*lbsitelength]);
	      file.write((char*)&ipos, sizeof(float));
        }
      }
    }
  }
  else {
  // write x-component of velocity (v_x)
    for(k=kstart; k<kend; k++) {
      for(j=jstart; j<jend; j++) {
        for(i=istart; i<iend; i++) {
	      ilen = (i * lbdm.youter + j) * lbdm.zouter + k;
	      if(lbphi[ilen] == 12 || lbphi[ilen] == 13)
	        ipos = 0;
	      else
	        ipos=fGetOneDirecSpeedIncomSite(0, &lbf[ilen*lbsitelength]);
	      file.write((char*)&ipos, sizeof(float));
        }
      }
    }
  // write y-component of velocity (v_y)
    for(k=kstart; k<kend; k++) {
      for(j=jstart; j<jend; j++) {
        for(i=istart; i<iend; i++) {
	      ilen = (i * lbdm.youter + j) * lbdm.zouter + k;
	      if(lbphi[ilen] == 12 || lbphi[ilen] == 13)
	        ipos = 0;
	      else
	        ipos=fGetOneDirecSpeedIncomSite(1, &lbf[ilen*lbsitelength]);
	      file.write((char*)&ipos, sizeof(float));
        }
      }
    }
  // write z-component of velocity (v_z)
    for(k=kstart; k<kend; k++) {
      for(j=jstart; j<jend; j++) {
        for(i=istart; i<iend; i++) {
	      ilen = (i * lbdm.youter + j) * lbdm.zouter + k;
	      if(lbphi[ilen] == 12 || lbphi[ilen] == 13)
	        ipos = 0;
	      else
	        ipos=fGetOneDirecSpeedIncomSite(2, &lbf[ilen*lbsitelength]);
	      file.write((char*)&ipos, sizeof(float));
        }
      }
    }
  }
  
  // write phase field/space property
  for(k=kstart; k<kend; k++)
    for(j=jstart; j<jend; j++) {
      for(i=istart; i<iend; i++) {
	    ilen = (i * lbdm.youter + j) * lbdm.zouter + k;
	    ipos=(float)lbphi[ilen];
	    file.write((char*)&ipos, sizeof(float));
      }
    }	
  file.close();
    
  return 0;
}


int fsOutputQT3D(const char* filename="lbout")
{
  int i, j, k, istart, iend, jstart, jend, kstart, kend;
  float ipos=0.0;
  long ilen=0,ilenend;
  char buf[80];
  if(lbdm.size>1)
    sprintf(buf, "%s%.6dat%.6d.q", filename, lbdm.rank, qVersion);
  else
    sprintf(buf, "%s%.6d.q", filename, qVersion);
    
  ofstream file(buf);
    
  istart = 0; iend = lbdm.xouter; 
  if(lbdm.xcor == 0)
    istart = lbdm.bwid;
  if(lbdm.xcor == lbdm.xdim-1)
    iend = lbdm.xouter - lbdm.bwid;

  jstart = 0; jend = lbdm.youter; 
  if(lbdm.ycor == 0)
    jstart = lbdm.bwid;
  if(lbdm.ycor == lbdm.ydim-1)
    jend = lbdm.youter - lbdm.bwid;

  kstart = 0; kend = lbdm.zouter; 
  if(lbdm.zcor == 0)
    kstart = lbdm.bwid;
  if(lbdm.zcor == lbdm.zdim-1)
    kend = lbdm.zouter - lbdm.bwid;

  ilenend = ((iend-1) * lbdm.youter + jend-1) * lbdm.zouter + k-1;
  file<<(iend-istart)<<" "<<(jend-jstart)<<" "<<(kend-kstart)<<" "<<endl;
  file<<lbsoundv<<" "<<1.0<<" "<<lbreynolds<<" "<<qVersion<<" "<<endl;
  // write temperature
  for(k=kstart; k<kend; k++)
    for(j=jstart; j<jend; j++)
      for(i=istart; i<iend; i++)
	    {
	      ilen = (i * lbdm.youter + j) * lbdm.zouter + k;
	      ipos = float(fGetTemperatureSite(ilen));
	      file<<ipos<<" ";
	    }

  if(interact==5) {
  // write x-component of velocity (v_x)
    for(k=kstart; k<kend; k++) {
      for(j=jstart; j<jend; j++) {
        for(i=istart; i<iend; i++) {
	      ilen = (i * lbdm.youter + j) * lbdm.zouter + k;
	      if(lbphi[ilen] == 12 || lbphi[ilen] == 13)
	        ipos = 0;
 	      else
	        ipos=fGetOneDirecSpeedSwiftSite(0, &lbf[ilen*lbsitelength]);
	      file<<ipos<<" ";
	    }
      }
    }
  // write y-component of velocity (v_y)
    for(k=kstart; k<kend; k++) {
      for(j=jstart; j<jend; j++) {
        for(i=istart; i<iend; i++) {
	      ilen = (i * lbdm.youter + j) * lbdm.zouter + k;
	      if(lbphi[ilen] == 12 || lbphi[ilen] == 13)
	        ipos = 0;
 	      else
	        ipos=fGetOneDirecSpeedSwiftSite(1, &lbf[ilen*lbsitelength]);
	      file<<ipos<<" ";
	    }
      }
    }
  // write z-component of velocity (v_z)
    for(k=kstart; k<kend; k++) {
      for(j=jstart; j<jend; j++) {
        for(i=istart; i<iend; i++) {
	      ilen = (i * lbdm.youter + j) * lbdm.zouter + k;
	      if(lbphi[ilen] == 12 || lbphi[ilen] == 13)
	        ipos = 0;
 	      else
	        ipos=fGetOneDirecSpeedSwiftSite(2, &lbf[ilen*lbsitelength]);
	      file<<ipos<<" ";
	    }
      }
    }
  }
  else if(!incompress) {
  // write x-component of velocity (v_x)
    for(k=kstart; k<kend; k++) {
      for(j=jstart; j<jend; j++) {
        for(i=istart; i<iend; i++) {
	      ilen = (i * lbdm.youter + j) * lbdm.zouter + k;
	      if(lbphi[ilen] == 12 || lbphi[ilen] == 13)
	        ipos = 0;
 	      else
	        ipos=fGetOneDirecSpeedSite(0, &lbf[ilen*lbsitelength]);
	      file<<ipos<<" ";
	    }
      }
    }
  // write y-component of velocity (v_y)
    for(k=kstart; k<kend; k++) {
      for(j=jstart; j<jend; j++) {
        for(i=istart; i<iend; i++) {
	      ilen = (i * lbdm.youter + j) * lbdm.zouter + k;
	      if(lbphi[ilen] == 12 || lbphi[ilen] == 13)
	        ipos = 0;
 	      else
	        ipos=fGetOneDirecSpeedSite(1, &lbf[ilen*lbsitelength]);
	      file<<ipos<<" ";
	    }
      }
    }
  // write z-component of velocity (v_z)
    for(k=kstart; k<kend; k++) {
      for(j=jstart; j<jend; j++) {
        for(i=istart; i<iend; i++) {
	      ilen = (i * lbdm.youter + j) * lbdm.zouter + k;
	      if(lbphi[ilen] == 12 || lbphi[ilen] == 13)
	        ipos = 0;
 	      else
	        ipos=fGetOneDirecSpeedSite(2, &lbf[ilen*lbsitelength]);
	      file<<ipos<<" ";
	    }
      }
    }
  }
  else {
  // write x-component of velocity (v_x)
    for(k=kstart; k<kend; k++) {
      for(j=jstart; j<jend; j++) {
        for(i=istart; i<iend; i++) {
	      ilen = (i * lbdm.youter + j) * lbdm.zouter + k;
	      if(lbphi[ilen] == 12 || lbphi[ilen] == 13)
	        ipos = 0;
 	      else
	        ipos=fGetOneDirecSpeedIncomSite(0, &lbf[ilen*lbsitelength]);
	      file<<ipos<<" ";
	    }
      }
    }
  // write y-component of velocity (v_y)
    for(k=kstart; k<kend; k++) {
      for(j=jstart; j<jend; j++) {
        for(i=istart; i<iend; i++) {
	      ilen = (i * lbdm.youter + j) * lbdm.zouter + k;
	      if(lbphi[ilen] == 12 || lbphi[ilen] == 13)
	        ipos = 0;
 	      else
	        ipos=fGetOneDirecSpeedIncomSite(1, &lbf[ilen*lbsitelength]);
	      file<<ipos<<" ";
	    }
      }
    }
  // write z-component of velocity (v_z)
    for(k=kstart; k<kend; k++) {
      for(j=jstart; j<jend; j++) {
        for(i=istart; i<iend; i++) {
	      ilen = (i * lbdm.youter + j) * lbdm.zouter + k;
	      if(lbphi[ilen] == 12 || lbphi[ilen] == 13)
	        ipos = 0;
 	      else
	        ipos=fGetOneDirecSpeedIncomSite(2, &lbf[ilen*lbsitelength]);
	      file<<ipos<<" ";
	    }
      }
    }
  }

  // write phase field/space property
  for(k=kstart; k<kend; k++)
    for(j=jstart; j<jend; j++)
      for(i=istart; i<iend; i++)
	    {
	      ilen = (i * lbdm.youter + j) * lbdm.zouter + k;
	      ipos=(float)lbphi[ilen];
	      file<<ipos;
          if(ilen<ilenend)
            file<<" ";
	    }
  file<<endl;
  file.close();
  return 0;
}


int fOutputQT2D(const char* filename="lbout")
{

  // output .q file with scalar temperature and velocity

  int i, j, istart, iend, jstart, jend;
  float ipos=0.0;
  int ilen=0;
  static int qVersion;
  char buf[80];
  if(lbdm.size>1)
    sprintf(buf, "%s%.6dat%.6d.q", filename, lbdm.rank, qVersion);
  else
    sprintf(buf, "%s%.6d.q", filename, qVersion);
    
  ofstream file(buf, ios::binary);

  ilen=lbdm.xouter;
  if(lbdm.xcor == 0)
    ilen -= lbdm.bwid;
  if(lbdm.xcor == lbdm.xdim-1)
    ilen -= lbdm.bwid;
  file.write((char*)&ilen, sizeof(int));

  ilen=lbdm.youter;
  if(lbdm.ycor == 0)
    ilen -= lbdm.bwid;
  if(lbdm.ycor == lbdm.ydim-1)
    ilen -= lbdm.bwid;
  file.write((char*)&ilen, sizeof(int));

  // write velocity scale (speed of sound)
  ipos=float(lbsoundv);
  file.write((char*)&ipos, sizeof(float));
  // write freestreaming angle-of-attack
  ipos=1.0;
  file.write((char*)&ipos, sizeof(float));  
  // write Reynolds number
  ipos=lbreynolds;
  file.write((char*)&ipos, sizeof(float));
  // write time (in time steps)
  ipos=qVersion * lbsave*1.0;
  file.write((char*)&ipos, sizeof(float));

  istart = 0; iend = lbdm.xouter; 
  if(lbdm.xcor == 0)
    istart = lbdm.bwid;
  if(lbdm.xcor == lbdm.xdim-1)
    iend = lbdm.xouter - lbdm.bwid;

  jstart = 0; jend = lbdm.youter; 
  if(lbdm.ycor == 0)
    jstart = lbdm.bwid;
  if(lbdm.ycor == lbdm.ydim-1)
    jend = lbdm.youter - lbdm.bwid;

  // write temperature
  for(j=jstart; j<jend; j++) 
    for(i=istart; i<iend; i++) {
      ilen = i * lbdm.youter + j;
      ipos = float(fGetTemperatureSite(ilen));
      file.write((char*)&ipos, sizeof(float));
    }

  if(interact==5) {
  // write x-component of velocity (v_x)
    for(j=jstart; j<jend; j++) {
      for(i=istart; i<iend; i++) {
  	    ilen = i * lbdm.youter + j;
	    if(lbphi[ilen] == 12 || lbphi[ilen] == 13)
	      ipos = 0;
  	    else
	      ipos=fGetOneDirecSpeedSwiftSite(0, &lbf[ilen*lbsitelength]);
	    file.write((char*)&ipos, sizeof(float));
      }
    }
  // write y-component of velocity (v_y)
    for(j=jstart; j<jend; j++) {
      for(i=istart; i<iend; i++) {
 	    ilen = i * lbdm.youter + j;
	    if(lbphi[ilen] == 12 || lbphi[ilen] == 13)
	      ipos = 0;
	    else
	      ipos=fGetOneDirecSpeedSwiftSite(1, &lbf[ilen*lbsitelength]);
	    file.write((char*)&ipos, sizeof(float));
      }
    }
  }
  else if(!incompress) {
  // write x-component of velocity (v_x)
    for(j=jstart; j<jend; j++) {
      for(i=istart; i<iend; i++) {
  	    ilen = i * lbdm.youter + j;
	    if(lbphi[ilen] == 12 || lbphi[ilen] == 13)
	      ipos = 0;
  	    else
	      ipos=fGetOneDirecSpeedSite(0, &lbf[ilen*lbsitelength]);
	    file.write((char*)&ipos, sizeof(float));
      }
    }
  // write y-component of velocity (v_y)
    for(j=jstart; j<jend; j++) {
      for(i=istart; i<iend; i++) {
 	    ilen = i * lbdm.youter + j;
	    if(lbphi[ilen] == 12 || lbphi[ilen] == 13)
	      ipos = 0;
	    else
	      ipos=fGetOneDirecSpeedSite(1, &lbf[ilen*lbsitelength]);
	    file.write((char*)&ipos, sizeof(float));
      }
    }
  }
  else {
  // write x-component of velocity (v_x)
    for(j=jstart; j<jend; j++) {
      for(i=istart; i<iend; i++) {
	    ilen = i * lbdm.youter + j;
	    if(lbphi[ilen] == 12 || lbphi[ilen] == 13)
	      ipos = 0;
	    else
	      ipos=fGetOneDirecSpeedIncomSite(0, &lbf[ilen*lbsitelength]);
	    file.write((char*)&ipos, sizeof(float));
      }
    }
  // write y-component of velocity (v_y)
    for(j=jstart; j<jend; j++) {
      for(i=istart; i<iend; i++) {
 	    ilen = i * lbdm.youter + j;
	    if(lbphi[ilen] == 12 || lbphi[ilen] == 13)
	      ipos = 0;
	    else
	     ipos=fGetOneDirecSpeedIncomSite(1, &lbf[ilen*lbsitelength]);
	    file.write((char*)&ipos, sizeof(float));
      }
    }
  }
  
  // write phase field/space property
  for(j=jstart; j<jend; j++) 
    for(i=istart; i<iend; i++) {
      ilen=i * lbdm.youter + j;
      ipos=(float)lbphi[ilen];
      file.write((char*)&ipos, sizeof(float));
    }
	
  file.close();
  return 0;
}


int fsOutputQT2D(const char* filename="lbout")
{
  int i, j, istart, iend, jstart, jend;
  float ipos=0.0;
  long ilen=0,ilenend;
  char buf[80];
  if(lbdm.size>1)
    sprintf(buf, "%s%.6dat%.6d.q", filename, lbdm.rank, qVersion);
  else
    sprintf(buf, "%s%.6d.q", filename, qVersion);
    
  ofstream file(buf);
    
  istart = 0; iend = lbdm.xouter; 
  if(lbdm.xcor == 0)
    istart = lbdm.bwid;
  if(lbdm.xcor == lbdm.xdim-1)
    iend = lbdm.xouter - lbdm.bwid;

  jstart = 0; jend = lbdm.youter; 
  if(lbdm.ycor == 0)
    jstart = lbdm.bwid;
  if(lbdm.ycor == lbdm.ydim-1)
    jend = lbdm.youter - lbdm.bwid;

  ilenend = (iend-1) * lbdm.youter + jend-1;
  file<<(iend-istart)<<" "<<(jend-jstart)<<" "<<endl;
    
  file<<lbsoundv<<" "<<1.0<<" "<<lbreynolds<<" "<<qVersion<<" "<<endl;
  // write temperature
  for(j=jstart; j<jend; j++)
    for(i=istart; i<iend; i++)
      {
	    ilen = i * lbdm.youter + j;
	    ipos = float(fGetTemperatureSite(ilen));
	    file<<ipos<<" ";
	  }

  if(interact==5) {
  // write x-component of velocity (v_x)
    for(j=jstart; j<jend; j++) {
      for(i=istart; i<iend; i++) {
	    ilen = i * lbdm.youter + j;
	    if(lbphi[ilen] == 12 || lbphi[ilen] == 13)
	      ipos = 0;
 	    else
	      ipos=fGetOneDirecSpeedSwiftSite(0, &lbf[ilen*lbsitelength]);
	    file<<ipos<<" ";
      }
    }
  // write y-component of velocity (v_y)
    for(j=jstart; j<jend; j++) {
      for(i=istart; i<iend; i++) {
	    ilen = i * lbdm.youter + j;
	    if(lbphi[ilen] == 12 || lbphi[ilen] == 13)
	      ipos = 0;
 	    else
	      ipos=fGetOneDirecSpeedSwiftSite(1, &lbf[ilen*lbsitelength]);
	    file<<ipos<<" ";
      }
    }
  }
  else if(!incompress) {
  // write x-component of velocity (v_x)
    for(j=jstart; j<jend; j++) {
      for(i=istart; i<iend; i++) {
	    ilen = i * lbdm.youter + j;
	    if(lbphi[ilen] == 12 || lbphi[ilen] == 13)
	      ipos = 0;
 	    else
	      ipos=fGetOneDirecSpeedSite(0, &lbf[ilen*lbsitelength]);
	    file<<ipos<<" ";
      }
    }
  // write y-component of velocity (v_y)
    for(j=jstart; j<jend; j++) {
      for(i=istart; i<iend; i++) {
	    ilen = i * lbdm.youter + j;
	    if(lbphi[ilen] == 12 || lbphi[ilen] == 13)
	      ipos = 0;
 	    else
	      ipos=fGetOneDirecSpeedSite(1, &lbf[ilen*lbsitelength]);
	    file<<ipos<<" ";
      }
    }
  }
  else {
  // write x-component of velocity (v_x)
    for(j=jstart; j<jend; j++) {
      for(i=istart; i<iend; i++) {
	    ilen = i * lbdm.youter + j;
	    if(lbphi[ilen] == 12 || lbphi[ilen] == 13)
	      ipos = 0;
 	    else
	      ipos=fGetOneDirecSpeedIncomSite(0, &lbf[ilen*lbsitelength]);
	    file<<ipos<<" ";
      }
    }
  // write y-component of velocity (v_y)
    for(j=jstart; j<jend; j++) {
      for(i=istart; i<iend; i++) {
	    ilen = i * lbdm.youter + j;
	    if(lbphi[ilen] == 12 || lbphi[ilen] == 13)
	      ipos = 0;
 	    else
	      ipos=fGetOneDirecSpeedIncomSite(1, &lbf[ilen*lbsitelength]);
	    file<<ipos<<" ";
      }
    }
  }

  // write phase field/space property
  for(j=0; j<lbsy.ny; j++)
    for(i=0; i<lbsy.nx; i++) 
      {
	    ilen = i * lbdm.youter + j;
	    ipos=(float)lbphi[ilen];
	    file<<ipos;
        if(ilen<ilenend)
          file<<" ";
      }
  file<<endl;
  file.close();
  return 0;
}



