/***********************************************
 *   DL_MESO       Version 2.6                 *
 *   Authors   :   R. S. Qin, M. A. Seaton     *
 *   Copyright :   STFC Daresbury Laboratory   *
 *             :   22/10/2015                  *
 ***********************************************/

// Functions in this package are general purpose and are not directly 
// related to Mesoscale Methods. These may be replaced with any suitable 
// functions in C++ standard libraries.

template <class T>
T fCppAbs(T a){return (a<0)?-a:a;}

template <class T>
T fCppSign(T a){return ((a>0)-(a<0));}

template <class T>
T fReciprocal(T a){return (a!=0)?1/a:0;}


template <class T>
T fEvapLimit(T a){return (a<lbevaplim)?0:a;}


template <class T> void fSwapPair ( T& a, T& b)
{
  T c(a); a=b; b=c;
}


template <typename T> T fStringToNumber ( const string &text )
  {
     istringstream ss(text);
     T result;
     return ss >> result ? result : 0;
  }


template <typename T> T fCppMax ( T& a, T& b)
{
    return (a>b?a:b);
}


template <typename T> T fCppMin ( T& a, T& b)
{
    return (a<b?a:b);
}


int fGetNumberOrdered(int &iox, int &ioy, int &ioz)
{

  // arrange three integers in decreasing order

  int itemp;
  if(iox < ioy){
    itemp = ioy; ioy=iox; iox=itemp;}
  if(iox < ioz){
    itemp = ioz; ioz=iox; iox=itemp;}
  if(ioy < ioz){
    itemp = ioz; ioz=ioy; ioy=itemp;}
  return 0;
}


int fGetNumberOrdered(int &iox, int &ioy)
{

  // arrange two integers in decreasing order

  int itemp;
  if(iox < ioy){
    itemp = ioy; ioy=iox; iox=itemp;}
  return 0;
}


int fGetNumberOrderFixed(int &iox, int &ioy, int &ioz,
			 int ix, int iy, int iz)
{

  // put iox, ioy and ioz in the same order as ix, iy and iz

  fGetNumberOrdered(iox, ioy, ioz);
  int xtem=iox, ytem=ioy, ztem=ioz;
  if(ix >= iy){
    if (iz >= ix){
      iox=ytem; ioy=ztem; ioz=xtem;}
    else if(iz >= iy) {
      ioy = ztem; ioz=ytem;}
    }
  else {
    if(iz >= iy) {
      iox=ztem; ioz=xtem;}
    else if(ix >= iz) {
      iox=ytem; ioy=xtem;}
    else {
      iox=ztem; ioy=xtem; ioz=ytem;}
    }
  return 0;
}


int fGetNumberOrderFixed(int &iox, int &ioy, int ix, int iy)
{

  // put iox and ioy in the same order as ix and iy

  fGetNumberOrdered(iox, ioy);
  int xtem=iox, ytem=ioy;
  if(ix < iy){
    iox=ytem; ioy=xtem;}
  return 0;
}

int fBestGrouping(int totalgrid, int totalgroup, 
		  int& indigrid, int& critigroup)
{

 // distribute grid points as evenly as possible:
 // when group <  criticalgroup, grid number = indigrid
 // when group >= criticalgroup, grid number = indigrid - 1

  indigrid = (totalgrid - 1) / totalgroup + 1;
  critigroup = totalgrid - totalgroup * (indigrid-1);
  return 0;
}

int fCppMod(int a, int b)
{

  // ensure integer number a is in a range between 0 and b-1

  if( a < 0 )
    return (a+b);

  else if(a >= b)
    return (a-b);

  else
    return a;
}


long fCppMod(long a, long b)
{

   // ensure long integer number a is in a range between 0 and b-1

  if( a < 0 )
    return (a+b);

  else if(a >= b)
    return (a-b);

  else
    return a;
}


int fPrintLine()
{
  cout << string(76, '-') << endl;
  return 0;
}


int fPrintDoubleLine()
{
  cout << string(76, '=') << endl;
  return 0;
}

double fRandom()
{

  //  create a random number between -1 and 1

  int seed = 50200 + lbdm.rank;
  static bool notFirstTime1;
  double randomNumber;
  static int theNumber;
  if(!notFirstTime1) theNumber=seed;   
  theNumber = 2045*theNumber + 1;
  theNumber = theNumber - (theNumber/1048576)*1048576;
  randomNumber=2.0*(theNumber+1)/1048577.0-1.0;
  notFirstTime1=1;
  return randomNumber;  
}


int fBigEndian()
{

  // indicate endianness of machine: 1 = big endian, 0 = little endian

  short int n = 1;
  char *ep = (char *)&n;

  return (*ep == 0);
}

void fByteSwap(void *data, int len, int count)
{

  // swap byte order to select endian type for binary files

  char tmp, *cdat = (char *) data;
  int k;
 
  if (len==1)
    return;
  else if (len==2)
    while (count--) {
      tmp = cdat[0];  cdat[0] = cdat[1];  cdat[1] = tmp;
      cdat += 2;
    }
  else if (len==4)
    while (count--) {
      tmp = cdat[0];  cdat[0] = cdat[3];  cdat[3] = tmp;
      tmp = cdat[1];  cdat[1] = cdat[2];  cdat[2] = tmp;
      cdat += 4;
    }
  else if (len==8)
    while (count--) {
      tmp = cdat[0];  cdat[0] = cdat[7];  cdat[7] = tmp;
      tmp = cdat[1];  cdat[1] = cdat[6];  cdat[6] = tmp;
      tmp = cdat[2];  cdat[2] = cdat[5];  cdat[5] = tmp;
      tmp = cdat[3];  cdat[3] = cdat[4];  cdat[4] = tmp;
      cdat += 8;
    }
  else {
    for(k=0; k<len/2; k++) {
      tmp = cdat[k];
      cdat[k] = cdat[len-1-k];
      cdat[len-1-k] = tmp;
    }
  }
}

double fCheckTimeSerial()
{

  // check the elapsed time (in seconds)

  static int timeini;
  static double starttime;
  double timeelapsed;
  struct timeval Tp;

  gettimeofday(&Tp, NULL);

  if(timeini == 0)
    {  
      timeini = 1;
      starttime = Tp.tv_sec + 0.000001 * (double) (Tp.tv_usec);
      timeelapsed = 0.0;
    }
  else
    timeelapsed = Tp.tv_sec + 0.000001 * (double) (Tp.tv_usec) - starttime;
  
  return timeelapsed;
}

string fReadString(string line, int i)
{
    // return i-th word of input string (line)

    string buf;
    vector<string> tokens;
    stringstream ss(line);

    while (ss >> buf)
        tokens.push_back(buf);

    if(i>=tokens.size()) {
      buf = string();
    }
    else {
      buf = tokens.at(i);
    }

    return(buf);
}


