int fOutputGrid(const char* filename);
int fsOutputGrid(const char* filename);

int fOutputQ(const char* filename);
int fsOutputQ(const char* filename);

int fOutputQP(const char* filename, int iprop);
int fsOutputQP(const char* filename, int iprop);

int fOutputQCA(const char* filename, int iprop);
int fsOutputQCA(const char* filename, int iprop);

int fOutputQCB(const char* filename, int iprop);
int fsOutputQCB(const char* filename, int iprop);

int fOutputQT(const char* filename);
int fsOutputQT(const char* filename);

int fOutputGrid3D(const char* filename);
int fOutputGrid2D(const char* filename);
int fsOutputGrid3D(const char* filename);
int fsOutputGrid2D(const char* filename);

int fOutputQP3D(const char* filename, int iprop);
int fsOutputQP3D(const char* filename, int iprop);
int fOutputQP2D(const char* filename, int iprop);
int fsOutputQP2D(const char* filename, int iprop);

int fOutputQCA3D(const char* filename, int iprop);
int fsOutputQCA3D(const char* filename, int iprop);
int fOutputQCA2D(const char* filename, int iprop);
int fsOutputQCA2D(const char* filename, int iprop);

int fOutputQCB3D(const char* filename, int iprop);
int fsOutputQCB3D(const char* filename, int iprop);
int fOutputQCB2D(const char* filename, int iprop);
int fsOutputQCB2D(const char* filename, int iprop);

int fOutputQT3D(const char* filename);
int fsOutputQT3D(const char* filename);
int fOutputQT2D(const char* filename);
int fsOutputQT2D(const char* filename);
